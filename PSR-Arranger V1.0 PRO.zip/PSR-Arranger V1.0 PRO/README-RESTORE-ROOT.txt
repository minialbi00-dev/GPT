ENSEMBLES V20 - ROOT LAYOUT FIX

This archive has been repacked so the project root is the archive root.
After extracting, these paths must exist directly in the extracted folder:
  CMakeLists.txt
  src\main_qt.cpp
  vcpkg.json

Also present:
  external\NativeTS\CMakeLists.txt
  external\NativeTS\src\CMakeLists.txt

Run V20.0-Apply-Build-Run.bat from this extracted folder.
Do not run a launcher BAT from a different folder.

The BAT configures/builds with the local Windows Qt MSVC x64, Visual Studio
C++ tools, CMake, Ninja, and vcpkg installation. This archive repair fixes
project-root discovery; it does not install those external build tools.
