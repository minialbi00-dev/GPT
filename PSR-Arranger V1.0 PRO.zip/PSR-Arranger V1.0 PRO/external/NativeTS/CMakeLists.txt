cmake_minimum_required(VERSION 3.24)
project(NativeTabulaSonora VERSION 0.1.0 DESCRIPTION "Native C++20 implementation of the Roland Sound Canvas VA synth voice" LANGUAGES CXX)

include(GNUInstallDirs)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Offline embedded-library build bridge for Ensembles. The NativeTS source, headers,
# manifest assets, LICENSE and NOTICE are bundled in this folder; do not fetch GitHub.
option(TS_INSTALL "Generate NativeTS install/package rules" OFF)

add_library(ts_numeric_semantics INTERFACE)
add_library(ts::numeric_semantics ALIAS ts_numeric_semantics)
set_target_properties(ts_numeric_semantics PROPERTIES EXPORT_NAME numeric_semantics)
if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
  target_compile_options(ts_numeric_semantics INTERFACE -fwrapv -ffp-contract=off)
elseif(MSVC)
  target_compile_options(ts_numeric_semantics INTERFACE /fp:precise)
endif()

add_library(ts_warnings INTERFACE)
add_library(ts::warnings ALIAS ts_warnings)
if(CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
  target_compile_options(ts_warnings INTERFACE -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion -Wold-style-cast -Wdouble-promotion -Wnon-virtual-dtor)
elseif(MSVC)
  target_compile_options(ts_warnings INTERFACE /W4 /permissive-)
endif()

find_package(ZLIB QUIET)
add_subdirectory(src)
