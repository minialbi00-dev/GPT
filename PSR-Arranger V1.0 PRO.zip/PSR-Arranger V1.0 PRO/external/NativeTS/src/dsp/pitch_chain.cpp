#include "tabulasonora/pitch_chain.hpp"

#include "dsp/fixed.hpp"

#include <algorithm>
#include <cmath>

namespace ts {
namespace {

/// The key-follow scale lookup, giving a clean 0% to 100% ladder in steps of 10%.
constexpr std::array<int, 11> key_follow_scale{
    0, 3276, 6553, 9830, 13107, 16383, 19660, 22937, 26214, 29491, 32767};

} // namespace

// ---------------------------------------------------------------------------------------------
// PitchEnvelopeRunner
// ---------------------------------------------------------------------------------------------

PitchEnvelopeRunner::PitchEnvelopeRunner(const PitchEnvelope& envelope, bool ignore_note_off)
    : release_(envelope.release),
      release_rate_(PitchChain::segment_rate_word(envelope.release_ms)),
      ignore_note_off_(ignore_note_off),
      segment_start_(envelope.start),
      level_(envelope.start)
{
    targets_.assign(envelope.targets.begin(), envelope.targets.end());

    rates_.reserve(envelope.times.size());
    for (double milliseconds : envelope.times) {
        rates_.push_back(PitchChain::segment_rate_word(milliseconds));
    }
}

PitchEnvelopeRunner PitchEnvelopeRunner::constant(double level)
{
    PitchEnvelopeRunner runner;
    runner.segment_start_ = level;
    runner.level_ = level;
    runner.segment_ = std::numeric_limits<int>::max();
    runner.ignore_note_off_ = true;
    return runner;
}

void PitchEnvelopeRunner::set_release_damper(int damper) noexcept
{
    release_damper_ = std::clamp(damper, 0, 0x3F);
}

int PitchEnvelopeRunner::scaled_release_rate() const noexcept
{
    if (release_damper_ == 0) {
        return release_rate_;
    }

    // 33279 * 65535 is about 2.18e9, past INT32_MAX, so this wraps by design.
    return fx::wmul(0xFFFF - (release_damper_ << 9), release_rate_) >> 16;
}

double PitchEnvelopeRunner::tick(bool released) noexcept
{
    double target = 0.0;
    int rate = 0;

    if (released && !released_ && !ignore_note_off_) {
        released_ = true;
        segment_start_ = level_;
        segment_ = -1;
        phase_ = 0;
        target = release_;
        rate = scaled_release_rate();
    } else if (segment_ < 0) {
        target = release_;
        rate = scaled_release_rate();
    } else if (static_cast<std::size_t>(segment_) < rates_.size()) {
        target = targets_[static_cast<std::size_t>(segment_)];
        rate = rates_[static_cast<std::size_t>(segment_)];
    } else {
        return level_;
    }

    phase_ += rate;
    if (phase_ >= 0xFFFF) {
        // Reaches 0xffff, not exceeds it, and the next segment starts with a fresh phase rather
        // than carrying the remainder -- which is why this has to be stepped, not evaluated.
        level_ = target;
        segment_start_ = target;
        phase_ = 0;
        if (segment_ >= 0) {
            ++segment_;
        }
    } else {
        level_ = segment_start_ + ((target - segment_start_) * (phase_ / 65536.0));
    }

    return level_;
}

// ---------------------------------------------------------------------------------------------
// PitchChain
// ---------------------------------------------------------------------------------------------

PitchChain::PitchChain(const TableSet& tables, const EnvelopeMachine& envelope, EngineNoise* noise)
    : envelope_(&envelope),
      noise_(noise),
      portamento_step_(tables.portamento_step()),
      pitch_bias_(tables.pitch_bias()),
      depth_velocity_sensitivity_(tables.pitch_depth_vs()),
      rate_key_follow0_(tables.kf_pitch_rate0()),
      rate_key_follow1_(tables.kf_pitch_rate1()),
      key_follow_(tables.kf_pitch()),
      rate_curve_(tables.rate_curve())
{
    if (noise_ == nullptr) {
        noise_ = &owned_noise_;
    }

    const auto pitch_env = tables.pitch_env();
    for (std::size_t i = 0; i < depth_slope_.size(); ++i) {
        depth_slope_[i] = fx::read_i16le(pitch_env.data() + (i * 2));
    }
}

PitchChain::KeyFollow
PitchChain::key_follow_key(const PartialParameters& partial, int note, int key_center) noexcept
{
    const auto raw = partial.raw();
    const int transpose = raw[0x10] - 0x40;
    const int amount = raw[0x13] - 0x40;

    // **The pivot is middle C, not the partial's key centre.** `multisample_key_zone @ 1800031f0`
    // holds it in one variable, and on the path every reachable tone takes, that variable is set by
    // a literal `uVar6 = 0x3c`. The same variable is what the interpolated step is added back to,
    // so it fixes both the distance measured and the key returned.
    //
    // This port used `key_center` -- the partial block's `+0x04` -- for both. The error that makes
    // is `(key_centre - 60) * 100 * (10 - amount)` milli-semitones, and it vanishes at full follow,
    // which is why it hid: 2,645 of the 3,438 present partials carry `amount == 10` and never
    // notice. On the 772 that do not it is worth up to 3.6 semitones. `Bubble` at bank 5 program
    // 122 measured 3598 milli-semitones sharp on its first partial and 3195 on its second, against
    // a predicted `(64-60) * 100 * (10-1)` = 3600 and `(64-60) * 100 * (10-2)` = 3200.
    //
    // Every partial in the table has key centre 64, so no measurement could have separated a pivot
    // of 60 from one of 64 with a constant offset. Only the listing settles it.
    //
    // The key centre is not unused, but it belongs to a path this port does not take:
    // `multisample_key_zone`'s B-table branch offsets the *note* by `block[0x10] - block[0x04]`
    // before looking up a zone. It is never the pivot.
    constexpr int pivot = 0x3C;
    (void)key_center;

    if (amount == 10) {
        // `bVar9 == 0x4a` falls straight through to returning the key untouched.
        return KeyFollow{note + transpose, 0};
    }
    if (amount == 0) {
        // `bVar9 == 0x40` pins the key at the pivot. The module spells it as two cases -- key 60
        // weight 0 at or above the pivot, key 59 weight 1000 below it -- which are the same pitch.
        return KeyFollow{pivot + transpose, 0};
    }

    // A negative amount is *inverted* follow rather than full follow: the module runs the same
    // interpolation with the magnitude indexing the table and the sign flipping which way the step
    // goes. No partial in the table has one -- `block[0x13]` spans 0x40 to 0x4f -- so this is
    // reachable only by a corrupt tone, but reading it as full follow was wrong.
    const int magnitude = std::abs(amount);
    const bool inverted = amount < 0;

    const int distance = note - pivot;
    const int product = key_follow_scale[static_cast<std::size_t>(std::min(magnitude, 10))]
                        * (std::abs(distance) * 2);
    const int high = product >> 16;
    const int low = product & 0xFFFF;

    // Which side of the pivot the step falls on, with a negative amount reflecting it.
    const bool ascending = (distance >= 0) != inverted;

    int weight = 0;
    int key_step = 0;
    if (low < 65000) {
        const int scaled = (low * 999) / 65000;
        if (ascending) {
            weight = scaled;
            key_step = high;
        } else {
            weight = 1000 - scaled;
            key_step = ~high;
        }
    } else {
        weight = 0;
        key_step = ascending ? high + 1 : ~high;
    }

    return KeyFollow{pivot + key_step + transpose, weight};
}

int PitchChain::base_pitch_milli_semitones(const PartialParameters& partial,
                                           int note,
                                           int key_center) const noexcept
{
    const auto raw = partial.raw();
    const KeyFollow follow = key_follow_key(partial, note, key_center);
    const int key = std::clamp(follow.key, 0, 0x7F);

    // The row comes from the **tone header's +0x17**, and reading it from the partial block at the
    // same index is what kept this on row 2. `partial_compute_pitch @ 18005fc20` takes the row from
    // the voice's +0x168, and the write at the decompile's line 1608 sources that from
    // `*(voice+0x150) + 0x17` -- and `voice+0x150` is the tone record, not the block that starts
    // 0x24 bytes into it. Dumping the whole structure through the module settles it: it opens with
    // twelve bytes of ASCII name, and +0x0c is the master level `Tone::level` already reads.
    //
    // Row 2 is the fallback, taken when the voice's +0x169 -- the part's +0x10 -- is zero. That
    // byte measures 1 on a part at its defaults, so the fallback is the rare path rather than the
    // usual one, and the header byte decides. Zero there means no curve at all.
    //
    // The earlier reasoning against this was sound given what it could see: block +0x17 is zero on
    // 3,900 of 4,096 blocks, so honouring it would have left almost every partial with no curve,
    // and row 2 scored 225 exact of 550 cases against no-curve's 16. Reading the *header* byte
    // instead gives 1 for Piano 1, 2 for most of the library and 0 for a few -- so the library
    // mostly stays where it was, and the tones that move, move onto the row the module measures.
    // Piano 1 is the case that exposed it: rows 1 and 2 differ by exactly the pitch error seen
    // against the module at every key, growing 85, 93, 101, 109 across keys 100 to 103.
    //
    // `g_kf_pitch` is four rows of 128, not eight — `g_kf_pitchrate0` begins where a fifth would.
    const int row = partial.pitch_curve_row();
    const int curve = [&]() -> int {
        if (row == PartialParameters::no_curve_row) {
            // A partial built without its header -- only the tests do this -- keeps the old row.
            return key_follow_[static_cast<std::size_t>((2 * 0x80) + key)];
        }
        if (row <= 0 || row >= key_follow_rows) {
            return 0;
        }
        return key_follow_[static_cast<std::size_t>((row * 0x80) + key)];
    }();
    return (key * 1000) + follow.weight + curve + ((raw[0x11] - 0x40) * 10);
}

int PitchChain::drum_pitch_milli_semitones(const PartialParameters& partial,
                                           int coarse_pitch) noexcept
{
    const KeyFollow follow = key_follow_key(partial, coarse_pitch, drum_key_centre);
    const int key = std::clamp(follow.key, 0, 0x7F);
    return (key * 1000) + follow.weight + ((partial.raw()[0x11] - 0x40) * 10);
}

int PitchChain::portamento_step(int time) const noexcept
{
    return portamento_step_[static_cast<std::size_t>(std::clamp(time, 0, 0x7F))];
}

int PitchChain::portamento_offset(int from_key, int target_pitch) noexcept
{
    return (std::clamp(from_key, 0, 0x7F) * 1000) - target_pitch;
}

double PitchChain::bend_offset_milli_semitones(int bend, double semitone_range) noexcept
{
    return (bend - 8192) / 8192.0 * semitone_range * 1000.0;
}

int PitchChain::base_pitch_jitter_milli_semitones(const PartialParameters& partial) const
{
    // `partial_compute_pitch @ 18005fc20` reads the depth from the byte immediately after the
    // coarse tune it has just applied, and takes the draw only when that byte is non-zero -- the
    // conditional is the whole point, since an unaffected patch must leave the shared generator
    // where it found it.
    const int depth = partial.raw()[0x12];
    if (depth == 0) {
        return 0;
    }
    return start_jitter_milli_semitones(depth, noise_->next());
}

std::optional<PitchEnvelope>
PitchChain::envelope_offsets(const PartialParameters& partial, int key, int velocity) const noexcept
{
    const auto raw = partial.raw();
    const int depth = raw[0x18] | (raw[0x19] << 8);
    if (depth == 0) {
        return std::nullopt;
    }

    int sensitivity = raw[0x2B] - 0x40;
    int scaled_depth = 0;
    if (sensitivity == 0) {
        scaled_depth = depth;
    } else {
        int v = std::clamp(velocity, 0, 127);
        if (sensitivity < 0) {
            sensitivity = -sensitivity;
            v = (-v) & 0x7F;
        }

        // The slope reaches +-32767, v 127 and depth 0xffff, so the product runs to about 2.7e11
        // and the engine keeps only the low word. Widening this to 64 bits changes the depth.
        const int inner =
            fx::wadd(fx::wmul(depth_slope_[static_cast<std::size_t>(sensitivity)], v),
                     depth_velocity_sensitivity_[static_cast<std::size_t>(sensitivity)]);
        scaled_depth = fx::wadd(fx::wmul(inner, depth), 0x8000) >> 16;
    }

    const auto delta = [&](int bias) {
        if (bias == 0) {
            return 0;
        }
        const int d =
            (pitch_bias_[static_cast<std::size_t>(std::min(64, std::abs(bias)))] * scaled_depth)
            >> 7;
        return bias < 0 ? -d : d;
    };

    std::array<int, 5> biases{};
    for (std::size_t i = 0; i < biases.size(); ++i) {
        biases[i] = fx::i8(raw[0x1B + i]) - 0x40;
    }

    const int main_rate = envelope_->rate_scale(
        (rate_key_follow0_[static_cast<std::size_t>((raw[0x27] * 0x80) + (key & 0x7F))] - 0x80)
            & 0xFF,
        raw[0x29]);
    const int release_rate = envelope_->rate_scale(
        (rate_key_follow1_[static_cast<std::size_t>((raw[0x27] * 0x80) + (key & 0x7F))] - 0x80)
            & 0xFF,
        raw[0x2A]);
    const int velocity_scale = envelope_->level_scale(std::clamp(velocity, 0, 127), raw[0x2C]);

    const auto time = [&](int rate_byte, int rate_multiplier) -> double {
        const int r = rate_byte & 0x7F;
        const int ticks = rate_curve_[static_cast<std::size_t>(r)];
        if (r == 0 || ticks < EnvelopeMachine::minimum_segment_ticks) {
            return 0.0;
        }
        // Both multipliers reach 0xffff, so the product overflows and the mask takes the low word.
        return fx::wmul((fx::wmul(rate_multiplier, ticks) >> 8) & 0xFFFF, velocity_scale) >> 8;
    };

    PitchEnvelope envelope;
    envelope.start = delta(biases[0]);
    // The fourth target is always zero: the envelope returns to the base pitch.
    envelope.targets = {delta(biases[1]), delta(biases[2]), delta(biases[3]), 0};
    envelope.release = delta(biases[4]);
    for (std::size_t i = 0; i < envelope.times.size(); ++i) {
        envelope.times[i] = time(raw[0x20 + i], main_rate);
    }
    envelope.release_ms = time(raw[0x24], release_rate);
    return envelope;
}

int PitchChain::segment_rate_word(double milliseconds) noexcept
{
    return milliseconds < 11 ? 0xFFFF : std::min(0xFFFF, 0xA0000 / static_cast<int>(milliseconds));
}

std::optional<std::vector<double>> PitchChain::envelope_ticks(const PartialParameters& partial,
                                                              int key,
                                                              int velocity,
                                                              double hold_seconds,
                                                              int tick_count) const
{
    std::optional<PitchEnvelopeRunner> runner = create_envelope_runner(partial, key, velocity);
    if (!runner) {
        return std::nullopt;
    }

    std::vector<double> output(static_cast<std::size_t>(std::max(0, tick_count)));
    const auto note_off_tick = static_cast<int>(hold_seconds * 100);

    for (std::size_t i = 0; i < output.size(); ++i) {
        output[i] = runner->tick(static_cast<int>(i) >= note_off_tick);
    }

    return output;
}

int PitchChain::start_jitter_milli_semitones(int depth, std::uint16_t draw) noexcept
{
    // Bit 14 picks the sign, and the magnitude slice is asymmetric: 7 bits positive, 8 negative.
    // The rounding term is added before the shift, not after -- parenthesised because that is the
    // precedence C# gives it too, and the two must not drift.
    //
    // The sign test is spelled as the bit it tests rather than as the C# original's
    // `(short)(draw << 1) >= 0`, and that is not a tidy-up. The two are the same predicate --
    // shifting left by one puts bit 14 into a signed 16-bit sign position -- but **MSVC
    // miscompiles the cast form under optimisation**. At `/O2` it takes the positive branch for
    // every draw below 0x8000, which is bit *15*, so half the negative range is unreachable and
    // the positive range doubles: swept over all 65536 draws at depth 10 the reachable range came
    // out [-100, +100] where it should be [-50, +50]. The same binary built at `/Od` is correct,
    // as is GCC at any level, and `fx::i16` evaluated into a variable one line away is correct
    // even in the miscompiled build -- it is only wrong when it feeds this branch directly.
    // Renders therefore differed by platform on any patch with a non-zero pitch-envelope jitter
    // byte. Testing the bit says the same thing with nothing left to optimise wrongly.
    if ((draw & 0x4000) == 0) {
        return (((((draw & 0x7FFF) >> 7) * depth) + 0x80) >> 8) * 10;
    }
    return ((((static_cast<std::uint16_t>(draw * -2) >> 8) * depth) + 0x80) >> 8) * -10;
}

std::optional<PitchEnvelopeRunner>
PitchChain::create_envelope_runner(const PartialParameters& partial, int key, int velocity) const
{
    const auto raw = partial.raw();

    // **This byte is right, and the case for replacing it with +0x12 was a false choice.** The two
    // are different features that happen to share `start_jitter_milli_semitones`, and the module
    // reads both: `pitch_env_apply_stage @ 1800600c0` tests **+0x1a** and adds its result to the
    // pitch envelope's start level, which is this call; `partial_compute_pitch @ 18005fc20` tests
    // **+0x12** and moves the base pitch, which is
    // `PitchChain::base_pitch_jitter_milli_semitones`. That +0x12 is non-zero on 223 of the 4,726
    // partial blocks and +0x1a on nineteen is not evidence for one over the other -- it is two
    // features used at different rates.
    //
    // Switching this byte to +0x12 used to make the song gate worse, and the reason is now plain:
    // it moved the draw rather than adding the one that was missing, so a patch with a non-zero
    // +0x12 drew in the wrong place *and* the +0x1a patches stopped drawing at all. Both are
    // present now, in the module's own order -- base pitch first, envelope start second.
    const int jitter_depth = raw[0x1A];

    // One draw per partial voice, and only when the byte is non-zero -- the engine skips the draw
    // entirely otherwise, so an unaffected patch must not consume from the shared generator.
    // `partial_compute_pitch_env` calls the stage unconditionally, so the *call* is not what is
    // conditional here; the draw inside it is.
    const int jitter =
        jitter_depth != 0 ? start_jitter_milli_semitones(jitter_depth, noise_->next()) : 0;
    const bool one_shot = (raw[0x00] & 0x80) != 0;

    std::optional<PitchEnvelope> envelope = envelope_offsets(partial, key, velocity);
    if (!envelope) {
        return jitter == 0 ? std::nullopt : std::optional{PitchEnvelopeRunner::constant(jitter)};
    }

    if (jitter != 0) {
        envelope->start += jitter;
    }

    const bool flat = envelope->start == 0 && envelope->release == 0
                      && std::all_of(envelope->targets.begin(), envelope->targets.end(), [](int t) {
                             return t == 0;
                         });

    return flat ? std::nullopt : std::optional{PitchEnvelopeRunner{*envelope, one_shot}};
}

double PitchChain::ratio(const PartialParameters& /*partial*/,
                         const WaveDescriptor& descriptor,
                         double pitch_milli_semitones) noexcept
{
    const double native = descriptor.native_milli_semitones();
    return std::pow(2.0, (pitch_milli_semitones - native) / 12000.0);
}

double PitchChain::clamp(double milli_semitones) noexcept
{
    return std::clamp(milli_semitones, 0.0, static_cast<double>(max_pitch_milli_semitones));
}

} // namespace ts
