# NativeTS library sources, kept aligned with the upstream library source list.
include(${PROJECT_SOURCE_DIR}/cmake/EmbedAsset.cmake)

find_package(nlohmann_json CONFIG REQUIRED)
find_package(PkgConfig QUIET)
if(PkgConfig_FOUND)
  pkg_check_modules(TS_FLAC IMPORTED_TARGET flac)
  pkg_check_modules(TS_VORBIS IMPORTED_TARGET vorbisenc vorbis ogg)
endif()

ts_embed_asset(TS_MANIFEST_SOURCE "${PROJECT_SOURCE_DIR}/assets/manifest.json" manifest_json)
ts_embed_asset(TS_BUILDS_SOURCE "${PROJECT_SOURCE_DIR}/assets/builds.json" builds_json)

add_library(tabulasonora
  dsp/envelope_machine.cpp
  dsp/interpolator.cpp
  dsp/lfo_engine.cpp
  dsp/pitch_chain.cpp
  dsp/segment_envelope.cpp
  dsp/tva_chain.cpp
  dsp/tvf_chain.cpp
  effects/effect_presets.cpp
  effects/effect_programmer.cpp
  effects/equalizer.cpp
  effects/insertion_effect.cpp
  effects/send_effects.cpp
  midi/control_decode.cpp
  midi/midi_formats.cpp
  midi/sequence.cpp
  midi/smf_reader.cpp
  patches/drum_kit_table.cpp
  patches/partial_parameters.cpp
  patches/patch_directory.cpp
  patches/tone.cpp
  dsp/sampler.cpp
  rom/build_registry.cpp
  rom/rom_image.cpp
  rom/rom_locator.cpp
  rom/table_set.cpp
  rom/wave_rom.cpp
  rom/sha256.cpp
  rom/table_manifest.cpp
  soundfont/bank_builder.cpp
  soundfont/encoders.cpp
  soundfont/envelope_fit.cpp
  soundfont/modulators.cpp
  soundfont/sample_set.cpp
  soundfont/sflist.cpp
  soundfont/writer.cpp
  voices/voice_pool.cpp
  realtime/frame_ring.cpp
  realtime/part.cpp
  realtime/partial_voice.cpp
  realtime/sequence_player.cpp
  realtime/tone_generator.cpp
  realtime/wave_reader.cpp
  render/note_renderer.cpp
  render/render_options.cpp
  render/wav_writer.cpp
  ${TS_MANIFEST_SOURCE}
  ${TS_BUILDS_SOURCE}
)
add_library(ts::tabulasonora ALIAS tabulasonora)
set_target_properties(tabulasonora PROPERTIES
  VERSION ${PROJECT_VERSION}
  SOVERSION ${PROJECT_VERSION_MAJOR}
  POSITION_INDEPENDENT_CODE ON
  WINDOWS_EXPORT_ALL_SYMBOLS ON)
target_compile_features(tabulasonora PUBLIC cxx_std_20)
target_include_directories(tabulasonora
  PUBLIC
    $<BUILD_INTERFACE:${PROJECT_SOURCE_DIR}/include>
    $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
  PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(tabulasonora
  PUBLIC ts::numeric_semantics
  PRIVATE $<BUILD_INTERFACE:ts::warnings> $<BUILD_INTERFACE:nlohmann_json::nlohmann_json>)
if(ZLIB_FOUND)
  target_compile_definitions(tabulasonora PRIVATE TS_HAVE_ZLIB)
  target_link_libraries(tabulasonora PRIVATE ZLIB::ZLIB)
endif()
if(TS_FLAC_FOUND)
  target_compile_definitions(tabulasonora PRIVATE TS_HAVE_FLAC)
  target_link_libraries(tabulasonora PRIVATE PkgConfig::TS_FLAC)
endif()
if(TS_VORBIS_FOUND)
  target_compile_definitions(tabulasonora PRIVATE TS_HAVE_VORBIS)
  target_link_libraries(tabulasonora PRIVATE PkgConfig::TS_VORBIS)
endif()
set_source_files_properties(${TS_MANIFEST_SOURCE} ${TS_BUILDS_SOURCE}
  PROPERTIES COMPILE_OPTIONS "$<IF:$<CXX_COMPILER_ID:MSVC>,/w,-w>")
