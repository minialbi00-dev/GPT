#pragma once

#include "tabulasonora/engine_noise.hpp"
#include "tabulasonora/part_modifiers.hpp"
#include "tabulasonora/partial_parameters.hpp"
#include "tabulasonora/table_set.hpp"

#include <cstdint>
#include <span>
#include <utility>
#include <vector>

namespace ts {

/// Which parameter an LFO's depth applies to.
enum class LfoDestination {
    /// Pitch, in milli-semitones.
    pitch,
    /// Filter cutoff, in the same units as the runtime cutoff.
    tvf,
    /// Amplitude, as a fraction of 0x7f00 applied multiplicatively.
    tva,
};

/// One LFO's static configuration.
struct LfoConfig {
    /// Waveform index, after the selector nibble is mapped.
    int waveform = 0;
    /// Starting phase, from the top two bits of the waveform byte.
    int initial_phase = 0;
    /// Phase increment per control tick.
    int increment = 0;
    /// Per-tick increment of the delay accumulator; zero means never start.
    int delay_rate = 0;
    /// Per-tick increment of the fade-in accumulator.
    int fade_rate = 0;
    /// Depth applied to pitch, in milli-semitones.
    int pitch_depth = 0;
    /// Depth applied to the filter cutoff.
    int tvf_depth = 0;
    /// Depth applied to amplitude.
    int tva_depth = 0;

    /// Bit 5 of the waveform byte: whether this LFO's node may inherit from a standing one.
    ///
    /// `partial_alloc_node @ 1800029e0` keeps a descriptor per part with one slot for LFO1
    /// (`+0x20`) and one per partial index for LFO2 (`+0x28 + i*8`). When the bit is set and the
    /// slot already holds a node, the new node's `+0xa0` points at it, and `note_on_voice_setup
    /// @ 18005f5c0` copies phase, out, held and slewed across instead of initialising them -- and
    /// takes no `prng_lfsr` draw. Bit clear, or slot empty, and the node is parentless and draws.
    ///
    /// The slot outlives the voice. Measured with `scdec lfonodes`: three notes two seconds apart,
    /// each released almost immediately, and notes 2 and 3 still inherit -- the held register stays
    /// at 20373, the generator's first draw, and the phase runs 3146 -> 45668 -> 22654 rather than
    /// restarting. Only `part_voice_desc_reset @ 1800010a0` empties it, and that is reached solely
    /// from `part_program_change @ 180068fe0` and `drum_part_program_change @ 180068e60`.
    bool shares_node = false;

    /// The depth for one destination.
    [[nodiscard]] constexpr int depth(LfoDestination destination) const noexcept
    {
        switch (destination) {
        case LfoDestination::pitch:
            return pitch_depth;
        case LfoDestination::tvf:
            return tvf_depth;
        case LfoDestination::tva:
            break;
        }
        return tva_depth;
    }
};

class LfoRunner;

/// The two LFO engines that modulate every partial.
///
/// A partial is modulated by both. LFO1 is tone-common, with its parameters in the tone header and
/// its per-partial depths in the partial block; LFO2 is per-partial throughout. The asymmetry that
/// matters is in how their rate and delay fields are read: LFO1's are *indices* into lookup tables,
/// while LFO2's are used raw as per-tick increments. Verified live — LFO1 rate 43 gives increment
/// 2817, LFO2 rate 917 gives 917.
///
/// Pitch depth is in *milli-semitones*, not cents. The pitch accumulator clamps at 0x1f018, which
/// is 127 x 1000, and that is what fixes the unit.
///
/// Waveform selectors 1, 2 and 3 are the random shapes. They are **not** functions of the phase the
/// way every other shape is — they redraw when the phase *wraps* and hold or walk toward that draw
/// in between — so they live in ts::LfoRunner rather than in `waveform` below, which asks only
/// where in the cycle the LFO is and cannot express them.
class LfoEngine {
public:
    /// Scale that maps a raw waveform value to [-1, 1].
    static constexpr double waveform_scale = 32640.0;

    /// Whether a waveform is one of the three random shapes, which the runner drives.
    [[nodiscard]] static constexpr bool is_random(int waveform) noexcept
    {
        return waveform >= 1 && waveform <= 3;
    }

    /// How far a slewed random shape moves toward its target in one control tick.
    static constexpr int slew_step = 0x50;

    /// Depth clamp and rounding constant for a destination.
    ///
    /// Amplitude rounds by ceiling while pitch and filter round to nearest. Only the constant
    /// differs; the sign-magnitude multiply is otherwise identical.
    struct Limits {
        int clamp = 0;
        int rounding = 0;
    };

    [[nodiscard]] static constexpr Limits destination_limits(LfoDestination destination) noexcept
    {
        switch (destination) {
        case LfoDestination::tva:
            return Limits{0x7F00, 0xFFFF};
        case LfoDestination::tvf:
            return Limits{0x1800, 0x8000};
        case LfoDestination::pitch:
            break;
        }
        return Limits{6000, 0x8000};
    }

    /// Creates the engine over a loaded table set, which must outlive it.
    ///
    /// `noise` is the engine's shared generator, which the random shapes draw from; when null a
    /// private one is used. Sharing it is not a detail — the module has exactly one generator, and
    /// the LFO shapes, the pitch start jitter and the random pan all draw from it, so which voice
    /// draws when is part of what the sequence is.
    explicit LfoEngine(const TableSet& tables, EngineNoise* noise = nullptr);

    /// The generator the random shapes draw from.
    [[nodiscard]] EngineNoise& noise() const noexcept { return *noise_; }

    /// Evaluates a waveform at a 16-bit phase.
    ///
    /// The three random shapes are not evaluable this way and return zero here; ts::LfoRunner
    /// drives them, because what they depend on is the phase having wrapped rather than the phase.
    [[nodiscard]] int waveform(int phase, int waveform_index) const noexcept;

    /// Reads both LFO configurations for one partial: the tone-common LFO1 and the per-partial
    /// LFO2.
    ///
    /// `modifiers` applies the part's vibrato rate, depth and delay. They reach LFO1 alone — LFO2
    /// has no table indices for them to bias.
    [[nodiscard]] std::pair<LfoConfig, LfoConfig>
    configure(int tone_number,
              const PartialParameters& partial,
              const PartModifiers& modifiers = {}) const;

    /// Creates a runner that steps one LFO a control tick at a time.
    [[nodiscard]] LfoRunner create_runner(const LfoConfig& config) const;

    /// Creates runners for both of a partial's LFOs.
    [[nodiscard]] std::pair<LfoRunner, LfoRunner>
    create_runners(int tone_number,
                   const PartialParameters& partial,
                   const PartModifiers& modifiers = {}) const;

    /// Runs one LFO for a number of control ticks.
    [[nodiscard]] std::vector<double>
    run(const LfoConfig& config, int tick_count, LfoDestination destination) const;

    /// The combined LFO1 and LFO2 modulation for a partial, per control tick.
    ///
    /// The first tick is always zero: the LFO object is created after that tick's control update,
    /// so nothing has been applied yet. Aligning to that is what makes the comparison against the
    /// engine's own trace line up.
    [[nodiscard]] std::vector<double> modulation(int tone_number,
                                                 const PartialParameters& partial,
                                                 int tick_count,
                                                 LfoDestination destination) const;

    /// Combined pitch modulation with a per-tick mod-wheel depth folded into LFO1.
    ///
    /// The wheel's contribution is added *after* the fade-in, then the total is clamped to +-6000 —
    /// six semitones, the GS full-scale figure. Only LFO1 takes it; LFO2 is unaffected.
    [[nodiscard]] std::vector<double>
    pitch_modulation_with_wheel(int tone_number,
                                const PartialParameters& partial,
                                int tick_count,
                                std::span<const double> mod_depth_per_tick) const;

    /// The mod wheel's contribution to LFO1 pitch depth, in milli-semitones.
    ///
    /// Summed with the tone's own pitch depth after the cents table, and the total is then clamped
    /// to +-6000.
    [[nodiscard]] static int
    mod_wheel_depth(int controller, int depth = 0x0A, int offset = 0) noexcept;

private:
    [[nodiscard]] std::vector<double> run_pitch_with_wheel(
        const LfoConfig& config, int tick_count, std::span<const double> mod_depth_per_tick) const;

    std::span<const std::uint8_t> half_sine_;
    std::span<const std::uint16_t> rate_table_;
    std::span<const std::uint16_t> cents_table_;
    std::span<const std::uint16_t> delay_table_;
    std::span<const std::uint8_t> wave_map_;
    std::span<const std::int16_t> wave_bank_;
    std::span<const std::uint8_t> tone_;

    EngineNoise* noise_;
    EngineNoise owned_noise_;
};

/// One LFO's running state: phase, delay and fade-in accumulators, stepped a control tick at a
/// time.
///
/// All three destinations share one runner. The accumulators do not depend on which depth is being
/// applied, so stepping once and reading three values is the same trajectory as running the LFO
/// three times — and it is what the engine does, since a partial has one LFO object, not one per
/// destination.
///
/// `tick` advances; the value is read afterwards, so the first tick already carries a phase
/// increment.
class LfoRunner {
public:
    LfoRunner(const LfoEngine& engine, const LfoConfig& config)
        : engine_(&engine), config_(config), phase_(config.initial_phase & 0xFFFF)
    {
    }

    /// The configuration this runner steps.
    [[nodiscard]] const LfoConfig& config() const noexcept { return config_; }

    /// Whether the last tick ran an update at all, so the LFO has an output to give.
    ///
    /// This is **not** "the delay has elapsed" — the delay holds the fade-in at zero but does not
    /// stop the LFO being applied, since a matrix depth is summed past the fade. What turns it off
    /// is an increment of nothing, which is the one case the module skips outright.
    [[nodiscard]] bool is_applied() const noexcept { return applied_; }

    /// Advances one control tick.
    ///
    /// `rate_offset` is the control matrix's LFO rate destination, in the same per-tick increment
    /// units as the configured rate — the engine adds it to the rate straight out of the table (or,
    /// for LFO2, to the raw rate) and clamps the total to 0x28f6.
    ///
    /// A total of zero or less does not merely stop the phase: the engine skips the whole update,
    /// so the depths are not applied either and the LFO's last output is held rather than decaying.
    /// Deep enough negative rate modulation is therefore an off switch, which is why this shares
    /// its early return with a configured rate of zero.
    void tick(int rate_offset = 0) noexcept;

    /// Advances one control tick, but at most once per `stamp`.
    ///
    /// This is what makes a **shared** runner safe to drive from several voices. The module walks
    /// its LFO node list once per tick, not once per voice; a note's partials all point at the same
    /// LFO1 node, so whichever of them reaches a tick first must advance it and the rest must read
    /// what it produced. `stamp` is the voice's own sample position, which is the note's age and so
    /// is the same number on every partial of one note — an armed partial keeps counting samples
    /// while it waits, so a staggered envelope delay does not desynchronise it.
    ///
    /// The one case this does not reproduce is a note whose partials are *all* armed: the module
    /// advances the node anyway, and here nobody is running to advance it. No affected tone carries
    /// an envelope delay, so it has never mattered.
    void tick_at(std::int64_t stamp, int rate_offset = 0) noexcept
    {
        if (stamp == last_stamp_) {
            return;
        }
        last_stamp_ = stamp;
        tick(rate_offset);
    }

    /// The modulation for one destination, after the last tick.
    ///
    /// `matrix_depth` is the control matrix's depth destination for this LFO, in the destination's
    /// own units. It is summed *after* the fade-in — the fade scales the patch's depth, not the
    /// controller's — and the total is then clamped to the destination's limit. Those limits are
    /// exactly the matrix's own full-scale figures, so a matrix depth alone can reach the rail but
    /// never exceed it.
    [[nodiscard]] double value(LfoDestination destination, int matrix_depth = 0) const noexcept;

    /// The same, with the patch depth supplied rather than read from this runner's own config.
    ///
    /// A shared LFO1 node has one phase and one random register but **per-partial depths**: the
    /// module stores them in the node itself, three shorts per partial at `+0x7c + i*8`, read from
    /// `block[0x56]`, `block[0x34]/2` and `block[0x15]`. So the phase is the note's and the depth
    /// is the partial's, and this is where the two meet.
    [[nodiscard]] double value_at_depth(LfoDestination destination,
                                        int patch_depth,
                                        int matrix_depth = 0) const noexcept;

    /// Seeds the random shapes' held register from the shared generator.
    ///
    /// `note_on_voice_setup @ 18005f5c0` does this for **every** LFO node it initialises, whatever
    /// the waveform, right after writing the rate and delay: `+0x7a = prng_lfsr()`. So the draw is
    /// spent even on a triangle, and a sample-and-hold opens on a real value rather than at zero —
    /// which is the whole first cycle of the LFO, up to a quarter of a second on a slow one.
    ///
    /// Measured against the module on `Bubble`: its LFO1 reads 20373 at the first control tick with
    /// no wrap in sight, and 20373 is the first draw from the `0xEFA6`/`0x9C23` seeds. The four
    /// values it takes at the next four wraps are draws 4, 5, 6 and 7 — the two in between going to
    /// the note's two LFO2 nodes, which is what makes the count `partials + 1`.
    void seed_random() noexcept;

    /// The random shapes' held register — the value a sample-and-hold is currently outputting.
    [[nodiscard]] int random_hold() const noexcept { return held_; }

    /// Copies a held register in rather than drawing one.
    ///
    /// A second note arriving on a part in the same dispatch chunk does **not** pay the generator
    /// again: its LFO nodes come up carrying the first note's values. Measured on the module with
    /// two notes struck together on one channel — both LFO1 nodes read the same seed, and the first
    /// wrap resumes at draw 4, so only one note's worth of draws was spent. Two notes on *different*
    /// channels do pay twice, seeding at draws 1 and 4, which is why this is a per-part rule rather
    /// than a per-chunk one.
    void copy_random_hold(const LfoRunner& other) noexcept { held_ = other.held_; }

    /// Takes a standing node's running state, the way an inheriting node does.
    ///
    /// The `+0xa0 != 0` branch of `note_on_voice_setup` copies `+0x72` phase, `+0x70` out, `+0x7a`
    /// held and `+0x78` slewed from the parent. The delay and fade accumulators are *not* copied:
    /// that branch zeroes `+0x74`/`+0x76` exactly as the parentless one does, so a note re-runs its
    /// own delay and fade over an already-running phase.
    void adopt(const LfoRunner& parent) noexcept
    {
        phase_ = parent.phase_;
        output_ = parent.output_;
        held_ = parent.held_;
        slewed_ = parent.slewed_;
        delay_ = 0;
        fade_ = 0;
    }

    /// The pitch modulation with a mod-wheel depth folded in, in milli-semitones.
    ///
    /// The offline path's spelling of the same thing: the wheel reaches LFO1 pitch depth through
    /// the matrix, so this is `value(LfoDestination::pitch, ...)` with the wheel's contribution
    /// standing in for the whole matrix sum.
    [[nodiscard]] double pitch_value(double wheel_depth) const noexcept;

private:
    /// Evaluates the waveform for the tick just taken, into `output_`.
    void advance_waveform(bool wrapped) noexcept;

    [[nodiscard]] int faded(int depth) const noexcept;
    [[nodiscard]] double apply(int effective, int rounding) const noexcept;

    const LfoEngine* engine_;
    LfoConfig config_;

    int phase_ = 0;
    int delay_ = 0;
    int fade_ = 0;
    bool applied_ = false;

    /// The stamp of the last tick `tick_at` ran, so a shared runner advances once and not once per
    /// partial pointing at it.
    std::int64_t last_stamp_ = -1;

    /// The waveform value for the last tick — `g_lfo_out`.
    ///
    /// Kept rather than recomputed from the phase because the random shapes cannot be recomputed:
    /// a slewed one that has arrived at its target leaves this standing untouched, so the previous
    /// tick's value *is* this tick's answer. For every other shape it is the same number
    /// `LfoEngine::waveform` would return, evaluated at the tick that produced the phase.
    int output_ = 0;

    /// The random shapes' two registers: the value last drawn from the generator, and the value
    /// walking toward it. They are the module's `+0x7a` and `+0x78` on the shared LFO node.
    ///
    /// Both are written at note-on rather than inherited. `note_on_voice_setup @ 18005f5c0`
    /// initialises every node it claims — phase from the waveform byte's top two bits, out, delay
    /// and fade accumulators and the slewed register to zero, rate and delay from the tone — and
    /// then `+0x7a = prng_lfsr()`. See `seed_random`, which is that write.
    ///
    /// **An earlier reading of this had the offset wrong and the conclusion with it.** It named the
    /// held register `+0x77`, said the per-tick save-back was its only writer, and concluded that a
    /// recycled node opens on the previous note's values. Reading `lfo_advance_waveform`'s globals
    /// against the node layout puts out at `+0x70`, phase at `+0x72`, slewed at `+0x78` and held at
    /// `+0x7a`, and the trace agrees: on `Bubble` the module reads 20373 off a freshly claimed node
    /// at its first control tick, which is the generator's first draw and not a leftover.
    ///
    /// The one branch that *does* inherit is the part-level one, `+0xa0 != 0`, where phase, out,
    /// held and slewed are all copied from the parent node instead. That is the case bit 5 of the
    /// waveform byte selects, and this port does not implement it.
    int held_ = 0;
    int slewed_ = 0;
};

} // namespace ts
