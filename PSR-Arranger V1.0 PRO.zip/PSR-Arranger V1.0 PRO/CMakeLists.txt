cmake_minimum_required(VERSION 3.24)
project(psr_arranger VERSION 0.3.0 LANGUAGES CXX)

# Compile Qt .qrc files into the executable. Without AUTORCC, the source list can
# contain data/native_scva.qrc while no qrc object is generated, causing
# QFile(":/SCVA/SCCore.dll") to fail at runtime even though the DLL exists.
set(CMAKE_AUTORCC ON)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Qt6 6.0 REQUIRED COMPONENTS Widgets)
find_package(FluidSynth CONFIG REQUIRED)

# Use the CMake package exported by vcpkg. The RtAudio header is not
# guaranteed to live directly under the triplet's include directory, so avoid
# a bare find_path(RtAudio.h) that can fail after vcpkg installed the package.
find_package(RtAudio CONFIG REQUIRED)

# Native SCVA voice engine: NativeTS reads the embedded SCCore.dll as a data
# image and renders in-process C++ (it does not load SOUND Canvas VA.dll).
#
# Bootstrap NativeTS without FetchContent_Populate or codeload.github.com. NMake's nested
# populate stamp graph was fragile, and the user's network resets TLS to codeload. The helper
# resolves a GitHub commit via the API and fetches verified source files over raw.githubusercontent.com.
# A local source tree or ZIP remains available for offline/repeatable builds.
if(EXISTS "${CMAKE_SOURCE_DIR}/plugins/SCVA/SCCore.dll")
  set(ENSEMBLES_NATIVETS_SOURCE_DIR "" CACHE PATH
      "Path to an existing NativeTS source tree (optional; avoids downloading it)")
  set(ENSEMBLES_NATIVETS_ARCHIVE "" CACHE FILEPATH
      "Path to a previously downloaded NativeTS source ZIP (optional; supports offline builds)")

  set(nativetsarchive_SOURCE_DIR "")
  set(nativetsarchive_BINARY_DIR "${CMAKE_BINARY_DIR}/_native_scva_build")

  if(ENSEMBLES_NATIVETS_SOURCE_DIR)
    if(NOT EXISTS "${ENSEMBLES_NATIVETS_SOURCE_DIR}/CMakeLists.txt")
      message(FATAL_ERROR
        "ENSEMBLES_NATIVETS_SOURCE_DIR does not contain CMakeLists.txt: ${ENSEMBLES_NATIVETS_SOURCE_DIR}")
    endif()
    set(nativetsarchive_SOURCE_DIR "${ENSEMBLES_NATIVETS_SOURCE_DIR}")
  elseif(EXISTS "${CMAKE_SOURCE_DIR}/external/NativeTS/CMakeLists.txt")
    set(nativetsarchive_SOURCE_DIR "${CMAKE_SOURCE_DIR}/external/NativeTS")
  else()
    set(ENSEMBLES_NATIVETS_CACHE_DIR "${CMAKE_BINARY_DIR}/_native_scva_source")
    set(_nativets_archive "${ENSEMBLES_NATIVETS_CACHE_DIR}/NativeTS-main.zip")
    set(_nativets_source "${ENSEMBLES_NATIVETS_CACHE_DIR}/NativeTS-src")
    file(MAKE_DIRECTORY "${ENSEMBLES_NATIVETS_CACHE_DIR}")

    if(ENSEMBLES_NATIVETS_ARCHIVE)
      # A user-supplied source ZIP is an offline override. Verify it before extraction.
      if(NOT EXISTS "${ENSEMBLES_NATIVETS_ARCHIVE}")
        message(FATAL_ERROR "ENSEMBLES_NATIVETS_ARCHIVE does not exist: ${ENSEMBLES_NATIVETS_ARCHIVE}")
      endif()
      file(SIZE "${ENSEMBLES_NATIVETS_ARCHIVE}" _nativets_archive_size)
      file(READ "${ENSEMBLES_NATIVETS_ARCHIVE}" _nativets_archive_magic LIMIT 4 HEX)
      if(_nativets_archive_size LESS 10000 OR NOT _nativets_archive_magic MATCHES "^504b")
        message(FATAL_ERROR "ENSEMBLES_NATIVETS_ARCHIVE is not a valid ZIP (size=${_nativets_archive_size}, magic=${_nativets_archive_magic})")
      endif()
      set(_nativets_unpack "${ENSEMBLES_NATIVETS_CACHE_DIR}/user-archive-unpacked")
      file(REMOVE_RECURSE "${_nativets_unpack}" "${_nativets_source}")
      file(MAKE_DIRECTORY "${_nativets_unpack}")
      file(ARCHIVE_EXTRACT INPUT "${ENSEMBLES_NATIVETS_ARCHIVE}" DESTINATION "${_nativets_unpack}")
      file(GLOB _nativets_archive_roots LIST_DIRECTORIES TRUE "${_nativets_unpack}/*")
      foreach(_nativets_root IN LISTS _nativets_archive_roots)
        if(IS_DIRECTORY "${_nativets_root}" AND EXISTS "${_nativets_root}/CMakeLists.txt")
          file(RENAME "${_nativets_root}" "${_nativets_source}")
          break()
        endif()
      endforeach()
      if(NOT EXISTS "${_nativets_source}/CMakeLists.txt")
        message(FATAL_ERROR "NativeTS ZIP extracted but no top-level CMakeLists.txt was found: ${ENSEMBLES_NATIVETS_ARCHIVE}")
      endif()
    elseif(NOT EXISTS "${_nativets_source}/CMakeLists.txt" OR NOT EXISTS "${_nativets_source}/src/CMakeLists.txt")
      # Do not use GitHub's source-archive endpoint here: it redirects to codeload.github.com,
      # which can be reset by firewalls/proxies even when github.com itself is reachable.
      # The helper resolves a commit through api.github.com, downloads only build inputs from
      # raw.githubusercontent.com, and checks every file against the Git blob SHA from the API tree.
      find_package(Python3 COMPONENTS Interpreter QUIET)
      if(NOT Python3_Interpreter_FOUND)
        message(FATAL_ERROR
          "Python 3 is required to retrieve NativeTS without codeload.github.com. Install Python 3, "
          "or set ENSEMBLES_NATIVETS_SOURCE_DIR to a local NativeTS source tree, "
          "or ENSEMBLES_NATIVETS_ARCHIVE to a valid source ZIP.")
      endif()
      set(_nativets_fetch_script "${CMAKE_SOURCE_DIR}/tools/fetch_nativets_via_github_api.py")
      if(NOT EXISTS "${_nativets_fetch_script}")
        message(FATAL_ERROR "NativeTS raw-source fetch helper is missing: ${_nativets_fetch_script}")
      endif()
      message(STATUS "Fetching NativeTS source files via GitHub API/raw URLs (avoids codeload)...")
      execute_process(
        COMMAND "${Python3_EXECUTABLE}" "${_nativets_fetch_script}"
                --repo "TabulaSonora/NativeTS"
                --ref "main"
                --destination "${_nativets_source}"
        RESULT_VARIABLE _nativets_fetch_result
        OUTPUT_VARIABLE _nativets_fetch_stdout
        ERROR_VARIABLE _nativets_fetch_stderr
        TIMEOUT 600
      )
      if(NOT "${_nativets_fetch_result}" STREQUAL "0")
        message(FATAL_ERROR
          "Unable to fetch NativeTS from GitHub API/raw file endpoints (codeload is intentionally not used).\n"
          "Fetcher output:\n${_nativets_fetch_stdout}\n${_nativets_fetch_stderr}\n"
          "If your network also blocks api.github.com/raw.githubusercontent.com, download a ZIP on a network "
          "that permits it and pass -DENSEMBLES_NATIVETS_ARCHIVE=<path>, or set "
          "-DENSEMBLES_NATIVETS_SOURCE_DIR=<extracted-source-folder>.")
      endif()
      message(STATUS "${_nativets_fetch_stdout}")
    endif()

    if(NOT EXISTS "${_nativets_source}/CMakeLists.txt" OR NOT EXISTS "${_nativets_source}/src/CMakeLists.txt")
      message(FATAL_ERROR
        "NativeTS source tree is incomplete: ${_nativets_source}. Expected CMakeLists.txt and src/CMakeLists.txt.")
    endif()
    set(nativetsarchive_SOURCE_DIR "${_nativets_source}")
  endif()

  # NativeTS's upstream insertion-EFX decoder has fixed SCVA 1.1.6 data offsets.
  # This project embeds the known SCVA 1.1.2 2017 x64 SCCore.dll, so patch that one EFX
  # address profile before add_subdirectory() configures and compiles NativeTS. The patcher
  # keeps runtime pointers recovered from the actual DLL unshifted and validates every marker.
  find_package(Python3 COMPONENTS Interpreter QUIET)
  if(NOT Python3_Interpreter_FOUND)
    message(FATAL_ERROR "Python 3 is required to apply the verified SCVA 1.1.2 EFX offset profile.")
  endif()
  set(_nativets_efx_patch_script "${CMAKE_SOURCE_DIR}/tools/patch_native_scva112_efx_offsets.py")
  if(NOT EXISTS "${_nativets_efx_patch_script}")
    message(FATAL_ERROR "SCVA 1.1.2 EFX offset patcher is missing: ${_nativets_efx_patch_script}")
  endif()
  execute_process(
    COMMAND "${Python3_EXECUTABLE}" "${_nativets_efx_patch_script}"
            --nativets-dir "${nativetsarchive_SOURCE_DIR}"
    RESULT_VARIABLE _nativets_efx_patch_result
    OUTPUT_VARIABLE _nativets_efx_patch_stdout
    ERROR_VARIABLE _nativets_efx_patch_stderr
  )
  if(NOT "${_nativets_efx_patch_result}" STREQUAL "0")
    message(FATAL_ERROR
      "Could not apply the verified NativeTS EFX profile for SCVA 1.1.2.
"
      "${_nativets_efx_patch_stdout}
${_nativets_efx_patch_stderr}")
  endif()
  message(STATUS "${_nativets_efx_patch_stdout}")

  # Locate the build-profile generator in the packaged source. Keep the profile generation
  # before add_subdirectory(), because NativeTS generates its compiled manifest during configure.
  set(ENSEMBLES_SCVA112_PROFILE_SCRIPT "")
  foreach(ENSEMBLES_PROFILE_CANDIDATE
      "${CMAKE_SOURCE_DIR}/tools/generate_native_scva112_profile.py"
      "${CMAKE_SOURCE_DIR}/generate_native_scva112_profile.py"
      "${CMAKE_SOURCE_DIR}/scripts/generate_native_scva112_profile.py")
    if(EXISTS "${ENSEMBLES_PROFILE_CANDIDATE}")
      set(ENSEMBLES_SCVA112_PROFILE_SCRIPT "${ENSEMBLES_PROFILE_CANDIDATE}")
      break()
    endif()
  endforeach()

  if(ENSEMBLES_SCVA112_PROFILE_SCRIPT)
    find_package(Python3 COMPONENTS Interpreter QUIET)
    if(Python3_Interpreter_FOUND)
      execute_process(
        COMMAND "${Python3_EXECUTABLE}" "${ENSEMBLES_SCVA112_PROFILE_SCRIPT}"
                --dll "${CMAKE_SOURCE_DIR}/plugins/SCVA/SCCore.dll"
                --nativets-dir "${nativetsarchive_SOURCE_DIR}"
                --report "${CMAKE_SOURCE_DIR}/SCVA-1.1.2-NATIVE-PROFILE-REPORT.txt"
        RESULT_VARIABLE ENSEMBLES_SCVA112_PROFILE_RESULT
        OUTPUT_VARIABLE ENSEMBLES_SCVA112_PROFILE_STDOUT
        ERROR_VARIABLE ENSEMBLES_SCVA112_PROFILE_STDERR
      )
      if(ENSEMBLES_SCVA112_PROFILE_RESULT EQUAL 0)
        message(STATUS "${ENSEMBLES_SCVA112_PROFILE_STDOUT}")
      else()
        message(WARNING
          "NativeTS did not install a SCVA 1.1.2 profile; native playback is NOT validated.\n"
          "Generator: ${ENSEMBLES_SCVA112_PROFILE_SCRIPT}\n"
          "${ENSEMBLES_SCVA112_PROFILE_STDERR}")
      endif()
    else()
      message(WARNING
        "Python 3 was not found, so the SCVA 1.1.2 profile generator was not run.\n"
        "Native playback cannot be considered validated until the profile is generated.")
    endif()
  else()
    message(WARNING
      "SCVA 1.1.2 profile generator is missing from tools/, project root, and scripts/.\n"
      "Native playback cannot be considered validated until the profile is generated.")
  endif()

  add_subdirectory("${nativetsarchive_SOURCE_DIR}" "${nativetsarchive_BINARY_DIR}")
  set(ENSEMBLES_HAS_NATIVE_SCVA TRUE)
else()
  message(WARNING "SCVA SCCore.dll not found; native SCVA backend will not be compiled.")
  set(ENSEMBLES_HAS_NATIVE_SCVA FALSE)
endif()

# Stage the optional user-supplied portable SCVA VST2 folder beside the executable.
# The source ZIP contains only instructions; when the user adds their licensed SCVA
# files under plugins/SCVA, CMake copies the complete folder (including companion data).
if(EXISTS "${CMAKE_SOURCE_DIR}/plugins/SCVA")
  file(COPY "${CMAKE_SOURCE_DIR}/plugins/SCVA" DESTINATION "${CMAKE_BINARY_DIR}/plugins")
endif()

# Ship the original Ensembles .enstl style assets next to the application.
file(COPY "${CMAKE_SOURCE_DIR}/data/StyleFiles" DESTINATION "${CMAKE_BINARY_DIR}/data")

# Stage each real SoundFont while refusing to copy Git-LFS pointer text as an SF2.
# EnsemblesGM.sf2 is the target/original bank, but this source snapshot may contain
# only its 134-byte pointer. TimGM6mb.sf2 is a separately licensed GM fallback.
file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/data/SoundFonts")
file(GLOB ENSEMBLES_SOUNDFONT_FILES "${CMAKE_SOURCE_DIR}/data/SoundFonts/*.sf2")
foreach(ENSEMBLES_SOUNDFONT IN LISTS ENSEMBLES_SOUNDFONT_FILES)
  file(SIZE "${ENSEMBLES_SOUNDFONT}" ENSEMBLES_SOUNDFONT_SIZE)
  get_filename_component(ENSEMBLES_SOUNDFONT_NAME "${ENSEMBLES_SOUNDFONT}" NAME)
  if(ENSEMBLES_SOUNDFONT_SIZE GREATER 1048576)
    file(COPY "${ENSEMBLES_SOUNDFONT}" DESTINATION "${CMAKE_BINARY_DIR}/data/SoundFonts")
    message(STATUS "Bundling SoundFont: ${ENSEMBLES_SOUNDFONT_NAME} (${ENSEMBLES_SOUNDFONT_SIZE} bytes)")
  else()
    message(STATUS "Skipping ${ENSEMBLES_SOUNDFONT_NAME} (${ENSEMBLES_SOUNDFONT_SIZE} bytes): likely a Git-LFS pointer or non-SF2 placeholder")
  endif()
endforeach()
foreach(ENSEMBLES_SF_NOTICE LICENSE.txt GPL-2.txt THIRD_PARTY_NOTICE.txt COPYRIGHT.txt README.md EnsemblesGMSchema.csv)
  if(EXISTS "${CMAKE_SOURCE_DIR}/data/SoundFonts/${ENSEMBLES_SF_NOTICE}")
    file(COPY "${CMAKE_SOURCE_DIR}/data/SoundFonts/${ENSEMBLES_SF_NOTICE}" DESTINATION "${CMAKE_BINARY_DIR}/data/SoundFonts")
  endif()
endforeach()

# Stage images for portable launches. The legacy-reference copy is optional in some
# source exports; prefer it when present, then fall back to the shipped data/Images copy.
# A missing optional splash photo must never abort CMake configuration for the audio engine.
file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/data/Images")
if(EXISTS "${CMAKE_SOURCE_DIR}/data/Images/Instruments")
  file(COPY "${CMAKE_SOURCE_DIR}/data/Images/Instruments" DESTINATION "${CMAKE_BINARY_DIR}/data/Images")
endif()
set(ENSEMBLES_HOME_IMAGE_SOURCE "")
foreach(ENSEMBLES_HOME_IMAGE_CANDIDATE
    "${CMAKE_SOURCE_DIR}/legacy-reference/data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"
    "${CMAKE_SOURCE_DIR}/data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg")
  if(EXISTS "${ENSEMBLES_HOME_IMAGE_CANDIDATE}")
    set(ENSEMBLES_HOME_IMAGE_SOURCE "${ENSEMBLES_HOME_IMAGE_CANDIDATE}")
    break()
  endif()
endforeach()
if(ENSEMBLES_HOME_IMAGE_SOURCE)
  configure_file(
    "${ENSEMBLES_HOME_IMAGE_SOURCE}"
    "${CMAKE_BINARY_DIR}/data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"
    COPYONLY
  )
else()
  message(WARNING "Optional home-screen image was not found; continuing without staging it.")
endif()

set(ENSEMBLES_NATIVE_SCVA_SOURCES)
if(ENSEMBLES_HAS_NATIVE_SCVA)
  list(APPEND ENSEMBLES_NATIVE_SCVA_SOURCES
    src/native_scva_engine.cpp
    src/native_scva_engine.hpp
    data/native_scva.qrc
  )
endif()

qt_add_executable(psr-arranger
  src/main_qt.cpp
  src/audio_engine.cpp
  src/audio_engine.hpp
  src/sf2_effects_dsp.cpp
  src/sf2_effects_dsp.hpp
  src/yamaha_style_effects.hpp
  src/SoundFont/sf2_synth.cpp
  src/SoundFont/sf2_synth.hpp
  src/SoundFont/tsf.h
  src/SoundFont/sty_file.cpp
  src/SoundFont/sty_file.hpp
  src/SoundFont/style_player.cpp
  src/SoundFont/style_player.hpp
  src/xg_part_manager.cpp
  src/xg_part_manager.hpp
  src/xg2006le_bank_table.cpp
  src/xg2006le_bank_table.hpp
  src/syxg2006le_native_renderer.cpp
  src/syxg2006le_native_renderer.hpp
  src/syxg2006le_native_contract.hpp
  src/scva_startup_policy.hpp
  src/vst2_host.cpp
  src/vst2_host.hpp
  src/midi_file.cpp
  src/midi_file.hpp
  src/roland_stl.cpp
  src/yamaha_style_runtime.cpp
  src/yamaha_style_runtime.hpp
  src/yamaha_arranger_engine.cpp
  src/yamaha_arranger_engine.hpp
  src/style_engine.cpp
  src/style_engine.hpp
  src/chord_finder.cpp
  src/chord_finder.h
  src/chord_input_note_map.hpp
  src/midi_input_router.hpp
  ${ENSEMBLES_NATIVE_SCVA_SOURCES}
)
# Explicitly require AUTORCC for this target as a guard against toolchain-level
# overrides of the global CMAKE_AUTORCC setting.
set_property(TARGET psr-arranger PROPERTY AUTORCC ON)
# LS-GM translation units include headers as "SoundFont/<name>.hpp".
# Add src/ to the app target include search path (the test target already does this).
target_include_directories(psr-arranger PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
if(ENSEMBLES_HAS_NATIVE_SCVA)
  message(STATUS "Native SCVA: Qt resource data/native_scva.qrc will be compiled into psr-arranger")
endif()
target_link_libraries(psr-arranger PRIVATE Qt6::Widgets FluidSynth::libfluidsynth RtAudio::rtaudio ${CMAKE_DL_LIBS})
if(ENSEMBLES_HAS_NATIVE_SCVA)
  target_link_libraries(psr-arranger PRIVATE ts::tabulasonora)
  target_compile_definitions(psr-arranger PRIVATE ENSEMBLES_HAS_NATIVE_SCVA=1)
else()
  target_compile_definitions(psr-arranger PRIVATE ENSEMBLES_HAS_NATIVE_SCVA=0)
endif()
# Ship the native LS-GM SoundFont beside the application. The renderer loads
# it as SF2 data; no SoundFont DLL or external synthesizer is required.
add_custom_command(TARGET psr-arranger POST_BUILD
  COMMAND ${CMAKE_COMMAND} -E make_directory "$<TARGET_FILE_DIR:psr-arranger>/data/SoundFont"
  COMMAND ${CMAKE_COMMAND} -E copy_if_different
          "${CMAKE_SOURCE_DIR}/data/SoundFont/LS-GM.sf2"
          "$<TARGET_FILE_DIR:psr-arranger>/data/SoundFont/LS-GM.sf2"
  COMMAND ${CMAKE_COMMAND} -E make_directory "$<TARGET_FILE_DIR:psr-arranger>/data/StyleFiles"
  COMMAND ${CMAKE_COMMAND} -E copy_directory
          "${CMAKE_SOURCE_DIR}/data/StyleFiles"
          "$<TARGET_FILE_DIR:psr-arranger>/data/StyleFiles")

if(WIN32)
  set_target_properties(psr-arranger PROPERTIES WIN32_EXECUTABLE TRUE)
endif()
target_compile_definitions(psr-arranger PRIVATE ENSEMBLES_VERSION="${PROJECT_VERSION}")

if(WIN32)
  target_link_libraries(psr-arranger PRIVATE winmm)

  # Copy runtime DLLs from known CMake targets plus all vcpkg runtime DLLs.
  # The latter includes transitive FluidSynth dependencies not always exposed as
  # imported-target runtime locations on every vcpkg release.
  if(DEFINED VCPKG_INSTALLED_DIR AND DEFINED VCPKG_TARGET_TRIPLET)
    file(GLOB ENSEMBLES_VCPKG_RUNTIME_DLLS
      "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/bin/*.dll")
    if(ENSEMBLES_VCPKG_RUNTIME_DLLS)
      add_custom_command(TARGET psr-arranger POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
          ${ENSEMBLES_VCPKG_RUNTIME_DLLS} $<TARGET_FILE_DIR:psr-arranger>
        COMMAND_EXPAND_LISTS)
    endif()
  endif()
endif()

if(MSVC)
  target_compile_options(psr-arranger PRIVATE /W4 /permissive- /utf-8)
else()
  target_compile_options(psr-arranger PRIVATE -Wall -Wextra -Wpedantic)
endif()

include(CTest)
if(BUILD_TESTING)
  add_executable(chord-finder-genos-test
    tests/chord_finder_genos_test.cpp
    src/chord_finder.cpp
    src/chord_finder.h)
  target_include_directories(chord-finder-genos-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(chord-finder-genos-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(chord-finder-genos-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(chord-finder-genos-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME genos-chord-id-octave-and-slash-bass COMMAND chord-finder-genos-test)

  add_executable(chord-input-note-map-test tests/chord_input_note_map_test.cpp)
  target_include_directories(chord-input-note-map-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(chord-input-note-map-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(chord-input-note-map-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(chord-input-note-map-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME chord-input-note-press-time-transpose COMMAND chord-input-note-map-test)

  add_executable(sf2-drum-bank-resolver-test tests/sf2_drum_bank_resolver_test.cpp)
  target_include_directories(sf2-drum-bank-resolver-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(sf2-drum-bank-resolver-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(sf2-drum-bank-resolver-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(sf2-drum-bank-resolver-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME sf2-yamaha-rhythm-bank-resolution COMMAND sf2-drum-bank-resolver-test)

  add_executable(soundfont-external-bank-test
    tests/soundfont_external_bank_test.cpp
    src/SoundFont/sf2_synth.cpp
    src/SoundFont/sf2_synth.hpp
    src/SoundFont/tsf.h)
  target_include_directories(soundfont-external-bank-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(soundfont-external-bank-test PRIVATE cxx_std_20)
  if(MSVC)
    target_compile_options(soundfont-external-bank-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(soundfont-external-bank-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  if(DEFINED ENV{ENSEMBLES_EXTERNAL_SF2_TEST_PATH} AND NOT "$ENV{ENSEMBLES_EXTERNAL_SF2_TEST_PATH}" STREQUAL "")
    add_test(NAME external-sf2-load-and-render
      COMMAND soundfont-external-bank-test "$ENV{ENSEMBLES_EXTERNAL_SF2_TEST_PATH}")
  else()
    add_test(NAME external-sf2-load-and-render
      COMMAND soundfont-external-bank-test "${CMAKE_SOURCE_DIR}/data/SoundFont/LS-GM.sf2")
  endif()

  add_executable(soundfont-native-engine-test
    tests/soundfont_native_engine_test.cpp
    src/SoundFont/sf2_synth.cpp
    src/SoundFont/sf2_synth.hpp
    src/SoundFont/tsf.h)
  target_include_directories(soundfont-native-engine-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(soundfont-native-engine-test PRIVATE cxx_std_20)
  target_compile_definitions(soundfont-native-engine-test PRIVATE SOUNDFONT_SF2_PATH=\"${CMAKE_SOURCE_DIR}/data/SoundFont/LS-GM.sf2\")
  add_test(NAME soundfont-native-64-channel-renderer COMMAND soundfont-native-engine-test)

  add_executable(xg-part-manager-test
    tests/xg_part_manager_test.cpp
    src/xg_part_manager.cpp
    src/xg_part_manager.hpp)
  target_include_directories(xg-part-manager-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(xg-part-manager-test PRIVATE cxx_std_20)
  add_test(NAME xg-16-part-midi-state COMMAND xg-part-manager-test)

  add_executable(syxg2006le-native-renderer-test
    tests/syxg2006le_native_renderer_test.cpp
    src/xg_part_manager.cpp
    src/xg_part_manager.hpp
    src/xg2006le_bank_table.cpp
    src/xg2006le_bank_table.hpp
    src/syxg2006le_native_renderer.cpp
    src/syxg2006le_native_renderer.hpp
    src/syxg2006le_native_contract.hpp)
  target_include_directories(syxg2006le-native-renderer-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(syxg2006le-native-renderer-test PRIVATE cxx_std_20)
  if(MSVC)
    target_compile_options(syxg2006le-native-renderer-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(syxg2006le-native-renderer-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME syxg2006le-native-pcm-renderer COMMAND syxg2006le-native-renderer-test)

  # A small policy test guards the strict native-only startup switch independently of audio devices.
  add_executable(scva-native-startup-policy-test tests/scva_native_startup_policy_test.cpp)
  target_include_directories(scva-native-startup-policy-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(scva-native-startup-policy-test PRIVATE cxx_std_20)
  add_test(NAME scva-native-required-disables-vst2-fallback COMMAND scva-native-startup-policy-test)

  find_package(Python3 COMPONENTS Interpreter QUIET)
  if(Python3_Interpreter_FOUND)
    add_test(NAME scva-native-startup-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_startup_source_test.py")
    add_test(NAME scva-native-profile-generator-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_profile_generator_source_test.py")
    add_test(NAME scva-native-resource-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_resource_cmake_test.py")
    add_test(NAME scva-native-validation-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_validation_source_test.py")
    add_test(NAME v20-windows-build-optional-scva-target-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/windows_build_optional_scva_target_test.py")
    add_test(NAME scva-native-efx-profile-rom-layout
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_efx_profile_rom_test.py")
    add_test(NAME scva-native-voice-browser-efx-ui-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_scva_voice_efx_ui_test.py")
    add_test(NAME nativets-download-cmake-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/nativets_download_cmake_source_test.py")
    add_test(NAME nativets-api-raw-fetcher-unit-test
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/nativets_api_fetcher_unit_test.py")
    add_test(NAME roland-stl-ui-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/roland_stl_ui_source_test.py")
    add_test(NAME style-output-event-deadline-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/style_output_deadline_source_test.py")
    add_test(NAME acmp-runtime-trace-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/acmp_trace_instrumentation_test.py")
    add_test(NAME yamaha-style-picker-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/yamaha_style_picker_source_test.py")
    add_test(NAME native-style-renderer-routing-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/native_style_renderer_routing_source_test.py")
    add_test(NAME audio-output-diagnostic-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/audio_output_diagnostic_source_test.py")
    add_test(NAME style-stop-midi-queue-source-invariants
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/style_stop_midi_queue_source_test.py")
    add_test(NAME genos2-immediate-button-and-autofill-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/genos2_button_press_source_test.py")
    add_test(NAME external-sf2-selection-persistence-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/soundfont_external_path_source_test.py")
    add_test(NAME sf2-msb-lsb-program-change-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/sf2_bank_select_source_test.py")
    add_test(NAME yamaha-rhy1-fluidsynth-bank-routing-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/yamaha_rhy1_fluidsynth_routing_test.py")
    add_test(NAME soundfont-mmap-selective-adoption
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/soundfont_mmap_source_test.py")
    add_test(NAME genos-chord-id-slash-bass-integration-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/chord_finder_genos_integration_source_test.py")
    add_test(NAME mixer-led-graphite-teal-theme-source-guard
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/mixer_palette_theme_source_test.py")
  endif()

  # Hardware-independent integration test. It embeds the same qrc resource and calls the native
  # renderer directly, without linking or loading VST2 or FluidSynth into this test executable.
  if(ENSEMBLES_HAS_NATIVE_SCVA)
    qt_add_executable(native-scva-validation-test
      tests/native_scva_validation_test.cpp
      src/native_scva_engine.cpp
      src/native_scva_engine.hpp
      data/native_scva.qrc
    )
    set_property(TARGET native-scva-validation-test PROPERTY AUTORCC ON)
    target_include_directories(native-scva-validation-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
    target_compile_features(native-scva-validation-test PRIVATE cxx_std_20)
    target_link_libraries(native-scva-validation-test PRIVATE Qt6::Core ts::tabulasonora)
    if(MSVC)
      target_compile_options(native-scva-validation-test PRIVATE /W4 /permissive- /utf-8)
    else()
      target_compile_options(native-scva-validation-test PRIVATE -Wall -Wextra -Wpedantic)
    endif()
    set_target_properties(native-scva-validation-test PROPERTIES
      RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/tests")

    # Windows loads a process's dependent DLLs from the executable directory before
    # searching PATH. This test lives in build/tests, while windeployqt stages Qt DLLs
    # beside the main application in build/. Stage Qt6Core beside the test executable
    # and prepend the main deployment directory to this CTest process's PATH so Qt's
    # transitive runtime DLLs are discoverable as well. Without this, Windows can exit
    # before main() with STATUS_DLL_NOT_FOUND (0xC0000135), producing no test report.
    if(WIN32)
      add_custom_command(TARGET native-scva-validation-test POST_BUILD
        COMMAND "${CMAKE_COMMAND}" -E copy_if_different
          "$<TARGET_FILE:Qt6::Core>"
          "$<TARGET_FILE_DIR:native-scva-validation-test>"
        COMMENT "Staging Qt6Core.dll beside the Native SCVA validation executable"
        VERBATIM)
    endif()

    add_test(NAME scva-native-profile-midi-audio-effects
      COMMAND "$<TARGET_FILE:native-scva-validation-test>"
        --report "${CMAKE_BINARY_DIR}/tests/SCVA-Native-Validation-Report.txt"
        --output-wav "${CMAKE_BINARY_DIR}/tests/SCVA-Native-Validation.wav")
    set_tests_properties(scva-native-profile-midi-audio-effects PROPERTIES
      WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}" TIMEOUT 180 LABELS "native;scva;audio-render")
    if(WIN32)
      set_tests_properties(scva-native-profile-midi-audio-effects PROPERTIES
        ENVIRONMENT_MODIFICATION "PATH=path_list_prepend:$<TARGET_FILE_DIR:psr-arranger>")
    endif()
  endif()

  add_executable(midi-parser-test
    src/midi_file.cpp
    tests/midi_parser_test.cpp
  )
  target_compile_features(midi-parser-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(midi-parser-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(midi-parser-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  set_target_properties(midi-parser-test PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/tests")
  add_test(NAME midi-parser-roundtrip COMMAND midi-parser-test)
  set_tests_properties(midi-parser-roundtrip PROPERTIES WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}")

  add_executable(acmp-level-compensation-test tests/acmp_level_compensation_test.cpp)
  target_compile_features(acmp-level-compensation-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(acmp-level-compensation-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(acmp-level-compensation-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME sf2-style-acmp-level-compensation COMMAND acmp-level-compensation-test)

  add_executable(midi-input-router-test tests/midi_input_router_test.cpp)
  target_include_directories(midi-input-router-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(midi-input-router-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(midi-input-router-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(midi-input-router-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  set_target_properties(midi-input-router-test PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/tests")
  add_test(NAME winmm-midi-input-routing COMMAND midi-input-router-test)

  add_executable(style-engine-test
    src/midi_file.cpp
    src/roland_stl.cpp
    src/yamaha_style_runtime.cpp
    src/yamaha_arranger_engine.cpp
    src/style_engine.cpp
    src/chord_finder.cpp
    tests/style_engine_test.cpp
  )
  target_compile_features(style-engine-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(style-engine-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(style-engine-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME original-style-analysis-and-transposition COMMAND style-engine-test)
  set_tests_properties(original-style-analysis-and-transposition PROPERTIES WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}")

  # Parser/marker-conversion regression for legacy Roland G8/EV .STL styles.
  add_executable(roland-stl-reader-test
    src/midi_file.cpp
    src/roland_stl.cpp
    src/yamaha_style_runtime.cpp
    src/yamaha_arranger_engine.cpp
    src/style_engine.cpp
    src/chord_finder.cpp
    tests/roland_stl_reader_test.cpp
  )
  target_compile_features(roland-stl-reader-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(roland-stl-reader-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(roland-stl-reader-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME roland-stl-header-events-and-style-markers COMMAND roland-stl-reader-test)

  add_executable(sf2-effects-dsp-test
    src/sf2_effects_dsp.cpp
    tests/sf2_effects_dsp_test.cpp
  )
  target_include_directories(sf2-effects-dsp-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(sf2-effects-dsp-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(sf2-effects-dsp-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(sf2-effects-dsp-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME sf2-yamaha-style-effects-dsp COMMAND sf2-effects-dsp-test)

  # Exercise the effects path using send values parsed from a real bundled
  # Yamaha Style, not only full-scale synthetic CC91/CC93=127 impulses.
  add_executable(yamaha-style-effects-audibility-test
    src/SoundFont/sf2_synth.cpp
    src/yamaha_style_runtime.cpp
    src/sf2_effects_dsp.cpp
    tests/yamaha_style_real_sf2_effects_test.cpp
  )
  target_include_directories(yamaha-style-effects-audibility-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_definitions(yamaha-style-effects-audibility-test PRIVATE
    ENSEMBLES_SOURCE_DIR="${CMAKE_SOURCE_DIR}")
  target_compile_features(yamaha-style-effects-audibility-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(yamaha-style-effects-audibility-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(yamaha-style-effects-audibility-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME yamaha-style-real-send-reverb-chorus-audibility
    COMMAND yamaha-style-effects-audibility-test)

  add_executable(genos2-beat-pulse-test tests/genos2_beat_pulse_test.cpp)
  target_include_directories(genos2-beat-pulse-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(genos2-beat-pulse-test PRIVATE cxx_std_17)
  add_test(NAME genos2-start-stop-beat-phase COMMAND genos2-beat-pulse-test)

  add_executable(yamaha-style-runtime-test
    src/midi_file.cpp
    src/roland_stl.cpp
    src/yamaha_style_runtime.cpp
    src/yamaha_arranger_engine.cpp
    src/style_engine.cpp
    src/chord_finder.cpp
    tests/yamaha_style_runtime_test.cpp
  )
  target_include_directories(yamaha-style-runtime-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(yamaha-style-runtime-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(yamaha-style-runtime-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(yamaha-style-runtime-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME yamaha-psr-s-style-load-casm-scheduler COMMAND yamaha-style-runtime-test)

  # Full supplied Yamaha MIDI-style corpus playback through the actual StyleEngine
  # MIDI sink. This catches setup/preamble and arranger regressions that a
  # simple file-load test cannot detect.
  add_executable(yamaha-sty-playback-corpus-test
    src/midi_file.cpp
    src/roland_stl.cpp
    src/yamaha_style_runtime.cpp
    src/yamaha_arranger_engine.cpp
    src/style_engine.cpp
    src/chord_finder.cpp
    tests/yamaha_sty_playback_corpus_test.cpp
  )
  target_include_directories(yamaha-sty-playback-corpus-test PRIVATE "${CMAKE_SOURCE_DIR}/src")
  target_compile_features(yamaha-sty-playback-corpus-test PRIVATE cxx_std_17)
  if(MSVC)
    target_compile_options(yamaha-sty-playback-corpus-test PRIVATE /W4 /permissive- /utf-8)
  else()
    target_compile_options(yamaha-sty-playback-corpus-test PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  add_test(NAME yamaha-psr-s-real-time-playback-corpus
    COMMAND yamaha-sty-playback-corpus-test "${CMAKE_SOURCE_DIR}/data/StyleFiles/Yamaha PSR-S")
endif()
