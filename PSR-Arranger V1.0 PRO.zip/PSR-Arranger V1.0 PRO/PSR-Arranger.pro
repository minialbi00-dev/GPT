# Qt Creator / qmake fallback. For a CMake build, see README.md.
# (CMake + vcpkg manifest), which handles runtime DLL and Qt plugin deployment.
TEMPLATE = app
TARGET = PSR-Arranger
QT += widgets
CONFIG += c++17 release windows
CONFIG -= debug_and_release

SOURCES += \
    $$PWD/src/main_qt.cpp \
    $$PWD/src/audio_engine.cpp \
    $$PWD/src/midi_file.cpp \
    $$PWD/src/style_engine.cpp \
    $$PWD/src/chord_finder.cpp

HEADERS += \
    $$PWD/src/audio_engine.hpp \
    $$PWD/src/midi_file.hpp \
    $$PWD/src/style_engine.hpp \
    $$PWD/src/chord_finder.h

VCPKG_ROOT = $$(VCPKG_ROOT)
VCPKG_INSTALLED_DIR_ENV = $$(VCPKG_INSTALLED_DIR)
!isEmpty(VCPKG_INSTALLED_DIR_ENV) {
    VCPKG_INSTALLED_DIR = $$VCPKG_INSTALLED_DIR_ENV
} else {
    VCPKG_INSTALLED_DIR = $$OUT_PWD/vcpkg_installed
    !exists($$VCPKG_INSTALLED_DIR/x64-windows/include/fluidsynth.h) {
        VCPKG_INSTALLED_DIR = $$PWD/vcpkg_installed
    }
    !exists($$VCPKG_INSTALLED_DIR/x64-windows/include/fluidsynth.h):!isEmpty(VCPKG_ROOT) {
        VCPKG_INSTALLED_DIR = $$VCPKG_ROOT/installed
    }
}

INCLUDEPATH += $$VCPKG_INSTALLED_DIR/x64-windows/include
win32-msvc {
    LIBS += "$$VCPKG_INSTALLED_DIR/x64-windows/lib/libfluidsynth-3.lib"
    LIBS += "$$VCPKG_INSTALLED_DIR/x64-windows/lib/rtaudio.lib"
    LIBS += winmm.lib
}

DESTDIR = $$OUT_PWD
OBJECTS_DIR = $$OUT_PWD/obj
MOC_DIR = $$OUT_PWD/moc
RCC_DIR = $$OUT_PWD/rcc
UI_DIR = $$OUT_PWD/ui

win32-msvc:QMAKE_CXXFLAGS += /utf-8
win32-msvc:QMAKE_CXXFLAGS_RELEASE += /O2

# Keep the original .enstl assets beside the executable.
win32:QMAKE_POST_LINK += $$QMAKE_COPY_DIR $$shell_quote($$PWD/data/StyleFiles) $$shell_quote($$OUT_PWD/data/StyleFiles)
