#pragma once

#include <algorithm>
#include <cstdint>
#include <cmath>

namespace ensembles::audio {

// Yamaha style files commonly author accompaniment part levels much lower
// than the keyboard parts. In the bundled 642-style corpus, average CC7 is
// roughly 53..75 and CC11 roughly 82..91. Apply a style-only level trim for
// internal SF2 and external MIDI style output; live keyboard MIDI is untouched.
// Style pan is kept within a conservative +/-16 MIDI range around center so a
// single authored hard-pan event cannot make the whole accompaniment sound
// anchored to one speaker. The SF2 instrument's own stereo sample/pan remains.
constexpr std::uint8_t compensateStyleSf2Controller(std::uint8_t controller,
                                                     std::uint8_t value) noexcept {
    unsigned int scaled = value;
    if (controller == 7) {          // Channel Volume: +3.52 dB (x1.5)
        scaled = (static_cast<unsigned int>(value) * 3U + 1U) / 2U;
    } else if (controller == 11) {  // Expression: +1.94 dB (x1.25)
        scaled = (static_cast<unsigned int>(value) * 5U + 2U) / 4U;
    } else if (controller == 10) {  // Pan: protect against hard-left/right style setup.
        scaled = std::clamp(static_cast<unsigned int>(value), 48U, 80U);
    }
    return static_cast<std::uint8_t>(std::min(scaled, 127U));
}

// Add a controlled +3.01 dB trim after every renderer, then use a smooth
// ceiling. Combined with the moderate FluidSynth calibration, this restores
// usable output level without the previous excessive +12 dB test boost.
constexpr float kOutputLevelCompensation = 1.41421356f;

inline float limitOutputSample(float sample) noexcept {
    constexpr float kSoftLimitStart = 0.98f;
    constexpr float kSoftLimitWidth = 0.02f;
    const float boosted = sample * kOutputLevelCompensation;
    const float magnitude = std::abs(boosted);
    if (magnitude <= kSoftLimitStart) return boosted;
    const float limited = kSoftLimitStart + kSoftLimitWidth *
        std::tanh((magnitude - kSoftLimitStart) / kSoftLimitWidth);
    return std::copysign(limited, boosted);
}

} // namespace ensembles::audio
