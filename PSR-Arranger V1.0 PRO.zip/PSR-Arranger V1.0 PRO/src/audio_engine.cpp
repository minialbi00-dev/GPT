#include "audio_engine.hpp"
#include "acmp_timing_trace.hpp"
#if ENSEMBLES_HAS_NATIVE_SCVA
#include "native_scva_engine.hpp"
#endif
#include "syxg2006le_native_renderer.hpp"
#include "sf2_drum_bank_resolver.hpp"
#include "acmp_level_compensation.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <chrono>
#include <exception>
#include <filesystem>
#include <limits>
#include <utility>

namespace ensembles {
namespace {
int safeEffectLevel(int level) noexcept {
    return std::clamp(level, 0, 10);
}

std::uint64_t steadyClockMicroseconds() noexcept {
    const auto now = std::chrono::steady_clock::now().time_since_epoch();
    return static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(now).count());
}

// All renderers share the same modest output trim. A smooth ceiling catches
// only peaks that would otherwise exceed full scale; it does not compress the
// normal programme level or change left/right balance.
void applyOutputSoftLimiter(float *samples, std::size_t sampleCount) noexcept {
    if (!samples) return;
    for (std::size_t i = 0; i < sampleCount; ++i)
        samples[i] = audio::limitOutputSample(samples[i]);
}

void setFluidSettingInt(fluid_settings_t *settings, const char *key, int value) {
    if (settings) fluid_settings_setint(settings, key, value);
}
void setFluidSettingNum(fluid_settings_t *settings, const char *key, double value) {
    if (settings) fluid_settings_setnum(settings, key, value);
}
void setFluidSettingStr(fluid_settings_t *settings, const char *key, const char *value) {
    if (settings) fluid_settings_setstr(settings, key, value);
}

// The app master range is 0..0.9. A 0.65 calibration gives synth.gain=0.585
// at full UI scale; the shared output ceiling protects transient peaks without
// returning to the excessive +12 dB test boost used in an earlier iteration.
constexpr float kFluidSynthGainCalibration = 0.65f;

void configureFluidSynthSettings(fluid_settings_t *settings, unsigned int sampleRate, float masterGain) {
    setFluidSettingNum(settings, "synth.sample-rate", static_cast<double>(sampleRate));
    setFluidSettingNum(settings, "synth.gain", static_cast<double>(std::clamp(masterGain, 0.0f, 0.9f) * kFluidSynthGainCalibration));
    setFluidSettingInt(settings, "synth.polyphony", 1024);
    setFluidSettingInt(settings, "synth.midi-channels", 64);
    // MMA Bank Select uses the full 14-bit bank number represented by CC0/CC32.
    // This is required for exact SF2 bank = (MSB * 128) + LSB selection.
    setFluidSettingStr(settings, "synth.midi-bank-select", "mma");
    setFluidSettingInt(settings, "synth.reverb.active", 0);
    setFluidSettingInt(settings, "synth.chorus.active", 0);
    setFluidSettingInt(settings, "synth.audio-channels", 1);
    setFluidSettingInt(settings, "synth.audio-groups", 1);
}

std::vector<lsgm::PresetInfo> enumerateFluidPresets(fluid_synth_t *synth, int soundFontId) {
    std::vector<lsgm::PresetInfo> result;
    if (!synth || soundFontId < 0) return result;
    fluid_sfont_t *sfont = fluid_synth_get_sfont_by_id(synth, static_cast<unsigned int>(soundFontId));
    if (!sfont) return result;
    fluid_sfont_iteration_start(sfont);
    while (fluid_preset_t *preset = fluid_sfont_iteration_next(sfont)) {
        const int bank = fluid_preset_get_banknum(preset);
        const int program = fluid_preset_get_num(preset);
        const char *name = fluid_preset_get_name(preset);
        if (bank < 0 || bank > 0x3fff || program < 0 || program > 127) continue;
        result.push_back({name ? name : "(unnamed preset)",
                           static_cast<std::uint16_t>(bank),
                           static_cast<std::uint16_t>(program)});
    }
    std::sort(result.begin(), result.end(), [](const auto &a, const auto &b) {
        if (a.bank != b.bank) return a.bank < b.bank;
        if (a.program != b.program) return a.program < b.program;
        return a.name < b.name;
    });
    return result;
}

void configureFluidSynthChannels(fluid_synth_t *synth, int soundFontId,
                                  const std::vector<lsgm::PresetInfo>& presets) {
    if (!synth || soundFontId < 0) return;
    for (int channel = 0; channel < 64; ++channel) {
        int bank = 0;
        int program = 0;
        const bool drumChannel = channel == 9 || channel == 16 || channel == 40 || channel == 41;
        if (channel == 17) program = 0;
        if (channel == 18) program = 49;
        if (channel == 19) program = 33;
        if (channel == 20) program = 5;
        if (channel == 21) program = 33;
        if (channel == 22) program = 49;
        if (drumChannel) {
            const auto resolved = sf2::resolveDrumBank(presets, 0, static_cast<std::uint8_t>(program));
            if (resolved) (void)fluid_synth_program_select(synth, channel, soundFontId, *resolved, program);
        } else if (fluid_synth_program_select(synth, channel, soundFontId, bank, program) != FLUID_OK) {
            (void)fluid_synth_program_select(synth, channel, soundFontId, 0, program);
        }
        fluid_synth_cc(synth, channel, 3, 64);
        fluid_synth_cc(synth, channel, 10, 64); // Reset every SF2 part to stereo center.
    }
    fluid_synth_cc(synth, 17, 91, 100);
    fluid_synth_cc(synth, 17, 93, 100);
    fluid_synth_cc(synth, 16, 91, 0);
    fluid_synth_cc(synth, 16, 93, 0);
    // Keep the original keyboard-part balance (R1/R2/L). Style-track CC7
    // remains untouched so authored accompaniment balances are preserved.
    fluid_synth_cc(synth, 17, 7, 100);
    fluid_synth_cc(synth, 18, 7, 90);
    fluid_synth_cc(synth, 19, 7, 80);
    fluid_synth_cc(synth, 17, 74, 40);
    fluid_synth_cc(synth, 18, 74, 0);
    fluid_synth_cc(synth, 19, 74, 0);
    for (int channel = 24; channel < 64; ++channel) {
        fluid_synth_cc(synth, channel, 74, 40);
        fluid_synth_cc(synth, channel, 71, 10);
    }
    // Shared Sf2EffectsDsp owns Reverb/Chorus/Delay for this SF2 route.
}
} // namespace

// Defined out of line because NativeScvaEngine is forward-declared in the header.
// Keeping construction out of line prevents MSVC from instantiating unique_ptr
// cleanup while NativeScvaEngine is still an incomplete type in main_qt.cpp.
AudioEngine::AudioEngine() = default;

AudioEngine::~AudioEngine() { shutdown(); }

std::vector<RtAudio::Api> AudioEngine::availableApis() {
    std::vector<RtAudio::Api> apis;
    RtAudio::getCompiledApi(apis);
    apis.erase(std::remove(apis.begin(), apis.end(), RtAudio::RTAUDIO_DUMMY), apis.end());
    return apis;
}

std::vector<AudioEngine::OutputDevice> AudioEngine::availableOutputDevices(RtAudio::Api api) {
    std::vector<OutputDevice> result;
    try {
        RtAudio audio(api);
        const auto ids = audio.getDeviceIds(); // RtAudio 6 IDs are not guaranteed to be sequential.
        result.reserve(ids.size());
        for (const unsigned int id : ids) {
            const RtAudio::DeviceInfo info = audio.getDeviceInfo(id);
            if (info.name.empty() || info.outputChannels < 2) continue;
            OutputDevice device;
            device.id = info.ID;
            device.name = info.name;
            device.outputChannels = info.outputChannels;
            device.isDefaultOutput = info.isDefaultOutput;
            device.sampleRates = info.sampleRates;
            device.preferredSampleRate = info.preferredSampleRate;
            result.push_back(std::move(device));
        }
    } catch (...) {
        // Enumeration should not prevent the GUI from opening; the engine reports
        // the detailed error if the user tries to activate the unavailable API.
    }
    return result;
}

bool AudioEngine::initialize(const std::string &soundFontPath, std::string *error,
                             RtAudio::Api api,
                             std::optional<unsigned int> requestedOutputDeviceId,
                             unsigned int requestedSampleRate,
                             unsigned int requestedBufferFrames) {
    shutdown();
    xgPartManager_.reset();
    auto fail = [&](const std::string &message) {
        if (error) *error = message;
        shutdown();
        return false;
    };

    const bool useFluidSynth = !soundFontPath.empty();
    if (useFluidSynth) {
        std::error_code fsError;
        if (!std::filesystem::is_regular_file(std::filesystem::u8path(soundFontPath), fsError) || fsError)
            return fail("SoundFont file does not exist or is not readable: " + soundFontPath);
    }

    sampleRate_ = std::clamp(requestedSampleRate, 8000u, 192000u);
    bufferFrames_ = std::clamp(requestedBufferFrames, 64u, 4096u);
    sf2EffectsDsp_.prepare(sampleRate_);
    outputApi_ = api;
    // SoundFont/FluidSynth is optional for VST-only operation. RtAudio owns
    // the device stream; FluidSynth only renders into that stream when selected.
    if (useFluidSynth) {
        settings_ = new_fluid_settings();
        if (!settings_) return fail("FluidSynth could not allocate settings.");
        setFluidSettingNum(settings_, "synth.sample-rate", static_cast<double>(sampleRate_));
        setFluidSettingNum(settings_, "synth.gain", static_cast<double>(std::clamp(masterGain_.load(std::memory_order_acquire), 0.0f, 0.9f) * kFluidSynthGainCalibration));
        setFluidSettingInt(settings_, "synth.polyphony", 1024);
        setFluidSettingInt(settings_, "synth.midi-channels", 64);
        setFluidSettingStr(settings_, "synth.midi-bank-select", "mma");
        setFluidSettingInt(settings_, "synth.reverb.active", 0);
        setFluidSettingInt(settings_, "synth.chorus.active", 0);
        // The original app routes all 64 FluidSynth MIDI channels to one stereo bus.
        setFluidSettingInt(settings_, "synth.audio-channels", 1);
        setFluidSettingInt(settings_, "synth.audio-groups", 1);

        synth_ = new_fluid_synth(settings_);
        if (!synth_) return fail("FluidSynth could not create a synthesizer.");

        soundFontId_ = fluid_synth_sfload(synth_, soundFontPath.c_str(), 1);
        if (soundFontId_ < 0)
            return fail("FluidSynth rejected this SoundFont. Use a real .sf2 file, not a Git LFS pointer.");
        fluidSf2Presets_ = enumerateFluidPresets(synth_, soundFontId_);

        // Initialize the 16 style channels with the default GM piano patch, and
        // use the SoundFont's percussion bank on MIDI channel 10 when available.
        for (int channel = 0; channel < 16; ++channel) {
            if (channel == 9) {
                const auto drumBank = sf2::resolveDrumBank(fluidSf2Presets_, 0, 0);
                if (drumBank) (void)fluid_synth_program_select(synth_, channel, soundFontId_, *drumBank, 0);
            } else {
                fluid_synth_program_select(synth_, channel, soundFontId_, 0, 0);
            }
            fluid_synth_cc(synth_, channel, 3, 64);
            fluid_synth_cc(synth_, channel, 10, 64); // Prevent stale per-channel pan on reload.
        }

        // Match original synthesizer.c: R1=17, R2/layer=18, L/split=19,
        // channel 16 is metronome, and channels 20..22 are chord/harmony voices.
        if (const auto drumBank = sf2::resolveDrumBank(fluidSf2Presets_, 0, 0))
            (void)fluid_synth_program_select(synth_, 16, soundFontId_, *drumBank, 0);
        if (const auto drumBank = sf2::resolveDrumBank(fluidSf2Presets_, 0, 0)) {
            for (int rhythmChannel = 40; rhythmChannel <= 41; ++rhythmChannel)
                (void)fluid_synth_program_select(synth_, rhythmChannel, soundFontId_, *drumBank, 0);
        }
        fluidDrumBankMsb_.fill(0);
        fluidDrumBankLsb_.fill(0);
        fluid_synth_program_select(synth_, 17, soundFontId_, 0, 0);
        fluid_synth_program_select(synth_, 18, soundFontId_, 0, 49);
        fluid_synth_program_select(synth_, 19, soundFontId_, 0, 33);
        fluid_synth_program_select(synth_, 20, soundFontId_, 0, 5);
        fluid_synth_program_select(synth_, 21, soundFontId_, 0, 33);
        fluid_synth_program_select(synth_, 22, soundFontId_, 0, 49);

        for (int channel = 16; channel < 64; ++channel) {
            fluid_synth_cc(synth_, channel, 3, 64);
            fluid_synth_cc(synth_, channel, 10, 64); // Center internal keyboard/helper/rhythm parts too.
        }
        fluid_synth_cc(synth_, 17, 91, 100);
        fluid_synth_cc(synth_, 17, 93, 100);
        fluid_synth_cc(synth_, 16, 91, 0);
        fluid_synth_cc(synth_, 16, 93, 0);
        // Full MIDI channel volume for the three live keyboard parts. Their
        // expression and note velocity still preserve playing dynamics.
        fluid_synth_cc(synth_, 17, 7, 100);
        fluid_synth_cc(synth_, 18, 7, 90);
        fluid_synth_cc(synth_, 19, 7, 80);
        fluid_synth_cc(synth_, 17, 74, 40);
        fluid_synth_cc(synth_, 18, 74, 0);
        fluid_synth_cc(synth_, 19, 74, 0);
        for (int channel = 24; channel < 64; ++channel) {
            fluid_synth_cc(synth_, channel, 74, 40);
            fluid_synth_cc(synth_, channel, 71, 10);
        }
        applyReverb(true, 7);
        applyChorus(true, 2);
    }

    try {
        audio_ = std::make_unique<RtAudio>(api);
        const auto deviceIds = audio_->getDeviceIds();
        if (deviceIds.empty())
            return fail("RtAudio did not find an output device for the selected audio API.");
        const auto deviceId = requestedOutputDeviceId.value_or(audio_->getDefaultOutputDevice());
        const auto foundId = std::find(deviceIds.begin(), deviceIds.end(), deviceId);
        if (foundId == deviceIds.end())
            return fail("The selected RtAudio output device is no longer available. Refresh the device list.");
        const RtAudio::DeviceInfo deviceInfo = audio_->getDeviceInfo(deviceId);
        if (deviceInfo.name.empty() || deviceInfo.outputChannels < 2)
            return fail("The selected RtAudio output device does not expose stereo output.");

        RtAudio::StreamParameters outputParameters{};
        outputParameters.deviceId = deviceId;
        outputParameters.nChannels = 2;
        outputParameters.firstChannel = 0;
        RtAudio::StreamOptions options{};
        options.flags = RTAUDIO_MINIMIZE_LATENCY;
        options.numberOfBuffers = 3;
        unsigned int bufferFrames = bufferFrames_;
        const RtAudioErrorType openResult = audio_->openStream(
            &outputParameters, nullptr, RTAUDIO_FLOAT32, sampleRate_, &bufferFrames,
            &AudioEngine::audioCallback, this, &options);
        if (openResult != RTAUDIO_NO_ERROR) {
            const std::string detail = audio_->getErrorText();
            return fail("RtAudio could not open the output stream" +
                (detail.empty() ? std::string(".") : std::string(": ") + detail));
        }
        const RtAudioErrorType startResult = audio_->startStream();
        if (startResult != RTAUDIO_NO_ERROR) {
            const std::string detail = audio_->getErrorText();
            return fail("RtAudio could not start the output stream" +
                (detail.empty() ? std::string(".") : std::string(": ") + detail));
        }
        outputDeviceId_ = deviceId;
        outputDeviceName_ = deviceInfo.name;
        bufferFrames_ = bufferFrames;
        outputApi_ = audio_->getCurrentApi();
    } catch (const std::exception &ex) {
        return fail(std::string("RtAudio could not start the output stream: ") + ex.what());
    } catch (...) {
        return fail("RtAudio could not start the output stream (unknown device error).");
    }

    soundFontPath_ = soundFontPath;
    ready_.store(true, std::memory_order_release);
    if (error) error->clear();
    return true;
}

void AudioEngine::shutdown() noexcept {
    ready_.store(false, std::memory_order_release);
    useVst2_.store(false, std::memory_order_release);
    useNativeScva_.store(false, std::memory_order_release);
    useSyxg2006LeNative_.store(false, std::memory_order_release);
    useLsGmNative_.store(false, std::memory_order_release);
    testToneFramesRemaining_.store(0, std::memory_order_release);
    testTonePhase_ = 0.0;
    if (audio_) {
        try {
            if (audio_->isStreamRunning()) audio_->stopStream();
        } catch (...) {}
        try {
            if (audio_->isStreamOpen()) audio_->closeStream();
        } catch (...) {}
        audio_.reset();
    }
    // Stop the stream before unloading a plug-in that may be executing on its callback.
    vst2Host_.reset();
    syxg2006LeNative_.reset();
    nativeSf2_.reset();
#if ENSEMBLES_HAS_NATIVE_SCVA
    nativeScva_.reset();
#endif
    if (synth_) {
        fluid_synth_all_sounds_off(synth_, -1);
        delete_fluid_synth(synth_);
        synth_ = nullptr;
    }
    if (settings_) {
        delete_fluid_settings(settings_);
        settings_ = nullptr;
    }
    soundFontId_ = -1;
    fluidSf2Presets_.clear();
    retainedStyleEffectProfiles_.clear();
    soundFontPath_.clear();
    outputDeviceName_.clear();
    outputDeviceId_ = 0;
    writeIndex_.store(0, std::memory_order_relaxed);
    readIndex_.store(0, std::memory_order_relaxed);
    pendingTimedMidiCount_ = 0;
    callbackTimedMidiCount_ = 0;
}

bool AudioEngine::enqueue(const Command &command) noexcept {
    if (!isReady()) return false;
    const std::size_t write = writeIndex_.load(std::memory_order_relaxed);
    const std::size_t next = (write + 1) % kQueueCapacity;
    if (next == readIndex_.load(std::memory_order_acquire)) return false;
    queue_[write] = command;
    writeIndex_.store(next, std::memory_order_release);
    return true;
}

bool AudioEngine::dequeue(Command &command) noexcept {
    const std::size_t read = readIndex_.load(std::memory_order_relaxed);
    if (read == writeIndex_.load(std::memory_order_acquire)) return false;
    command = queue_[read];
    readIndex_.store((read + 1) % kQueueCapacity, std::memory_order_release);
    return true;
}

bool AudioEngine::sendMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                           int synthChannelOverride) noexcept {
    return sendMidiAt(status, data1, data2, 0, synthChannelOverride);
}

bool AudioEngine::sendMidiAt(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                             std::uint64_t targetTimeUs, int synthChannelOverride) noexcept {
    if (synthChannelOverride < -1 || synthChannelOverride > 63) return false;
    Command command;
    command.type = CommandType::Midi;
    command.status = status;
    command.data1 = static_cast<std::uint8_t>(data1 & 0x7f);
    command.data2 = static_cast<std::uint8_t>(data2 & 0x7f);
    command.channelOverride = static_cast<std::int16_t>(synthChannelOverride);
    command.targetTimeUs = targetTimeUs;
    return enqueue(command);
}

bool AudioEngine::sendStyleMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                                int synthChannelOverride) noexcept {
    return sendStyleMidiAt(status, data1, data2, 0, synthChannelOverride);
}

bool AudioEngine::sendStyleMidiAt(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                                  std::uint64_t targetTimeUs, int synthChannelOverride) noexcept {
    if (synthChannelOverride < -1 || synthChannelOverride > 63) return false;
    Command command;
    command.type = CommandType::Midi;
    command.status = status;
    command.data1 = static_cast<std::uint8_t>(data1 & 0x7f);
    command.data2 = static_cast<std::uint8_t>(data2 & 0x7f);
    command.channelOverride = static_cast<std::int16_t>(synthChannelOverride);
    command.targetTimeUs = targetTimeUs;
    command.styleMidi = true;
    command.styleGeneration = styleMidiGeneration_.load(std::memory_order_acquire);
    return enqueue(command);
}

void AudioEngine::cancelPendingStyleMidi() noexcept {
    // Bumping the generation invalidates style commands in the GUI->audio ring,
    // the callback-owned deadline heap, and any events already extracted for
    // the current callback. Live keyboard/record/playback MIDI is unaffected.
    styleMidiGeneration_.fetch_add(1, std::memory_order_acq_rel);
}

bool AudioEngine::isCurrentStyleCommand(const Command &command) const noexcept {
    return !command.styleMidi || command.styleGeneration ==
        styleMidiGeneration_.load(std::memory_order_acquire);
}

bool AudioEngine::setMasterGain(float gain) noexcept {
    Command command;
    command.type = CommandType::Gain;
    command.gain = std::clamp(gain, 0.0f, 0.9f);
    if (!enqueue(command)) return false;
    masterGain_.store(command.gain, std::memory_order_release);
    return true;
}

bool AudioEngine::setMasterReverb(bool enabled, int level) noexcept {
    Command command;
    command.type = CommandType::Reverb;
    command.enabled = enabled;
    command.value = static_cast<std::int16_t>(safeEffectLevel(level));
    return enqueue(command);
}

bool AudioEngine::setMasterChorus(bool enabled, int level) noexcept {
    Command command;
    command.type = CommandType::Chorus;
    command.enabled = enabled;
    command.value = static_cast<std::int16_t>(safeEffectLevel(level));
    return enqueue(command);
}

bool AudioEngine::setMasterDelay(bool enabled, int level) noexcept {
    Command command;
    command.type = CommandType::Delay;
    command.enabled = enabled;
    command.value = static_cast<std::int16_t>(safeEffectLevel(level));
    return enqueue(command);
}

bool AudioEngine::setYamahaStyleEffects(const arranger::YamahaStyleEffectProfile& profile,
                                        int tempoBpm) noexcept {
    try {
        auto retained = std::make_unique<arranger::YamahaStyleEffectProfile>(profile);
        const auto* profilePointer = retained.get();
        retainedStyleEffectProfiles_.push_back(std::move(retained));
        Command command;
        command.type = CommandType::StyleEffects;
        command.styleEffectProfile = profilePointer;
        command.value = static_cast<std::int16_t>(std::clamp(tempoBpm, 40, 300));
        return enqueue(command);
    } catch (...) {
        return false;
    }
}

bool AudioEngine::clearYamahaStyleEffects() noexcept {
    Command command;
    command.type = CommandType::ClearStyleEffects;
    return enqueue(command);
}

bool AudioEngine::setYamahaStyleTempo(int tempoBpm) noexcept {
    Command command;
    command.type = CommandType::StyleTempo;
    command.value = static_cast<std::int16_t>(std::clamp(tempoBpm, 40, 300));
    return enqueue(command);
}

bool AudioEngine::sendStyleXgEffectParameterAt(const std::array<std::uint8_t, 3>& address,
                                               const std::array<std::uint8_t, 16>& data,
                                               std::uint8_t dataLength,
                                               std::uint64_t targetTimeUs) noexcept {
    if (dataLength == 0 || dataLength > data.size()) return false;
    Command command;
    command.type = CommandType::XgEffectParameter;
    command.xgEffectAddress = address;
    command.xgEffectData = data;
    command.xgEffectDataLength = dataLength;
    command.targetTimeUs = targetTimeUs;
    command.styleMidi = true;
    command.styleGeneration = styleMidiGeneration_.load(std::memory_order_acquire);
    return enqueue(command);
}

bool AudioEngine::sendSysEx(std::span<const std::uint8_t> bytes) noexcept {
    if (bytes.empty() || bytes.size() > Command{}.sysex.size()) return false;
    Command command;
    command.type = CommandType::SysEx;
    command.sysexLength = static_cast<std::uint8_t>(bytes.size());
    std::copy(bytes.begin(), bytes.end(), command.sysex.begin());
    return enqueue(command);
}

bool AudioEngine::allSoundsOff() noexcept {
    Command command;
    command.type = CommandType::AllSoundsOff;
    return enqueue(command);
}

bool AudioEngine::loadNativeScvaFromMemory(std::vector<std::uint8_t> coreImage,
                                           std::string *error) {
#if !ENSEMBLES_HAS_NATIVE_SCVA
    (void)coreImage;
    if (error) *error = "Native SCVA backend was not compiled because plugins/SCVA/SCCore.dll was missing at configure time.";
    return false;
#else
    if (!isReady() || !audio_ || !audio_->isStreamRunning()) {
        if (error) *error = "RtAudio must be active before initializing native SCVA.";
        return false;
    }
    if (useNativeScva_.load(std::memory_order_acquire) && nativeScva_) {
        if (error) error->clear();
        return true;
    }
    if (vst2Host_ || useVst2_.load(std::memory_order_acquire) ||
        useSyxg2006LeNative_.load(std::memory_order_acquire) ||
        useLsGmNative_.load(std::memory_order_acquire)) {
        if (error) *error = "Native SCVA requires an exclusive audio route; unload VST2/native SF2 first.";
        return false;
    }

    auto candidate = std::make_unique<NativeScvaEngine>();
    std::string nativeError;
    if (!candidate->initialize(std::move(coreImage), &nativeError)) {
        if (error) *error = nativeError;
        return false;
    }

    try {
        const auto stopped = audio_->stopStream();
        if (stopped != RTAUDIO_NO_ERROR) {
            if (error) *error = "RtAudio could not pause before activating native SCVA: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Could not pause RtAudio before native SCVA: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Could not pause RtAudio before native SCVA.";
        return false;
    }

    // A file-based FluidSynth instance may have been active before a .STL was
    // selected. The native SCVA engine owns the callback exclusively, so dispose
    // FluidSynth only after RtAudio has stopped and can no longer access it.
    if (synth_) {
        fluid_synth_all_sounds_off(synth_, -1);
        delete_fluid_synth(synth_);
        synth_ = nullptr;
    }
    if (settings_) {
        delete_fluid_settings(settings_);
        settings_ = nullptr;
    }
    soundFontPath_.clear();

    nativeScva_ = std::move(candidate);
    useNativeScva_.store(true, std::memory_order_release);
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            useNativeScva_.store(false, std::memory_order_release);
            nativeScva_.reset();
            if (error) *error = "Native SCVA initialized, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        useNativeScva_.store(false, std::memory_order_release);
        nativeScva_.reset();
        if (error) *error = std::string("Native SCVA initialized, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        useNativeScva_.store(false, std::memory_order_release);
        nativeScva_.reset();
        if (error) *error = "Native SCVA initialized, but RtAudio could not restart.";
        return false;
    }
    if (error) error->clear();
    return true;
#endif
}

bool AudioEngine::unloadNativeScva(std::string *error) {
#if !ENSEMBLES_HAS_NATIVE_SCVA
    useNativeScva_.store(false, std::memory_order_release);
    if (error) error->clear();
    return true;
#else
    if (!nativeScva_ && !useNativeScva_.load(std::memory_order_acquire)) {
        if (error) error->clear();
        return true;
    }
    if (!audio_ || !audio_->isStreamOpen()) {
        useNativeScva_.store(false, std::memory_order_release);
        nativeScva_.reset();
        if (error) error->clear();
        return true;
    }

    useNativeScva_.store(false, std::memory_order_release);
    try {
        if (audio_->isStreamRunning()) {
            const auto stopped = audio_->stopStream();
            if (stopped != RTAUDIO_NO_ERROR) {
                useNativeScva_.store(true, std::memory_order_release);
                if (error) *error = "RtAudio could not pause; native SCVA remains active.";
                return false;
            }
        }
    } catch (const std::exception &ex) {
        useNativeScva_.store(true, std::memory_order_release);
        if (error) *error = std::string("Could not pause RtAudio before unloading native SCVA: ") + ex.what();
        return false;
    } catch (...) {
        useNativeScva_.store(true, std::memory_order_release);
        if (error) *error = "Could not pause RtAudio before unloading native SCVA.";
        return false;
    }

    nativeScva_.reset();
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            if (error) *error = "Native SCVA unloaded, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Native SCVA unloaded, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Native SCVA unloaded, but RtAudio could not restart.";
        return false;
    }
    if (error) error->clear();
    return true;
#endif
}

bool AudioEngine::loadSyxg2006LeNative(const std::string &bankTablePath,
                                          const std::string &pcmManifestPath,
                                          std::string *error) {
    if (!isReady() || !audio_ || !audio_->isStreamRunning()) {
        if (error) *error = "RtAudio must be active before loading the Yamaha native renderer.";
        return false;
    }
    if (useVst2_.load(std::memory_order_acquire) || vst2Host_ ||
        useNativeScva_.load(std::memory_order_acquire) || useLsGmNative_.load(std::memory_order_acquire)) {
        if (error) *error = "Unload the active VST2/SCVA/native SF2 renderer before activating Yamaha.";
        return false;
    }
    if (useSyxg2006LeNative_.load(std::memory_order_acquire) || syxg2006LeNative_ ||
        useLsGmNative_.load(std::memory_order_acquire) || nativeSf2_) {
        if (error) *error = "Another native sampler is already active.";
        return false;
    }

    auto candidate = std::make_unique<Syxg2006LeNativeRenderer>();
    std::string detail;
    if (!candidate->loadAssets(std::filesystem::u8path(bankTablePath),
                               std::filesystem::u8path(pcmManifestPath), &detail) ||
        !candidate->open(StereoPcmFormat{sampleRate_, 2}, &detail)) {
        if (error) *error = detail;
        return false;
    }

    try {
        const auto stopped = audio_->stopStream();
        if (stopped != RTAUDIO_NO_ERROR) {
            if (error) *error = "RtAudio could not pause before activating Yamaha: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Could not pause RtAudio before activating Yamaha: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Could not pause RtAudio before activating Yamaha.";
        return false;
    }

    syxg2006LeNative_ = std::move(candidate);
    syxg2006LeNative_->setMasterGain(0.6f);
    xgPartManager_.reset();
    useSyxg2006LeNative_.store(true, std::memory_order_release);
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            useSyxg2006LeNative_.store(false, std::memory_order_release);
            syxg2006LeNative_.reset();
            if (error) *error = "Yamaha initialized, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        useSyxg2006LeNative_.store(false, std::memory_order_release);
        syxg2006LeNative_.reset();
        if (error) *error = std::string("Yamaha initialized, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        useSyxg2006LeNative_.store(false, std::memory_order_release);
        syxg2006LeNative_.reset();
        if (error) *error = "Yamaha initialized, but RtAudio could not restart.";
        return false;
    }
    if (error) error->clear();
    return true;
}

bool AudioEngine::unloadSyxg2006LeNative(std::string *error) {
    if (!syxg2006LeNative_ && !useSyxg2006LeNative_.load(std::memory_order_acquire)) {
        if (error) error->clear();
        return true;
    }
    if (!audio_ || !audio_->isStreamOpen()) {
        useSyxg2006LeNative_.store(false, std::memory_order_release);
        syxg2006LeNative_.reset();
        if (error) error->clear();
        return true;
    }
    useSyxg2006LeNative_.store(false, std::memory_order_release);
    try {
        if (audio_->isStreamRunning()) {
            const auto stopped = audio_->stopStream();
            if (stopped != RTAUDIO_NO_ERROR) {
                useSyxg2006LeNative_.store(true, std::memory_order_release);
                if (error) *error = "RtAudio could not pause; Yamaha renderer remains active.";
                return false;
            }
        }
    } catch (const std::exception &ex) {
        useSyxg2006LeNative_.store(true, std::memory_order_release);
        if (error) *error = std::string("Could not stop audio before unloading Yamaha: ") + ex.what();
        return false;
    } catch (...) {
        useSyxg2006LeNative_.store(true, std::memory_order_release);
        if (error) *error = "Could not stop audio before unloading Yamaha.";
        return false;
    }
    syxg2006LeNative_.reset();
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            if (error) *error = "Yamaha renderer unloaded, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Yamaha renderer unloaded, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Yamaha renderer unloaded, but RtAudio could not restart.";
        return false;
    }
    if (error) error->clear();
    return true;
}

bool AudioEngine::loadNativeSoundFont(const std::string &soundFontPath, std::string *error) {
    if (!isReady() || !audio_ || !audio_->isStreamRunning()) {
        if (error) *error = "RtAudio must be active before loading native SF2 sampler.";
        return false;
    }
    if (useVst2_.load(std::memory_order_acquire) || vst2Host_ ||
        useNativeScva_.load(std::memory_order_acquire) ||
        useSyxg2006LeNative_.load(std::memory_order_acquire)) {
        if (error) *error = "Unload VST2/SCVA/Yamaha renderer before activating native SF2 sampler.";
        return false;
    }
    auto candidate = std::make_unique<lsgm::Sf2Synth>();
    std::string detail;
    if (!candidate->load(soundFontPath, &detail)) {
        if (error) *error = "Native SF2 load failed: " + detail;
        return false;
    }
    candidate->setSampleRate(static_cast<double>(sampleRate_));
    candidate->setMasterGain(std::clamp(masterGain_.load(std::memory_order_acquire) / 0.6f, 0.0f, 1.0f));

    try {
        const auto stopped = audio_->stopStream();
        if (stopped != RTAUDIO_NO_ERROR) {
            if (error) *error = "RtAudio could not pause before activating native SF2: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Could not pause RtAudio before activating native SF2: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Could not pause RtAudio before activating native SF2.";
        return false;
    }

    nativeSf2_ = std::move(candidate);
    useLsGmNative_.store(true, std::memory_order_release);
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            useLsGmNative_.store(false, std::memory_order_release);
            nativeSf2_.reset();
            if (error) *error = "Native SF2 loaded, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        useLsGmNative_.store(false, std::memory_order_release);
        nativeSf2_.reset();
        if (error) *error = std::string("Native SF2 loaded, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        useLsGmNative_.store(false, std::memory_order_release);
        nativeSf2_.reset();
        if (error) *error = "Native SF2 loaded, but RtAudio could not restart.";
        return false;
    }
    xgPartManager_.reset();
    if (error) error->clear();
    return true;
}

bool AudioEngine::loadFluidSynthSoundFont(const std::string &soundFontPath, std::string *error) {
    if (!isReady() || !audio_ || !audio_->isStreamOpen()) {
        if (error) *error = "RtAudio harus aktif sebelum mengaktifkan FluidSynth SF2.";
        return false;
    }
    if (useVst2_.load(std::memory_order_acquire) || vst2Host_ ||
        useNativeScva_.load(std::memory_order_acquire) ||
        useSyxg2006LeNative_.load(std::memory_order_acquire)) {
        if (error) *error = "Lepas VST2/SCVA/Yamaha native renderer sebelum mengaktifkan FluidSynth SF2.";
        return false;
    }

    std::unique_ptr<fluid_settings_t, decltype(&delete_fluid_settings)> candidateSettings(
        new_fluid_settings(), &delete_fluid_settings);
    if (!candidateSettings) {
        if (error) *error = "FluidSynth tidak dapat mengalokasikan settings untuk SF2 eksternal.";
        return false;
    }
    configureFluidSynthSettings(candidateSettings.get(), sampleRate_, masterGain_.load(std::memory_order_acquire));
    std::unique_ptr<fluid_synth_t, decltype(&delete_fluid_synth)> candidateSynth(
        new_fluid_synth(candidateSettings.get()), &delete_fluid_synth);
    if (!candidateSynth) {
        if (error) *error = "FluidSynth tidak dapat membuat synthesizer untuk SF2 eksternal.";
        return false;
    }
    const int candidateSoundFontId = fluid_synth_sfload(candidateSynth.get(), soundFontPath.c_str(), 1);
    if (candidateSoundFontId < 0) {
        if (error) *error = "FluidSynth menolak SF2 eksternal. Pastikan file SF2 valid dan bukan Git-LFS pointer.";
        return false;
    }
    auto candidatePresets = enumerateFluidPresets(candidateSynth.get(), candidateSoundFontId);
    if (candidatePresets.empty()) {
        if (error) *error = "FluidSynth membaca file, tetapi tidak menemukan preset bank/program yang dapat dipilih.";
        return false;
    }
    configureFluidSynthChannels(candidateSynth.get(), candidateSoundFontId, candidatePresets);

    bool wasRunning = false;
    try {
        wasRunning = audio_->isStreamRunning();
        if (wasRunning) {
            const auto stopped = audio_->stopStream();
            if (stopped != RTAUDIO_NO_ERROR) {
                if (error) *error = "RtAudio tidak dapat dijeda sebelum mengganti SF2: " + audio_->getErrorText();
                return false;
            }
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Gagal menjeda RtAudio sebelum mengganti SF2: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Gagal menjeda RtAudio sebelum mengganti SF2.";
        return false;
    }

    // Preserve every old resource until the replacement stream has restarted.
    auto oldSynth = synth_;
    auto oldSettings = settings_;
    const int oldSoundFontId = soundFontId_;
    const std::string oldPath = soundFontPath_;
    auto oldCatalog = std::move(fluidSf2Presets_);
    auto oldNative = std::move(nativeSf2_);
    const auto oldDrumBankMsb = fluidDrumBankMsb_;
    const auto oldDrumBankLsb = fluidDrumBankLsb_;
    const bool oldNativeActive = useLsGmNative_.load(std::memory_order_acquire);

    synth_ = candidateSynth.release();
    settings_ = candidateSettings.release();
    soundFontId_ = candidateSoundFontId;
    soundFontPath_ = soundFontPath;
    fluidSf2Presets_ = std::move(candidatePresets);
    fluidDrumBankMsb_.fill(0);
    fluidDrumBankLsb_.fill(0);
    useLsGmNative_.store(false, std::memory_order_release);

    bool restarted = true;
    if (wasRunning) {
        try {
            const auto started = audio_->startStream();
            restarted = started == RTAUDIO_NO_ERROR;
            if (!restarted && error)
                *error = "FluidSynth SF2 sudah disiapkan, tetapi RtAudio gagal dimulai ulang: " + audio_->getErrorText();
        } catch (const std::exception &ex) {
            restarted = false;
            if (error) *error = std::string("FluidSynth SF2 siap, tetapi RtAudio gagal dimulai ulang: ") + ex.what();
        } catch (...) {
            restarted = false;
            if (error) *error = "FluidSynth SF2 siap, tetapi RtAudio gagal dimulai ulang.";
        }
    }

    if (!restarted) {
        // Stop any partially restarted callback before restoring its previous renderer.
        try { if (audio_->isStreamRunning()) audio_->stopStream(); } catch (...) {}
        auto failedSynth = synth_;
        auto failedSettings = settings_;
        synth_ = oldSynth;
        settings_ = oldSettings;
        soundFontId_ = oldSoundFontId;
        soundFontPath_ = oldPath;
        fluidSf2Presets_ = std::move(oldCatalog);
        fluidDrumBankMsb_ = oldDrumBankMsb;
        fluidDrumBankLsb_ = oldDrumBankLsb;
        nativeSf2_ = std::move(oldNative);
        useLsGmNative_.store(oldNativeActive, std::memory_order_release);
        if (failedSynth) delete_fluid_synth(failedSynth);
        if (failedSettings) delete_fluid_settings(failedSettings);
        try { if (wasRunning) (void)audio_->startStream(); } catch (...) {}
        return false;
    }

    if (oldSynth) {
        fluid_synth_all_sounds_off(oldSynth, -1);
        delete_fluid_synth(oldSynth);
    }
    if (oldSettings) delete_fluid_settings(oldSettings);
    // oldNative is destroyed only after the audio callback has stopped using it.
    oldNative.reset();
    xgPartManager_.reset();
    if (error) error->clear();
    return true;
}

bool AudioEngine::unloadNativeSoundFont(std::string *error) {
    if (!nativeSf2_ && !useLsGmNative_.load(std::memory_order_acquire)) {
        if (error) error->clear();
        return true;
    }
    if (!audio_ || !audio_->isStreamOpen()) {
        useLsGmNative_.store(false, std::memory_order_release);
        nativeSf2_.reset();
        if (error) error->clear();
        return true;
    }
    useLsGmNative_.store(false, std::memory_order_release);
    try {
        if (audio_->isStreamRunning()) {
            const auto stopped = audio_->stopStream();
            if (stopped != RTAUDIO_NO_ERROR) {
                useLsGmNative_.store(true, std::memory_order_release);
                if (error) *error = "RtAudio could not pause; Native SF2 renderer remains active.";
                return false;
            }
        }
    } catch (const std::exception &ex) {
        useLsGmNative_.store(true, std::memory_order_release);
        if (error) *error = std::string("Could not pause RtAudio before unloading native SF2: ") + ex.what();
        return false;
    } catch (...) {
        useLsGmNative_.store(true, std::memory_order_release);
        if (error) *error = "Could not pause RtAudio before unloading native SF2.";
        return false;
    }
    nativeSf2_.reset();
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            if (error) *error = "Native SF2 unloaded, but RtAudio could not restart: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Native SF2 unloaded, but RtAudio could not restart: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Native SF2 unloaded, but RtAudio could not restart.";
        return false;
    }
    if (error) error->clear();
    return true;
}

bool AudioEngine::loadVst2Plugin(const std::string &pluginPath, std::string *error) {
    if (!isReady() || !audio_ || !audio_->isStreamRunning()) {
        if (error) *error = "RtAudio harus aktif sebelum plugin VST2 dimuat.";
        return false;
    }
    if (useSyxg2006LeNative_.load(std::memory_order_acquire) || useLsGmNative_.load(std::memory_order_acquire)) {
        if (error) *error = "Nonaktifkan Yamaha/native SF2 sampler sebelum memilih VST2.";
        return false;
    }
    if (useVst2_.load(std::memory_order_acquire) || vst2Host_) {
        if (error) *error = "Plugin VST2 masih aktif. Nonaktifkan dulu sebelum memilih plugin lain.";
        return false;
    }

    // VST dispatch/lifecycle calls must not race the RtAudio callback. Keep the
    // SAME stream/device open, but stop its callback while the plugin is created.
    try {
        const auto stopped = audio_->stopStream();
        if (stopped != RTAUDIO_NO_ERROR) {
            if (error) *error = "RtAudio gagal dihentikan sementara sebelum memuat VST2: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Gagal menghentikan callback RtAudio sebelum memuat VST2: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Gagal menghentikan callback RtAudio sebelum memuat VST2.";
        return false;
    }

    auto restartStream = [&]() -> std::string {
        try {
            const auto started = audio_->startStream();
            if (started == RTAUDIO_NO_ERROR) return {};
            return audio_->getErrorText().empty()
                ? "RtAudio tidak berhasil berjalan kembali." : audio_->getErrorText();
        } catch (const std::exception &ex) {
            return std::string("RtAudio gagal berjalan kembali: ") + ex.what();
        } catch (...) {
            return "RtAudio gagal berjalan kembali (unknown error).";
        }
    };

    auto candidate = std::make_unique<Vst2Host>();
    std::string pluginError;
    if (!candidate->load(pluginPath, static_cast<double>(sampleRate_), bufferFrames_, &pluginError)) {
        const std::string restartError = restartStream();
        if (error) {
            *error = pluginError;
            if (!restartError.empty()) *error += "\nAudio stream juga gagal dimulai kembali: " + restartError;
        }
        return false;
    }

    vst2Host_ = std::move(candidate);
    useVst2_.store(true, std::memory_order_release);
    const std::string restartError = restartStream();
    if (!restartError.empty()) {
        useVst2_.store(false, std::memory_order_release);
        vst2Host_.reset();
        if (error) *error = "VST2 berhasil diinisialisasi, tetapi RtAudio gagal berjalan kembali: " + restartError;
        return false;
    }
    // Prime all 16 external MIDI channels with explicit, audible defaults.
    // Some multitimbral instruments preserve muted channel state from their last
    // session; setting volume and expression removes that common silent-host case.
    for (int channel = 0; channel < 16; ++channel) {
        sendMidi(static_cast<std::uint8_t>(0xB0 | channel), 7, 110, channel);  // Channel volume
        sendMidi(static_cast<std::uint8_t>(0xB0 | channel), 11, 127, channel); // Expression
        sendMidi(static_cast<std::uint8_t>(0xB0 | channel), 10, 64, channel);  // Pan center
    }
    if (error) error->clear();
    return true;
}

bool AudioEngine::unloadVst2Plugin(std::string *error) {
    if (!vst2Host_ && !useVst2_.load(std::memory_order_acquire)) {
        if (error) error->clear();
        return true;
    }
    if (!audio_ || !audio_->isStreamOpen()) {
        useVst2_.store(false, std::memory_order_release);
        vst2Host_.reset();
        if (error) error->clear();
        return true;
    }
    // Quiesce the callback before destroying the native plug-in instance.
    useVst2_.store(false, std::memory_order_release);
    try {
        if (audio_->isStreamRunning()) {
            const auto stopped = audio_->stopStream();
            if (stopped != RTAUDIO_NO_ERROR) {
                useVst2_.store(true, std::memory_order_release);
                if (error) *error = "RtAudio gagal berhenti sementara; plugin tetap aktif.";
                return false;
            }
        }
    } catch (const std::exception &ex) {
        useVst2_.store(true, std::memory_order_release);
        if (error) *error = std::string("Gagal menghentikan callback audio: ") + ex.what();
        return false;
    } catch (...) {
        useVst2_.store(true, std::memory_order_release);
        if (error) *error = "Gagal menghentikan callback audio.";
        return false;
    }
    vst2Host_.reset();
    try {
        const auto started = audio_->startStream();
        if (started != RTAUDIO_NO_ERROR) {
            if (error) *error = "Plugin dilepas, tetapi RtAudio gagal berjalan kembali: " + audio_->getErrorText();
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Plugin dilepas, tetapi RtAudio gagal berjalan kembali: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Plugin dilepas, tetapi RtAudio gagal berjalan kembali.";
        return false;
    }
    if (error) error->clear();
    return true;
}

const std::string &AudioEngine::vst2PluginName() const noexcept {
    static const std::string empty;
    return vst2Host_ ? vst2Host_->pluginName() : empty;
}

void AudioEngine::processQueuedCommands(std::uint64_t blockStartTimeUs,
                                       std::uint64_t blockEndTimeUs,
                                       unsigned int frameCount) noexcept {
    callbackTimedMidiCount_ = 0;
    Command command;
    while (dequeue(command)) {
        if (!isCurrentStyleCommand(command)) continue;
        if ((command.type == CommandType::Midi || command.type == CommandType::XgEffectParameter) &&
            command.targetTimeUs != 0) {
            if (pendingTimedMidiCount_ < pendingTimedMidi_.size()) {
                pendingTimedMidi_[pendingTimedMidiCount_++] = command;
            } else {
                // Record the loss of sample-accurate timing if the bounded deadline
                // scheduler saturates. The note is still delivered immediately.
                acmp_trace::Trace::instance().recordAudio(
                    acmp_trace::Stage::AudioFallback, blockStartTimeUs, command.targetTimeUs, -1,
                    command.status, command.data1, command.data2,
                    static_cast<std::uint32_t>(pendingTimedMidiCount_), 1,
                    "timed MIDI scheduler full; command applied immediately");
                command.targetTimeUs = 0;
                applyCommand(command);
            }
        } else {
            if (command.type == CommandType::Midi) {
                acmp_trace::Trace::instance().recordAudio(
                    acmp_trace::Stage::AudioApply, blockStartTimeUs, 0, -1,
                    command.status, command.data1, command.data2, 0, 1,
                    "immediate MIDI command applied at audio block start");
            }
            applyCommand(command);
        }
    }

    // Extract only events whose target falls in this audio block. Events are
    // retained when their target lies beyond the block boundary.
    std::size_t retained = 0;
    for (std::size_t i = 0; i < pendingTimedMidiCount_; ++i) {
        const Command pending = pendingTimedMidi_[i];
        if (!isCurrentStyleCommand(pending)) continue;
        if (pending.targetTimeUs <= blockEndTimeUs && callbackTimedMidiCount_ < callbackTimedMidi_.size()) {
            std::uint64_t offsetFrames = 0;
            if (pending.targetTimeUs > blockStartTimeUs && sampleRate_ > 0) {
                offsetFrames = ((pending.targetTimeUs - blockStartTimeUs) * sampleRate_) / 1'000'000ULL;
            }
            if (frameCount > 0) offsetFrames = std::min<std::uint64_t>(offsetFrames, frameCount - 1);
            std::size_t insertAt = callbackTimedMidiCount_;
            while (insertAt > 0 && callbackMidiOffsets_[insertAt - 1] > offsetFrames) {
                callbackTimedMidi_[insertAt] = callbackTimedMidi_[insertAt - 1];
                callbackMidiOffsets_[insertAt] = callbackMidiOffsets_[insertAt - 1];
                --insertAt;
            }
            callbackTimedMidi_[insertAt] = pending;
            callbackMidiOffsets_[insertAt] = static_cast<std::uint32_t>(offsetFrames);
            ++callbackTimedMidiCount_;
        } else {
            pendingTimedMidi_[retained++] = pending;
        }
    }
    pendingTimedMidiCount_ = retained;
}

void AudioEngine::applyCommand(const Command &command) noexcept {
    const bool vstActive = useVst2_.load(std::memory_order_acquire) && static_cast<bool>(vst2Host_);
    const bool nativeActive = useNativeScva_.load(std::memory_order_acquire)
#if ENSEMBLES_HAS_NATIVE_SCVA
        && static_cast<bool>(nativeScva_)
#endif
        ;
    const bool yamahaActive = useSyxg2006LeNative_.load(std::memory_order_acquire) &&
                              static_cast<bool>(syxg2006LeNative_);
    const bool lsGmActive = useLsGmNative_.load(std::memory_order_acquire) && static_cast<bool>(nativeSf2_);
    // Selected native instruments own the output exclusively.
    const bool isSf2DspCommand = command.type == CommandType::Reverb ||
        command.type == CommandType::Chorus || command.type == CommandType::Delay ||
        command.type == CommandType::StyleEffects || command.type == CommandType::ClearStyleEffects ||
        command.type == CommandType::StyleTempo || command.type == CommandType::XgEffectParameter;
    if (!synth_ && !vstActive && !nativeActive && !yamahaActive && !lsGmActive && !isSf2DspCommand) return;
    switch (command.type) {
    case CommandType::Midi: applyMidi(command); break;
    case CommandType::Gain:
        if (yamahaActive && syxg2006LeNative_) syxg2006LeNative_->setMasterGain(command.gain);
        if (lsGmActive && nativeSf2_) nativeSf2_->setMasterGain(std::clamp(command.gain / 0.6f, 0.0f, 1.0f));
        if (synth_ && !yamahaActive && !lsGmActive)
            fluid_synth_set_gain(synth_, command.gain * kFluidSynthGainCalibration);
        if (vstActive && !yamahaActive && !lsGmActive) vst2Host_->setGain(command.gain / 0.6f);
#if ENSEMBLES_HAS_NATIVE_SCVA
        if (nativeActive && nativeScva_ && !lsGmActive) nativeScva_->setMasterGain(command.gain);
#endif
        break;
    case CommandType::Reverb:
        applyReverb(command.enabled, command.value);
        break;
    case CommandType::Chorus:
        applyChorus(command.enabled, command.value);
        break;
    case CommandType::Delay:
        applyDelay(command.enabled, command.value);
        break;
    case CommandType::StyleEffects:
        if (command.styleEffectProfile)
            sf2EffectsDsp_.setStyleProfile(*command.styleEffectProfile, command.value);
        break;
    case CommandType::ClearStyleEffects:
        sf2EffectsDsp_.clearStyleProfile();
        break;
    case CommandType::StyleTempo:
        sf2EffectsDsp_.setTempoBpm(command.value);
        break;
    case CommandType::XgEffectParameter:
        sf2EffectsDsp_.applyXgParameterChange(command.xgEffectAddress,
            command.xgEffectData, command.xgEffectDataLength);
        break;
    case CommandType::SysEx:
#if ENSEMBLES_HAS_NATIVE_SCVA
        if (nativeActive && nativeScva_ && command.sysexLength > 0)
            nativeScva_->sendSysEx(std::span<const std::uint8_t>(command.sysex.data(), command.sysexLength));
#endif
        break;
    case CommandType::AllSoundsOff:
        sf2EffectsDsp_.resetActiveNotes();
        xgPartManager_.allSoundsOff();
        if (yamahaActive && syxg2006LeNative_) syxg2006LeNative_->allSoundsOff();
        if (lsGmActive && nativeSf2_) nativeSf2_->allSoundsOff();
        if (synth_ && !vstActive && !nativeActive && !yamahaActive && !lsGmActive) fluid_synth_all_sounds_off(synth_, -1);
#if ENSEMBLES_HAS_NATIVE_SCVA
        if (nativeActive && nativeScva_) nativeScva_->allSoundsOff();
#endif
        if (vstActive) {
            for (int ch = 0; ch < 16; ++ch) {
                vst2Host_->queueMidi(static_cast<std::uint8_t>(0xB0 | ch), 120, 0, ch);
                vst2Host_->queueMidi(static_cast<std::uint8_t>(0xB0 | ch), 123, 0, ch);
            }
        }
        break;
    }
}

void AudioEngine::applyMidi(const Command &command) noexcept {
    const int midiChannel = static_cast<int>(command.status & 0x0f);
    const int routedChannel = command.channelOverride >= 0
        ? command.channelOverride : midiChannel;

    const bool nativeSf2Active = useLsGmNative_.load(std::memory_order_acquire) &&
                                 static_cast<bool>(nativeSf2_);
    const bool fluidSf2Active = synth_ && soundFontId_ >= 0 &&
        !useVst2_.load(std::memory_order_acquire) &&
        !useNativeScva_.load(std::memory_order_acquire) &&
        !useSyxg2006LeNative_.load(std::memory_order_acquire) && !nativeSf2Active;
    const std::uint8_t midiType = static_cast<std::uint8_t>(command.status & 0xF0u);
    if (midiType == 0xB0u &&
        (command.data1 == 91u || command.data1 == 93u || command.data1 == 94u))
        sf2EffectsDsp_.setChannelSend(routedChannel, command.data1, command.data2);
    if (midiType == 0x90u && command.data2 > 0u)
        sf2EffectsDsp_.setNoteActive(routedChannel, command.data1, true);
    else if (midiType == 0x80u || (midiType == 0x90u && command.data2 == 0u))
        sf2EffectsDsp_.setNoteActive(routedChannel, command.data1, false);
    std::uint8_t effectiveData2 = command.data2;
    if (command.styleMidi && (nativeSf2Active || fluidSf2Active) &&
        (command.status & 0xf0) == 0xb0) {
        effectiveData2 = audio::compensateStyleSf2Controller(command.data1, command.data2);
    }

    if (nativeSf2Active) {
        const int type = command.status & 0xf0;
        const int channel = routedChannel;
        if (channel < 0 || channel >= 64) return;
        switch (type) {
        case 0x80: nativeSf2_->noteOff(channel, command.data1); break;
        case 0x90:
            if (command.data2 == 0) nativeSf2_->noteOff(channel, command.data1);
            else nativeSf2_->noteOn(channel, command.data1, command.data2);
            break;
        case 0xB0: nativeSf2_->controlChange(channel, command.data1, effectiveData2); break;
        case 0xC0: nativeSf2_->programChange(channel, command.data1); break;
        case 0xE0: nativeSf2_->pitchBend(channel, static_cast<std::uint16_t>(command.data1 | (command.data2 << 7))); break;
        default: break;
        }
        return; // LS-GM is the exclusive renderer; do not mirror to FluidSynth/VST/SCVA.
    }

    // The Yamaha XG engine has exactly sixteen MIDI parts. Ensembles may use
    // FluidSynth-only channel overrides 16..63 for keyboard layers, but those
    // overrides must not push Yamaha MIDI outside its sixteen channel map.
    // For Yamaha, the channel encoded in the MIDI status byte is authoritative.
    if (useSyxg2006LeNative_.load(std::memory_order_acquire) && syxg2006LeNative_) {
        const XgMidiEvent event{command.status, command.data1, command.data2, -1};
        (void)xgPartManager_.apply(event);
        (void)syxg2006LeNative_->dispatch(event,
            xgPartManager_.part(static_cast<std::size_t>(midiChannel)), nullptr);
        return; // Yamaha is the sole selected renderer; never mirror to SCVA/VST/FluidSynth.
    }

    if (routedChannel >= 0 && routedChannel < static_cast<int>(XgPartManager::kPartCount)) {
        (void)xgPartManager_.apply(XgMidiEvent{
            command.status, command.data1, command.data2,
            static_cast<std::int16_t>(command.channelOverride)});
    }
    if (useVst2_.load(std::memory_order_acquire) && vst2Host_) {
        vst2Host_->queueMidi(command.status, command.data1, command.data2, command.channelOverride);
        return; // Never mirror normal VST2 MIDI into FluidSynth.
    }
#if ENSEMBLES_HAS_NATIVE_SCVA
    if (useNativeScva_.load(std::memory_order_acquire) && nativeScva_) {
        nativeScva_->sendMidi(command.status, command.data1, command.data2, command.channelOverride);
        return;
    }
#endif
    if (!synth_) return;
    const int messageType = command.status & 0xf0;
    const int channel = routedChannel;
    if (channel < 0 || channel >= 64) return;

    // Yamaha RHY1/RHY2 are routed to private FluidSynth channels 40/41. They
    // are not GM channel 10, so FluidSynth will not automatically select its
    // percussion bank. Stage CC0/CC32 per private channel and commit the SF2
    // drum preset only when Program Change arrives.
    const int drumSlot = channel == 40 ? 0 : (channel == 41 ? 1 : -1);
    if (drumSlot >= 0) {
        const auto slot = static_cast<std::size_t>(drumSlot);
        if (messageType == 0xb0) {
            if (command.data1 == 0) {
                fluidDrumBankMsb_[slot] = static_cast<std::uint8_t>(command.data2 & 0x7fU);
                return;
            }
            if (command.data1 == 32) {
                fluidDrumBankLsb_[slot] = static_cast<std::uint8_t>(command.data2 & 0x7fU);
                return;
            }
            if (command.data1 == 121) {
                fluidDrumBankMsb_[slot] = 0;
                fluidDrumBankLsb_[slot] = 0;
            }
            fluid_synth_cc(synth_, channel, command.data1, effectiveData2);
            return;
        }
        if (messageType == 0xc0) {
            const auto requestedBank = static_cast<std::uint16_t>(
                (static_cast<std::uint16_t>(fluidDrumBankMsb_[slot]) << 7) |
                static_cast<std::uint16_t>(fluidDrumBankLsb_[slot]));
            const auto resolvedBank = sf2::resolveDrumBank(
                fluidSf2Presets_, requestedBank, command.data1);
            if (resolvedBank) {
                (void)fluid_synth_program_select(synth_, channel, soundFontId_, *resolvedBank,
                                                 static_cast<int>(command.data1));
            }
            return; // Never let RHY1/RHY2 fall through to a melodic bank.
        }
    }

    switch (messageType) {
    case 0x80:
        fluid_synth_noteoff(synth_, channel, command.data1);
        break;
    case 0x90:
        if (command.data2 == 0) fluid_synth_noteoff(synth_, channel, command.data1);
        else fluid_synth_noteon(synth_, channel, command.data1, command.data2);
        break;
    case 0xa0:
        fluid_synth_key_pressure(synth_, channel, command.data1, command.data2);
        break;
    case 0xb0:
        fluid_synth_cc(synth_, channel, command.data1, effectiveData2);
        break;
    case 0xc0:
        fluid_synth_program_change(synth_, channel, command.data1);
        break;
    case 0xd0:
        fluid_synth_channel_pressure(synth_, channel, command.data1);
        break;
    case 0xe0:
        fluid_synth_pitch_bend(synth_, channel,
            static_cast<int>(command.data1) | (static_cast<int>(command.data2) << 7));
        break;
    default:
        // SysEx/system messages are not represented by short MIDI events.
        break;
    }
}

void AudioEngine::applyReverb(bool enabled, int level) noexcept {
    sf2EffectsDsp_.setMasterReverb(enabled, level);
}

void AudioEngine::applyChorus(bool enabled, int level) noexcept {
    sf2EffectsDsp_.setMasterChorus(enabled, level);
}

void AudioEngine::applyDelay(bool enabled, int level) noexcept {
    sf2EffectsDsp_.setMasterDelay(enabled, level);
}

bool AudioEngine::playTestTone(double frequencyHz, float amplitude,
                               unsigned int durationMs, std::string *error) {
    if (!isReady() || !audio_) {
        if (error) *error = "RtAudio belum siap; test output tidak dapat dijalankan.";
        return false;
    }
    try {
        if (!audio_->isStreamOpen() || !audio_->isStreamRunning()) {
            if (error) *error = "RtAudio stream tidak sedang berjalan.";
            return false;
        }
    } catch (const std::exception &ex) {
        if (error) *error = std::string("Tidak dapat memeriksa RtAudio stream: ") + ex.what();
        return false;
    } catch (...) {
        if (error) *error = "Tidak dapat memeriksa RtAudio stream.";
        return false;
    }
    if (sampleRate_ == 0) {
        if (error) *error = "Sample rate RtAudio tidak valid.";
        return false;
    }
    frequencyHz = std::clamp(frequencyHz, 20.0, static_cast<double>(sampleRate_) * 0.45);
    amplitude = std::clamp(amplitude, 0.01f, 0.30f);
    durationMs = std::clamp(durationMs, 100u, 5000u);
    const auto frames = std::max<std::uint64_t>(1,
        (static_cast<std::uint64_t>(sampleRate_) * durationMs) / 1000u);
    testToneFrequencyHz_.store(frequencyHz, std::memory_order_relaxed);
    testToneAmplitude_.store(amplitude, std::memory_order_relaxed);
    testToneFramesRemaining_.store(frames, std::memory_order_release);
    if (error) error->clear();
    return true;
}

void AudioEngine::mixTestTone(float *output, unsigned int frameCount) noexcept {
    if (!output || frameCount == 0) return;
    std::uint64_t remaining = testToneFramesRemaining_.load(std::memory_order_acquire);
    std::uint64_t framesToMix = 0;
    while (remaining > 0) {
        framesToMix = std::min<std::uint64_t>(remaining, frameCount);
        if (testToneFramesRemaining_.compare_exchange_weak(
                remaining, remaining - framesToMix,
                std::memory_order_acq_rel, std::memory_order_acquire)) {
            break;
        }
        framesToMix = 0;
    }
    if (framesToMix == 0) return;

    const double frequency = testToneFrequencyHz_.load(std::memory_order_relaxed);
    const float amplitude = testToneAmplitude_.load(std::memory_order_relaxed);
    const double phaseStep = (6.28318530717958647692 * frequency) /
                             static_cast<double>(sampleRate_);
    double phase = testTonePhase_;
    const auto count = static_cast<std::size_t>(framesToMix);
    for (std::size_t i = 0; i < count; ++i) {
        const float sample = amplitude * static_cast<float>(std::sin(phase));
        output[2 * i] += sample;
        output[2 * i + 1] += sample;
        phase += phaseStep;
        if (phase >= 6.28318530717958647692) phase -= 6.28318530717958647692;
    }
    testTonePhase_ = phase;
}

int AudioEngine::audioCallback(void *outputBuffer, void *inputBuffer,
                               unsigned int frameCount, double streamTime,
                               RtAudioStreamStatus status, void *userData) {
    (void)inputBuffer;
    (void)streamTime;
    (void)status;
    auto *self = static_cast<AudioEngine *>(userData);
    auto *output = static_cast<float *>(outputBuffer);
    if (!self || !output) return 1;
    std::fill_n(output, static_cast<std::size_t>(frameCount) * 2, 0.0f);
#if ENSEMBLES_HAS_NATIVE_SCVA
    const bool nativeActive = self->useNativeScva_.load(std::memory_order_acquire) && static_cast<bool>(self->nativeScva_);
#else
    const bool nativeActive = false;
#endif
    const bool yamahaActive = self->useSyxg2006LeNative_.load(std::memory_order_acquire) &&
                              static_cast<bool>(self->syxg2006LeNative_);
    const bool lsGmActive = self->useLsGmNative_.load(std::memory_order_acquire) && static_cast<bool>(self->nativeSf2_);
    if (!self->synth_ && !self->vst2Host_ && !nativeActive && !yamahaActive && !lsGmActive) {
        self->mixTestTone(output, frameCount);
        return 0;
    }
    if (frameCount > static_cast<unsigned int>(std::numeric_limits<int>::max())) return 2;

    const std::uint64_t blockStartTimeUs = steadyClockMicroseconds();
    const std::uint64_t blockDurationUs = self->sampleRate_ > 0
        ? (static_cast<std::uint64_t>(frameCount) * 1'000'000ULL) / self->sampleRate_
        : 0;
    const std::uint64_t blockEndTimeUs = blockStartTimeUs + blockDurationUs;
    self->processQueuedCommands(blockStartTimeUs, blockEndTimeUs, frameCount);

    if (yamahaActive && self->syxg2006LeNative_) {
        if (self->callbackTimedMidiCount_ > 0) {
            std::size_t cursor = 0;
            std::size_t eventIndex = 0;
            while (eventIndex < self->callbackTimedMidiCount_) {
                const std::size_t targetOffset = std::min<std::size_t>(
                    self->callbackMidiOffsets_[eventIndex], frameCount);
                if (targetOffset > cursor) {
                    (void)self->syxg2006LeNative_->render(output + cursor * 2, targetOffset - cursor);
                    cursor = targetOffset;
                }
                while (eventIndex < self->callbackTimedMidiCount_ &&
                       self->callbackMidiOffsets_[eventIndex] == targetOffset) {
                    const Command &scheduled = self->callbackTimedMidi_[eventIndex];
                    if (self->isCurrentStyleCommand(scheduled)) self->applyCommand(scheduled);
                    ++eventIndex;
                }
            }
            if (cursor < frameCount)
                (void)self->syxg2006LeNative_->render(output + cursor * 2, frameCount - cursor);
        } else {
            (void)self->syxg2006LeNative_->render(output, frameCount);
        }
        applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
        self->mixTestTone(output, frameCount);
        return 0;
    }

    if (lsGmActive && self->nativeSf2_) {
        if (self->callbackTimedMidiCount_ > 0) {
            std::size_t cursor = 0;
            std::size_t eventIndex = 0;
            while (eventIndex < self->callbackTimedMidiCount_) {
                const std::size_t targetOffset = std::min<std::size_t>(self->callbackMidiOffsets_[eventIndex], frameCount);
                if (targetOffset > cursor) {
                    self->nativeSf2_->render(output + cursor * 2, targetOffset - cursor, true);
                    self->sf2EffectsDsp_.process(output + cursor * 2, targetOffset - cursor);
                    cursor = targetOffset;
                }
                while (eventIndex < self->callbackTimedMidiCount_ && self->callbackMidiOffsets_[eventIndex] == targetOffset) {
                    const Command &scheduled = self->callbackTimedMidi_[eventIndex];
                    if (self->isCurrentStyleCommand(scheduled)) self->applyCommand(scheduled);
                    ++eventIndex;
                }
            }
            if (cursor < frameCount) {
                self->nativeSf2_->render(output + cursor * 2, frameCount - cursor, true);
                self->sf2EffectsDsp_.process(output + cursor * 2, frameCount - cursor);
            }
        } else {
            self->nativeSf2_->render(output, frameCount, false);
            self->sf2EffectsDsp_.process(output, frameCount);
        }
        applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
        self->mixTestTone(output, frameCount);
        return 0;
    }

    if (self->useVst2_.load(std::memory_order_acquire) && self->vst2Host_) {
        for (std::size_t i = 0; i < self->callbackTimedMidiCount_; ++i) {
            const Command &cmd = self->callbackTimedMidi_[i];
            if (cmd.type != CommandType::Midi || !self->isCurrentStyleCommand(cmd)) continue;
            const auto offsetFrames = self->callbackMidiOffsets_[i];
            const auto estimatedApplyUs = blockStartTimeUs + (self->sampleRate_ > 0
                ? (static_cast<std::uint64_t>(offsetFrames) * 1'000'000ULL) / self->sampleRate_ : 0);
            acmp_trace::Trace::instance().recordAudio(
                acmp_trace::Stage::AudioApply, estimatedApplyUs, cmd.targetTimeUs, -1,
                cmd.status, cmd.data1, cmd.data2, offsetFrames, 1,
                "VST MIDI queued with sample offset");
            self->vst2Host_->queueMidi(cmd.status, cmd.data1, cmd.data2, cmd.channelOverride,
                                      static_cast<int>(offsetFrames));
        }
        // VST2 owns the output while selected, including silent/error blocks.
        // Each scheduled event carries its sample offset rather than being flattened
        // to frame zero of the callback.
        (void)self->vst2Host_->process(output, frameCount);
        applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
        self->mixTestTone(output, frameCount);
        return 0;
    }

    // For sample-accurate scheduled MIDI, render up to each event, apply it on
    // the audio thread at that exact frame, then continue rendering the block.
    if (self->callbackTimedMidiCount_ > 0) {
        std::size_t cursor = 0;
        std::size_t eventIndex = 0;
        while (eventIndex < self->callbackTimedMidiCount_) {
            const std::size_t targetOffset = std::min<std::size_t>(self->callbackMidiOffsets_[eventIndex], frameCount);
            if (targetOffset > cursor) {
#if ENSEMBLES_HAS_NATIVE_SCVA
                if (nativeActive && self->nativeScva_) {
                    self->nativeScva_->render(output + cursor * 2, targetOffset - cursor, self->sampleRate_);
                } else
#endif
                if (self->synth_) {
                    float *segment = output + cursor * 2;
                    if (fluid_synth_write_float(self->synth_, static_cast<int>(targetOffset - cursor),
                                                segment, 0, 2, segment, 1, 2) != FLUID_OK) {
                        std::fill_n(segment, (targetOffset - cursor) * 2, 0.0f);
                    }
                    if (!nativeActive) self->sf2EffectsDsp_.process(segment, targetOffset - cursor);
                }
                cursor = targetOffset;
            }
            // Multiple MIDI events can intentionally share the same sample.
            while (eventIndex < self->callbackTimedMidiCount_ &&
                   self->callbackMidiOffsets_[eventIndex] == targetOffset) {
                const Command& cmd = self->callbackTimedMidi_[eventIndex];
                const auto estimatedApplyUs = blockStartTimeUs + (self->sampleRate_ > 0
                    ? (static_cast<std::uint64_t>(targetOffset) * 1'000'000ULL) / self->sampleRate_ : 0);
                acmp_trace::Trace::instance().recordAudio(
                    acmp_trace::Stage::AudioApply, estimatedApplyUs, cmd.targetTimeUs, -1,
                    cmd.status, cmd.data1, cmd.data2, static_cast<std::uint32_t>(targetOffset), 1,
                    nativeActive ? "NativeSCVA scheduled event sample offset" : "FluidSynth scheduled event sample offset");
                if (self->isCurrentStyleCommand(cmd)) self->applyCommand(cmd);
                ++eventIndex;
            }
        }
        if (cursor < frameCount) {
#if ENSEMBLES_HAS_NATIVE_SCVA
            if (nativeActive && self->nativeScva_) {
                self->nativeScva_->render(output + cursor * 2, frameCount - cursor, self->sampleRate_);
            } else
#endif
            if (self->synth_) {
                float *segment = output + cursor * 2;
                if (fluid_synth_write_float(self->synth_, static_cast<int>(frameCount - cursor),
                                            segment, 0, 2, segment, 1, 2) != FLUID_OK) {
                    std::fill_n(segment, (frameCount - cursor) * 2, 0.0f);
                }
                if (!nativeActive) self->sf2EffectsDsp_.process(segment, frameCount - cursor);
            }
        }
        applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
        self->mixTestTone(output, frameCount);
        return 0;
    }

#if ENSEMBLES_HAS_NATIVE_SCVA
    if (nativeActive && self->nativeScva_) {
        self->nativeScva_->render(output, static_cast<std::size_t>(frameCount), self->sampleRate_);
        applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
        self->mixTestTone(output, frameCount);
        return 0;
    }
#endif
    if (!self->synth_) {
        self->mixTestTone(output, frameCount);
        return 0;
    }
    // FluidSynth supports interleaved stereo by using the same buffer with
    // left/right offsets 0/1 and strides of two samples.
    if (fluid_synth_write_float(self->synth_, static_cast<int>(frameCount),
                                output, 0, 2, output, 1, 2) != FLUID_OK) {
        std::fill_n(output, static_cast<std::size_t>(frameCount) * 2, 0.0f);
        self->mixTestTone(output, frameCount);
        return 0;
    }
    self->sf2EffectsDsp_.process(output, frameCount);
    applyOutputSoftLimiter(output, static_cast<std::size_t>(frameCount) * 2);
    self->mixTestTone(output, frameCount);
    return 0;
}

} // namespace ensembles
