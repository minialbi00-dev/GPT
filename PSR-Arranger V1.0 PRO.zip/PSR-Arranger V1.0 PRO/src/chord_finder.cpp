/*
 * Copyright 2020-2022 Subhadeep Jasu <subhajasu@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "chord_finder.h"
#include "genos_chord_control.hpp"

#include <limits>
#include <array>

int key_track[13];
int chord_possibility[144];

/*
 * The original score formulas index pitch classes both below zero and above
 * eleven. Directly indexing key_track with those values is undefined behavior
 * (the source snapshot declared only 13 entries). Keep its chord scoring
 * formulas, but normalize every pitch-class lookup to the 12-note chromatic
 * ring so scores are deterministic and memory-safe.
 */
static int key_at(int semitone)
{
    int pitch_class = semitone % 12;
    if (pitch_class < 0) pitch_class += 12;
    return key_track[pitch_class];
}

int
chord_finder_infer (int key, int on, int* type)
{
    key_track [key % 12] = ((on == 144) ? 1 : 0);

    int n_keys = 0;
    int probable_root = -1;
    for (int i = 0; i < 12; i++)
    {
        n_keys += key_at(i);
        if (probable_root < 0 && key_at(i))
        {
            probable_root = i;
        }
    }
    // printf("\n");
    for (int i = 0; i < 144; i++)
    {
        chord_possibility[i] = 0;
    }

    int i = 0;

    if (n_keys < 4)
    {
        // Major
        for (; i < 5; i++)
        {
            chord_possibility [i] = 6 * key_at(i) + key_at(i + 4) + key_at(i + 7); // One way to play it
        }
        /*                           ^
         *                           |
         *                           |
         *                       Root contribution
         */
        for (; i < 9; i++)
        {
            chord_possibility [i] = key_at(i - 5) + 6 * key_at(i) + key_at(i + 4); // Another way to play it
        }
        for (; i < 12; i++)
        {
            chord_possibility [i] = key_at(i - 8) + key_at(i - 5) + 6 * key_at(i); // Yet another way to play it
        }

        // minor
        for (; i < 17; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 12) + key_at(i - 12 + 3) + key_at(i - 12 + 7);
        }
        for (; i < 21; i++)
        {
            chord_possibility [i] = key_at(i - 12 - 5) + 6 * key_at(i - 12) + key_at(i - 12 + 3);
        }
        for (; i < 24; i++)
        {
            chord_possibility [i] = key_at(i - 12 - 9) + key_at(i - 12 - 5) + 6 * key_at(i - 12);
        }

        // diminished
        for (; i < 29; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 24) + key_at(i - 24 + 3) + key_at(i - 24 + 6);
        }
        for (; i < 33; i++)
        {
            chord_possibility [i] = key_at(i - 24 + 6) + 6 * key_at(i - 24) + key_at(i - 24 + 3);
        }
        for (; i < 36; i++)
        {
            chord_possibility [i] = key_at(i - 24 - 9) + key_at(i - 24 - 6) + 6 * key_at(i - 24);
        }

        // suspended 2
        for (; i < 41; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 36) + key_at(i - 36 + 2) + key_at(i - 36 + 7);
        }
        for (; i < 45; i++)
        {
            chord_possibility [i] = key_at(i - 36 - 5) + 6 * key_at(i - 36) + key_at(i - 36 + 2);
        }
        for (; i < 48; i++)
        {
            chord_possibility [i] = key_at(i - 36 - 10) + key_at(i - 36 - 5) + 6 * key_at(i - 36);
        }

        // suspended 4
        for (; i < 53; i++)
        {
            chord_possibility [i] = (i - 48 == probable_root && n_keys > 2 ? 7 : 6) * key_at(i - 48) + key_at(i - 48 + 5) + key_at(i - 48 + 7);
        }
        for (; i < 57; i++)
        {
            chord_possibility [i] = key_at(i - 48 - 5) + (i - 48 == probable_root && n_keys > 2 ? 7 : 6) * key_at(i - 48) + key_at(i - 48 + 5);
        }
        for (; i < 60; i++)
        {
            chord_possibility [i] = key_at(i - 48 - 7) + key_at(i - 48 - 5) + (i - 48 == probable_root && n_keys > 2 ? 7 : 6) * key_at(i - 48);
        }

        // augmented
        for (; i < 65; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 60) + key_at(i - 60 + 4) + key_at(i - 60 + 8);
        }
        for (; i < 69; i++)
        {
            chord_possibility [i] = key_at(i - 60 - 4) + 6 * key_at(i - 60) + key_at(i - 60 + 4);
        }
        for (; i < 72; i++)
        {
            chord_possibility [i] = key_at(i - 60 - 8) + key_at(i - 60 - 4) + 6 * key_at(i - 60);
        }
    }
    else if (n_keys == 4)
    {
        // Dominant Sixth
        for (i = 72; i < 77; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 72) + key_at(i - 72 + 4) + key_at(i - 72 + 7) + key_at(i - 72 + 9);
        }
        for (; i < 81; i++)
        {
            chord_possibility [i] = key_at(i - 72 - 5) + key_at(i - 72 - 3) + 6 * key_at(i - 72) + key_at(i - 72 + 4);
        }
        for (; i < 84; i++)
        {
            chord_possibility [i] = key_at(i - 72 - 8) + key_at(i - 72 - 5) + key_at(i - 72 - 3) + 6 * key_at(i - 72);
        }

        // Dominant Seventh
        for (; i < 89; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 84) + key_at(i - 84 + 4) + key_at(i - 84 + 7) + key_at(i - 84 + 10);
        }
        for (; i < 93; i++)
        {
            chord_possibility [i] = key_at(i - 84 - 5) + key_at(i - 84 - 2) + 6 * key_at(i - 84) + key_at(i - 84 + 4);
        }
        for (; i < 96; i++)
        {
            chord_possibility [i] = key_at(i - 84 - 8) + key_at(i - 84 - 5) + key_at(i - 84 - 2) + 6 * key_at(i - 84);
        }

        // Major Seventh
        for (; i < 101; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 96) + key_at(i - 96 + 4) + key_at(i - 96 + 7) + key_at(i - 96 + 11);
        }
        for (; i < 105; i++)
        {
            chord_possibility [i] = key_at(i - 96 - 5) + key_at(i - 96 - 1) + 6 * key_at(i - 96) + key_at(i - 96 + 4);
        }
        for (; i < 108; i++)
        {
            chord_possibility [i] = key_at(i - 96 - 8) + key_at(i - 96 - 5) + key_at(i - 96 - 1) + 6 * key_at(i - 96);
        }

        // minor seventh
        for (; i < 113; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 108) + key_at(i - 108 + 3) + key_at(i - 108 + 7) + key_at(i - 108 + 10);
        }
        for (; i < 117; i++)
        {
            chord_possibility [i] = key_at(i - 108 - 5) + key_at(i - 108 - 2) + 6 * key_at(i - 108) + key_at(i - 108 + 3);
        }
        for (; i < 120; i++)
        {
            chord_possibility [i] = key_at(i - 108 - 9) + key_at(i - 108 - 5) + key_at(i - 108 - 2) + 6 * key_at(i - 108);
        }

        // add9
        for (; i < 125; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 120) + key_at(i - 120 + 4) + key_at(i - 120 + 7) + key_at(i - 120 + 2);
        }
        for (; i < 129; i++)
        {
            chord_possibility [i] = key_at(i - 120 - 5) + key_at(i - 120  + 2) + 6 * key_at(i - 120) + key_at(i - 120 + 4);
        }
        for (; i < 132; i++)
        {
            chord_possibility [i] = key_at(i - 120 - 8) + key_at(i - 120 - 5) + key_at(i - 120 - 10) + 6 * key_at(i - 120);
        }
    }
    else if (n_keys == 5)
    {
        // Dominant 9th
        for (; i < 137; i++)
        {
            chord_possibility [i] = 6 * key_at(i - 132) + key_at(i - 132 + 4) + key_at(i - 132 + 7) + key_at(i - 132 + 10) + key_at(i - 132 + 2);
        }
        for (; i < 141; i++)
        {
            chord_possibility [i] = key_at(i - 132 - 5) + key_at(i - 132 - 2) + key_at(i - 120  + 2) + 6 * key_at(i - 132) + key_at(i - 132 + 4);
        }
        for (; i < 144; i++)
        {
            chord_possibility [i] = key_at(i - 132 - 8) + key_at(i - 132 - 5) + key_at(i - 132 - 2) + 6 * key_at(i - 132) + key_at(i - 120 - 10);
        }
    }


    i = n_keys < 4 ? 0 : n_keys == 4 ? 72 : 132;
    int max_i = n_keys < 4 ? 72 : n_keys == 4 ? 132 : 144;
    int max = -1;
    int max_index = 0;
    for (; i < max_i; i++)
    {
        // printf("%d ", chord_possibility[i]);
        if (max < chord_possibility[i])
        {
            max = chord_possibility[i];
            max_index = i;
        }
    }
    if (on == 128)
    {
        return -6;
    }

    // Set the chord type
    if (max_index < 12)
    {
        *type = 0; // M
    }
    else if (max_index < 24)
    {
        *type = 1; // m
    }
    else if (max_index < 36)
    {
        *type = 2; // dim
    }
    else if (max_index < 48)
    {
        *type = 3; // sus2
    }
    else if (max_index < 60)
    {
        *type = 4; // sus4
    }
    else if (max_index < 72)
    {
        *type = 5; // aug
    }
    else if (max_index < 84)
    {
        *type = 6; // 6
    }
    else if (max_index < 96)
    {
        *type = 7; // 7
    }
    else if (max_index < 108)
    {
        *type = 8; // M7
    }
    else if (max_index < 120)
    {
        *type = 9; // m7
    }
    else if (max_index < 132)
    {
        *type = 10; // add9
    }
    else
    {
        *type = 11; // 9
    }

    // Return the root note
    if (max > 0)
    {
        if (max_index >= 0 && max_index <= 6)
        {
            return max_index;
        }
        else if (max_index >= 7 && max_index <= 18)
        {
            return max_index - 12;
        }
        else if (max_index >= 19 && max_index <= 30)
        {
            return max_index - 24;
        }
        else if (max_index >= 31 && max_index <= 42)
        {
            return max_index - 36;
        }
        else if (max_index >= 43 && max_index <= 54)
        {
            return max_index - 48;
        }
        else if (max_index >= 55 && max_index <= 66)
        {
            return max_index - 60;
        }
        else if (max_index >= 67 && max_index <= 78)
        {
            return max_index - 72;
        }
        else if (max_index >= 79 && max_index <= 90)
        {
            return max_index - 84;
        }
        else if (max_index >= 91 && max_index <= 102)
        {
            return max_index - 96;
        }
        else if (max_index >= 103 && max_index <= 114)
        {
            return max_index - 108;
        }
        else if (max_index >= 115 && max_index <= 126)
        {
            return max_index - 120;
        }
        else if (max_index >= 127 && max_index <= 138)
        {
            return max_index - 132;
        }
        else if (max_index >= 139 && max_index <= 156)
        {
            return max_index - 150;
        }
    }
    return -6;
}


namespace {
// Preserve MIDI note numbers as well as pitch classes: Genos distinguishes
// octave fingering (Chord Control ID 30) and slash-bass from the voicing.
constexpr int kGenosChordSourceCount = 17; // UI keyboard + MIDI channels 1..16.
std::array<std::array<std::uint16_t, 128>, kGenosChordSourceCount> genos_note_tracks{};

int normalized_source(int source) noexcept {
    return (source < 0 || source >= kGenosChordSourceCount) ? 0 : source;
}

constexpr unsigned short rotateChordMask(unsigned short mask, int root) {
    const unsigned value = static_cast<unsigned>(mask & 0x0FFFu);
    const unsigned shift = static_cast<unsigned>(root % 12);
    if (shift == 0u) return static_cast<unsigned short>(value);
    return static_cast<unsigned short>(((value << shift) | (value >> (12u - shift))) & 0x0FFFu);
}

int countBits12(unsigned value) {
    int count = 0;
    value &= 0x0FFFu;
    while (value) { count += static_cast<int>(value & 1u); value >>= 1u; }
    return count;
}


}

int chord_finder_classify_genos_mask(unsigned short pitch_class_mask, int* genos_chord_id)
{
    return chord_finder_classify_genos_mask(pitch_class_mask, -1, genos_chord_id);
}

int chord_finder_classify_genos_mask(unsigned short pitch_class_mask, int preferred_root, int* genos_chord_id)
{
    const unsigned short input = static_cast<unsigned short>(pitch_class_mask & 0x0FFFu);
    if (genos_chord_id) *genos_chord_id = 34;
    if (input == 0u) return -6;

    // A single pitch class is the standard Single Finger / Multi Finger major
    // fingering. Genos' octave-only ID 30 requires the note-number-aware path.
    if (countBits12(input) == 1) {
        for (int root = 0; root < 12; ++root) {
            if (input == static_cast<unsigned short>(1u << root)) {
                if (genos_chord_id) *genos_chord_id = 0;
                return root;
            }
        }
    }

    // Yamaha's Fingered-mode Chord Cancel fingering is 1+b2+2. It is not a
    // nearest ordinary chord and must never be promoted to a guessed triad.
    for (int root = 0; root < 12; ++root) {
        const unsigned short cancelMask = rotateChordMask(0x007u, root);
        if (input == cancelMask) {
            if (genos_chord_id) *genos_chord_id = 34;
            return -6;
        }
    }

    // Accept only a complete Yamaha chord template (mandatory tones present,
    // optional tones either present or absent, and no foreign pitch classes).
    // The old nearest-score policy turned transitional two-note fingerings
    // into unrelated chords such as C+E => Caug. Stale-note ownership is
    // handled by per-source Note-Off/reset tracking; incomplete fingering must
    // preserve the previous stable chord instead of guessing an extension.
    int bestRoot = -6;
    int bestId = 34;
    int bestRequiredCount = -1;
    bool found = false;
    for (int root = 0; root < 12; ++root) {
        for (const auto& chord : genos_chord_control::kTemplates) {
            const unsigned short required = rotateChordMask(chord.required, root);
            const unsigned short optional = rotateChordMask(chord.optional, root);
            const unsigned short allowed = static_cast<unsigned short>(required | optional);
            const bool missingRequired = (required & input) != required;
            const bool unexpected = (input & static_cast<unsigned short>(~allowed)) != 0u;
            if (missingRequired || unexpected) continue;

            const int requiredCount = countBits12(chord.required);
            const bool preferredRootTieBreak = found &&
                preferred_root >= 0 && preferred_root < 12 &&
                ((root == preferred_root) != (bestRoot == preferred_root));
            if (!found ||
                (preferredRootTieBreak && root == preferred_root) ||
                (!preferredRootTieBreak && requiredCount > bestRequiredCount) ||
                (!preferredRootTieBreak && requiredCount == bestRequiredCount && chord.id < bestId)) {
                found = true;
                bestRoot = root;
                bestId = chord.id;
                bestRequiredCount = requiredCount;
            }
        }
    }

    if (!found) return -6;
    if (genos_chord_id) *genos_chord_id = bestId;
    return bestRoot;
}

void chord_finder_clear_genos_notes(int source)
{
    if (source < 0) {
        for (auto& track : genos_note_tracks) track.fill(0u);
        for (int pc = 0; pc < 13; ++pc) key_track[pc] = 0;
        for (int i = 0; i < 144; ++i) chord_possibility[i] = 0;
        return;
    }
    if (source < kGenosChordSourceCount)
        genos_note_tracks[static_cast<std::size_t>(source)].fill(0u);
}

bool chord_finder_genos_note_is_held(int key, int source)
{
    if (key < 0 || key >= 128) return false;
    const auto note = static_cast<std::size_t>(key);
    if (source >= 0) {
        if (source >= kGenosChordSourceCount) return false;
        return genos_note_tracks[static_cast<std::size_t>(source)][note];
    }
    for (const auto& track : genos_note_tracks)
        if (track[note]) return true;
    return false;
}

int chord_finder_infer_genos(int key, int on, int* legacy_type, int* genos_chord_id,
                             int* bass_pc, int source)
{
    int legacy = 0;
    // Keep the legacy scoring state in sync for callers which still consume its
    // display/transform family. Its pitch-class-only state is not authoritative
    // for Genos chord IDs, octave fingering, or slash bass.
    (void)chord_finder_infer(key, on, &legacy);

    const int sourceIndex = normalized_source(source);
    if (key >= 0 && key < 128) {
        auto& held_count = genos_note_tracks[static_cast<std::size_t>(sourceIndex)]
            [static_cast<std::size_t>(key)];
        if (on == 144) {
            if (held_count < std::numeric_limits<std::uint16_t>::max()) ++held_count;
        } else if (held_count > 0u) {
            --held_count;
        }
    }

    unsigned short mask = 0;
    int lowestNote = 128;
    int pressedCount = 0;
    int firstNote = -1;
    int secondNote = -1;
    for (int pc = 0; pc < 12; ++pc) key_track[pc] = 0;
    for (int note = 0; note < 128; ++note) {
        bool held = false;
        for (const auto& track : genos_note_tracks)
            held = held || track[static_cast<std::size_t>(note)] > 0u;
        if (!held) continue;
        key_track[note % 12] = 1;
        if (lowestNote > note) lowestNote = note;
        if (firstNote < 0) firstNote = note;
        else if (secondNote < 0) secondNote = note;
        ++pressedCount;
        mask = static_cast<unsigned short>(mask | static_cast<unsigned short>(1u << (note % 12)));
    }

    if (pressedCount == 0) {
        if (legacy_type) *legacy_type = legacy;
        if (genos_chord_id) *genos_chord_id = 34; // Yamaha Chord Cancel
        if (bass_pc) *bass_pc = -1;
        return -6;
    }

    if (bass_pc) *bass_pc = lowestNote % 12;

    int genosId = 34;
    int root = -6;
    // Genos Chord Control ID 30 is the octave-only 1+8 fingering. The legacy
    // pitch-class mask necessarily collapses this to a single bit, so inspect
    // the actual MIDI key numbers before falling back to Major.
    if (pressedCount == 2 && firstNote >= 0 && secondNote >= 0 &&
        (secondNote - firstNote == 12 || firstNote - secondNote == 12) &&
        (firstNote % 12) == (secondNote % 12)) {
        root = firstNote % 12;
        genosId = 30;
    } else {
        root = chord_finder_classify_genos_mask(mask, lowestNote % 12, &genosId);
    }

    if (root < 0) {
        if (legacy_type) *legacy_type = legacy;
        if (genos_chord_id) *genos_chord_id = 34;
        return -6;
    }

    if (legacy_type) {
        for (const auto& chord : genos_chord_control::kTemplates) {
            if (chord.id == genosId) { *legacy_type = chord.legacy_type; break; }
        }
        if (genosId == 30) *legacy_type = 0;
    }
    if (genos_chord_id) *genos_chord_id = genosId;
    return root;
}
