#pragma once

// Opt-in, low-impact ACMP timing trace. Set ENSEMBLES_ACMP_TRACE=1 to enable.
// Producers only copy a fixed-size record into per-thread SPSC rings. A separate
// writer thread performs all file I/O, including when the audio callback records.

#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <thread>

namespace ensembles::acmp_trace {

enum class Stage : std::uint8_t {
    StyleLoad = 1,
    Section = 2,
    EngineDispatch = 3,
    OutputQueue = 4,
    AudioApply = 5,
    WinMmSend = 6,
    QueueDrop = 7,
    AudioFallback = 8,
    WinMmFallback = 9,
    TraceDrop = 10,
    ParserTickCorrection = 11
};

struct Record {
    std::uint64_t observedUs = 0;
    std::uint64_t targetUs = 0;
    std::int64_t styleTick = -1;
    std::int64_t sourceTick = -1;
    std::int32_t sourceTrack = -1;
    std::int32_t sourceFamily = -1;
    std::int32_t sourcePart = -1;
    std::int32_t sourceAdvanced = -1;
    std::uint32_t aux = 0;
    std::uint8_t stage = 0;
    std::uint8_t status = 0;
    std::uint8_t data1 = 0;
    std::uint8_t data2 = 0;
    std::uint8_t route = 0; // 0=not applicable, 1=internal audio, 2=WinMM, 3=both
    char text[80]{};
};

inline std::uint64_t monotonicNowUs() noexcept {
    const auto now = std::chrono::steady_clock::now().time_since_epoch();
    return static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(now).count());
}

template <std::size_t Capacity>
class SpscRing final {
public:
    bool push(const Record& record) noexcept {
        const auto head = head_.load(std::memory_order_relaxed);
        const auto next = (head + 1) % Capacity;
        if (next == tail_.load(std::memory_order_acquire)) return false;
        records_[head] = record;
        head_.store(next, std::memory_order_release);
        return true;
    }

    bool pop(Record& record) noexcept {
        const auto tail = tail_.load(std::memory_order_relaxed);
        if (tail == head_.load(std::memory_order_acquire)) return false;
        record = records_[tail];
        tail_.store((tail + 1) % Capacity, std::memory_order_release);
        return true;
    }

    bool empty() const noexcept {
        return tail_.load(std::memory_order_acquire) == head_.load(std::memory_order_acquire);
    }

private:
    std::array<Record, Capacity> records_{};
    alignas(64) std::atomic<std::size_t> head_{0};
    alignas(64) std::atomic<std::size_t> tail_{0};
};

class Trace final {
public:
    static Trace& instance() {
        static Trace trace;
        return trace;
    }

    void initialize() {
        if (initialized_.load(std::memory_order_acquire)) return;
        const char* requested = std::getenv("ENSEMBLES_ACMP_TRACE");
        if (!requested || !*requested || std::strcmp(requested, "0") == 0) {
            initialized_.store(true, std::memory_order_release);
            return;
        }
        const char* customPath = std::getenv("ENSEMBLES_ACMP_TRACE_PATH");
        try {
            path_ = customPath && *customPath
                ? std::filesystem::path(customPath)
                : std::filesystem::temp_directory_path() / "Ensembles_ACMP_RuntimeTrace.csv";
        } catch (...) {
            path_ = "Ensembles_ACMP_RuntimeTrace.csv";
        }
        running_.store(true, std::memory_order_release);
        enabled_.store(true, std::memory_order_release);
        writer_ = std::thread([this] { writerLoop(); });
        initialized_.store(true, std::memory_order_release);
        recordGui(Stage::StyleLoad, monotonicNowUs(), 0, -1, 0, 0, 0, 0, 0,
                  path_.string().c_str());
    }

    ~Trace() {
        enabled_.store(false, std::memory_order_release);
        running_.store(false, std::memory_order_release);
        if (writer_.joinable()) writer_.join();
    }

    bool enabled() const noexcept { return enabled_.load(std::memory_order_relaxed); }

    void recordGui(Stage stage, std::uint64_t observedUs, std::uint64_t targetUs,
                   std::int64_t styleTick, std::uint8_t status, std::uint8_t data1,
                   std::uint8_t data2, std::uint32_t aux = 0, std::uint8_t route = 0,
                   std::string_view text = {}) noexcept {
        record(gui_, droppedGui_, stage, observedUs, targetUs, styleTick, status,
               data1, data2, aux, route, text);
    }

    void recordAudio(Stage stage, std::uint64_t observedUs, std::uint64_t targetUs,
                     std::int64_t styleTick, std::uint8_t status, std::uint8_t data1,
                     std::uint8_t data2, std::uint32_t aux = 0, std::uint8_t route = 1,
                     std::string_view text = {}) noexcept {
        record(audio_, droppedAudio_, stage, observedUs, targetUs, styleTick, status,
               data1, data2, aux, route, text);
    }

    void recordWinMm(Stage stage, std::uint64_t observedUs, std::uint64_t targetUs,
                     std::int64_t styleTick, std::uint8_t status, std::uint8_t data1,
                     std::uint8_t data2, std::uint32_t aux = 0, std::uint8_t route = 2,
                     std::string_view text = {}) noexcept {
        record(winmm_, droppedWinmm_, stage, observedUs, targetUs, styleTick, status,
               data1, data2, aux, route, text);
    }

    // Records the raw local-pattern tick and the local tick after the STL
    // saturated-delta normalization pass. These rows are intentionally kept
    // separate from microsecond timing rows, so the analyzer cannot confuse
    // parser tick edits with event lateness.
    void recordParserCorrection(std::uint64_t observedUs, std::uint64_t rawTick,
                                std::uint64_t normalizedTick, std::uint8_t status,
                                std::uint8_t data1, std::uint8_t data2,
                                std::int32_t sourceTrack, std::int32_t sourceFamily,
                                std::int32_t sourcePart, bool sourceAdvanced,
                                std::uint32_t sourceRecordIndex) noexcept {
        if (!enabled()) return;
        Record r{};
        r.observedUs = observedUs;
        r.styleTick = static_cast<std::int64_t>(normalizedTick);
        r.sourceTick = static_cast<std::int64_t>(rawTick);
        r.sourceTrack = sourceTrack;
        r.sourceFamily = sourceFamily;
        r.sourcePart = sourcePart;
        r.sourceAdvanced = sourceAdvanced ? 1 : 0;
        r.aux = sourceRecordIndex;
        r.stage = static_cast<std::uint8_t>(Stage::ParserTickCorrection);
        r.status = status;
        r.data1 = data1;
        r.data2 = data2;
        std::strncpy(r.text, "local pattern tick adjusted by STL 255-to-240 pass", sizeof(r.text) - 1);
        if (!gui_.push(r)) droppedGui_.fetch_add(1, std::memory_order_relaxed);
    }

    const std::filesystem::path& path() const noexcept { return path_; }

private:
    static constexpr std::size_t kCapacity = 32768; // 32767 rows per producer before dropping.
    SpscRing<kCapacity> gui_;
    SpscRing<kCapacity> audio_;
    SpscRing<kCapacity> winmm_;
    std::atomic<std::uint64_t> droppedGui_{0};
    std::atomic<std::uint64_t> droppedAudio_{0};
    std::atomic<std::uint64_t> droppedWinmm_{0};
    std::atomic<bool> initialized_{false};
    std::atomic<bool> enabled_{false};
    std::atomic<bool> running_{false};
    std::filesystem::path path_;
    std::thread writer_;

    static const char* stageName(Stage stage) noexcept {
        switch (stage) {
            case Stage::StyleLoad: return "STYLE_LOAD";
            case Stage::Section: return "SECTION";
            case Stage::EngineDispatch: return "ENGINE_DISPATCH";
            case Stage::OutputQueue: return "OUTPUT_QUEUE";
            case Stage::AudioApply: return "AUDIO_APPLY_ESTIMATE";
            case Stage::WinMmSend: return "WINMM_SEND";
            case Stage::QueueDrop: return "QUEUE_DROP";
            case Stage::AudioFallback: return "AUDIO_FALLBACK";
            case Stage::WinMmFallback: return "WINMM_FALLBACK";
            case Stage::TraceDrop: return "TRACE_DROP";
            case Stage::ParserTickCorrection: return "PARSER_TICK_CORRECTION";
        }
        return "UNKNOWN";
    }

    static void writeCsvText(std::ofstream& out, const char* text) {
        out << '"';
        for (const char* p = text; p && *p; ++p) {
            if (*p == '"') out << "\"\"";
            else if (*p == '\r' || *p == '\n') out << ' ';
            else out << *p;
        }
        out << '"';
    }

    void record(SpscRing<kCapacity>& ring, std::atomic<std::uint64_t>& dropped,
                Stage stage, std::uint64_t observedUs, std::uint64_t targetUs,
                std::int64_t styleTick, std::uint8_t status, std::uint8_t data1,
                std::uint8_t data2, std::uint32_t aux, std::uint8_t route,
                std::string_view text) noexcept {
        if (!enabled()) return;
        Record r{};
        r.observedUs = observedUs;
        r.targetUs = targetUs;
        r.styleTick = styleTick;
        r.aux = aux;
        r.stage = static_cast<std::uint8_t>(stage);
        r.status = status;
        r.data1 = data1;
        r.data2 = data2;
        r.route = route;
        const auto n = text.size() < sizeof(r.text) - 1 ? text.size() : sizeof(r.text) - 1;
        if (n) std::memcpy(r.text, text.data(), n);
        r.text[n] = '\0';
        if (!ring.push(r)) dropped.fetch_add(1, std::memory_order_relaxed);
    }

    static void writeRecord(std::ofstream& out, const Record& r) {
        out << stageName(static_cast<Stage>(r.stage)) << ','
            << r.observedUs << ',' << r.targetUs << ',' << r.styleTick << ','
            << r.sourceTick << ',' << r.sourceTrack << ',' << r.sourceFamily << ','
            << r.sourcePart << ',' << r.sourceAdvanced << ','
            << static_cast<unsigned int>(r.status) << ','
            << static_cast<unsigned int>(r.status & 0x0f) << ','
            << static_cast<unsigned int>(r.data1) << ','
            << static_cast<unsigned int>(r.data2) << ','
            << r.aux << ',' << static_cast<unsigned int>(r.route) << ',';
        writeCsvText(out, r.text);
        out << '\n';
    }

    void writerLoop() {
        std::ofstream out(path_, std::ios::out | std::ios::trunc);
        if (!out) {
            enabled_.store(false, std::memory_order_release);
            running_.store(false, std::memory_order_release);
            return;
        }
        out << "stage,observed_us,target_us,style_tick,source_tick,source_track,source_family,source_part,source_advanced,status_decimal,channel,data1,data2,aux,route,text\n";
        out.flush();
        while (running_.load(std::memory_order_acquire) ||
               !gui_.empty() || !audio_.empty() || !winmm_.empty()) {
            Record r{};
            bool wrote = false;
            while (gui_.pop(r)) { writeRecord(out, r); wrote = true; }
            while (audio_.pop(r)) { writeRecord(out, r); wrote = true; }
            while (winmm_.pop(r)) { writeRecord(out, r); wrote = true; }
            const auto dg = droppedGui_.exchange(0, std::memory_order_acq_rel);
            const auto da = droppedAudio_.exchange(0, std::memory_order_acq_rel);
            const auto dw = droppedWinmm_.exchange(0, std::memory_order_acq_rel);
            const auto totalDropped = dg + da + dw;
            if (totalDropped) {
                Record drop{};
                drop.stage = static_cast<std::uint8_t>(Stage::TraceDrop);
                drop.observedUs = monotonicNowUs();
                drop.aux = static_cast<std::uint32_t>(totalDropped > UINT32_MAX ? UINT32_MAX : totalDropped);
                std::strncpy(drop.text, "trace ring overflow; capture may be incomplete", sizeof(drop.text) - 1);
                writeRecord(out, drop);
                wrote = true;
            }
            if (wrote) out.flush();
            if (running_.load(std::memory_order_acquire))
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        out.flush();
    }
};

} // namespace ensembles::acmp_trace
