/*
 * Copyright 2020-2022 Subhadeep Jasu <subhajasu@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */


#ifndef CHORD_FINDER_H
#define CHORD_FINDER_H

/** Chord Type Index
 * 0 - Major
 * 1 - minor
 * 2 - diminished
 * 3 - suspended 2
 * 4 - suspended 4
 * 5 - augmented
 * 6 - Dominant Sixth
 * 7 - Dominant Seventh
 * 8 - Major Seventh
 * 9 - minor seventh
 * 10 - add9
 * 11 - Dominant Ninth
 */


/** This function returns an inferred chord based on subsequent
 * invocations of note-on and note-off events
 */
int chord_finder_infer (int key, int on, int* type);

/**
 * Genos-aware chord inference. Updates the same held-note state as the legacy
 * detector and returns the recognized root. legacy_type remains the app's
 * 12-family display/transform category; genos_chord_id is Yamaha's exact
 * Chord Control ID (0..33), or 34 for Chord Cancel/no held chord.
 */
int chord_finder_infer_genos(int key, int on, int* legacy_type, int* genos_chord_id,
                             int* bass_pc = nullptr, int source = 0);

/** Clear held notes for one input source, or every source when source < 0. */
void chord_finder_clear_genos_notes(int source = -1);

/** Query held-note ownership for one source, or any source when source < 0. */
bool chord_finder_genos_note_is_held(int key, int source = -1);

/** Classify a 12-bit pitch-class mask using the Genos Chord Control table. */
int chord_finder_classify_genos_mask(unsigned short pitch_class_mask, int* genos_chord_id);
/** Classify with an independently known lowest-note/root hint for enharmonic sets. */
int chord_finder_classify_genos_mask(unsigned short pitch_class_mask, int preferred_root, int* genos_chord_id);

#endif /* CHORD_FINDER_H */
