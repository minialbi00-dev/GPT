#pragma once

#include <algorithm>
#include <cstdint>

namespace ensembles {

// Returns true only during the short pulse window at the start of each
// MIDI-denominator beat. The phase is derived from the arranger's absolute
// tick counter, not from an independent UI timer, so tempo changes and bar
// boundaries cannot drift away from the audible Style clock.
inline bool genos2BeatPulseActive(std::int64_t globalTick,
                                  int ticksPerQuarter,
                                  int timeSignatureDenominator,
                                  int tempoBpm,
                                  int pulseMilliseconds = 85) noexcept {
    if (globalTick < 0 || ticksPerQuarter <= 0 || timeSignatureDenominator <= 0 ||
        tempoBpm <= 0 || pulseMilliseconds <= 0) {
        return false;
    }

    const std::int64_t ticksPerBeat = std::max<std::int64_t>(
        1, (static_cast<std::int64_t>(ticksPerQuarter) * 4) / timeSignatureDenominator);
    const std::int64_t phase = globalTick % ticksPerBeat;

    // One MIDI denominator beat lasts 60 s * 4 / (denominator * BPM).
    // Convert the desired pulse width in milliseconds into that same tick grid.
    const std::int64_t numerator = ticksPerBeat * pulseMilliseconds *
        static_cast<std::int64_t>(tempoBpm) * timeSignatureDenominator;
    constexpr std::int64_t denominator = 240000;
    const std::int64_t pulseTicks = std::clamp<std::int64_t>(
        (numerator + denominator - 1) / denominator, 1, ticksPerBeat);
    return phase < pulseTicks;
}

} // namespace ensembles
