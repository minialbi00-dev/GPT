#pragma once

#include <RtAudio.h>
#include <fluidsynth.h>

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <memory>
#include <optional>
#include <span>
#include <vector>

#include "vst2_host.hpp"
#include "xg_part_manager.hpp"
#include "SoundFont/sf2_synth.hpp"
#include "sf2_effects_dsp.hpp"

namespace ensembles {

#if ENSEMBLES_HAS_NATIVE_SCVA
class NativeScvaEngine;
#endif
class Syxg2006LeNativeRenderer;

// Owns the local SoundFont synthesizer and a stereo RtAudio output stream.
// MIDI/control commands are queued by the GUI thread and applied on the audio
// callback thread, keeping FluidSynth's render and event calls serialized.
class AudioEngine final {
public:
    struct OutputDevice {
        unsigned int id = 0;
        std::string name;
        unsigned int outputChannels = 0;
        bool isDefaultOutput = false;
        std::vector<unsigned int> sampleRates;
        unsigned int preferredSampleRate = 0;
    };

    static std::vector<RtAudio::Api> availableApis();
    static std::vector<OutputDevice> availableOutputDevices(
        RtAudio::Api api = RtAudio::UNSPECIFIED);
    AudioEngine();
    ~AudioEngine();

    AudioEngine(const AudioEngine &) = delete;
    AudioEngine &operator=(const AudioEngine &) = delete;

    bool initialize(const std::string &soundFontPath, std::string *error = nullptr,
                    RtAudio::Api api = RtAudio::UNSPECIFIED,
                    std::optional<unsigned int> outputDeviceId = std::nullopt,
                    unsigned int sampleRate = 44100,
                    unsigned int bufferFrames = 256);
    void shutdown() noexcept;

    bool isReady() const noexcept { return ready_.load(std::memory_order_acquire); }
    const std::string &soundFontPath() const noexcept { return soundFontPath_; }
    const std::string &outputDeviceName() const noexcept { return outputDeviceName_; }
    unsigned int outputDeviceId() const noexcept { return outputDeviceId_; }
    unsigned int sampleRate() const noexcept { return sampleRate_; }
    unsigned int bufferFrames() const noexcept { return bufferFrames_; }
    RtAudio::Api outputApi() const noexcept { return outputApi_; }

    // synthChannelOverride can address Ensembles' internal FluidSynth channels
    // 16..63; ordinary MIDI status bytes only encode channels 0..15.
    bool sendMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                  int synthChannelOverride = -1) noexcept;
    // Schedule an event against std::chrono::steady_clock time in microseconds.
    // targetTimeUs == 0 retains the legacy immediate-at-next-callback behavior.
    bool sendMidiAt(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                    std::uint64_t targetTimeUs, int synthChannelOverride = -1) noexcept;
    // Style MIDI has its own generation so Stop can invalidate queued and
    // future-deadline arranger events without touching live keyboard MIDI.
    bool sendStyleMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                       int synthChannelOverride = -1) noexcept;
    bool sendStyleMidiAt(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                         std::uint64_t targetTimeUs, int synthChannelOverride = -1) noexcept;
    void cancelPendingStyleMidi() noexcept;
    bool setMasterGain(float gain) noexcept;
    bool setMasterReverb(bool enabled, int level) noexcept;
    bool setMasterChorus(bool enabled, int level) noexcept;
    bool setMasterDelay(bool enabled, int level) noexcept;
    bool setYamahaStyleEffects(const arranger::YamahaStyleEffectProfile& profile, int tempoBpm) noexcept;
    bool clearYamahaStyleEffects() noexcept;
    bool setYamahaStyleTempo(int tempoBpm) noexcept;
    bool sendStyleXgEffectParameterAt(const std::array<std::uint8_t, 3>& address,
                                      const std::array<std::uint8_t, 16>& data,
                                      std::uint8_t dataLength,
                                      std::uint64_t targetTimeUs) noexcept;
    // Queue a short GS DT1 SysEx message for the native SCVA engine on the audio thread.
    bool sendSysEx(std::span<const std::uint8_t> bytes) noexcept;
    bool allSoundsOff() noexcept;

    // Generate a short sine directly in the RtAudio callback, bypassing MIDI and
    // every instrument renderer. This isolates the physical output path.
    bool playTestTone(double frequencyHz = 440.0, float amplitude = 0.18f,
                      unsigned int durationMs = 1000, std::string *error = nullptr);

    // Load a user-owned VST2 instrument into the existing RtAudio stream.
    // FluidSynth stays active as a fallback if the VST faults or returns a silent block.
    // Load the embedded SCCore.dll as data and render through the native C++ engine.
    // This is independent from the VST2 host; unsupported SCCore builds are rejected.
    bool loadNativeScvaFromMemory(std::vector<std::uint8_t> coreImage,
                                  std::string *error = nullptr);
    bool unloadNativeScva(std::string *error = nullptr);
    bool isNativeScvaActive() const noexcept {
        return useNativeScva_.load(std::memory_order_acquire);
    }

    // Activate the in-process C++ Yamaha-compatible PCM renderer on the
    // existing RtAudio stream. The bank index is sxgbnw6l.tbl; the PCM manifest
    // is XGPCM1 and references mono PCM16 WAV zones.
    bool loadSyxg2006LeNative(const std::string &bankTablePath,
                             const std::string &pcmManifestPath,
                             std::string *error = nullptr);
    bool unloadSyxg2006LeNative(std::string *error = nullptr);
    bool isSyxg2006LeNativeActive() const noexcept {
        return useSyxg2006LeNative_.load(std::memory_order_acquire);
    }

    // Load an SF2 into the separate native C++ fallback sampler. The application
    // reserves this route for the bundled LS-GM bank; user-selected external SF2
    // files are rendered by FluidSynth via loadFluidSynthSoundFont().
    bool loadNativeSoundFont(const std::string &soundFontPath,
                             std::string *error = nullptr);
    bool unloadNativeSoundFont(std::string *error = nullptr);
    bool isNativeSoundFontActive() const noexcept {
        return useLsGmNative_.load(std::memory_order_acquire);
    }
    // Load an external SF2 into FluidSynth while reusing the currently-open
    // RtAudio stream. The candidate synth is fully prepared before the audio
    // callback is paused and the active renderer is swapped.
    bool loadFluidSynthSoundFont(const std::string &soundFontPath,
                                 std::string *error = nullptr);
    bool isFluidSynthSoundFontActive() const noexcept {
        return synth_ != nullptr && soundFontId_ >= 0 &&
            !useVst2_.load(std::memory_order_acquire) &&
            !useNativeScva_.load(std::memory_order_acquire) &&
            !useSyxg2006LeNative_.load(std::memory_order_acquire) &&
            !useLsGmNative_.load(std::memory_order_acquire);
    }
    bool isSoundFontPresetBrowserActive() const noexcept {
        return isNativeSoundFontActive() || isFluidSynthSoundFontActive();
    }
    std::vector<lsgm::PresetInfo> activeSoundFontPresets() const {
        if (isNativeSoundFontActive() && nativeSf2_) return nativeSf2_->presets();
        return isFluidSynthSoundFontActive() ? fluidSf2Presets_ : std::vector<lsgm::PresetInfo>{};
    }
    std::size_t nativeSoundFontPresetCount() const noexcept {
        return nativeSf2_ ? nativeSf2_->presetCount() : 0;
    }
    // Snapshot of the active SF2 bank's actual phdr directory. Bank values are
    // SF2 bank numbers (0..16383); MIDI bytes are MSB=(bank>>7), LSB=(bank&127).
    std::vector<lsgm::PresetInfo> nativeSoundFontPresets() const {
        return nativeSf2_ ? nativeSf2_->presets() : std::vector<lsgm::PresetInfo>{};
    }
    bool nativeSoundFontHasPreset(std::uint16_t bank, std::uint8_t program) const noexcept {
        return nativeSf2_ && nativeSf2_->hasPreset(bank, program);
    }
    // Source-compatible aliases kept for older integrations.
    bool loadLsGmNativeSoundFont(const std::string &soundFontPath,
                                 std::string *error = nullptr) {
        return loadNativeSoundFont(soundFontPath, error);
    }
    bool unloadLsGmNativeSoundFont(std::string *error = nullptr) {
        return unloadNativeSoundFont(error);
    }
    bool isLsGmNativeActive() const noexcept { return isNativeSoundFontActive(); }

    bool loadVst2Plugin(const std::string &pluginPath, std::string *error = nullptr);
    bool unloadVst2Plugin(std::string *error = nullptr);
    bool isVst2PluginLoaded() const noexcept { return useVst2_.load(std::memory_order_acquire); }
    const std::string &vst2PluginName() const noexcept;

private:
    enum class CommandType : std::uint8_t { Midi, Gain, Reverb, Chorus, Delay, StyleEffects, ClearStyleEffects, StyleTempo, XgEffectParameter, SysEx, AllSoundsOff };
    struct Command {
        CommandType type = CommandType::Midi;
        std::uint8_t status = 0;
        std::uint8_t data1 = 0;
        std::uint8_t data2 = 0;
        std::int16_t channelOverride = -1;
        std::int16_t value = 0;
        bool enabled = true;
        float gain = 1.0f;
        std::array<std::uint8_t, 16> sysex{};
        std::uint8_t sysexLength = 0;
        std::array<std::uint8_t, 3> xgEffectAddress{};
        std::array<std::uint8_t, 16> xgEffectData{};
        std::uint8_t xgEffectDataLength = 0;
        const arranger::YamahaStyleEffectProfile *styleEffectProfile = nullptr;
        std::uint64_t targetTimeUs = 0;
        std::uint64_t styleGeneration = 0;
        bool styleMidi = false;
    };

    static constexpr std::size_t kQueueCapacity = 8192;
    std::array<Command, kQueueCapacity> queue_{};
    // The following MIDI scheduler storage is owned exclusively by the audio callback.
    std::array<Command, kQueueCapacity> pendingTimedMidi_{};
    std::size_t pendingTimedMidiCount_ = 0;
    std::array<Command, kQueueCapacity> callbackTimedMidi_{};
    std::array<std::uint32_t, kQueueCapacity> callbackMidiOffsets_{};
    std::size_t callbackTimedMidiCount_ = 0;
    std::atomic<std::size_t> writeIndex_{0};
    std::atomic<std::size_t> readIndex_{0};
    std::atomic<bool> ready_{false};
    std::atomic<bool> useVst2_{false};
    std::atomic<bool> useNativeScva_{false};
    std::atomic<bool> useSyxg2006LeNative_{false};
    std::atomic<bool> useLsGmNative_{false};
    std::atomic<std::uint64_t> styleMidiGeneration_{1};
    std::atomic<std::uint64_t> testToneFramesRemaining_{0};
    std::atomic<double> testToneFrequencyHz_{440.0};
    std::atomic<float> testToneAmplitude_{0.18f};
    // UI master gain (0..0.9); FluidSynth uses a 0.65 calibration
    // and every renderer receives the same 1.414x output trim plus soft ceiling.
    // Style-only CC7/CC11 and pan normalization stays separate from keyboard MIDI.
    std::atomic<float> masterGain_{0.4f};
    // Owned only by the RtAudio callback thread.
    double testTonePhase_ = 0.0;
    std::unique_ptr<Syxg2006LeNativeRenderer> syxg2006LeNative_;
    std::unique_ptr<lsgm::Sf2Synth> nativeSf2_;
    Sf2EffectsDsp sf2EffectsDsp_;
    // Profiles are immutable and retained until shutdown so queued raw pointers
    // remain valid even if the user switches styles before the audio callback runs.
    std::vector<std::unique_ptr<arranger::YamahaStyleEffectProfile>> retainedStyleEffectProfiles_;
    // Preset metadata enumerated from the active FluidSynth SoundFont. This is
    // only a catalog; all external SF2 audio is rendered by FluidSynth.
    std::vector<lsgm::PresetInfo> fluidSf2Presets_;
    // Bank Select state for the two Yamaha rhythm-only FluidSynth channels.
    // These are consumed on the audio thread and committed at Program Change.
    std::array<std::uint8_t, 2> fluidDrumBankMsb_{};
    std::array<std::uint8_t, 2> fluidDrumBankLsb_{};
    std::unique_ptr<Vst2Host> vst2Host_;
    // Audio-thread-owned normalized state for the eventual native Yamaha XG renderer.
    XgPartManager xgPartManager_;
#if ENSEMBLES_HAS_NATIVE_SCVA
    std::unique_ptr<NativeScvaEngine> nativeScva_;
#endif

    fluid_settings_t *settings_ = nullptr;
    fluid_synth_t *synth_ = nullptr;
    int soundFontId_ = -1;
    std::unique_ptr<RtAudio> audio_;
    std::string soundFontPath_;
    std::string outputDeviceName_;
    unsigned int outputDeviceId_ = 0;
    unsigned int sampleRate_ = 44100;
    unsigned int bufferFrames_ = 256;
    RtAudio::Api outputApi_ = RtAudio::UNSPECIFIED;

    bool enqueue(const Command &command) noexcept;
    bool dequeue(Command &command) noexcept;
    void processQueuedCommands(std::uint64_t blockStartTimeUs, std::uint64_t blockEndTimeUs,
                               unsigned int frameCount) noexcept;
    void applyCommand(const Command &command) noexcept;
    void applyMidi(const Command &command) noexcept;
    bool isCurrentStyleCommand(const Command &command) const noexcept;
    void applyReverb(bool enabled, int level) noexcept;
    void applyChorus(bool enabled, int level) noexcept;
    void applyDelay(bool enabled, int level) noexcept;
    void mixTestTone(float *output, unsigned int frameCount) noexcept;
    static int audioCallback(void *outputBuffer, void *inputBuffer,
                             unsigned int frameCount, double streamTime,
                             RtAudioStreamStatus status, void *userData);
};

} // namespace ensembles
