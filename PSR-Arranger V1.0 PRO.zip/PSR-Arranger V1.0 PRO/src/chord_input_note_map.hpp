#pragma once

#include <array>
#include <vector>

namespace ensembles {

// Pairs each physical/input note with the transposed pitch used at Note-On.
// A Note-Off must release that original pitch even if transpose/octave settings
// changed while the key was held. Sources are UI keyboard (0) and MIDI
// channels (1..16).
class ChordInputNoteMap {
public:
    int resolve(int source_note, int current_output_note, bool pressed, int source) {
        if (source_note < 0 || source_note >= 128) return current_output_note;
        const int safe_source = source < 0 || source >= kSourceCount ? 0 : source;
        auto& mappings = notes_[static_cast<std::size_t>(safe_source)]
                               [static_cast<std::size_t>(source_note)];
        if (pressed) {
            mappings.push_back(current_output_note);
            return current_output_note;
        }
        if (mappings.empty()) return current_output_note;
        const int press_time_output_note = mappings.back();
        mappings.pop_back();
        return press_time_output_note;
    }

    void clear(int source = -1) {
        if (source < 0) {
            for (auto& source_notes : notes_)
                for (auto& note_mappings : source_notes) note_mappings.clear();
            return;
        }
        if (source >= kSourceCount) return;
        for (auto& note_mappings : notes_[static_cast<std::size_t>(source)])
            note_mappings.clear();
    }

    static constexpr int kSourceCount = 17;

private:
    std::array<std::array<std::vector<int>, 128>, kSourceCount> notes_{};
};

} // namespace ensembles
