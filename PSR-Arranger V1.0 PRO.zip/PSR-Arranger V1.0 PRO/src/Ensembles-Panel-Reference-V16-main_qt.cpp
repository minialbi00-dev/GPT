/*
 * Ensembles C++ - Qt 6 Windows frontend
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Audio is rendered locally by FluidSynth from a user-supplied SoundFont and
 * streamed through the selected RtAudio output device/API. WinMM remains available
 * as a selectable alternative or parallel MIDI output.
 */
#include "audio_engine.hpp"
#include "scva_startup_policy.hpp"
#include "midi_file.hpp"
#include "style_engine.hpp"
#include "chord_finder.h"
#include "midi_input_router.hpp"

#include <QApplication>
#include <QGuiApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QElapsedTimer>
#include <QFileDialog>
#include <QFile>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QMainWindow>
#include <QPushButton>
#include <QScrollArea>
#include <QListWidget>
#include <QListView>
#include <QStackedWidget>
#include <QStyledItemDelegate>
#include <QStyleOptionViewItem>
#include <QAbstractItemView>
#include <QIcon>
#include <QSlider>
#include <QSplitter>
#include <QStatusBar>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>
#include <QGridLayout>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QSettings>
#include <QStyle>
#include <QDial>
#include <QSpinBox>
#include <QProgressBar>
#include <QToolButton>
#include <QFrame>
#include <QPainter>
#include <QLinearGradient>
#include <QPolygon>
#include <QPen>
#include <QSizePolicy>
#include <QAbstractSpinBox>
#include <QMouseEvent>
#include <QPoint>
#include <QRect>
#include <QRectF>
#include <QSizeF>
#include <QEvent>
#include <QScreen>
#include <QPaintEvent>
#include <QPixmap>
#include <QColor>
#include <QFontMetrics>
#include <QFileInfo>
#include <QStringList>
#include <QDir>
#include <QCoreApplication>
#include <QMetaObject>
#include <QListWidgetItem>
#include <QStandardPaths>
#include <QSignalBlocker>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <tuple>
#include <utility>
#include <functional>
#include <memory>
#include <map>
#include <limits>
#include <optional>
#include <set>
#include <vector>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

namespace {
// Minimal crash-stage trace that does not depend on Qt being initialized.
// The file is recreated at each launch in the user's temporary directory.
std::ofstream gStartupTraceFile;
void startupTrace(const char *stage) noexcept {
    try {
        if (!gStartupTraceFile.is_open()) {
            std::filesystem::path directory;
            try { directory = std::filesystem::temp_directory_path(); }
            catch (...) { directory = std::filesystem::current_path(); }
            gStartupTraceFile.open(directory / "ensembles-startup-trace.log",
                                   std::ios::out | std::ios::trunc);
        }
        if (gStartupTraceFile.is_open()) {
            gStartupTraceFile << stage << '\n';
            gStartupTraceFile.flush();
        }
    } catch (...) {
        // Diagnostics must never prevent the application from starting.
    }
}

constexpr std::array<const char *, 128> kPatchNames = {
    "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano",
    "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavinet",
    "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba", "Xylophone",
    "Tubular Bells", "Dulcimer", "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ",
    "Reed Organ", "Accordion", "Harmonica", "Tango Accordion", "Nylon Guitar", "Steel Guitar",
    "Jazz Electric Guitar", "Clean Electric Guitar", "Muted Electric Guitar", "Overdrive Guitar",
    "Distortion Guitar", "Guitar Harmonics", "Acoustic Bass", "Fingered Bass", "Picked Bass", "Fretless Bass",
    "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello", "Contrabass",
    "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani", "String Ensemble 1", "String Ensemble 2",
    "SynthStrings 1", "SynthStrings 2", "Choir Aahs", "Voice Oohs", "Synth Voice", "Orchestra Hit",
    "Trumpet", "Trombone", "Tuba", "Muted Trumpet", "French Horn", "Brass Section", "SynthBrass 1", "SynthBrass 2",
    "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon", "Clarinet",
    "Piccolo", "Flute", "Recorder", "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
    "Lead 1 (Square)", "Lead 2 (Sawtooth)", "Lead 3 (Calliope)", "Lead 4 (Chiff)", "Lead 5 (Charang)",
    "Lead 6 (Voice)", "Lead 7 (Fifths)", "Lead 8 (Bass + Lead)", "Pad 1 (New Age)", "Pad 2 (Warm)",
    "Pad 3 (Polysynth)", "Pad 4 (Choir)", "Pad 5 (Bowed)", "Pad 6 (Metallic)", "Pad 7 (Halo)", "Pad 8 (Sweep)",
    "FX 1 (Rain)", "FX 2 (Soundtrack)", "FX 3 (Crystal)", "FX 4 (Atmosphere)", "FX 5 (Brightness)",
    "FX 6 (Goblins)", "FX 7 (Echoes)", "FX 8 (Sci-fi)", "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba",
    "Bag Pipe", "Fiddle", "Shanai", "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock", "Taiko Drum",
    "Melodic Tom", "Synth Drum", "Reverse Cymbal", "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird Tweet",
    "Telephone Ring", "Helicopter", "Applause", "Gunshot"
};
constexpr std::array<const char *, 12> kNoteNames = {
    "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
constexpr std::array<const char *, 12> kChordNames = {
    "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"};
constexpr std::array<const char *, 12> kChordTypeNames = {
    "Major", "Minor", "Diminished", "Sus2", "Sus4", "Augmented",
    "Sixth", "Seventh", "Major 7th", "Minor 7th", "Add 9", "Ninth"};
constexpr int kOriginalSplitKey = 54; // Core/ChoppingBlock/central_bus.c default

QString nativePathMessage(const QString &path) { return QDir::toNativeSeparators(path); }

struct VoiceCatalogEntry {
    int program = 0; // zero-based MIDI Program Change
    int bank = 0;    // SCVSC.tnf variation bank, selected by CC0
    int map = 4;     // GS Tone Map: 1=SC-55, 2=SC-88, 3=SC-88Pro, 4=SC-8820
    QString name;
    QString category;
};

struct NativeEfxChoice { const char *name; int key; };
static const std::array<NativeEfxChoice, 65> kNativeEfxChoices = {{
    {"Thru / Bypass", 0x0000}, {"Equalizer", 0x0100}, {"Spectrum", 0x0101},
    {"Enhancer", 0x0102}, {"Humanizer", 0x0103}, {"Overdrive", 0x0110},
    {"Distortion", 0x0111}, {"Phaser", 0x0120}, {"Auto Wah", 0x0121},
    {"Rotary", 0x0122}, {"Stereo Flanger", 0x0123}, {"Step Flanger", 0x0124},
    {"Tremolo", 0x0125}, {"Auto Pan", 0x0126}, {"Compressor", 0x0130},
    {"Limiter", 0x0131}, {"Hexa Chorus", 0x0140}, {"Tremolo Chorus", 0x0141},
    {"Stereo Chorus", 0x0142}, {"Space-D", 0x0143}, {"3D Chorus", 0x0144},
    {"Stereo Delay", 0x0150}, {"Modulation Delay", 0x0151}, {"Triple Tap Delay", 0x0152},
    {"Quad Tap Delay", 0x0153}, {"Time Control Delay", 0x0154}, {"Reverb", 0x0155},
    {"Gate Reverb", 0x0156}, {"3D Delay", 0x0157}, {"2-Voice Pitch Shifter", 0x0160},
    {"Feedback Pitch Shifter", 0x0161}, {"3D Auto", 0x0170}, {"3D Manual", 0x0171},
    {"Lo-Fi", 0x0172}, {"Lo-Fi 2", 0x0173}, {"Overdrive + Chorus", 0x0200},
    {"Overdrive + Flanger", 0x0201}, {"Overdrive + Delay", 0x0202}, {"Distortion + Chorus", 0x0203},
    {"Distortion + Flanger", 0x0204}, {"Distortion + Delay", 0x0205}, {"Enhancer + Chorus", 0x0206},
    {"Enhancer → Flanger", 0x0207}, {"Enhancer → Delay", 0x0208}, {"Chorus + Delay", 0x0209},
    {"Flanger + Delay", 0x020A}, {"Chorus + Flanger", 0x020B}, {"Rotary Multi", 0x0300},
    {"Guitar Multi 1", 0x0400}, {"Guitar Multi 2", 0x0401}, {"Guitar Multi 3", 0x0402},
    {"Clean Guitar Multi 1", 0x0403}, {"Clean Guitar Multi 2", 0x0404}, {"Bass Multi", 0x0405},
    {"Rhodes Multi", 0x0406}, {"Keyboard Multi", 0x0500}, {"Chorus // Delay", 0x1100},
    {"Flanger // Delay", 0x1101}, {"Chorus // Flanger", 0x1102}, {"Overdrive // Overdrive 2", 0x1103},
    {"Overdrive // Rotary", 0x1104}, {"Overdrive // Phaser", 0x1105}, {"Overdrive // Auto Wah", 0x1106},
    {"Phaser // Rotary", 0x1107}, {"Phaser // Auto Wah", 0x1108}
}};

QString voiceCategoryForProgram(int p) {
    static const std::array<const char *, 16> names = {"Piano", "Chromatic Percussion", "Organ", "Guitar", "Bass", "Strings", "Ensemble", "Brass", "Reed", "Pipe", "Synth Lead", "Synth Pad", "Synth Effects", "Ethnic", "Percussion", "Sound Effects"};
    return QString::fromLatin1(names[static_cast<std::size_t>(std::clamp(p, 0, 127) / 8)]);
}

std::array<std::uint8_t, 11> makeGsDt1(std::uint8_t ah, std::uint8_t am, std::uint8_t al, std::uint8_t value) {
    const int sum = ah + am + al + value;
    const auto checksum = static_cast<std::uint8_t>((128 - (sum & 0x7f)) & 0x7f);
    return {0xF0, 0x41, 0x10, 0x42, 0x12, ah, am, al, value, checksum, 0xF7};
}


// A small painter-based piano keyboard. This follows the original KeyBed's
// five-octave C2..B6 range and sends real note-on/note-off events through the
// existing Windows MIDI path rather than rendering a screenshot as a fake UI.
class PianoKeyboardWidget final : public QWidget {
public:
    explicit PianoKeyboardWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumHeight(125);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        setMouseTracking(true);
        setFocusPolicy(Qt::StrongFocus);
        setToolTip(QStringLiteral("Keyboard 5 oktaf. Klik kiri untuk memainkan nada; klik kanan pada sebuah key untuk memindahkan split point, seperti tombol split pada KeyBed asli."));
    }

    void setNoteCallback(std::function<void(int, bool)> callback) { noteCallback_ = std::move(callback); }
    void setSplitKeyCallback(std::function<void(int)> callback) { splitKeyCallback_ = std::move(callback); }
    void setSplitKey(int note) { splitKey_ = std::clamp(note, baseNote_, baseNote_ + 59); update(); }
    int splitKey() const { return splitKey_; }
    void setBaseNote(int note) { baseNote_ = std::clamp(note, 0, 127 - 59); splitKey_ = std::clamp(splitKey_, baseNote_, baseNote_ + 59); update(); }
    void setActiveNote(int note, bool active, int noteType = 0) {
        if (active) activeNoteTypes_[note] = noteType;
        else activeNoteTypes_.erase(note);
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, false);
        p.fillRect(rect(), QColor("#101010"));
        int whiteCount = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) if (!isBlack(n)) ++whiteCount;
        if (whiteCount <= 0) return;
        const qreal ww = static_cast<qreal>(width()) / whiteCount;
        const qreal keyTop = 4.0; // In the original, the switch bar overlays the keyboard's top margin.
        const qreal keyHeight = std::max<qreal>(1.0, height() - keyTop);
        int wi = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (isBlack(n)) continue;
            QRectF r(wi * ww, keyTop, ww, keyHeight);
            const auto active = activeNoteTypes_.find(n);
            if (active != activeNoteTypes_.end()) {
                const QColor base = active->second == 1 ? QColor("#e3b22b")
                    : active->second == 2 ? QColor("#16a995") : QColor("#168de1");
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, base.lighter(175));
                g.setColorAt(0.25, base);
                g.setColorAt(1.0, base.darker(155));
                p.fillRect(r, g);
            } else {
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, QColor("#585858"));
                g.setColorAt(0.80, QColor("#383838"));
                g.setColorAt(1.0, QColor("#2e2e2e"));
                p.fillRect(r, g);
            }
            p.setPen(QPen(QColor("#090909"), 1.0));
            p.drawRect(r.adjusted(0, 0, -0.6, -0.6));
            ++wi;
        }
        // Black keys are painted over the white keys and receive priority in hit testing.
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (!isBlack(n)) continue;
            const QRectF r = blackRect(n, ww, keyTop, keyHeight);
            const auto active = activeNoteTypes_.find(n);
            if (active != activeNoteTypes_.end()) {
                const QColor base = active->second == 1 ? QColor("#b78512")
                    : active->second == 2 ? QColor("#087d71") : QColor("#0969b4");
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, base.lighter(165));
                g.setColorAt(1.0, base.darker(175));
                p.fillRect(r, g);
            } else {
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, QColor("#444444"));
                g.setColorAt(0.12, QColor("#181818"));
                g.setColorAt(1.0, QColor("#020202"));
                p.fillRect(r, g);
            }
            p.setPen(QPen(QColor("#000000"), 1.1));
            p.drawRect(r.adjusted(0, 0, -0.6, -0.6));
            p.setPen(QPen(QColor(255, 255, 255, 24), 1.0));
            p.drawLine(r.left() + 2, r.top() + 2, r.right() - 2, r.top() + 2);
        }
        // Match KeyBed: the split marker follows the user-selectable split key.
        int splitWhiteIndex = 0;
        for (int n = baseNote_; n < std::min(splitKey_, baseNote_ + 60); ++n) if (!isBlack(n)) ++splitWhiteIndex;
        const qreal sx = splitWhiteIndex * ww;
        p.setPen(Qt::NoPen);
        p.setBrush(QColor("#606060"));
        QPolygon marker;
        marker << QPoint(static_cast<int>(sx - 5), 0) << QPoint(static_cast<int>(sx + 5), 0)
               << QPoint(static_cast<int>(sx), 7);
        p.drawPolygon(marker);
    }

    void mousePressEvent(QMouseEvent *e) override {
        const int note = noteAt(e->position().toPoint());
        if (e->button() == Qt::RightButton) {
            // The original KeyBed exposes a split-key button on each key.
            // Right-click is the compact Qt equivalent and does not trigger a note.
            if (note >= 0 && splitKeyCallback_) splitKeyCallback_(note);
            e->accept();
            return;
        }
        if (e->button() != Qt::LeftButton) return;
        if (note >= 0) {
            pressedNote_ = note;
            if (noteCallback_) noteCallback_(note, true);
        }
    }

    void mouseMoveEvent(QMouseEvent *e) override {
        if (!(e->buttons() & Qt::LeftButton)) return;
        const int next = noteAt(e->position().toPoint());
        if (next >= 0 && next != pressedNote_) {
            if (pressedNote_ >= 0) {
                if (noteCallback_) noteCallback_(pressedNote_, false);
            }
            pressedNote_ = next;
            if (noteCallback_) noteCallback_(next, true);
        }
    }

    void mouseReleaseEvent(QMouseEvent *e) override {
        if (e->button() == Qt::LeftButton && pressedNote_ >= 0) {
            if (noteCallback_) noteCallback_(pressedNote_, false);
            pressedNote_ = -1;
        }
    }

private:
    static bool isBlack(int note) {
        const int pc = note % 12;
        return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10;
    }
    QRectF blackRect(int note, qreal whiteWidth, qreal keyTop, qreal keyHeight) const {
        int whitesBefore = 0;
        for (int n = baseNote_; n < note; ++n) if (!isBlack(n)) ++whitesBefore;
        return QRectF((whitesBefore - 0.36) * whiteWidth, keyTop, whiteWidth * 0.72, keyHeight * 0.575);
    }
    int noteAt(const QPoint &point) const {
        constexpr qreal keyTop = 4.0;
        if (point.y() < static_cast<int>(keyTop)) return -1;
        int whiteCount = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) if (!isBlack(n)) ++whiteCount;
        if (!whiteCount) return -1;
        const qreal ww = static_cast<qreal>(width()) / whiteCount;
        const qreal keyHeight = std::max<qreal>(1.0, height() - keyTop);
        for (int n = baseNote_; n < baseNote_ + 60; ++n)
            if (isBlack(n) && blackRect(n, ww, keyTop, keyHeight).contains(point)) return n;
        int wi = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (isBlack(n)) continue;
            if (QRectF(wi * ww, keyTop, ww, keyHeight).contains(point)) return n;
            ++wi;
        }
        return -1;
    }
    std::function<void(int, bool)> noteCallback_;
    std::function<void(int)> splitKeyCallback_;
    std::map<int, int> activeNoteTypes_;
    int baseNote_ = 36;
    int splitKey_ = kOriginalSplitKey;
    int pressedNote_ = -1;
};

// The original uses a client-side headerbar rather than a second native caption.
// Keep the same structure on Windows and allow dragging from its empty areas.
class DraggableHeaderWidget final : public QWidget {
public:
    explicit DraggableHeaderWidget(QMainWindow *window, QWidget *parent = nullptr)
        : QWidget(parent), window_(window) {}
protected:
    void mousePressEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton && window_ && !window_->isMaximized() && !window_->isFullScreen()) {
            dragging_ = true;
            dragOffset_ = event->globalPosition().toPoint() - window_->frameGeometry().topLeft();
            event->accept();
            return;
        }
        QWidget::mousePressEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event) override {
        if (dragging_ && window_ && (event->buttons() & Qt::LeftButton) && !window_->isMaximized() && !window_->isFullScreen()) {
            window_->move(event->globalPosition().toPoint() - dragOffset_);
            event->accept();
            return;
        }
        QWidget::mouseMoveEvent(event);
    }
    void mouseReleaseEvent(QMouseEvent *event) override {
        dragging_ = false;
        QWidget::mouseReleaseEvent(event);
    }
private:
    QMainWindow *window_ = nullptr;
    QPoint dragOffset_;
    bool dragging_ = false;
};

// The GTK reference uses a recessed silver knob with a small movable socket,
// not Qt's default dark QDial face. Keep QDial's input/value behavior but paint
// the same hardware-like face used by the original panel.
class PanelDial final : public QDial {
public:
    explicit PanelDial(QWidget *parent = nullptr) : QDial(parent) {
        setAttribute(Qt::WA_OpaquePaintEvent, false);
        setNotchesVisible(false);
        setWrapping(false);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);

        const qreal side = std::max<qreal>(12.0, std::min(width(), height()) - 3.0);
        const QRectF outer((width() - side) / 2.0, (height() - side) / 2.0, side, side);
        const bool masterTarget = property("masterTarget").toBool();
        const QColor rim = masterTarget ? QColor("#b89a45") : QColor("#171717");

        p.setPen(Qt::NoPen);
        p.setBrush(QColor(0, 0, 0, 135));
        p.drawEllipse(outer.translated(0.4, 1.3));

        QLinearGradient rimGradient(outer.topLeft(), outer.bottomLeft());
        rimGradient.setColorAt(0.0, masterTarget ? QColor("#d8bd69") : QColor("#686868"));
        rimGradient.setColorAt(0.22, QColor("#3d3d3d"));
        rimGradient.setColorAt(1.0, QColor("#101010"));
        p.setBrush(rimGradient);
        p.setPen(QPen(rim, masterTarget ? 1.2 : 1.0));
        p.drawEllipse(outer.adjusted(0.5, 0.5, -0.5, -0.5));

        const qreal inset = std::max<qreal>(2.2, side * 0.105);
        const QRectF face = outer.adjusted(inset, inset, -inset, -inset);
        QLinearGradient faceGradient(face.topLeft(), face.bottomLeft());
        faceGradient.setColorAt(0.0, QColor("#e6e6e6"));
        faceGradient.setColorAt(0.28, QColor("#c9c9c9"));
        faceGradient.setColorAt(0.72, QColor("#b0b0b0"));
        faceGradient.setColorAt(1.0, QColor("#929292"));
        p.setBrush(faceGradient);
        p.setPen(QPen(QColor("#d4d4d4"), 0.7));
        p.drawEllipse(face);

        // The original knob indicates its position with a small socket on the
        // perimeter. Mid-value is at 12 o'clock, matching the four assignable knobs.
        const int span = maximum() - minimum();
        const qreal t = span > 0 ? std::clamp((value() - minimum()) / static_cast<qreal>(span), 0.0, 1.0) : 0.5;
        const qreal angle = (135.0 + t * 270.0) * 3.14159265358979323846 / 180.0;
        const qreal radius = face.width() * 0.285;
        const QPointF center = face.center() + QPointF(std::cos(angle) * radius, std::sin(angle) * radius);
        const qreal socketSize = side < 37.0 ? 3.8 : (side < 57.0 ? 5.2 : 6.2);
        const QRectF socket(center.x() - socketSize / 2.0, center.y() - socketSize / 2.0, socketSize, socketSize);
        p.setBrush(QColor("#737373"));
        p.setPen(QPen(QColor("#eeeeee"), 0.65));
        p.drawEllipse(socket.adjusted(-0.7, -0.7, 0.7, 0.7));
        p.setBrush(QColor("#555555"));
        p.setPen(QPen(QColor("#4b4b4b"), 0.45));
        p.drawEllipse(socket);
        p.setPen(QPen(QColor(255, 255, 255, 70), 0.55));
        p.drawArc(face.adjusted(1.1, 1.1, -1.1, -1.1), 35 * 16, 110 * 16);
    }
};

class CoverPhotoWidget final : public QWidget {
public:
    explicit CoverPhotoWidget(const QString &path, QWidget *parent = nullptr) : QWidget(parent), pixmap_(path) {
        setMinimumHeight(80);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.fillRect(rect(), QColor("#111111"));
        if (pixmap_.isNull()) return;
        const QSizeF srcSize = pixmap_.size();
        const qreal scale = std::max(width() / srcSize.width(), height() / srcSize.height());
        const QSizeF scaled(srcSize.width() * scale, srcSize.height() * scale);
        const QRectF target((width() - scaled.width()) / 2.0, (height() - scaled.height()) / 2.0, scaled.width(), scaled.height());
        p.setRenderHint(QPainter::SmoothPixmapTransform, true);
        p.drawPixmap(target, pixmap_, QRectF(pixmap_.rect()));
        // The legacy LCD uses the photo underneath charcoal/teal overlays. Darken
        // the Qt crop slightly so the cover image sits inside the display rather
        // than looking like a bright, unframed desktop photograph.
        QLinearGradient shade(0.0, 0.0, 0.0, height());
        shade.setColorAt(0.0, QColor(28, 34, 35, 58));
        shade.setColorAt(0.58, QColor(22, 29, 32, 36));
        shade.setColorAt(1.0, QColor(13, 19, 22, 72));
        p.fillRect(rect(), shade);
    }
private:
    QPixmap pixmap_;
};

// Paints the Voice and Style chooser rows in the same compact, instrument-panel
// language as the original LCD: charcoal rows, thumbnail/category badge, and an
// amber selected row.  Item metadata lives in Qt::UserRole + 1 (secondary line)
// and Qt::UserRole + 2 (right-hand badge).
class JoystickPadWidget final : public QWidget {
public:
    explicit JoystickPadWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumSize(110, 76);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        setMouseTracking(true);
        setToolTip(QStringLiteral("Seret titik untuk mengirim dua MIDI CC; default X=Pan CC10, Y=Modulation CC1."));
    }
    void setAxisValues(int x, int y) {
        x_ = std::clamp(x, 0, 127); y_ = std::clamp(y, 0, 127); update();
    }
    void setChangedCallback(std::function<void(int, int)> callback) { changed_ = std::move(callback); }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this); p.setRenderHint(QPainter::Antialiasing, true);
        p.fillRect(rect(), QColor("#151515"));
        QRectF area = QRectF(rect()).adjusted(9, 7, -9, -7);
        p.setPen(QPen(QColor("#3a3a3a"), 1)); p.setBrush(QColor("#1c1c1c")); p.drawRoundedRect(area, 3, 3);
        p.setPen(QPen(QColor("#424242"), 1, Qt::DashLine));
        p.drawLine(QPointF(area.center().x(), area.top()+3), QPointF(area.center().x(), area.bottom()-3));
        p.drawLine(QPointF(area.left()+3, area.center().y()), QPointF(area.right()-3, area.center().y()));
        const qreal cx = area.left() + 6 + (area.width()-12) * (static_cast<qreal>(x_) / 127.0);
        const qreal cy = area.bottom()-6 - (area.height()-12) * (static_cast<qreal>(y_) / 127.0);
        p.setPen(QPen(QColor("#6d6d6d"), 2)); p.setBrush(QColor("#b7b7b7")); p.drawEllipse(QPointF(cx, cy), 7, 7);
        p.setPen(QColor("#c6dfde")); p.setFont(QFont(p.font().family(), 7));
        p.drawText(QRectF(area.left()+2, area.bottom()-14, area.width()-4, 11), Qt::AlignRight|Qt::AlignVCenter,
                   QStringLiteral("X %1  Y %2").arg(x_).arg(y_));
    }
    void mousePressEvent(QMouseEvent *event) override { updateFromPoint(event->position()); event->accept(); }
    void mouseMoveEvent(QMouseEvent *event) override { if (event->buttons() & Qt::LeftButton) updateFromPoint(event->position()); event->accept(); }
private:
    int x_ = 64, y_ = 64;
    std::function<void(int, int)> changed_;
    void updateFromPoint(const QPointF &point) {
        const QRectF area = QRectF(rect()).adjusted(15, 13, -15, -13);
        if (area.width() <= 0 || area.height() <= 0) return;
        const int nx = std::clamp(qRound((point.x()-area.left())/area.width()*127.0),0,127);
        const int ny = std::clamp(qRound((area.bottom()-point.y())/area.height()*127.0),0,127);
        if (nx == x_ && ny == y_) return;
        x_ = nx; y_ = ny; update(); if (changed_) changed_(x_, y_);
    }
};

class LcdPickerItemDelegate final : public QStyledItemDelegate {
public:
    explicit LcdPickerItemDelegate(bool voiceMode, QObject *parent = nullptr)
        : QStyledItemDelegate(parent), voiceMode_(voiceMode) {}

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const override {
        QSize hint = QStyledItemDelegate::sizeHint(option, index);
        if (voiceMode_) {
            hint.setHeight(40);
            hint.setWidth(option.widget ? std::max(360, option.widget->width()) : 480);
        } else {
            hint.setHeight(45);
        }
        return hint;
    }

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const override {
        painter->save();
        const QRect row = option.rect;
        const bool selected = option.state.testFlag(QStyle::State_Selected);
        painter->fillRect(row, selected ? QColor(QStringLiteral("#665400"))
                                        : QColor(QStringLiteral("#2e2e2e")));
        painter->setPen(QColor(QStringLiteral("#414141")));
        painter->drawLine(row.bottomLeft(), row.bottomRight());

        int textLeft = row.left() + 9;
        const QIcon icon = qvariant_cast<QIcon>(index.data(Qt::DecorationRole));
        if (voiceMode_) {
            const QRect iconRect(row.left() + 7, row.top() + 2, 54, 36);
            if (!icon.isNull()) icon.paint(painter, iconRect, Qt::AlignCenter, QIcon::Normal, QIcon::Off);
            textLeft = row.left() + 70;
        }

        const QString badge = index.data(Qt::UserRole + 2).toString();
        const QString secondary = index.data(Qt::UserRole + 1).toString();
        const QFont originalFont = painter->font();
        QFont mainFont = originalFont;
        mainFont.setPointSize(9);
        painter->setFont(mainFont);
        painter->setPen(selected ? QColor(QStringLiteral("#ffffff"))
                                 : QColor(QStringLiteral("#bdbdbd")));
        const int rightReserve = voiceMode_ ? 152 : 102;
        QRect mainRect(textLeft, row.top() + (voiceMode_ ? 1 : 3),
                       std::max(0, row.right() - textLeft - rightReserve),
                       voiceMode_ ? 21 : 21);
        painter->drawText(mainRect, Qt::AlignVCenter | Qt::AlignLeft,
                          painter->fontMetrics().elidedText(index.data(Qt::DisplayRole).toString(),
                                                             Qt::ElideRight, mainRect.width()));

        if (!badge.isEmpty()) {
            QFont badgeFont = originalFont;
            badgeFont.setPointSize(7);
            painter->setFont(badgeFont);
            const int badgeWidth = std::min(122, std::max(48, painter->fontMetrics().horizontalAdvance(badge) + 14));
            const QRect badgeRect(row.right() - badgeWidth - 7, row.top() + (voiceMode_ ? 2 : 5),
                                  badgeWidth, 16);
            painter->setPen(Qt::NoPen);
            painter->setBrush(QColor(QStringLiteral("#c5c5c5")));
            painter->drawRoundedRect(badgeRect, 2, 2);
            painter->setPen(QColor(QStringLiteral("#333333")));
            painter->drawText(badgeRect.adjusted(3, 0, -3, 0), Qt::AlignCenter,
                              painter->fontMetrics().elidedText(badge, Qt::ElideRight, badgeRect.width() - 6));
        }

        if (!secondary.isEmpty()) {
            QFont detailFont = originalFont;
            detailFont.setPointSize(7);
            painter->setFont(detailFont);
            painter->setPen(selected ? QColor(QStringLiteral("#f4e8b4"))
                                     : QColor(QStringLiteral("#b5b5b5")));
            const int detailTop = voiceMode_ ? row.top() + 21 : row.top() + 23;
            painter->drawText(QRect(textLeft, detailTop, row.width() - (textLeft - row.left()) - 8, 16),
                              voiceMode_ ? (Qt::AlignLeft | Qt::AlignVCenter)
                                         : (Qt::AlignRight | Qt::AlignVCenter), secondary);
        }
        painter->restore();
    }

private:
    bool voiceMode_ = false;
};

class EnsemblesWindow final : public QMainWindow {
public:
    EnsemblesWindow() {
        const bool safeUiMode = QCoreApplication::arguments().contains(QStringLiteral("--safe-ui"));
        startupTrace(safeUiMode ? "window: constructor begin (--safe-ui)" : "window: constructor begin");
        setWindowFlag(Qt::FramelessWindowHint, true); // Original application uses an in-client titlebar.
        setWindowTitle(QStringLiteral("Ensembles"));
        resize(1344, 708); // Original reference content canvas; controls retain its proportions.
        setMinimumSize(1040, 680);
        if (QScreen *screen = QGuiApplication::primaryScreen()) {
            const QRect area = screen->availableGeometry();
            move(area.center() - QPoint(width() / 2, height() / 2));
        }
        startupTrace("window: before application stylesheet");
        setStyleSheet(QString::fromLatin1(R"STYLE(
            QMainWindow { background: #101010; color: #e5e5e5; }
            QWidget { color: #dedede; font-family: "Segoe UI"; font-size: 9pt; }
            QWidget#appSurface { background: #222222; }
            QFrame#panel { border: 1px solid #080808; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #414141, stop:1 #292929); }
            QWidget#headerBar { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #3c3c3c, stop:1 #202020); border: 1px solid #070707; }
            QLabel#appTitle { font-size: 10pt; font-weight: 700; color: #f0f0f0; }
            QLabel#sectionLabel { color: #929292; font-size: 8pt; }
            QLabel#metricHeading { color: #b6b6b6; font-size: 8pt; }
            QLabel#metricValue { color: #9deeea; font-size: 9pt; font-weight: 600; }
            QPushButton, QToolButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #5a5a5a, stop:0.45 #454545, stop:1 #303030); border: 1px solid #171717; border-top-color: #666666; border-radius: 1px; padding: 1px 4px; color: #f0f0f0; }
            QPushButton:hover, QToolButton:hover { border-color: #777777; background: #555555; }
            QPushButton:pressed, QToolButton:pressed { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #5a5a5a, stop:1 #303030); border-color: #2c8c83; }
            QPushButton:checked, QToolButton:checked, QToolButton[active="true"] { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #5a5a5a, stop:0.45 #454545, stop:1 #303030); border: 1px solid #171717; border-top: 4px solid #459bf4; }
            QPushButton#flatButton { padding: 1px 3px; }
            QPushButton#transportPlay { background: #cf202c; border: 1px solid #701016; color: white; font-size: 15pt; font-weight: 700; }
            QPushButton#transportPlay:hover { background: #e12b38; }
            QPushButton#blueAction { background: #24608c; border-color: #102e45; }
            QPushButton#redAction { background: #bb1e2b; border-color: #671017; }
            QPushButton#displayTab { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #00675f, stop:1 #004f49); border: 0; border-right: 1px solid #08423e; padding: 0; }
            QPushButton#displayTab:hover { background: #087568; }
            QPushButton#displayTab QLabel:first-child { color: #ffffff; font-size: 10pt; }
            QPushButton#displayTab QLabel:last-child { color: #d3efea; font-size: 8pt; }
            QDial { background: transparent; border: 0; }
            QSlider::groove:vertical { width: 5px; background: #202020; border: 1px solid #111111; }
            QSlider::handle:vertical { width: 11px; height: 13px; margin: 0 -4px; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #c6c6c6, stop:1 #a5a5a5); border: 1px solid #4e4e4e; border-radius: 0; }
            QSlider[masterTarget="true"]::handle:vertical { background: #c7a43d; border-color: #f0d57a; }
            QSlider::groove:horizontal { height: 5px; background: #202020; border: 1px solid #111111; }
            QSlider::handle:horizontal { width: 13px; height: 11px; margin: -4px 0; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #c6c6c6, stop:1 #a5a5a5); border: 1px solid #4e4e4e; border-radius: 0; }
            QSpinBox, QComboBox { background: #393939; color: #eeeeee; border: 1px solid #151515; padding: 1px 3px; min-height: 20px; }
            QProgressBar { background: #202727; border: 1px solid #111; border-radius: 0; }
            QProgressBar::chunk { background: qlineargradient(x1:0,y1:1,x2:0,y2:0, stop:0 #0a756e, stop:0.6 #459f56, stop:1 #a8c936); }
            QCheckBox { spacing: 5px; }
            QDialog { background: #242424; }
        )STYLE"));
        startupTrace("window: application stylesheet complete");

        startupTrace("window: entering buildUi");
        buildUi();
        channelActivityTimer_.setInterval(55);
        connect(&channelActivityTimer_, &QTimer::timeout, this, [this] {
            for (std::size_t i = 0; i < channelActivityLevels_.size(); ++i) {
                channelActivityLevels_[i] = std::max(0, channelActivityLevels_[i] - 9);
                if (channelActivityMeters_[i] && channelActivityMeters_[i]->value() != channelActivityLevels_[i])
                    channelActivityMeters_[i]->setValue(channelActivityLevels_[i]);
            }
        });
        channelActivityTimer_.start();
        startupTrace("window: buildUi returned");
        if (safeUiMode) {
            // This mode deliberately skips QSettings, MIDI device enumeration,
            // NativeTS/SCVA, FluidSynth, VST2 and style-engine startup. It is a
            // diagnostic isolation mode, not the normal audio-enabled launch.
            setStatus(QStringLiteral("SAFE UI MODE — audio/MIDI startup intentionally skipped"));
            startupTrace("window: --safe-ui skipped runtime/audio initialization");
        } else {
            startupTrace("window: before refreshMidiInputDevices");
            refreshMidiInputDevices();
            startupTrace("window: after refreshMidiInputDevices");
            loadPanelSettings();
            startupTrace("window: after loadPanelSettings");
            audioSettingsReady_ = true;
            loadControllerMaps();
            refreshControllerTooltips();
            updateAssignmentButtonAvailability();
            startupTrace("window: before openMidiOutput");
            openMidiOutput();
            startupTrace("window: before initializeAudioEngine (Native SCVA / fallback)");
            initializeAudioEngine();
            startupTrace("window: initializeAudioEngine returned");
            applyInitialMixerLevels();
            for (int i = 0; i < static_cast<int>(rightVoiceFaders_.size()); ++i) {
                if (!rightVoiceFaders_[static_cast<std::size_t>(i)]) continue;
                static constexpr int extChannels[4] = {1, 0, 2, 3};
                static constexpr int intChannels[4] = {19, 17, 18, 3};
                sendMidi(static_cast<quint8>(0xB0 | extChannels[i]), 7,
                         static_cast<quint8>(rightVoiceFaders_[static_cast<std::size_t>(i)]->value()), intChannels[i]);
            }
            applyPanelMidiSettings();
            for (int channel = 0; channel < 3; ++channel) {
                const auto slot = static_cast<std::size_t>(channel);
                sendMidi(static_cast<quint8>(0xB0 | channel), 32, static_cast<quint8>(voiceMaps_[slot]), internalVoiceChannel(channel));
                sendMidi(static_cast<quint8>(0xB0 | channel), 0, static_cast<quint8>(voiceBanks_[slot]), internalVoiceChannel(channel));
                sendMidi(static_cast<quint8>(0xC0 | channel), static_cast<quint8>(voicePrograms_[slot]), 0, internalVoiceChannel(channel));
            }
            for (int i = 0; i < 10; ++i) {
                if (assignableSliders_[static_cast<std::size_t>(i)])
                    handleAssignableControlValue(i, assignableSliders_[static_cast<std::size_t>(i)]->value());
            }
            for (int i = 0; i < 4; ++i) {
                if (assignableKnobs_[static_cast<std::size_t>(i)])
                    handleAssignableControlValue(10 + i, assignableKnobs_[static_cast<std::size_t>(i)]->value());
            }
            startupTrace("window: before setupStyleEngine");
            setupStyleEngine();
            startupTrace("window: setupStyleEngine returned");
        }
        styleTimer_.setInterval(3);
        connect(&styleTimer_, &QTimer::timeout, this, [this] { onStyleTick(); });
        modulationTimer_.setInterval(10);
        connect(&modulationTimer_, &QTimer::timeout, this, [this] { onModulationTick(); });
        playbackTimer_.setInterval(3);
        connect(&playbackTimer_, &QTimer::timeout, this, [this] { onPlaybackTick(); });
    }

    // Data Entry selects the active Voice or Style directly within the central LCD.
    void rotateDataEntryDial(int value) {
        int delta = value - dataEntryDialLastValue_;
        if (delta > 64) delta -= 128;
        else if (delta < -64) delta += 128;
        dataEntryDialLastValue_ = value;
        if (delta == 0) return;

        if (dataEntryStyleMode_) {
            if (!lcdStyleList_ || lcdStyleList_->count() == 0) {
                setStatus(QStringLiteral("Belum ada Style pada daftar LCD."));
                return;
            }
            int row = lcdStyleList_->currentRow();
            if (row < 0) row = 0;
            row = std::clamp(row + delta, 0, lcdStyleList_->count() - 1);
            lcdStyleList_->setCurrentRow(row); // The existing row handler loads the selected Style.
            if (lcdStyleList_->item(row)) setStatus(QStringLiteral("Style: %1").arg(lcdStyleList_->item(row)->text()));
            return;
        }

        if (voiceSelectFilteredEntries_.empty()) openVoiceSelectPage(selectedProgramChannel_);
        const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        int selectedIndex = -1;
        for (std::size_t i = 0; i < voiceSelectFilteredEntries_.size(); ++i) {
            const auto &entry = voiceSelectFilteredEntries_[i];
            if (entry.program == voicePrograms_[slot] && entry.bank == voiceBanks_[slot] && entry.map == voiceMaps_[slot]) {
                selectedIndex = static_cast<int>(i);
                break;
            }
        }
        if (voiceSelectFilteredEntries_.empty()) {
            setStatus(QStringLiteral("Tidak ada Voice di kategori/map yang aktif."));
            return;
        }
        if (selectedIndex < 0) selectedIndex = std::clamp(voiceSelectPage_ * 12, 0, static_cast<int>(voiceSelectFilteredEntries_.size()) - 1);
        selectedIndex = std::clamp(selectedIndex + delta, 0, static_cast<int>(voiceSelectFilteredEntries_.size()) - 1);
        voiceSelectPage_ = selectedIndex / 12;
        refreshVoiceSelectPage();
        applyVoiceCatalogEntry(voiceSelectFilteredEntries_[static_cast<std::size_t>(selectedIndex)]);
        setStatus(QStringLiteral("Voice %1: %2").arg(selectedProgramChannel_ == 0 ? QStringLiteral("R1") : selectedProgramChannel_ == 1 ? QStringLiteral("L") : QStringLiteral("R2"), voiceSelectFilteredEntries_[static_cast<std::size_t>(selectedIndex)].name));
    }

    void activateDataEntryContext() {
        if (!lcdContentStack_) return;
        const QWidget *current = lcdContentStack_->currentWidget();
        if (current == lcdVoicePickerPage_ || current == lcdStylePickerPage_) {
            if (lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
            return;
        }
        if (dataEntryStyleMode_) {
            if (lcdStylePickerPage_) lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
        } else {
            openVoiceSelectPage(selectedProgramChannel_);
        }
    }

    // Used by the launcher to switch the central LCD to Voice Select after show().
    void showVoiceSelectPreview() { dataEntryStyleMode_ = false; openVoiceSelectPage(0); }

    ~EnsemblesWindow() override {
        playbackTimer_.stop();
        modulationTimer_.stop();
        styleTimer_.stop();
        channelActivityTimer_.stop();
        arpeggiatorTimer_.stop();
        styleEngine_.stop();
        allSoundsOff();
#ifdef _WIN32
        closeAllMidiInputDevices();
        if (midiOut_) {
            midiOutReset(midiOut_);
            midiOutClose(midiOut_);
            midiOut_ = nullptr;
        }
#endif
    }

private:
    enum ControlTarget : int {
        GenericMidiCc = 0,
        VoiceLVolume = 1,
        VoiceR1Volume = 2,
        VoiceR2Volume = 3,
        StyleVolume = 4,
        ReverbSend = 5,
        ChorusSend = 6,
        FilterCutoff = 7,
        FilterResonance = 8,
        VoiceExpression = 9,
        DrumVolume = 10,
        VoicePan = 11,
        VoiceModulation = 12,
        MasterVolume = 13,
        VoiceVolumeAll = 14,
        VoiceAttack = 15,
        VoiceRelease = 16,
        VoiceVibratoRate = 17,
        VoiceVibratoDepth = 18,
        SongVolume = 19,
        AudioVolume = 20,
        PadsVolume = 21,
        ChordVolume = 22
    };
    struct ControllerMap {
        bool assigned = false;
        int channel = 0; // zero-based MIDI channel for Generic MIDI CC
        int controller = 74;
        int target = GenericMidiCc;
    };
    std::array<ControllerMap, 16> controllerMaps_{}; // sliders 1..10, knobs 1..4, joystick X/Y
    std::array<bool, 14> masterTargets_{}; // ten sliders and four physical knobs; joystick axes are direct mappings.
    int styleVolume_ = 127; // Style bus level (0..127).
    int songVolume_ = 127; // MIDI-file playback velocity/CC7 scale.
    int audioFaderVolume_ = 127; // Temporary audio-layer fader until a dedicated audio-file player exists.
    int padsVolume_ = 127; // GM pad velocity scale.
    int chordVolume_ = 127; // Style accompaniment note velocity scale, separate from drum channel.
    std::array<QSlider *, 10> assignableSliders_{}; // First six are the fixed function faders on the reference left panel.
    std::array<QLabel *, 10> assignableSliderNameLabels_{};
    std::array<QSlider *, 4> rightVoiceFaders_{}; // L, R1, R2, R3; R3 uses MIDI channel 4.
    QDial *dataEntryDial_ = nullptr;
    int dataEntryDialLastValue_ = 64;
    bool dataEntryStyleMode_ = false;
    std::array<QDial *, 4> assignableKnobs_{};
    std::array<QLabel *, 4> assignableKnobNameLabels_{};
    QDial *masterControlDial_ = nullptr;
    QLabel *masterControlNameLabel_ = nullptr;
    QPushButton *knobAssignButton_ = nullptr;
    QPushButton *masterAssignButton_ = nullptr;
    QPushButton *sliderAssignButton_ = nullptr;
    bool knobAssignMode_ = false;
    bool masterAssignMode_ = false;
    bool sliderAssignMode_ = false;
    std::array<QPushButton *, 10> registryButtons_{};
    QPushButton *registryMemorizeButton_ = nullptr;
    QLabel *registryBankLabel_ = nullptr;
    int currentRegistryBank_ = 0;
    bool registryMemorizeMode_ = false;
    std::array<QProgressBar *, 19> channelActivityMeters_{};
    std::array<int, 19> channelActivityLevels_{};
    std::array<QSlider *, 20> channelMixerSliders_{};
    QTimer channelActivityTimer_;
    QTimer arpeggiatorTimer_;
    struct ArpeggiatorHeldNote { int note = 0; int voiceSlot = 0; int velocity = 90; bool internalOnly = false; };
    std::vector<ArpeggiatorHeldNote> arpeggiatorHeldNotes_;
    int arpeggiatorStep_ = 0;
    int arpeggiatorCurrentNote_ = -1;
    int arpeggiatorCurrentVoiceSlot_ = 0;
    bool arpeggiatorCurrentLayered_ = false;
    bool arpeggiatorCurrentInternalOnly_ = false;

    QLabel *statusLabel_ = nullptr;
    QLabel *midiFileLabel_ = nullptr;
    QLabel *recordLabel_ = nullptr;
    QLabel *outputLabel_ = nullptr;
    QPushButton *playButton_ = nullptr;
    QPushButton *recordButton_ = nullptr;
    QComboBox *programCombo_ = nullptr;
    QComboBox *styleCombo_ = nullptr;
    QLabel *styleInfo_ = nullptr;
    QLabel *chordLabel_ = nullptr;
    QSlider *tempoSlider_ = nullptr;
    QLabel *tempoValue_ = nullptr; // Central display tempo metric
    QLabel *tempoDialogValue_ = nullptr;
    QSlider *gainSlider_ = nullptr;
    QCheckBox *metronomeCheck_ = nullptr;
    QCheckBox *lfoCheck_ = nullptr;
    QCheckBox *reverbCheck_ = nullptr;
    QCheckBox *chorusCheck_ = nullptr;
    QDialog *styleDialog_ = nullptr;
    QDialog *voiceDialog_ = nullptr;
    QStackedWidget *lcdContentStack_ = nullptr;
    QWidget *lcdHomePage_ = nullptr;
    QWidget *lcdVoicePickerPage_ = nullptr;
    QWidget *lcdStylePickerPage_ = nullptr;
    QListWidget *lcdVoiceList_ = nullptr;
    QListWidget *lcdStyleList_ = nullptr;
    QLabel *lcdVoicePickerTitle_ = nullptr;
    QLabel *lcdVoicePickerSubtitle_ = nullptr;
    QComboBox *lcdVoiceMapCombo_ = nullptr;
    QComboBox *lcdVoiceCategoryCombo_ = nullptr;
    QComboBox *lcdVoiceBankCombo_ = nullptr;
    QPushButton *lcdVoicePrevPage_ = nullptr;
    QPushButton *lcdVoiceNextPage_ = nullptr;
    QLabel *lcdVoicePageLabel_ = nullptr;
    int lcdVoicePage_ = 0;
    std::vector<VoiceCatalogEntry> voiceCatalog_;
    std::vector<VoiceCatalogEntry> filteredVoiceCatalog_;
    // Screenshot-matched Voice Select page embedded in the central LCD stack.
    QWidget *voiceSelectPageWidget_ = nullptr;
    QLabel *voiceSelectTitleLabel_ = nullptr;
    QListWidget *voiceSelectCategoryList_ = nullptr;
    QWidget *voiceSelectGridHost_ = nullptr;
    QGridLayout *voiceSelectGridLayout_ = nullptr;
    QHBoxLayout *voiceSelectPageButtonsLayout_ = nullptr;
    QPushButton *voiceSelectPreviousPageButton_ = nullptr;
    QPushButton *voiceSelectNextPageButton_ = nullptr;
    QLabel *voiceSelectPageSummaryLabel_ = nullptr;
    std::vector<QPushButton *> voiceSelectModelButtons_;
    std::vector<VoiceCatalogEntry> voiceSelectFilteredEntries_;
    QString voiceSelectCategory_ = QStringLiteral("Piano");
    int voiceSelectMap_ = 4;
    int voiceSelectPage_ = 0;
    std::array<int, 3> voiceMaps_ = {4, 4, 4};
    std::array<int, 3> voiceBanks_ = {0, 0, 0};
    QCheckBox *nativeEfxCheck_ = nullptr;
    QComboBox *nativeEfxTypeCombo_ = nullptr;
    QToolButton *nativeEfxPanelButton_ = nullptr;
    QLabel *nativeEfxNameLabel_ = nullptr;
    std::array<QSpinBox *, 20> nativeEfxParams_{};
    QDialog *settingsDialog_ = nullptr;
    JoystickPadWidget *joystickPad_ = nullptr;
    QPushButton *joystickXAssignButton_ = nullptr;
    QPushButton *joystickYAssignButton_ = nullptr;
    QComboBox *audioRoutingCombo_ = nullptr;
    QComboBox *audioApiCombo_ = nullptr;
    QComboBox *audioDeviceCombo_ = nullptr;
    QPushButton *refreshAudioDevicesButton_ = nullptr;
    QPushButton *testAudioButton_ = nullptr;
    QComboBox *audioSampleRateCombo_ = nullptr;
    QComboBox *audioBufferCombo_ = nullptr;
    QLabel *audioOutputStatusLabel_ = nullptr;
    QListWidget *midiInputDeviceList_ = nullptr;
    QPushButton *refreshMidiInputDevicesButton_ = nullptr;
    QLabel *midiInputStatusLabel_ = nullptr;
    QCheckBox *midiSplitByChannelCheck_ = nullptr;
    std::vector<ensembles::AudioEngine::OutputDevice> audioOutputDevices_;
    bool audioSettingsReady_ = false;
    QLabel *soundFontStatusLabel_ = nullptr;
    QPushButton *chooseSoundFontButton_ = nullptr;
    QLabel *vst2PluginStatusLabel_ = nullptr;
    QPushButton *chooseVst2PluginButton_ = nullptr;
    QPushButton *disableVst2PluginButton_ = nullptr;
    QString soundFontPath_;
    QString vst2PluginPath_;
    std::unique_ptr<ensembles::AudioEngine> audioEngine_ = std::make_unique<ensembles::AudioEngine>();
    QDialog *recorderDialog_ = nullptr;
    PianoKeyboardWidget *pianoKeyboard_ = nullptr;
    QLabel *styleNameLabel_ = nullptr;
    QLabel *voiceLLabel_ = nullptr;
    QLabel *voiceR1Label_ = nullptr;
    QLabel *voiceR2Label_ = nullptr;
    QLabel *measureMetricLabel_ = nullptr;
    QLabel *beatMetricLabel_ = nullptr;
    QLabel *transposeMetricLabel_ = nullptr;
    QLabel *octaveMetricLabel_ = nullptr;
    QSpinBox *transposeSpin_ = nullptr;
    QSpinBox *octaveSpin_ = nullptr;
    QSpinBox *reverbLevelSpin_ = nullptr;
    QSpinBox *chorusLevelSpin_ = nullptr;
    bool transposeActive_ = false;
    bool octaveShiftActive_ = false;
    bool accompanimentEnabled_ = false; // Original ControlPanel "Chords" / accompaniment switch
    bool layerEnabled_ = false;
    bool splitEnabled_ = false;
    int transposeAmount_ = 0;
    int octaveShiftAmount_ = 0;
    int splitKey_ = kOriginalSplitKey;
    QPushButton *accompButton_ = nullptr;
    QPushButton *layerButton_ = nullptr;
    QPushButton *splitButton_ = nullptr;
    QPushButton *metronomeButton_ = nullptr;
    QToolButton *transposeButton_ = nullptr;
    QToolButton *octaveButton_ = nullptr;
    QToolButton *reverbButton_ = nullptr;
    QToolButton *chorusButton_ = nullptr;
    QToolButton *arpButton_ = nullptr;
    QToolButton *harmonizerButton_ = nullptr;
    QSpinBox *arpSpin_ = nullptr;
    QSpinBox *harmonizerSpin_ = nullptr;
    int selectedProgramChannel_ = 0; // GM output channels: R1=1, L=2, R2=3
    std::array<int, 3> voicePrograms_ = {0, 33, 49};
    QTimer playbackTimer_;
    QTimer modulationTimer_;
    QTimer styleTimer_;
    QElapsedTimer playbackClock_;
    QElapsedTimer recordClock_;
    QElapsedTimer modulationClock_;
    QElapsedTimer styleClock_;
    qint64 lastStyleElapsedUs_ = 0;
    ensembles::StyleEngine styleEngine_;
    ensembles::MidiFile midiFile_;
    QString midiPath_;
    QString pendingStylePath_;
    int pendingStyleTempoBpm_ = 0;
    std::size_t playbackIndex_ = 0;
    bool playbackActive_ = false;
    bool recording_ = false;
    std::vector<ensembles::MidiEvent> recordedEvents_;
    int baseNote_ = 36;
    int tempo_ = 120;
    int beatCount_ = 0;
    qint64 nextBeatUs_ = 0;
    qint64 lastLfoUs_ = 0;
    bool midiOutputReady_ = false;
#ifdef _WIN32
    HMIDIOUT midiOut_ = nullptr;
    std::map<UINT, HMIDIIN> midiInputHandles_;
#endif
    int resizingEdges_ = 0;
    QPoint resizeStartGlobal_;
    QRect resizeStartGeometry_;

    // Match the original FluidSynth synthesizer.c mapping: R1=17, R2/layer=18, L/split=19.
    // UI voice slots remain ordered [R1, L, R2] for backward-compatible settings.
    static int internalVoiceChannel(int voiceSlot) noexcept {
        static constexpr int channels[] = {17, 19, 18};
        return voiceSlot >= 0 && voiceSlot < 3 ? channels[voiceSlot] : 17;
    }

    void setStatus(const QString &message) {
        if (statusLabel_) {
            statusLabel_->setText(QFontMetrics(statusLabel_->font()).elidedText(message, Qt::ElideRight, statusLabel_->maximumWidth()));
            statusLabel_->setToolTip(message);
            statusLabel_->show();
        }
        statusBar()->showMessage(message, 6000);
    }

    static QString controllerLabel(int cc) {
        switch (cc) {
        case 1: return QStringLiteral("Modulation (CC 1)");
        case 3: return QStringLiteral("Controller 3 / Pitch (CC 3)");
        case 7: return QStringLiteral("Volume (CC 7)");
        case 10: return QStringLiteral("Pan (CC 10)");
        case 11: return QStringLiteral("Expression (CC 11)");
        case 71: return QStringLiteral("Resonance (CC 71)");
        case 72: return QStringLiteral("Release Time (CC 72)");
        case 73: return QStringLiteral("Attack Time (CC 73)");
        case 74: return QStringLiteral("Filter Cutoff (CC 74)");
        case 76: return QStringLiteral("Vibrato Rate (CC 76)");
        case 77: return QStringLiteral("Vibrato Depth (CC 77)");
        case 91: return QStringLiteral("Reverb Send (CC 91)");
        case 93: return QStringLiteral("Chorus Send (CC 93)");
        default: return QStringLiteral("MIDI CC %1").arg(cc);
        }
    }

    static QString controlTargetLabel(int target) {
        switch (target) {
        case VoiceLVolume: return QStringLiteral("Voice L Volume");
        case VoiceR1Volume: return QStringLiteral("Voice R1 Volume");
        case VoiceR2Volume: return QStringLiteral("Voice R2 Volume");
        case StyleVolume: return QStringLiteral("Style Volume");
        case ReverbSend: return QStringLiteral("Reverb Send (selected Voice)");
        case ChorusSend: return QStringLiteral("Chorus Send (selected Voice)");
        case FilterCutoff: return QStringLiteral("Filter Cutoff (CC 74, selected Voice)");
        case FilterResonance: return QStringLiteral("Filter Resonance (CC 71, selected Voice)");
        case VoiceExpression: return QStringLiteral("Expression (CC 11, selected Voice)");
        case DrumVolume: return QStringLiteral("Drum Volume (MIDI channel 10)");
        case VoicePan: return QStringLiteral("Pan (CC 10, selected Voice)");
        case VoiceModulation: return QStringLiteral("Modulation (CC 1, selected Voice)");
        case MasterVolume: return QStringLiteral("Master Volume");
        case VoiceVolumeAll: return QStringLiteral("Voice Volume — L + R1 + R2 bersama");
        case VoiceAttack: return QStringLiteral("Attack Time (CC 73, Voice terpilih)");
        case VoiceRelease: return QStringLiteral("Release Time (CC 72, Voice terpilih)");
        case VoiceVibratoRate: return QStringLiteral("Vibrato Rate (CC 76, Voice terpilih)");
        case VoiceVibratoDepth: return QStringLiteral("Vibrato Depth (CC 77, Voice terpilih)");
        case SongVolume: return QStringLiteral("Song playback volume");
        case AudioVolume: return QStringLiteral("Audio output layer (temporary, before Audio Player)");
        case PadsVolume: return QStringLiteral("Percussion pad velocity");
        case ChordVolume: return QStringLiteral("Accompaniment/chord level");
        default: return QStringLiteral("Custom MIDI CC");
        }
    }

    // Compact labels stay directly attached to each physical control; full names remain in tooltips.
    static QString controlShortLabel(int target, int controller, bool assigned = true) {
        if (!assigned) return QStringLiteral("Unmap");
        if (target == GenericMidiCc) {
            switch (controller) {
            case 1: return QStringLiteral("Mod");
            case 7: return QStringLiteral("Vol");
            case 10: return QStringLiteral("Pan");
            case 11: return QStringLiteral("Expr.");
            case 71: return QStringLiteral("Reso");
            case 72: return QStringLiteral("Release");
            case 73: return QStringLiteral("Attack");
            case 74: return QStringLiteral("Cutoff");
            case 76: return QStringLiteral("Vib Rate");
            case 77: return QStringLiteral("Vib Depth");
            case 91: return QStringLiteral("Reverb");
            case 93: return QStringLiteral("Chorus");
            default: return QStringLiteral("CC%1").arg(controller);
            }
        }
        switch (target) {
        case VoiceLVolume: return QStringLiteral("L Vol");
        case VoiceR1Volume: return QStringLiteral("R1 Vol");
        case VoiceR2Volume: return QStringLiteral("R2 Vol");
        case StyleVolume: return QStringLiteral("Style");
        case ReverbSend: return QStringLiteral("Rev Send");
        case ChorusSend: return QStringLiteral("Ch Send");
        case FilterCutoff: return QStringLiteral("Cutoff");
        case FilterResonance: return QStringLiteral("Reso");
        case VoiceExpression: return QStringLiteral("Expr.");
        case DrumVolume: return QStringLiteral("Drum");
        case VoicePan: return QStringLiteral("Pan");
        case VoiceModulation: return QStringLiteral("Mod");
        case MasterVolume: return QStringLiteral("Master");
        case VoiceVolumeAll: return QStringLiteral("Voice Vol");
        case VoiceAttack: return QStringLiteral("Attack");
        case VoiceRelease: return QStringLiteral("Release");
        case VoiceVibratoRate: return QStringLiteral("Vib Rate");
        case VoiceVibratoDepth: return QStringLiteral("Vib Depth");
        case SongVolume: return QStringLiteral("SONG");
        case AudioVolume: return QStringLiteral("AUDIO");
        case PadsVolume: return QStringLiteral("PADS");
        case ChordVolume: return QStringLiteral("CHORD");
        default: return QStringLiteral("CC%1").arg(controller);
        }
    }

    static int defaultControlTarget(int index) {
        // Slider 1..10, then assignable knob 1..4. Joystick X/Y remain generic CC mappings.
        // Simplified V15: avoid three confusing voice-volume faders and duplicate
        // Reverb/Chorus assignments across both faders and knobs.
        static constexpr int defaults[14] = {
            StyleVolume, SongVolume, AudioVolume, PadsVolume, DrumVolume, ChordVolume,
            VoicePan, VoiceModulation, ReverbSend, ChorusSend,
            FilterCutoff, FilterResonance, ReverbSend, ChorusSend
        };
        return index >= 0 && index < 14 ? defaults[index] : GenericMidiCc;
    }

    static int defaultControllerForTarget(int target) {
        switch (target) {
        case VoiceLVolume: case VoiceR1Volume: case VoiceR2Volume:
        case VoiceVolumeAll: case StyleVolume: case DrumVolume: return 7;
        case ReverbSend: return 91;
        case ChorusSend: return 93;
        case FilterCutoff: return 74;
        case FilterResonance: return 71;
        case VoiceExpression: return 11;
        case VoicePan: return 10;
        case VoiceModulation: return 1;
        case VoiceAttack: return 73;
        case VoiceRelease: return 72;
        case VoiceVibratoRate: return 76;
        case VoiceVibratoDepth: return 77;
        case SongVolume: case AudioVolume: case PadsVolume: case ChordVolume: return 7;
        case MasterVolume: return 7;
        default: return 74;
        }
    }

    QString registrySlotGroupName(int slot, int bank = -1) const {
        const int resolvedBank = bank < 0 ? currentRegistryBank_ : bank;
        // Preserve old first-bank snapshots; additional banks have independent slots.
        if (resolvedBank == 0) return QStringLiteral("registry/slots/%1").arg(slot + 1);
        return QStringLiteral("registry/banks/%1/slots/%2").arg(resolvedBank + 1).arg(slot + 1);
    }

    void setRegistryBank(int bank) {
        currentRegistryBank_ = std::clamp(bank, 0, 99);
        QSettings settings;
        settings.setValue(QStringLiteral("registry/currentBank"), currentRegistryBank_);
        settings.sync();
        if (registryBankLabel_) registryBankLabel_->setText(QStringLiteral("%1").arg(currentRegistryBank_ + 1));
        updateRegistryButtonLabels();
        setStatus(QStringLiteral("Registration bank %1 aktif.").arg(currentRegistryBank_ + 1));
    }

    void updateRegistryButtonLabels() {
        QSettings settings;
        for (int i = 0; i < static_cast<int>(registryButtons_.size()); ++i) {
            auto *button = registryButtons_[static_cast<std::size_t>(i)];
            if (!button) continue;
            settings.beginGroup(registrySlotGroupName(i));
            const bool saved = settings.value(QStringLiteral("valid"), false).toBool();
            const QString stylePath = settings.value(QStringLiteral("stylePath")).toString();
            settings.endGroup();
            button->setText(saved ? QStringLiteral("%1*").arg(i + 1) : QString::number(i + 1));
            const QString styleName = stylePath.isEmpty()
                ? QStringLiteral("tanpa style") : QFileInfo(stylePath).completeBaseName();
            button->setToolTip(saved
                ? QStringLiteral("Bank %1 / Registration %2 tersimpan · %3. Klik untuk recall; aktifkan Memorize untuk menimpa.").arg(currentRegistryBank_ + 1).arg(i + 1).arg(styleName)
                : QStringLiteral("Bank %1 / Registration %2 kosong. Aktifkan Memorize lalu klik untuk menyimpan.").arg(currentRegistryBank_ + 1).arg(i + 1));
        }
    }

    void activateRegistrySlot(int slot) {
        if (slot < 0 || slot >= static_cast<int>(registryButtons_.size())) return;
        if (registryMemorizeMode_) {
            QSettings settings;
            const QString group = registrySlotGroupName(slot);
            settings.beginGroup(group);
            settings.setValue(QStringLiteral("valid"), true);
            settings.setValue(QStringLiteral("stylePath"), styleCombo_ ? styleCombo_->currentData().toString() : QString());
            settings.setValue(QStringLiteral("tempo"), tempoSlider_ ? tempoSlider_->value() : tempo_);
            settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]);
            settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]);
            settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
            settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]); settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]); settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
            settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]); settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]); settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
            settings.setValue(QStringLiteral("transpose"), transposeSpin_ ? transposeSpin_->value() : transposeAmount_);
            settings.setValue(QStringLiteral("transposeOn"), transposeButton_ && transposeButton_->isChecked());
            settings.setValue(QStringLiteral("octave"), octaveSpin_ ? octaveSpin_->value() : octaveShiftAmount_);
            settings.setValue(QStringLiteral("octaveOn"), octaveButton_ && octaveButton_->isChecked());
            settings.setValue(QStringLiteral("accompanimentOn"), accompButton_ && accompButton_->isChecked());
            settings.setValue(QStringLiteral("layerOn"), layerButton_ && layerButton_->isChecked());
            settings.setValue(QStringLiteral("splitOn"), splitButton_ && splitButton_->isChecked());
            settings.setValue(QStringLiteral("splitKey"), splitKey_);
            settings.setValue(QStringLiteral("metronomeOn"), metronomeCheck_ && metronomeCheck_->isChecked());
            settings.setValue(QStringLiteral("reverbOn"), reverbCheck_ && reverbCheck_->isChecked());
            settings.setValue(QStringLiteral("reverbLevel"), reverbLevelSpin_ ? reverbLevelSpin_->value() : 7);
            settings.setValue(QStringLiteral("chorusOn"), chorusCheck_ && chorusCheck_->isChecked());
            settings.setValue(QStringLiteral("chorusLevel"), chorusLevelSpin_ ? chorusLevelSpin_->value() : 2);
            settings.setValue(QStringLiteral("outputVolume"), gainSlider_ ? gainSlider_->value() : 75);
            settings.setValue(QStringLiteral("arpeggiatorType"), arpSpin_ ? arpSpin_->value() : 1);
            settings.setValue(QStringLiteral("arpeggiatorOn"), arpButton_ && arpButton_->isChecked());
            settings.setValue(QStringLiteral("harmonizerType"), harmonizerSpin_ ? harmonizerSpin_->value() : 1);
            settings.endGroup();
            settings.sync();
            if (registryMemorizeButton_) registryMemorizeButton_->setChecked(false);
            updateRegistryButtonLabels();
            setStatus(QStringLiteral("Registration Memory Bank %1 / Slot %2 disimpan.").arg(currentRegistryBank_ + 1).arg(slot + 1));
            return;
        }

        QSettings settings;
        settings.beginGroup(registrySlotGroupName(slot));
        if (!settings.value(QStringLiteral("valid"), false).toBool()) {
            settings.endGroup();
            setStatus(QStringLiteral("Registration Memory Bank %1 / Slot %2 masih kosong. Aktifkan Memorize untuk menyimpan preset.").arg(currentRegistryBank_ + 1).arg(slot + 1));
            return;
        }
        const QString stylePath = settings.value(QStringLiteral("stylePath")).toString();
        const int savedTempo = std::clamp(settings.value(QStringLiteral("tempo"), 120).toInt(), 40, 240);
        const std::array<int, 3> savedVoices = {
            std::clamp(settings.value(QStringLiteral("voiceR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceL"), 33).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceR2"), 49).toInt(), 0, 127)
        };
        const std::array<int, 3> savedVoiceMaps = {
            std::clamp(settings.value(QStringLiteral("voiceMapR1"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapL"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapR2"), 4).toInt(), 1, 4)
        };
        const std::array<int, 3> savedVoiceBanks = {
            std::clamp(settings.value(QStringLiteral("voiceBankR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankR2"), 0).toInt(), 0, 127)
        };
        const int savedTranspose = std::clamp(settings.value(QStringLiteral("transpose"), 0).toInt(), -12, 12);
        const bool savedTransposeOn = settings.value(QStringLiteral("transposeOn"), false).toBool();
        const int savedOctave = std::clamp(settings.value(QStringLiteral("octave"), 0).toInt(), -2, 2);
        const bool savedOctaveOn = settings.value(QStringLiteral("octaveOn"), false).toBool();
        const bool savedAccompaniment = settings.value(QStringLiteral("accompanimentOn"), false).toBool();
        const bool savedLayer = settings.value(QStringLiteral("layerOn"), false).toBool();
        const bool savedSplit = settings.value(QStringLiteral("splitOn"), false).toBool();
        const int savedSplitKey = std::clamp(settings.value(QStringLiteral("splitKey"), kOriginalSplitKey).toInt(), 36, 95);
        const bool savedMetronome = settings.value(QStringLiteral("metronomeOn"), false).toBool();
        const bool savedReverb = settings.value(QStringLiteral("reverbOn"), true).toBool();
        const int savedReverbLevel = std::clamp(settings.value(QStringLiteral("reverbLevel"), 7).toInt(), 0, 10);
        const bool savedChorus = settings.value(QStringLiteral("chorusOn"), true).toBool();
        const int savedChorusLevel = std::clamp(settings.value(QStringLiteral("chorusLevel"), 2).toInt(), 0, 10);
        const int savedOutputVolume = std::clamp(settings.value(QStringLiteral("outputVolume"), 75).toInt(), 0, 100);
        const int savedArpeggiatorType = std::clamp(settings.value(QStringLiteral("arpeggiatorType"), 1).toInt(), 1, 12);
        const bool savedArpeggiatorOn = settings.value(QStringLiteral("arpeggiatorOn"), false).toBool();
        const int savedHarmonizerType = std::clamp(settings.value(QStringLiteral("harmonizerType"), 1).toInt(), 1, 6);
        settings.endGroup();

        allSoundsOff();
        if (styleEngine_.isPlaying()) styleEngine_.stop();
        styleTimer_.stop();
        bool styleRestored = stylePath.isEmpty();
        if (styleCombo_) {
            const int styleIndex = stylePath.isEmpty() ? -1 : styleCombo_->findData(stylePath);
            if (styleIndex >= 0) {
                const QSignalBlocker blocker(styleCombo_);
                styleCombo_->setCurrentIndex(styleIndex);
                styleRestored = applyStyleFile(stylePath, savedTempo);
            } else if (stylePath.isEmpty()) {
                const QSignalBlocker blocker(styleCombo_);
                styleCombo_->setCurrentIndex(-1);
                styleEngine_.unloadStyle();
                if (styleNameLabel_) styleNameLabel_->setText(QStringLiteral("No Style"));
                if (styleInfo_) styleInfo_->setText(QStringLiteral("Belum ada style dipilih."));
            }
        }
        tempo_ = savedTempo;
        if (tempoSlider_) { const QSignalBlocker blocker(tempoSlider_); tempoSlider_->setValue(savedTempo); }
        if (tempoValue_) tempoValue_->setText(QString::number(savedTempo));
        if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(savedTempo));
        styleEngine_.setTempo(savedTempo);

        voicePrograms_ = savedVoices;
        for (int i = 0; i < 3; ++i) {
            const auto slot = static_cast<std::size_t>(i);
            const int map = savedVoiceMaps[slot];
            const int bank = savedVoiceBanks[slot];
            voiceMaps_[slot] = map; voiceBanks_[slot] = bank;
            sendMidi(static_cast<quint8>(0xB0 | i), 32, static_cast<quint8>(map), internalVoiceChannel(i));
            sendMidi(static_cast<quint8>(0xB0 | i), 0, static_cast<quint8>(bank), internalVoiceChannel(i));
            sendMidi(static_cast<quint8>(0xC0 | i), static_cast<quint8>(voicePrograms_[slot]), 0, internalVoiceChannel(i));
        }
        auto voiceLabelForSlot = [this](int slot) {
            const auto program = voicePrograms_[static_cast<std::size_t>(slot)];
            const auto bank = voiceBanks_[static_cast<std::size_t>(slot)];
            const auto map = voiceMaps_[static_cast<std::size_t>(slot)];
            for (const auto &entry : voiceCatalog_)
                if (entry.program == program && entry.bank == bank && entry.map == map) return entry.name;
            return QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
        };
        if (voiceR1Label_) voiceR1Label_->setText(voiceLabelForSlot(0));
        if (voiceLLabel_) voiceLLabel_->setText(voiceLabelForSlot(1));
        if (voiceR2Label_) voiceR2Label_->setText(voiceLabelForSlot(2));
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(voicePrograms_[static_cast<std::size_t>(selectedProgramChannel_)]); }

        if (transposeSpin_) transposeSpin_->setValue(savedTranspose);
        if (transposeButton_) transposeButton_->setChecked(savedTransposeOn);
        if (octaveSpin_) octaveSpin_->setValue(savedOctave);
        if (octaveButton_) octaveButton_->setChecked(savedOctaveOn);
        if (splitKey_ != savedSplitKey) {
            splitKey_ = savedSplitKey;
            if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        }
        if (accompButton_) accompButton_->setChecked(savedAccompaniment);
        if (layerButton_) layerButton_->setChecked(savedLayer);
        if (splitButton_) splitButton_->setChecked(savedSplit);
        if (metronomeCheck_) metronomeCheck_->setChecked(savedMetronome);
        if (reverbLevelSpin_) reverbLevelSpin_->setValue(savedReverbLevel);
        if (reverbCheck_) reverbCheck_->setChecked(savedReverb);
        if (chorusLevelSpin_) chorusLevelSpin_->setValue(savedChorusLevel);
        if (chorusCheck_) chorusCheck_->setChecked(savedChorus);
        if (nativeEfxCheck_) nativeEfxCheck_->setChecked(settings.value(QStringLiteral("nativeEfxOn"), true).toBool());
        if (nativeEfxTypeCombo_) nativeEfxTypeCombo_->setCurrentIndex(std::clamp(settings.value(QStringLiteral("nativeEfxType"), 5).toInt(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1));
        if (gainSlider_) gainSlider_->setValue(savedOutputVolume);
        if (masterControlDial_) {
            const QSignalBlocker blocker(masterControlDial_);
            masterControlDial_->setValue(std::clamp((savedOutputVolume * 127 + 50) / 100, 0, 127));
        }
        if (arpSpin_) arpSpin_->setValue(savedArpeggiatorType);
        if (arpButton_) arpButton_->setChecked(savedArpeggiatorOn);
        if (harmonizerSpin_) harmonizerSpin_->setValue(savedHarmonizerType);
        if (metronomeButton_ && metronomeButton_->isChecked() != savedMetronome) metronomeButton_->setChecked(savedMetronome);
        if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        applyPanelMidiSettings();
        savePanelSettings();
        setStatus(styleRestored
            ? QStringLiteral("Registration Memory Bank %1 / Slot %2 dipanggil.").arg(currentRegistryBank_ + 1).arg(slot + 1)
            : QStringLiteral("Registration Memory Bank %1 / Slot %2 dipanggil, tetapi file style tersimpan tidak ditemukan; style aktif dipertahankan.").arg(currentRegistryBank_ + 1).arg(slot + 1));
    }

    void loadPanelSettings() {
        QSettings settings;
        currentRegistryBank_ = std::clamp(settings.value(QStringLiteral("registry/currentBank"), 0).toInt(), 0, 99);
        voicePrograms_ = {
            std::clamp(settings.value(QStringLiteral("voiceR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceL"), 33).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceR2"), 49).toInt(), 0, 127)
        };
        voiceMaps_ = {
            std::clamp(settings.value(QStringLiteral("voiceMapR1"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapL"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapR2"), 4).toInt(), 1, 4)
        };
        voiceBanks_ = {
            std::clamp(settings.value(QStringLiteral("voiceBankR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankR2"), 0).toInt(), 0, 127)
        };
        auto voiceLabelForSlot = [this](int slot) {
            const auto program = voicePrograms_[static_cast<std::size_t>(slot)];
            const auto bank = voiceBanks_[static_cast<std::size_t>(slot)];
            const auto map = voiceMaps_[static_cast<std::size_t>(slot)];
            for (const auto &entry : voiceCatalog_)
                if (entry.program == program && entry.bank == bank && entry.map == map) return entry.name;
            return QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
        };
        if (voiceR1Label_) voiceR1Label_->setText(voiceLabelForSlot(0));
        if (voiceLLabel_) voiceLLabel_->setText(voiceLabelForSlot(1));
        if (voiceR2Label_) voiceR2Label_->setText(voiceLabelForSlot(2));
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(voicePrograms_[static_cast<std::size_t>(selectedProgramChannel_)]); }
        soundFontPath_ = settings.value(QStringLiteral("audio/soundFontPath"), QString()).toString();
        vst2PluginPath_ = settings.value(QStringLiteral("audio/vst2PluginPath"), QString()).toString();
        const QString routing = settings.value(QStringLiteral("audio/outputRouting"), QStringLiteral("auto")).toString();
        if (audioRoutingCombo_) {
            const int routeIndex = audioRoutingCombo_->findData(routing);
            audioRoutingCombo_->setCurrentIndex(routeIndex >= 0 ? routeIndex : 0);
        }
        const int apiValue = settings.value(QStringLiteral("audio/rtaudioApi"),
            static_cast<int>(RtAudio::UNSPECIFIED)).toInt();
        if (audioApiCombo_) {
            const int apiIndex = audioApiCombo_->findData(apiValue);
            audioApiCombo_->setCurrentIndex(apiIndex >= 0 ? apiIndex : 0);
        }
        const qint64 deviceValue = settings.value(QStringLiteral("audio/outputDeviceId"), -1).toLongLong();
        refreshAudioOutputDevices(deviceValue);
        refreshAudioSampleRates(static_cast<unsigned int>(settings.value(QStringLiteral("audio/sampleRate"), 44100).toUInt()));
        if (audioBufferCombo_) {
            const int index = audioBufferCombo_->findData(settings.value(QStringLiteral("audio/bufferFrames"), 256).toInt());
            audioBufferCombo_->setCurrentIndex(index >= 0 ? index : audioBufferCombo_->findData(256));
        }
        accompanimentEnabled_ = settings.value(QStringLiteral("panel/accompanimentOn"), false).toBool();
        layerEnabled_ = settings.value(QStringLiteral("panel/layerOn"), false).toBool();
        splitEnabled_ = settings.value(QStringLiteral("panel/splitOn"), false).toBool();
        transposeActive_ = settings.value(QStringLiteral("panel/transposeOn"), false).toBool();
        octaveShiftActive_ = settings.value(QStringLiteral("panel/octaveOn"), false).toBool();
        transposeAmount_ = std::clamp(settings.value(QStringLiteral("panel/transpose"), 0).toInt(), -12, 12);
        octaveShiftAmount_ = std::clamp(settings.value(QStringLiteral("panel/octave"), 0).toInt(), -2, 2);
        splitKey_ = std::clamp(settings.value(QStringLiteral("panel/splitKey"), kOriginalSplitKey).toInt(), 36, 95);
        const bool metronomeOn = settings.value(QStringLiteral("panel/metronomeOn"), false).toBool();
        // Match the original GSettings schema defaults: reverb and chorus start enabled.
        const bool reverbOn = settings.value(QStringLiteral("panel/reverbOn"), true).toBool();
        const bool chorusOn = settings.value(QStringLiteral("panel/chorusOn"), true).toBool();
        const QSignalBlocker b1(accompButton_), b2(layerButton_), b3(splitButton_), b4(metronomeButton_);
        const QSignalBlocker b5(transposeButton_), b6(octaveButton_), b7(arpButton_), b8(harmonizerButton_);
        const QSignalBlocker b9(reverbButton_), b10(chorusButton_);
        const QSignalBlocker b11(transposeSpin_), b12(octaveSpin_), b13(reverbLevelSpin_), b14(chorusLevelSpin_);
        const QSignalBlocker b15(reverbCheck_), b16(chorusCheck_), b17(metronomeCheck_);
        accompButton_->setChecked(accompanimentEnabled_);
        layerButton_->setChecked(layerEnabled_);
        splitButton_->setChecked(splitEnabled_);
        metronomeButton_->setChecked(metronomeOn);
        transposeButton_->setChecked(transposeActive_);
        octaveButton_->setChecked(octaveShiftActive_);
        // Restore the implemented Arpeggiator state; no held notes exist until the user plays.
        arpButton_->setChecked(settings.value(QStringLiteral("panel/arpeggiatorOn"), false).toBool());
        if (harmonizerButton_) harmonizerButton_->setChecked(false);
        reverbButton_->setChecked(reverbOn);
        chorusButton_->setChecked(chorusOn);
        metronomeCheck_->setChecked(metronomeOn);
        reverbCheck_->setChecked(reverbOn);
        chorusCheck_->setChecked(chorusOn);
        if (nativeEfxCheck_) nativeEfxCheck_->setChecked(settings.value(QStringLiteral("nativeEfxOn"), true).toBool());
        if (nativeEfxTypeCombo_) nativeEfxTypeCombo_->setCurrentIndex(std::clamp(settings.value(QStringLiteral("nativeEfxType"), 5).toInt(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1));
        transposeSpin_->setValue(transposeAmount_);
        octaveSpin_->setValue(octaveShiftAmount_);
        reverbLevelSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/reverbLevel"), 7).toInt(), 0, 10));
        chorusLevelSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/chorusLevel"), 2).toInt(), 0, 10));
        arpSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/arpeggiatorType"), 1).toInt(), 1, 12));
        if (harmonizerSpin_) harmonizerSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/harmonizerType"), 1).toInt(), 1, 6));
        if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        transposeButton_->setProperty("active", transposeActive_);
        transposeButton_->setStyleSheet(QString());
        octaveButton_->setProperty("active", octaveShiftActive_);
        octaveButton_->setStyleSheet(QString());
        if (transposeMetricLabel_) transposeMetricLabel_->setText(transposeActive_ ? QString::number(transposeAmount_) : QStringLiteral("0"));
        if (octaveMetricLabel_) octaveMetricLabel_->setText(octaveShiftActive_ ? QString::number(octaveShiftAmount_) : QStringLiteral("0"));
        if (gainSlider_) {
            const int savedVolume = std::clamp(settings.value(QStringLiteral("panel/outputVolume"), 75).toInt(), 0, 100);
            gainSlider_->setValue(savedVolume);
            if (masterControlDial_) {
                const QSignalBlocker blocker(masterControlDial_);
                masterControlDial_->setValue(std::clamp((savedVolume * 127 + 50) / 100, 0, 127));
            }
        }
        if (registryBankLabel_) registryBankLabel_->setText(QString::number(currentRegistryBank_ + 1));
        updateRegistryButtonLabels();
    }

    void savePanelSettings() {
        QSettings settings;
        settings.setValue(QStringLiteral("panel/accompanimentOn"), accompanimentEnabled_);
        settings.setValue(QStringLiteral("panel/layerOn"), layerEnabled_);
        settings.setValue(QStringLiteral("panel/splitOn"), splitEnabled_);
        settings.setValue(QStringLiteral("panel/transposeOn"), transposeActive_);
        settings.setValue(QStringLiteral("panel/octaveOn"), octaveShiftActive_);
        settings.setValue(QStringLiteral("panel/transpose"), transposeAmount_);
        settings.setValue(QStringLiteral("panel/octave"), octaveShiftAmount_);
        settings.setValue(QStringLiteral("panel/splitKey"), splitKey_);
        settings.setValue(QStringLiteral("panel/metronomeOn"), metronomeCheck_ && metronomeCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/reverbOn"), reverbCheck_ && reverbCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/chorusOn"), chorusCheck_ && chorusCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/reverbLevel"), reverbLevelSpin_ ? reverbLevelSpin_->value() : 7);
        settings.setValue(QStringLiteral("panel/chorusLevel"), chorusLevelSpin_ ? chorusLevelSpin_->value() : 2);
        settings.setValue(QStringLiteral("nativeEfxOn"), nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        settings.setValue(QStringLiteral("nativeEfxType"), nativeEfxTypeCombo_ ? nativeEfxTypeCombo_->currentIndex() : 5);
        settings.setValue(QStringLiteral("panel/arpeggiatorType"), arpSpin_ ? arpSpin_->value() : 1);
        settings.setValue(QStringLiteral("panel/arpeggiatorOn"), arpButton_ && arpButton_->isChecked());
        settings.setValue(QStringLiteral("panel/harmonizerType"), harmonizerSpin_ ? harmonizerSpin_->value() : 1);
        settings.setValue(QStringLiteral("panel/outputVolume"), gainSlider_ ? gainSlider_->value() : 75);
        settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]); settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]); settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
        settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]); settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]); settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
        settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]); settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]); settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
        settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
        if (audioRoutingCombo_) settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_->currentData().toString());
        if (audioApiCombo_) settings.setValue(QStringLiteral("audio/rtaudioApi"), audioApiCombo_->currentData().toInt());
        if (audioDeviceCombo_) settings.setValue(QStringLiteral("audio/outputDeviceId"), selectedRtAudioDeviceId().has_value()
            ? static_cast<qint64>(*selectedRtAudioDeviceId()) : qint64(-1));
        if (audioSampleRateCombo_) settings.setValue(QStringLiteral("audio/sampleRate"), audioSampleRateCombo_->currentData().toUInt());
        if (audioBufferCombo_) settings.setValue(QStringLiteral("audio/bufferFrames"), audioBufferCombo_->currentData().toInt());
        settings.sync();
    }

    void applyPanelMidiSettings() {
        const bool reverbOn = reverbCheck_ && reverbCheck_->isChecked();
        const bool chorusOn = chorusCheck_ && chorusCheck_->isChecked();
        const int reverbLevel = reverbLevelSpin_ ? reverbLevelSpin_->value() : 7;
        const int chorusLevel = chorusLevelSpin_ ? chorusLevelSpin_->value() : 2;
        if (audioEngine_ && audioEngine_->isReady()) {
            audioEngine_->setMasterReverb(reverbOn, reverbLevel);
            audioEngine_->setMasterChorus(chorusOn, chorusLevel);
        }
        // Hardware MIDI output still receives the GM CC91/CC93 equivalents.
        if (wantsWindowsMidiOutput()) {
            sendWindowsMidi(0xB0, 91, reverbOn ? static_cast<quint8>(std::clamp(reverbLevel * 127 / 10, 0, 127)) : 0);
            sendWindowsMidi(0xB0, 93, chorusOn ? static_cast<quint8>(std::clamp(chorusLevel * 127 / 10, 0, 127)) : 0);
        }
        updateModulationTimer();
        updateOutputStatus();
    }

    void loadControllerMaps() {
        QSettings settings;
        styleVolume_ = std::clamp(settings.value(QStringLiteral("uiControls/styleVolume"), 127).toInt(), 0, 127);
        const bool simplifiedDefaultsMigration = settings.value(QStringLiteral("uiControls/defaultMappingVersion"), 0).toInt() < 16;
        // V15 defaults are migrated once to the reference-panel layout. The first six faders
        // now have fixed instrument-section roles; four obsolete generic fader slots are hidden.
        static constexpr int oldDefaults[14] = {
            VoiceVolumeAll, StyleVolume, DrumVolume, VoiceExpression,
            ReverbSend, ChorusSend, FilterCutoff, FilterResonance,
            VoicePan, VoiceModulation, VoiceAttack, VoiceRelease, VoiceVibratoRate, VoiceVibratoDepth
        };
        // V14 used a different target for the four physical knobs; recognize both generations
        // so factory defaults migrate but deliberate custom assignments remain intact.
        static constexpr int legacyV14Defaults[14] = {
            VoiceLVolume, VoiceR1Volume, VoiceR2Volume, StyleVolume,
            ReverbSend, ChorusSend, FilterCutoff, FilterResonance,
            VoiceExpression, DrumVolume, VoicePan, VoiceModulation, ReverbSend, ChorusSend
        };
        static constexpr int simpleDefaultValues[14] = {100, 100, 100, 100, 100, 100, 64, 64, 30, 30, 64, 64, 30, 30};
        for (int i = 0; i < static_cast<int>(controllerMaps_.size()); ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            const bool hasTarget = settings.contains(prefix + QStringLiteral("target"));
            const bool storedAssigned = settings.value(prefix + QStringLiteral("assigned"), false).toBool();
            bool remappedDefault = false;
            map.channel = std::clamp(settings.value(prefix + QStringLiteral("channel"), (i == 0 ? 1 : (i == 2 ? 2 : 0))).toInt(), 0, 15);
            const int savedTarget = std::clamp(settings.value(prefix + QStringLiteral("target"), static_cast<int>(GenericMidiCc)).toInt(), static_cast<int>(GenericMidiCc), static_cast<int>(ChordVolume));
            const bool matchesKnownDefault = !hasTarget || savedTarget == oldDefaults[i] || savedTarget == legacyV14Defaults[i];
            if (i < 14 && simplifiedDefaultsMigration && matchesKnownDefault) {
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
                remappedDefault = true;
            } else if (hasTarget) {
                map.target = std::clamp(settings.value(prefix + QStringLiteral("target"), static_cast<int>(GenericMidiCc)).toInt(), static_cast<int>(GenericMidiCc), static_cast<int>(ChordVolume));
                map.assigned = settings.value(prefix + QStringLiteral("assigned"), true).toBool();
                map.controller = std::clamp(settings.value(prefix + QStringLiteral("controller"), defaultControllerForTarget(map.target)).toInt(), 0, 127);
            } else if (i < 14 && !storedAssigned) {
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
                remappedDefault = true;
            } else {
                map.target = GenericMidiCc;
                map.assigned = storedAssigned;
                const int defaultController = i == 14 ? 10 : (i == 15 ? 1 : 74);
                map.controller = std::clamp(settings.value(prefix + QStringLiteral("controller"), defaultController).toInt(), 0, 127);
                if ((i == 14 || i == 15) && !settings.contains(prefix + QStringLiteral("assigned"))) map.assigned = true;
            }
            if (i >= 14) {
                // Joystick axes always remain direct configurable CC mappings.
                map.target = GenericMidiCc;
                if (!settings.contains(prefix + QStringLiteral("assigned"))) map.assigned = true;
            }
            if (i < 6) {
                // These six faders are fixed by the reference design rather than user-remappable CC strips.
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
            }
            const QString valueKey = QStringLiteral("uiControls/value/%1").arg(i);
            if (i < 10 && assignableSliders_[static_cast<std::size_t>(i)]) {
                const int saved = settings.value(valueKey, simpleDefaultValues[i]).toInt();
                const QSignalBlocker blocker(assignableSliders_[static_cast<std::size_t>(i)]);
                assignableSliders_[static_cast<std::size_t>(i)]->setValue(remappedDefault ? simpleDefaultValues[i] : std::clamp(saved, 0, 127));
            } else if (i >= 10 && i < 14 && assignableKnobs_[static_cast<std::size_t>(i - 10)]) {
                const int saved = settings.value(valueKey, simpleDefaultValues[i]).toInt();
                const QSignalBlocker blocker(assignableKnobs_[static_cast<std::size_t>(i - 10)]);
                assignableKnobs_[static_cast<std::size_t>(i - 10)]->setValue(remappedDefault ? simpleDefaultValues[i] : std::clamp(saved, 0, 127));
            }
            if (i < static_cast<int>(masterTargets_.size()))
                masterTargets_[static_cast<std::size_t>(i)] = settings.value(QStringLiteral("masterTargets/%1").arg(i), false).toBool();
        }
        settings.setValue(QStringLiteral("uiControls/defaultMappingVersion"), 16);
        for (int i = 0; i < 14; ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            settings.setValue(prefix + QStringLiteral("assigned"), map.assigned);
            settings.setValue(prefix + QStringLiteral("channel"), map.channel);
            settings.setValue(prefix + QStringLiteral("controller"), map.controller);
            settings.setValue(prefix + QStringLiteral("target"), map.target);
            const int value = i < 10 ? (assignableSliders_[static_cast<std::size_t>(i)] ? assignableSliders_[static_cast<std::size_t>(i)]->value() : simpleDefaultValues[i])
                                     : (assignableKnobs_[static_cast<std::size_t>(i - 10)] ? assignableKnobs_[static_cast<std::size_t>(i - 10)]->value() : simpleDefaultValues[i]);
            settings.setValue(QStringLiteral("uiControls/value/%1").arg(i), value);
        }
        settings.sync();
    }

    void saveControllerMaps() {
        QSettings settings;
        for (int i = 0; i < static_cast<int>(controllerMaps_.size()); ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            settings.setValue(prefix + QStringLiteral("assigned"), map.assigned);
            settings.setValue(prefix + QStringLiteral("channel"), map.channel);
            settings.setValue(prefix + QStringLiteral("controller"), map.controller);
            settings.setValue(prefix + QStringLiteral("target"), map.target);
            if (i < static_cast<int>(masterTargets_.size()))
                settings.setValue(QStringLiteral("masterTargets/%1").arg(i), masterTargets_[static_cast<std::size_t>(i)]);
        }
        settings.setValue(QStringLiteral("uiControls/styleVolume"), styleVolume_);
        settings.sync();
    }

    void refreshControllerTooltips() {
        for (int i = 0; i < 10; ++i) {
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            QString tip = QStringLiteral("Slider %1").arg(i + 1);
            tip += map.assigned
                ? (map.target == GenericMidiCc
                    ? QStringLiteral(" — Channel %1, %2").arg(map.channel + 1).arg(controllerLabel(map.controller))
                    : QStringLiteral(" — %1").arg(controlTargetLabel(map.target)))
                : QStringLiteral(" — belum dipetakan; aktifkan Slider Assign lalu klik slider");
            if (masterTargets_[static_cast<std::size_t>(i)]) tip += QStringLiteral(" — target Master Knob");
            if (assignableSliders_[static_cast<std::size_t>(i)]) {
                assignableSliders_[static_cast<std::size_t>(i)]->setToolTip(tip);
                assignableSliders_[static_cast<std::size_t>(i)]->setProperty("masterTarget", masterTargets_[static_cast<std::size_t>(i)]);
                if (assignableSliderNameLabels_[static_cast<std::size_t>(i)]) {
                    if (i >= 6) assignableSliderNameLabels_[static_cast<std::size_t>(i)]->setText(controlShortLabel(map.target, map.controller, map.assigned));
                    assignableSliderNameLabels_[static_cast<std::size_t>(i)]->setToolTip(tip);
                }
                assignableSliders_[static_cast<std::size_t>(i)]->style()->unpolish(assignableSliders_[static_cast<std::size_t>(i)]);
                assignableSliders_[static_cast<std::size_t>(i)]->style()->polish(assignableSliders_[static_cast<std::size_t>(i)]);
            }
        }
        for (int i = 0; i < 4; ++i) {
            const int idx = 10 + i;
            const auto &map = controllerMaps_[static_cast<std::size_t>(idx)];
            QString tip = QStringLiteral("Knob %1").arg(i + 1);
            tip += map.assigned
                ? (map.target == GenericMidiCc
                    ? QStringLiteral(" — Channel %1, %2").arg(map.channel + 1).arg(controllerLabel(map.controller))
                    : QStringLiteral(" — %1").arg(controlTargetLabel(map.target)))
                : QStringLiteral(" — belum dipetakan; aktifkan Knob Assign lalu klik knob");
            if (masterTargets_[static_cast<std::size_t>(idx)]) tip += QStringLiteral(" — target Master Knob");
            if (assignableKnobs_[static_cast<std::size_t>(i)]) {
                assignableKnobs_[static_cast<std::size_t>(i)]->setToolTip(tip);
                assignableKnobs_[static_cast<std::size_t>(i)]->setProperty("masterTarget", masterTargets_[static_cast<std::size_t>(idx)]);
                if (assignableKnobNameLabels_[static_cast<std::size_t>(i)]) {
                    assignableKnobNameLabels_[static_cast<std::size_t>(i)]->setText(controlShortLabel(map.target, map.controller, map.assigned));
                    assignableKnobNameLabels_[static_cast<std::size_t>(i)]->setToolTip(tip);
                }
                assignableKnobs_[static_cast<std::size_t>(i)]->style()->unpolish(assignableKnobs_[static_cast<std::size_t>(i)]);
                assignableKnobs_[static_cast<std::size_t>(i)]->style()->polish(assignableKnobs_[static_cast<std::size_t>(i)]);
            }
        }
        for (int axis = 0; axis < 2; ++axis) {
            const int idx = 14 + axis;
            const auto &map = controllerMaps_[static_cast<std::size_t>(idx)];
            const QString label = axis == 0 ? QStringLiteral("Joystick X") : QStringLiteral("Joystick Y");
            const QString tip = map.assigned
                ? QStringLiteral("%1 → Channel %2, %3; seret pad XY untuk mengirim nilai.").arg(label).arg(map.channel + 1).arg(controllerLabel(map.controller))
                : QStringLiteral("%1 belum dipetakan; klik tombol Assign untuk mengatur MIDI CC.").arg(label);
            if (axis == 0 && joystickXAssignButton_) joystickXAssignButton_->setToolTip(tip);
            if (axis == 1 && joystickYAssignButton_) joystickYAssignButton_->setToolTip(tip);
        }
    }

    void updateAssignmentButtonAvailability() {
        if (!knobAssignButton_ || !masterAssignButton_) return;
        knobAssignButton_->setEnabled(!masterAssignMode_ && !sliderAssignMode_);
        if (sliderAssignButton_) sliderAssignButton_->setEnabled(!masterAssignMode_ && !knobAssignMode_);
        masterAssignButton_->setEnabled(!knobAssignMode_ && !sliderAssignMode_);
    }

    void stopControlAssignmentModes() {
        knobAssignMode_ = false;
        masterAssignMode_ = false;
        sliderAssignMode_ = false;
        if (knobAssignButton_) knobAssignButton_->setChecked(false);
        if (masterAssignButton_) masterAssignButton_->setChecked(false);
        if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
        updateAssignmentButtonAvailability();
    }

    void configureControlMapping(int index, const QString &controlName) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        auto &current = controllerMaps_[static_cast<std::size_t>(index)];
        QDialog dialog(this);
        dialog.setWindowTitle(QStringLiteral("Pemetaan %1").arg(controlName));
        dialog.setMinimumWidth(340);
        auto *layout = new QVBoxLayout(&dialog);
        auto *form = new QFormLayout;
        auto *targetBox = new QComboBox(&dialog);
        for (int target = GenericMidiCc; target <= ChordVolume; ++target)
            targetBox->addItem(controlTargetLabel(target), target);
        targetBox->setCurrentIndex(std::max(0, targetBox->findData(current.target)));
        auto *channelBox = new QComboBox(&dialog);
        for (int ch = 0; ch < 16; ++ch)
            channelBox->addItem(QStringLiteral("Channel %1").arg(ch + 1), ch);
        channelBox->setCurrentIndex(std::clamp(current.channel, 0, 15));
        auto *controllerBox = new QComboBox(&dialog);
        for (int cc = 0; cc <= 127; ++cc) controllerBox->addItem(controllerLabel(cc), cc);
        int ccIndex = controllerBox->findData(current.controller);
        controllerBox->setCurrentIndex(ccIndex >= 0 ? ccIndex : controllerBox->findData(74));
        form->addRow(QStringLiteral("Fungsi kontrol"), targetBox);
        form->addRow(QStringLiteral("Kanal MIDI (untuk Custom CC)"), channelBox);
        form->addRow(QStringLiteral("Controller (untuk Custom CC)"), controllerBox);
        layout->addLayout(form);
        auto *note = new QLabel(QStringLiteral("Fungsi bernama mengontrol target internal yang ditentukan. Kanal dan CC manual hanya digunakan untuk Custom MIDI CC."), &dialog);
        note->setWordWrap(true);
        layout->addWidget(note);
        auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
        connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
        connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
        layout->addWidget(buttons);
        if (dialog.exec() != QDialog::Accepted) return;
        current.assigned = true;
        current.target = targetBox->currentData().toInt();
        current.channel = channelBox->currentData().toInt();
        current.controller = current.target == GenericMidiCc
            ? controllerBox->currentData().toInt() : defaultControllerForTarget(current.target);
        saveControllerMaps();
        refreshControllerTooltips();
        stopControlAssignmentModes();
        const QString mapping = current.target == GenericMidiCc
            ? QStringLiteral("Channel %1, %2").arg(current.channel + 1).arg(controllerLabel(current.controller))
            : controlTargetLabel(current.target);
        setStatus(QStringLiteral("%1 → %2.").arg(controlName, mapping));
    }

    void handleAssignableControlPressed(int index, const QString &controlName) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        if (masterAssignMode_) {
            if (index >= static_cast<int>(masterTargets_.size())) {
                setStatus(QStringLiteral("Joystick X/Y tidak menjadi target Master Knob; keduanya punya pemetaan MIDI CC langsung."));
                return;
            }
            masterTargets_[static_cast<std::size_t>(index)] = !masterTargets_[static_cast<std::size_t>(index)];
            saveControllerMaps();
            refreshControllerTooltips();
            setStatus(QStringLiteral("%1 %2 untuk Master Knob.").arg(controlName).arg(masterTargets_[static_cast<std::size_t>(index)] ? QStringLiteral("ditambahkan sebagai target") : QStringLiteral("dihapus dari target")));
            return;
        }
        if ((index < 10 && sliderAssignMode_) || (index >= 10 && index < 14 && knobAssignMode_)) {
            configureControlMapping(index, controlName);
            return;
        }
        if (index >= 0 && index < 14) {
            const int value = index < 10
                ? (assignableSliders_[static_cast<std::size_t>(index)] ? assignableSliders_[static_cast<std::size_t>(index)]->value() : 0)
                : (assignableKnobs_[static_cast<std::size_t>(index - 10)] ? assignableKnobs_[static_cast<std::size_t>(index - 10)]->value() : 0);
            QSettings settings;
            settings.setValue(QStringLiteral("uiControls/value/%1").arg(index), value);
            settings.sync();
        }
    }

    void sendSelectedVoiceController(int controller, int value) {
        const int slot = std::clamp(selectedProgramChannel_, 0, 2);
        sendMidi(static_cast<quint8>(0xB0 | slot), static_cast<quint8>(controller),
                 static_cast<quint8>(std::clamp(value, 0, 127)), internalVoiceChannel(slot));
    }

    void setAssignableMasterVolume(int value) {
        const int percent = std::clamp((std::clamp(value, 0, 127) * 100 + 63) / 127, 0, 100);
        if (gainSlider_) {
            const QSignalBlocker blocker(gainSlider_);
            gainSlider_->setValue(percent);
        }
        setMidiOutputVolume(percent);
        QSettings settings;
        settings.setValue(QStringLiteral("panel/outputVolume"), percent);
        settings.sync();
        if (masterControlDial_) {
            const QSignalBlocker blocker(masterControlDial_);
            masterControlDial_->setValue(std::clamp(value, 0, 127));
        }
    }

    void applyControlTarget(int index, int target, int value) {
        const int bounded = std::clamp(value, 0, 127);
        switch (target) {
        case VoiceVolumeAll:
            for (int slot = 0; slot < 3; ++slot)
                sendMidi(static_cast<quint8>(0xB0 | slot), 7, static_cast<quint8>(bounded), internalVoiceChannel(slot));
            return;
        case VoiceAttack: sendSelectedVoiceController(73, bounded); return;
        case VoiceRelease: sendSelectedVoiceController(72, bounded); return;
        case VoiceVibratoRate: sendSelectedVoiceController(76, bounded); return;
        case VoiceVibratoDepth: sendSelectedVoiceController(77, bounded); return;
        case SongVolume:
            songVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/songVolume"), songVolume_); settings.sync(); }
            return;
        case AudioVolume:
            audioFaderVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/audioVolume"), audioFaderVolume_); settings.sync(); }
            setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
            return;
        case PadsVolume:
            padsVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/padsVolume"), padsVolume_); settings.sync(); }
            return;
        case ChordVolume:
            chordVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/chordVolume"), chordVolume_); settings.sync(); }
            return;
        case VoiceLVolume:
            sendMidi(0xB1, 7, static_cast<quint8>(bounded), internalVoiceChannel(1));
            return;
        case VoiceR1Volume:
            sendMidi(0xB0, 7, static_cast<quint8>(bounded), internalVoiceChannel(0));
            return;
        case VoiceR2Volume:
            sendMidi(0xB2, 7, static_cast<quint8>(bounded), internalVoiceChannel(2));
            return;
        case StyleVolume: {
            // Native style tracks live on MIDI channels 1..16. Send channel volume to the internal
            // accompaniment channels. External output scales style note-on velocity separately so
            // the three dedicated external keyboard-voice channels are not unintentionally changed.
            styleVolume_ = bounded;
            for (int channel = 0; channel < 16; ++channel) {
                if (channel == 9) continue; // Keep the dedicated Drum Volume control independent.
                sendInternalMidiOnly(static_cast<quint8>(0xB0 | channel), 7, bounded, channel);
            }
            QSettings settings;
            settings.setValue(QStringLiteral("uiControls/styleVolume"), styleVolume_);
            settings.sync();
            return;
        }
        case ReverbSend: sendSelectedVoiceController(91, bounded); return;
        case ChorusSend: sendSelectedVoiceController(93, bounded); return;
        case FilterCutoff: sendSelectedVoiceController(74, bounded); return;
        case FilterResonance: sendSelectedVoiceController(71, bounded); return;
        case VoiceExpression: sendSelectedVoiceController(11, bounded); return;
        case DrumVolume:
            sendMidi(0xB9, 7, static_cast<quint8>(bounded), 9);
            return;
        case VoicePan: sendSelectedVoiceController(10, bounded); return;
        case VoiceModulation: sendSelectedVoiceController(1, bounded); return;
        case MasterVolume: setAssignableMasterVolume(bounded); return;
        default: break;
        }
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
        const auto status = static_cast<quint8>(0xB0 | map.channel);
        const auto controller = static_cast<quint8>(map.controller);
        const auto data = static_cast<quint8>(bounded);
        // Joystick axes route to the active internal voice while retaining the configured external channel.
        if (index >= 14) sendMidi(status, controller, data, internalVoiceChannel(selectedProgramChannel_));
        else sendMidi(status, controller, data);
    }

    void handleAssignableControlValue(int index, int value) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        if (masterAssignMode_ || (index < 10 && sliderAssignMode_) || (index >= 10 && index < 14 && knobAssignMode_)) return;
        const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
        if (!map.assigned) return;
        applyControlTarget(index, map.target, value);
    }

    void handleMasterControlValue(int value) {
        const int boundedValue = std::clamp(value, 0, 127);
        // Master knob always controls actual application/audio output volume; optional assigned
        // targets below provide additional linked control, rather than replacing Master Volume.
        const int percent = std::clamp((boundedValue * 100 + 63) / 127, 0, 100);
        if (gainSlider_) {
            const QSignalBlocker blocker(gainSlider_);
            gainSlider_->setValue(percent);
        }
        setMidiOutputVolume(percent);
        QSettings masterSettings;
        masterSettings.setValue(QStringLiteral("panel/outputVolume"), percent);
        masterSettings.sync();
        for (int i = 0; i < static_cast<int>(masterTargets_.size()); ++i) {
            if (!masterTargets_[static_cast<std::size_t>(i)] || !controllerMaps_[static_cast<std::size_t>(i)].assigned) continue;
            if (i < 10 && assignableSliders_[static_cast<std::size_t>(i)]) {
                const QSignalBlocker blocker(assignableSliders_[static_cast<std::size_t>(i)]);
                assignableSliders_[static_cast<std::size_t>(i)]->setValue(boundedValue);
            } else if (i >= 10 && i < 14 && assignableKnobs_[static_cast<std::size_t>(i - 10)]) {
                const QSignalBlocker blocker(assignableKnobs_[static_cast<std::size_t>(i - 10)]);
                assignableKnobs_[static_cast<std::size_t>(i - 10)]->setValue(boundedValue);
            } else if (i >= 14) {
                continue; // Joystick axes are direct controls, not targets of the physical Master Knob.
            }
            handleAssignableControlValue(i, boundedValue);
        }
    }

    enum ResizeEdge : int { NoResizeEdge = 0, ResizeLeft = 1, ResizeRight = 2, ResizeTop = 4, ResizeBottom = 8 };

    int hitTestResizeEdge(const QPoint &globalPos) const {
        if (isFullScreen() || isMaximized()) return NoResizeEdge;
        constexpr int margin = 6;
        const QRect r = frameGeometry();
        int edges = NoResizeEdge;
        if (globalPos.x() >= r.left() && globalPos.x() < r.left() + margin) edges |= ResizeLeft;
        else if (globalPos.x() <= r.right() && globalPos.x() > r.right() - margin) edges |= ResizeRight;
        if (globalPos.y() >= r.top() && globalPos.y() < r.top() + margin) edges |= ResizeTop;
        else if (globalPos.y() <= r.bottom() && globalPos.y() > r.bottom() - margin) edges |= ResizeBottom;
        return edges;
    }

    Qt::CursorShape cursorForResizeEdges(int edges) const {
        const bool left = (edges & ResizeLeft) != 0;
        const bool right = (edges & ResizeRight) != 0;
        const bool top = (edges & ResizeTop) != 0;
        const bool bottom = (edges & ResizeBottom) != 0;
        if ((left && top) || (right && bottom)) return Qt::SizeFDiagCursor;
        if ((right && top) || (left && bottom)) return Qt::SizeBDiagCursor;
        if (left || right) return Qt::SizeHorCursor;
        if (top || bottom) return Qt::SizeVerCursor;
        return Qt::ArrowCursor;
    }

    bool eventFilter(QObject *watched, QEvent *event) override {
        Q_UNUSED(watched);
        if (event->type() == QEvent::MouseButtonPress) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton) {
                const int edges = hitTestResizeEdge(mouse->globalPosition().toPoint());
                if (edges != NoResizeEdge) {
                    resizingEdges_ = edges;
                    resizeStartGlobal_ = mouse->globalPosition().toPoint();
                    resizeStartGeometry_ = geometry();
                    mouse->accept();
                    return true;
                }
            }
        } else if (event->type() == QEvent::MouseMove) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            const QPoint globalPos = mouse->globalPosition().toPoint();
            if (resizingEdges_ != NoResizeEdge && (mouse->buttons() & Qt::LeftButton)) {
                const QPoint delta = globalPos - resizeStartGlobal_;
                QRect next = resizeStartGeometry_;
                if (resizingEdges_ & ResizeLeft)
                    next.setLeft(std::min(resizeStartGeometry_.left() + delta.x(), resizeStartGeometry_.right() - minimumWidth() + 1));
                if (resizingEdges_ & ResizeRight)
                    next.setRight(std::max(resizeStartGeometry_.right() + delta.x(), resizeStartGeometry_.left() + minimumWidth() - 1));
                if (resizingEdges_ & ResizeTop)
                    next.setTop(std::min(resizeStartGeometry_.top() + delta.y(), resizeStartGeometry_.bottom() - minimumHeight() + 1));
                if (resizingEdges_ & ResizeBottom)
                    next.setBottom(std::max(resizeStartGeometry_.bottom() + delta.y(), resizeStartGeometry_.top() + minimumHeight() - 1));
                setGeometry(next);
                mouse->accept();
                return true;
            }
            if (resizingEdges_ == NoResizeEdge) {
                const int edges = hitTestResizeEdge(globalPos);
                if (edges != NoResizeEdge) setCursor(cursorForResizeEdges(edges));
                else unsetCursor();
            }
        } else if (event->type() == QEvent::MouseButtonRelease) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton && resizingEdges_ != NoResizeEdge) {
                resizingEdges_ = NoResizeEdge;
                unsetCursor();
                mouse->accept();
                return true;
            }
        }
        return QMainWindow::eventFilter(watched, event);
    }

    void buildUi() {
        startupTrace("buildUi: begin");
        auto *central = new QWidget(this);
        central->setObjectName(QStringLiteral("appSurface"));
        auto *root = new QVBoxLayout(central);
        root->setContentsMargins(4, 4, 4, 4);
        root->setSpacing(3);

        auto makePanel = [](QWidget *parent) {
            auto *frame = new QFrame(parent);
            frame->setObjectName(QStringLiteral("panel"));
            frame->setFrameShape(QFrame::StyledPanel);
            return frame;
        };
        auto makeCaption = [](const QString &text, QWidget *parent = nullptr) {
            auto *label = new QLabel(text, parent);
            label->setObjectName(QStringLiteral("sectionLabel"));
            return label;
        };
        auto makeMetric = [&](const QString &heading, QLabel **valueOut, QWidget *parent) {
            auto *box = new QWidget(parent);
            auto *layout = new QVBoxLayout(box);
            layout->setContentsMargins(1, 1, 1, 1);
            layout->setSpacing(0);
            auto *h = makeCaption(heading, box);
            h->setAlignment(Qt::AlignCenter);
            auto *v = new QLabel(QStringLiteral("0"), box);
            v->setObjectName(QStringLiteral("metricValue"));
            v->setAlignment(Qt::AlignCenter);
            layout->addWidget(h);
            layout->addWidget(v);
            if (valueOut) *valueOut = v;
            return box;
        };
        auto makeDisplayTab = [&](const QString &heading, const QString &value, QLabel **valueOut, QWidget *parent) {
            auto *button = new QPushButton(parent);
            button->setObjectName(QStringLiteral("displayTab"));
            // The four tab buttons must stretch to the exact height of the LCD
            // header row. QPushButton's default vertical size policy can leave
            // a short button face inside a taller header, exposing a gap above
            // or below the teal strip. Expanding makes the button background,
            // hit target, and border fill the header's available height.
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            auto *layout = new QVBoxLayout(button);
            layout->setContentsMargins(1, 3, 1, 3);
            layout->setSpacing(0);
            layout->addStretch(1);
            auto *top = new QLabel(heading, button);
            top->setObjectName(QStringLiteral("displayTabTitle"));
            top->setAlignment(Qt::AlignCenter);
            top->setAttribute(Qt::WA_TransparentForMouseEvents);
            top->setFixedHeight(18);
            top->setStyleSheet(QStringLiteral("color:#ffffff;font-size:10pt;background:transparent;"));
            auto *bottom = new QLabel(value, button);
            bottom->setObjectName(QStringLiteral("displayTabSubtitle"));
            bottom->setAlignment(Qt::AlignCenter);
            bottom->setAttribute(Qt::WA_TransparentForMouseEvents);
            bottom->setFixedHeight(14);
            bottom->setStyleSheet(QStringLiteral("color:#d3efea;font-size:8pt;background:transparent;"));
            layout->addWidget(top);
            layout->addWidget(bottom);
            layout->addStretch(1);
            if (valueOut) *valueOut = bottom;
            return button;
        };

        // Utility dialogs keep secondary workflows accessible without cluttering the original home surface.
        auto makeDialog = [&](const QString &title) {
            auto *dialog = new QDialog(this);
            dialog->setWindowTitle(title);
            dialog->setModal(false);
            dialog->setMinimumWidth(390);
            return dialog;
        };
        startupTrace("buildUi: before style dialog");
        styleDialog_ = makeDialog(QStringLiteral("Ensembles — Styles"));
        auto *styleLayout = new QVBoxLayout(styleDialog_);
        styleLayout->addWidget(new QLabel(QStringLiteral("Pilih style auto-accompaniment (.enstl)."), styleDialog_));
        styleCombo_ = new QComboBox(styleDialog_);
        styleCombo_->setMinimumWidth(340);
        styleLayout->addWidget(styleCombo_);
        styleInfo_ = new QLabel(QStringLiteral("Mencari style asli Ensembles…"), styleDialog_);
        styleInfo_->setWordWrap(true);
        styleLayout->addWidget(styleInfo_);
        auto *styleHint = new QLabel(QStringLiteral("Style asli dipertahankan; preset GM Windows bukan pengganti bank SoundFont FluidSynth."), styleDialog_);
        styleHint->setWordWrap(true);
        styleHint->setStyleSheet(QStringLiteral("color:#d6b46c"));
        styleLayout->addWidget(styleHint);
        auto *styleClose = new QPushButton(QStringLiteral("Tutup"), styleDialog_);
        styleLayout->addWidget(styleClose);
        connect(styleClose, &QPushButton::clicked, styleDialog_, &QDialog::hide);

        voiceDialog_ = makeDialog(QStringLiteral("Ensembles — Voice / GM Program"));
        auto *voiceLayout = new QVBoxLayout(voiceDialog_);
        voiceLayout->addWidget(new QLabel(QStringLiteral("Pilih preset General MIDI untuk voice R1 / L / R2. Perubahan dikirim ke kanal FluidSynth internal yang sesuai dan, bila dipilih, ke Windows MIDI Mapper."), voiceDialog_));
        programCombo_ = new QComboBox(voiceDialog_);
        for (const char *name : kPatchNames) programCombo_->addItem(QString::fromUtf8(name));
        voiceLayout->addWidget(programCombo_);
        auto *voiceNote = new QLabel(QStringLiteral("Rute internal mengikuti mapping asli: R1=kanal 17, R2/layer=18, L/split=19. Rute eksternal memakai kanal MIDI standar 1–3."), voiceDialog_);
        voiceNote->setWordWrap(true);
        voiceLayout->addWidget(voiceNote);
        auto *voiceClose = new QPushButton(QStringLiteral("Tutup"), voiceDialog_);
        voiceLayout->addWidget(voiceClose);
        connect(voiceClose, &QPushButton::clicked, voiceDialog_, &QDialog::hide);

        startupTrace("buildUi: before settings dialog and audio controls");
        settingsDialog_ = makeDialog(QStringLiteral("Ensembles — Settings"));
        auto *settingsLayout = new QVBoxLayout(settingsDialog_);
        settingsLayout->addWidget(new QLabel(QStringLiteral("MIDI Input — perangkat eksternal"), settingsDialog_));
        auto *midiInputRow = new QWidget(settingsDialog_);
        auto *midiInputRowLayout = new QHBoxLayout(midiInputRow);
        midiInputRowLayout->setContentsMargins(0, 0, 0, 0);
        midiInputRowLayout->setSpacing(4);
        midiInputDeviceList_ = new QListWidget(midiInputRow);
        midiInputDeviceList_->setMinimumHeight(68);
        midiInputDeviceList_->setMaximumHeight(112);
        midiInputDeviceList_->setToolTip(QStringLiteral("Centang satu atau beberapa perangkat MIDI input. Event note-on/note-off masuk ke synthesizer internal."));
        refreshMidiInputDevicesButton_ = new QPushButton(QStringLiteral("Refresh input"), midiInputRow);
        midiInputRowLayout->addWidget(midiInputDeviceList_, 1);
        midiInputRowLayout->addWidget(refreshMidiInputDevicesButton_);
        settingsLayout->addWidget(midiInputRow);
        midiInputStatusLabel_ = new QLabel(QStringLiteral("Perangkat MIDI input belum dipindai."), settingsDialog_);
        midiInputStatusLabel_->setWordWrap(true);
        settingsLayout->addWidget(midiInputStatusLabel_);
        midiSplitByChannelCheck_ = new QCheckBox(QStringLiteral("Split By Channel (ikuti routing MIDI asli)"), settingsDialog_);
        {
            QSettings midiSettings;
            midiSplitByChannelCheck_->setChecked(midiSettings.value(QStringLiteral("midi/splitByChannel"), false).toBool());
        }
        midiSplitByChannelCheck_->setToolTip(QStringLiteral("Jika aktif dan perangkat input terhubung, kanal 1/2/3 mengikuti slot internal R1/R2/L sebagaimana logika MidiInputHost asli."));
        settingsLayout->addWidget(midiSplitByChannelCheck_);
        settingsLayout->addWidget(new QLabel(QStringLiteral("Tempo / output routing"), settingsDialog_));
        audioRoutingCombo_ = new QComboBox(settingsDialog_);
        audioRoutingCombo_->addItem(QStringLiteral("Auto: FluidSynth when ready, else Windows MIDI"), QStringLiteral("auto"));
        audioRoutingCombo_->addItem(QStringLiteral("Internal FluidSynth + RtAudio only"), QStringLiteral("fluid"));
        audioRoutingCombo_->addItem(QStringLiteral("Windows MIDI Mapper only"), QStringLiteral("winmm"));
        audioRoutingCombo_->addItem(QStringLiteral("Both: internal audio + Windows MIDI"), QStringLiteral("both"));
        settingsLayout->addWidget(audioRoutingCombo_);
        auto *audioForm = new QFormLayout;
        audioApiCombo_ = new QComboBox(settingsDialog_);
        audioApiCombo_->addItem(QStringLiteral("Automatic (RtAudio default API)"), static_cast<int>(RtAudio::UNSPECIFIED));
        for (const RtAudio::Api api : ensembles::AudioEngine::availableApis()) {
            if (api == RtAudio::UNSPECIFIED || api == RtAudio::RTAUDIO_DUMMY) continue;
            const std::string display = RtAudio::getApiDisplayName(api);
            const QString label = display.empty()
                ? QString::fromUtf8(RtAudio::getApiName(api).c_str())
                : QString::fromUtf8(display.c_str());
            audioApiCombo_->addItem(label, static_cast<int>(api));
        }
        audioDeviceCombo_ = new QComboBox(settingsDialog_);
        audioDeviceCombo_->setMinimumWidth(300);
        auto *audioDeviceRow = new QWidget(settingsDialog_);
        auto *audioDeviceRowLayout = new QHBoxLayout(audioDeviceRow);
        audioDeviceRowLayout->setContentsMargins(0, 0, 0, 0);
        audioDeviceRowLayout->setSpacing(4);
        refreshAudioDevicesButton_ = new QPushButton(QStringLiteral("Refresh"), audioDeviceRow);
        testAudioButton_ = new QPushButton(QStringLiteral("Test sound"), audioDeviceRow);
        audioDeviceRowLayout->addWidget(audioDeviceCombo_, 1);
        audioDeviceRowLayout->addWidget(refreshAudioDevicesButton_);
        audioDeviceRowLayout->addWidget(testAudioButton_);
        audioSampleRateCombo_ = new QComboBox(settingsDialog_);
        audioBufferCombo_ = new QComboBox(settingsDialog_);
        for (const int frames : {64, 128, 256, 512, 1024, 2048})
            audioBufferCombo_->addItem(QStringLiteral("%1 frames").arg(frames), frames);
        audioForm->addRow(QStringLiteral("RtAudio host API"), audioApiCombo_);
        audioForm->addRow(QStringLiteral("Output device"), audioDeviceRow);
        audioForm->addRow(QStringLiteral("Sample rate"), audioSampleRateCombo_);
        audioForm->addRow(QStringLiteral("Buffer size / latency"), audioBufferCombo_);
        settingsLayout->addLayout(audioForm);
        audioOutputStatusLabel_ = new QLabel(QStringLiteral("RtAudio belum diinisialisasi"), settingsDialog_);
        audioOutputStatusLabel_->setWordWrap(true);
        settingsLayout->addWidget(audioOutputStatusLabel_);
        auto *soundFontRow = new QHBoxLayout;
        chooseSoundFontButton_ = new QPushButton(QStringLiteral("Pilih SoundFont (.sf2)…"), settingsDialog_);
        soundFontStatusLabel_ = new QLabel(QStringLiteral("Memeriksa SoundFont…"), settingsDialog_);
        soundFontStatusLabel_->setWordWrap(true);
        soundFontStatusLabel_->setMinimumWidth(170);
        soundFontRow->addWidget(chooseSoundFontButton_);
        soundFontRow->addWidget(soundFontStatusLabel_, 1);
        settingsLayout->addLayout(soundFontRow);
        auto *vst2Row = new QHBoxLayout;
        chooseVst2PluginButton_ = new QPushButton(QStringLiteral("Pilih instrumen VST2 (.dll)…"), settingsDialog_);
        disableVst2PluginButton_ = new QPushButton(QStringLiteral("Gunakan FluidSynth"), settingsDialog_);
        vst2PluginStatusLabel_ = new QLabel(QStringLiteral("Instrumen eksternal: tidak aktif"), settingsDialog_);
        vst2PluginStatusLabel_->setWordWrap(true);
        vst2Row->addWidget(chooseVst2PluginButton_);
        vst2Row->addWidget(disableVst2PluginButton_);
        settingsLayout->addLayout(vst2Row);
        settingsLayout->addWidget(vst2PluginStatusLabel_);
        auto *tempoRow = new QHBoxLayout;
        tempoSlider_ = new QSlider(Qt::Horizontal, settingsDialog_);
        tempoSlider_->setRange(40, 240);
        tempoSlider_->setValue(120);
        tempoDialogValue_ = new QLabel(QStringLiteral("120"), settingsDialog_);
        tempoDialogValue_->setMinimumWidth(32);
        tempoRow->addWidget(tempoSlider_, 1);
        tempoRow->addWidget(tempoDialogValue_);
        settingsLayout->addLayout(tempoRow);
        settingsLayout->addWidget(new QLabel(QStringLiteral("Master MIDI output volume"), settingsDialog_));
        gainSlider_ = new QSlider(Qt::Horizontal, settingsDialog_);
        gainSlider_->setRange(0, 100);
        gainSlider_->setValue(75);
        settingsLayout->addWidget(gainSlider_);
        metronomeCheck_ = new QCheckBox(QStringLiteral("Metronome 4/4"), settingsDialog_);
        lfoCheck_ = new QCheckBox(QStringLiteral("LFO → MIDI CC1"), settingsDialog_);
        reverbCheck_ = new QCheckBox(QStringLiteral("Reverb (FluidSynth DSP / CC91 for hardware)"), settingsDialog_);
        chorusCheck_ = new QCheckBox(QStringLiteral("Chorus (FluidSynth DSP / CC93 for hardware)"), settingsDialog_);
        auto *fxRow = new QHBoxLayout;
        fxRow->addWidget(reverbCheck_);
        fxRow->addWidget(chorusCheck_);
        settingsLayout->addLayout(fxRow);
        auto *nativeEfxGroup = new QGroupBox(QStringLiteral("Native SCVA · EFX Insert Effect"), settingsDialog_);
        auto *nativeEfxLayout = new QVBoxLayout(nativeEfxGroup);
        nativeEfxCheck_ = new QCheckBox(QStringLiteral("Aktifkan EFX dan route part ke EFX"), nativeEfxGroup);
        nativeEfxTypeCombo_ = new QComboBox(nativeEfxGroup);
        for (const auto &choice : kNativeEfxChoices)
            nativeEfxTypeCombo_->addItem(QString::fromUtf8(choice.name), choice.key);
        nativeEfxCheck_->setChecked(true);
        nativeEfxTypeCombo_->setCurrentIndex(5); // SCVA Overdrive, a verified native EFX key 0x0110.
        nativeEfxLayout->addWidget(nativeEfxCheck_);
        nativeEfxLayout->addWidget(new QLabel(QStringLiteral("Algorithm / type (64 native SCVA effect records + Thru)"), nativeEfxGroup));
        nativeEfxLayout->addWidget(nativeEfxTypeCombo_);
        auto *efxParamGrid = new QGridLayout;
        efxParamGrid->setContentsMargins(0, 2, 0, 2);
        efxParamGrid->setHorizontalSpacing(6);
        efxParamGrid->setVerticalSpacing(3);
        for (int i = 0; i < 20; ++i) {
            auto *cell = new QWidget(nativeEfxGroup);
            auto *cellLayout = new QHBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(3);
            auto *label = new QLabel(QStringLiteral("P%1").arg(i + 1), cell);
            label->setToolTip(QStringLiteral("GS EFX Parameter %1; meaning depends on selected effect algorithm").arg(i + 1));
            auto *spin = new QSpinBox(cell);
            spin->setRange(-1, 127);
            spin->setValue(-1);
            spin->setSpecialValueText(QStringLiteral("ROM"));
            spin->setToolTip(QStringLiteral("ROM = use the selected SCVA effect's native default; 0–127 overrides parameter %1").arg(i + 1));
            spin->setFixedWidth(72);
            nativeEfxParams_[static_cast<std::size_t>(i)] = spin;
            cellLayout->addWidget(label);
            cellLayout->addWidget(spin, 1);
            efxParamGrid->addWidget(cell, i / 4, i % 4);
            connect(spin, qOverload<int>(&QSpinBox::valueChanged), this, [this, i](int value) {
                if (value >= 0) sendGsDt1(0x40, 0x03, static_cast<std::uint8_t>(0x03 + i), static_cast<std::uint8_t>(value));
            });
        }
        nativeEfxLayout->addLayout(efxParamGrid);
        auto *efxNote = new QLabel(QStringLiteral("Tipe dan routing dikirim sebagai GS DT1 SysEx ke Native SCVA. EFX menyediakan 20 slot parameter GS (P1–P20); label fungsional tiap parameter bergantung pada algoritma. ROM berarti nilai default native SCVA. Efek aktif hanya untuk part yang diarahkan ke EFX."), nativeEfxGroup);
        efxNote->setWordWrap(true); efxNote->setStyleSheet(QStringLiteral("color:#b8c7d9;"));
        nativeEfxLayout->addWidget(efxNote);
        settingsLayout->addWidget(nativeEfxGroup);
        settingsLayout->addWidget(metronomeCheck_);
        settingsLayout->addWidget(lfoCheck_);
        auto *settingsHint = new QLabel(QStringLiteral("RtAudio menyediakan pemilihan host API, output stereo, sample rate, dan buffer. Untuk ASIO4ALL, pilih host API Windows ASIO lalu pilih perangkat ASIO4ALL pada daftar output; ASIO4ALL harus terpasang untuk arsitektur x64. Jika Windows ASIO tidak muncul, backend ASIO belum berhasil dikompilasi. Buffer kecil mengurangi latensi tetapi bisa menimbulkan putus-putus; buffer besar lebih stabil dengan latensi lebih tinggi. Perubahan diterapkan dengan membuka ulang stream. File SoundFont harus benar-benar berupa SF2, bukan pointer Git LFS."), settingsDialog_);
        settingsHint->setWordWrap(true);
        settingsLayout->addWidget(settingsHint);
        auto *settingsClose = new QPushButton(QStringLiteral("Tutup"), settingsDialog_);
        settingsLayout->addWidget(settingsClose);
        connect(settingsClose, &QPushButton::clicked, settingsDialog_, &QDialog::hide);
        connect(nativeEfxCheck_, &QCheckBox::toggled, this, [this] { applyNativeEfxSettings(); });
        connect(nativeEfxTypeCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { applyNativeEfxSettings(true); });
        connect(refreshMidiInputDevicesButton_, &QPushButton::clicked, this, [this] { refreshMidiInputDevices(); });
        connect(midiInputDeviceList_, &QListWidget::itemChanged, this, [this](QListWidgetItem *item) {
#ifdef _WIN32
            if (!item) return;
            bool idOk = false;
            const UINT id = item->data(Qt::UserRole).toUInt(&idOk);
            if (!idOk) return;
            const bool shouldConnect = item->checkState() == Qt::Checked;
            if (shouldConnect) {
                if (!connectMidiInputDevice(id)) {
                    const QSignalBlocker blocker(midiInputDeviceList_);
                    item->setCheckState(Qt::Unchecked);
                }
            } else {
                disconnectMidiInputDevice(id);
            }
            updateMidiInputStatus();
#else
            Q_UNUSED(item);
#endif
        });
        connect(midiSplitByChannelCheck_, &QCheckBox::toggled, this, [this](bool checked) {
            QSettings settings;
            settings.setValue(QStringLiteral("midi/splitByChannel"), checked);
            settings.sync();
            setStatus(checked
                ? QStringLiteral("Split By Channel MIDI aktif; input eksternal mengikuti pemetaan kanal asli jika perangkat tersambung.")
                : QStringLiteral("Split By Channel MIDI nonaktif; input eksternal mengikuti routing keyboard utama."));
        });
        connect(chooseSoundFontButton_, &QPushButton::clicked, this, [this] { chooseSoundFont(); });
        connect(chooseVst2PluginButton_, &QPushButton::clicked, this, [this] { chooseVst2Plugin(); });
        connect(disableVst2PluginButton_, &QPushButton::clicked, this, [this] { disableVst2Plugin(); });
        connect(audioRoutingCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            QSettings settings; settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_->currentData().toString()); settings.sync();
            synchronizeOutputRoutes();
            applyPanelMidiSettings();
        });
        connect(audioApiCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (!audioSettingsReady_) return;
            refreshAudioOutputDevices(-1);
            refreshAudioSampleRates(44100);
            applyAudioOutputSettings();
        });
        connect(audioDeviceCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (!audioSettingsReady_) return;
            refreshAudioSampleRates(audioSampleRateCombo_ ? audioSampleRateCombo_->currentData().toUInt() : 44100u);
            applyAudioOutputSettings();
        });
        connect(audioSampleRateCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (audioSettingsReady_) applyAudioOutputSettings();
        });
        connect(audioBufferCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (audioSettingsReady_) applyAudioOutputSettings();
        });
        connect(refreshAudioDevicesButton_, &QPushButton::clicked, this, [this] {
            const auto preferred = selectedRtAudioDeviceId();
            refreshAudioOutputDevices(preferred ? static_cast<qint64>(*preferred) : -1);
            refreshAudioSampleRates(audioSampleRateCombo_ ? audioSampleRateCombo_->currentData().toUInt() : 44100u);
            applyAudioOutputSettings();
            setStatus(QStringLiteral("Daftar output RtAudio diperbarui."));
        });
        connect(testAudioButton_, &QPushButton::clicked, this, [this] {
            if (!audioEngine_ || !audioEngine_->isReady()) {
                setStatus(QStringLiteral("Test sound gagal: aktifkan SoundFont SF2 dan output RtAudio terlebih dahulu."));
                return;
            }
            sendMidi(0x90, 69, 100, 17); // A4 through R1 internal channel.
            QTimer::singleShot(350, this, [this] { sendMidi(0x80, 69, 0, 17); });
            setStatus(QStringLiteral("Mengirim nada uji A4 ke rute audio terpilih."));
        });

        recorderDialog_ = makeDialog(QStringLiteral("Ensembles — MIDI Recorder"));
        auto *recorderLayout = new QVBoxLayout(recorderDialog_);
        midiFileLabel_ = new QLabel(QStringLiteral("Belum ada berkas MIDI"), recorderDialog_);
        midiFileLabel_->setWordWrap(true);
        recorderLayout->addWidget(midiFileLabel_);
        auto *midiButtons = new QHBoxLayout;
        auto *openMidiButton = new QPushButton(QStringLiteral("Buka MIDI…"), recorderDialog_);
        playButton_ = new QPushButton(QStringLiteral("▶ Putar MIDI"), recorderDialog_);
        auto *stopMidiButton = new QPushButton(QStringLiteral("■ Stop"), recorderDialog_);
        midiButtons->addWidget(openMidiButton);
        midiButtons->addWidget(playButton_);
        midiButtons->addWidget(stopMidiButton);
        recorderLayout->addLayout(midiButtons);
        recordLabel_ = new QLabel(QStringLiteral("Perekam MIDI siap"), recorderDialog_);
        recordLabel_->setWordWrap(true);
        recorderLayout->addWidget(recordLabel_);
        recordButton_ = new QPushButton(QStringLiteral("● Rekam MIDI"), recorderDialog_);
        recorderLayout->addWidget(recordButton_);
        outputLabel_ = new QLabel(QStringLiteral("Memeriksa output MIDI Windows…"), recorderDialog_);
        outputLabel_->setWordWrap(true);
        recorderLayout->addWidget(outputLabel_);
        auto *recorderNote = new QLabel(QStringLiteral("Ini adalah recorder MIDI untuk event keyboard/pad, bukan perekam sampel audio asli."), recorderDialog_);
        recorderNote->setWordWrap(true);
        recorderNote->setStyleSheet(QStringLiteral("color:#d6b46c"));
        recorderLayout->addWidget(recorderNote);
        auto *recorderClose = new QPushButton(QStringLiteral("Tutup"), recorderDialog_);
        recorderLayout->addWidget(recorderClose);
        connect(openMidiButton, &QPushButton::clicked, this, [this] { loadMidi(); });
        connect(playButton_, &QPushButton::clicked, this, [this] { togglePlayback(); });
        connect(stopMidiButton, &QPushButton::clicked, this, [this] { stopPlayback(); });
        connect(recordButton_, &QPushButton::clicked, this, [this] { toggleRecording(); });
        connect(recorderClose, &QPushButton::clicked, recorderDialog_, &QDialog::hide);

        connect(programCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int index) {
            if (index < 0) return;
            const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
            voicePrograms_[slot] = index;
            const int midiChannel = selectedProgramChannel_; // Keep the MIDI channel mapping for external output.
            sendMidi(static_cast<quint8>(0xB0 | midiChannel), 32, static_cast<quint8>(voiceMaps_[slot]), internalVoiceChannel(selectedProgramChannel_));
            sendMidi(static_cast<quint8>(0xB0 | midiChannel), 0, static_cast<quint8>(voiceBanks_[slot]), internalVoiceChannel(selectedProgramChannel_));
            sendMidi(static_cast<quint8>(0xC0 | midiChannel), static_cast<quint8>(index), 0, internalVoiceChannel(selectedProgramChannel_));
            if (lcdVoiceList_) refreshVoicePickerPage();
            const QString name = QString::fromUtf8(kPatchNames[static_cast<std::size_t>(index)]);
            if (selectedProgramChannel_ == 0 && voiceR1Label_) voiceR1Label_->setText(name);
            if (selectedProgramChannel_ == 1 && voiceLLabel_) voiceLLabel_->setText(name);
            if (selectedProgramChannel_ == 2 && voiceR2Label_) voiceR2Label_->setText(name);
        });
        connect(tempoSlider_, &QSlider::valueChanged, this, [this](int value) {
            tempo_ = value;
            if (tempoValue_) tempoValue_->setText(QString::number(value));
            if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(value));
            styleEngine_.setTempo(value);
        });
        connect(gainSlider_, &QSlider::valueChanged, this, [this](int value) {
            setMidiOutputVolume(value);
            if (masterControlDial_) {
                const QSignalBlocker blocker(masterControlDial_);
                masterControlDial_->setValue(std::clamp((value * 127 + 50) / 100, 0, 127));
            }
            QSettings settings; settings.setValue(QStringLiteral("panel/outputVolume"), value); settings.sync();
        });
        connect(metronomeCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (metronomeButton_ && metronomeButton_->isChecked() != on) metronomeButton_->setChecked(on);
            updateModulationTimer();
            QSettings settings; settings.setValue(QStringLiteral("panel/metronomeOn"), on); settings.sync();
        });
        connect(lfoCheck_, &QCheckBox::toggled, this, [this] { updateModulationTimer(); });
        connect(reverbCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (reverbButton_ && reverbButton_->isChecked() != on) reverbButton_->setChecked(on);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        connect(chorusCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (chorusButton_ && chorusButton_->isChecked() != on) chorusButton_->setChecked(on);
            applyPanelMidiSettings();
            savePanelSettings();
        });

        startupTrace("buildUi: settings dialog and controller hookups complete; building main panel");
        // Top title bar mirrors the original custom GTK header.
        auto *header = new DraggableHeaderWidget(this, central);
        header->setObjectName(QStringLiteral("headerBar"));
        header->setFixedHeight(54);
        auto *headerLayout = new QHBoxLayout(header);
        headerLayout->setContentsMargins(5, 2, 5, 2);
        headerLayout->setSpacing(5);
        auto *closeButton = new QPushButton(QStringLiteral("×"), header);
        closeButton->setObjectName(QStringLiteral("flatButton"));
        closeButton->setFixedWidth(36);
        connect(closeButton, &QPushButton::clicked, this, &QWidget::close);
        headerLayout->addWidget(closeButton);
        for (int i = 0; i < 4; ++i) {
            auto *arrow = new QPushButton(QStringLiteral("❯"), header);
            arrow->setObjectName(QStringLiteral("flatButton"));
            arrow->setFixedWidth(24);
            arrow->setToolTip(QStringLiteral("Navigasi cepat arranger; fungsi navigasi lanjut belum dipindahkan."));
            arrow->setEnabled(false);
            headerLayout->addWidget(arrow);
        }
        // The reference header places Metronome beside the transport buttons.
        metronomeButton_ = new QPushButton(QStringLiteral("Metronome"), header);
        metronomeButton_->setFixedWidth(84);
        metronomeButton_->setCheckable(true);
        metronomeButton_->setToolTip(QStringLiteral("Toggle metronome click."));
        connect(metronomeButton_, &QPushButton::toggled, this, [this](bool on) {
            if (metronomeCheck_ && metronomeCheck_->isChecked() != on) metronomeCheck_->setChecked(on);
        });
        headerLayout->addWidget(metronomeButton_);
        headerLayout->addStretch(1);
        auto *title = new QLabel(QStringLiteral("Ensembles"), header);
        title->setObjectName(QStringLiteral("appTitle"));
        title->setAlignment(Qt::AlignCenter);
        headerLayout->addWidget(title);
        headerLayout->addStretch(1);
        auto *headerBalance = new QWidget(header);
        headerBalance->setFixedWidth(94); // Keeps the title centered despite asymmetric side controls.
        headerLayout->addWidget(headerBalance);
        auto *folderButton = new QPushButton(QStringLiteral("▱"), header);
        folderButton->setFixedSize(33, 30);
        folderButton->setToolTip(QStringLiteral("Buka MIDI / Recorder"));
        connect(folderButton, &QPushButton::clicked, recorderDialog_, &QDialog::show);
        headerLayout->addWidget(folderButton);
        auto *settingsButton = new QPushButton(QStringLiteral("⚙"), header);
        settingsButton->setFixedSize(33, 30);
        connect(settingsButton, &QPushButton::clicked, settingsDialog_, &QDialog::show);
        headerLayout->addWidget(settingsButton);
        auto *fullscreenButton = new QPushButton(QStringLiteral("⛶"), header);
        fullscreenButton->setFixedSize(33, 30);
        fullscreenButton->setToolTip(QStringLiteral("Toggle fullscreen"));
        connect(fullscreenButton, &QPushButton::clicked, this, [this] {
            if (isFullScreen()) showNormal(); else showFullScreen();
        });
        headerLayout->addWidget(fullscreenButton);
        root->addWidget(header);

        // Upper three-column deck: assignable controls, original central display, and transport/effects.
        startupTrace("buildUi: before three-panel LCD surface");
        auto *topRow = new QWidget(central);
        auto *topLayout = new QHBoxLayout(topRow);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(4);

        auto *leftTop = makePanel(topRow);
        auto *leftTopLayout = new QVBoxLayout(leftTop);
        leftTopLayout->setContentsMargins(4, 4, 4, 3);
        leftTopLayout->setSpacing(2);
        auto *assignBars = new QHBoxLayout;
        knobAssignButton_ = new QPushButton(QStringLiteral("Knob Assign"), leftTop);
        masterAssignButton_ = new QPushButton(QStringLiteral("Master Knob Assign"), leftTop);
        auto *knobAssign = knobAssignButton_;
        auto *masterAssign = masterAssignButton_;
        knobAssign->setCheckable(true);
        masterAssign->setCheckable(true);
        knobAssign->setToolTip(QStringLiteral("Aktifkan, lalu klik salah satu dari empat knob untuk memetakan MIDI CC."));
        masterAssign->setToolTip(QStringLiteral("Aktifkan, lalu klik kontrol mana pun untuk memasukkan/mengeluarkannya dari kendali Master Knob."));
        connect(knobAssign, &QPushButton::clicked, this, [this, knobAssign, masterAssign](bool checked) {
            knobAssignMode_ = checked;
            if (checked) {
                masterAssignMode_ = false; sliderAssignMode_ = false;
                masterAssign->setChecked(false); if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
                setStatus(QStringLiteral("Mode Knob Assign aktif — klik knob 1–4 untuk memilih pemetaan."));
            } else setStatus(QStringLiteral("Mode Knob Assign nonaktif."));
            updateAssignmentButtonAvailability();
        });
        connect(masterAssign, &QPushButton::clicked, this, [this, knobAssign, masterAssign](bool checked) {
            masterAssignMode_ = checked;
            if (checked) {
                knobAssignMode_ = false; sliderAssignMode_ = false;
                knobAssign->setChecked(false); if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
                setStatus(QStringLiteral("Mode Master Knob aktif — klik kontrol untuk menambah/menghapus target."));
            } else setStatus(QStringLiteral("Mode Master Knob nonaktif."));
            updateAssignmentButtonAvailability();
        });
        assignBars->addWidget(knobAssign, 1);
        assignBars->addWidget(masterAssign, 1);
        leftTopLayout->addLayout(assignBars);
        auto *dialRow = new QWidget(leftTop);
        auto *dialLayout = new QHBoxLayout(dialRow);
        dialLayout->setContentsMargins(3, 0, 3, 0);
        dialLayout->setSpacing(8);
        for (int i = 0; i < 4; ++i) {
            auto *cell = new QWidget(dialRow);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(0);
            auto *dial = new PanelDial(cell);
            dial->setRange(0, 127); dial->setValue(64); dial->setNotchesVisible(false);
            dial->setFixedSize(29, 29);
            dial->setEnabled(true);
            assignableKnobs_[static_cast<std::size_t>(i)] = dial;
            connect(dial, &QDial::valueChanged, this, [this, i](int value) { handleAssignableControlValue(10 + i, value); });
            connect(dial, &QDial::sliderReleased, this, [this, i] {
                const int index = 10 + i;
                const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
                const QString shortName = controlShortLabel(map.target, map.controller, map.assigned);
                handleAssignableControlPressed(index, QStringLiteral("Knob %1 (%2)").arg(i + 1).arg(shortName));
            });
            cellLayout->addWidget(dial, 0, Qt::AlignHCenter);
            auto *number = new QLabel(QString::number(i + 1), cell);
            number->setAlignment(Qt::AlignCenter);
            cellLayout->addWidget(number);
            auto *nameLabel = new QLabel(controlShortLabel(defaultControlTarget(10 + i), defaultControllerForTarget(defaultControlTarget(10 + i))), cell);
            nameLabel->setAlignment(Qt::AlignCenter);
            nameLabel->setMinimumWidth(0); nameLabel->setMaximumWidth(52);
            QFont nameFont = nameLabel->font(); nameFont.setPointSize(7); nameLabel->setFont(nameFont);
            nameLabel->setToolTip(controlTargetLabel(defaultControlTarget(10 + i)));
            assignableKnobNameLabels_[static_cast<std::size_t>(i)] = nameLabel;
            cellLayout->addWidget(nameLabel);
            dialLayout->addWidget(cell, 1);
        }
        auto *masterCell = new QWidget(dialRow);
        auto *masterCellLayout = new QVBoxLayout(masterCell);
        masterCellLayout->setContentsMargins(0, 0, 0, 0);
        masterControlDial_ = new PanelDial(masterCell);
        masterControlDial_->setRange(0, 127); masterControlDial_->setValue(64); masterControlDial_->setFixedSize(48, 48);
        masterControlDial_->setToolTip(QStringLiteral("Master Volume — mengatur output aplikasi. Master Knob Assign menambahkan slider/knob lain sebagai target ikutan."));
        connect(masterControlDial_, &QDial::valueChanged, this, [this](int value) { handleMasterControlValue(value); });
        masterCellLayout->addWidget(masterControlDial_, 0, Qt::AlignHCenter | Qt::AlignVCenter);
        masterControlNameLabel_ = new QLabel(QStringLiteral("Master Vol"), masterCell);
        masterControlNameLabel_->setAlignment(Qt::AlignCenter);
        QFont masterNameFont = masterControlNameLabel_->font(); masterNameFont.setPointSize(7); masterControlNameLabel_->setFont(masterNameFont);
        masterControlNameLabel_->setToolTip(QStringLiteral("Master Volume — output aplikasi"));
        masterCellLayout->addWidget(masterControlNameLabel_, 0, Qt::AlignHCenter);
        dialLayout->addWidget(masterCell, 1);
        leftTopLayout->addWidget(dialRow);
        // Six physical function faders match the supplied reference image exactly.
        // They are intentionally not presented as a second 10-channel mixer.
        auto *slidersRow = new QWidget(leftTop);
        auto *slidersLayout = new QHBoxLayout(slidersRow);
        slidersLayout->setContentsMargins(1, 0, 1, 0);
        slidersLayout->setSpacing(7);
        static const std::array<const char *, 6> panelFaderLabels = {"STYLE", "SONG", "AUDIO", "PADS", "DRUM/PERC", "CHORD"};
        const std::array<int, 6> sliderInitial = {100, 100, 100, 100, 100, 100};
        for (int i = 0; i < 6; ++i) {
            auto *cell = new QWidget(slidersRow);
            cell->setObjectName(QStringLiteral("leftPanelFader_%1").arg(i));
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(1);
            auto *slider = new QSlider(Qt::Vertical, cell);
            slider->setObjectName(QStringLiteral("leftPanelFaderSlider_%1").arg(i));
            slider->setRange(0, 127);
            slider->setValue(sliderInitial[static_cast<std::size_t>(i)]);
            slider->setMinimumWidth(14);
            slider->setInvertedAppearance(true);
            slider->setEnabled(true);
            assignableSliders_[static_cast<std::size_t>(i)] = slider;
            connect(slider, &QSlider::valueChanged, this, [this, i](int value) { handleAssignableControlValue(i, value); });
            connect(slider, &QSlider::sliderReleased, this, [this, i] {
                handleAssignableControlPressed(i, QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)]));
            });
            cellLayout->addWidget(slider, 1, Qt::AlignHCenter);
            auto *nameLabel = new QLabel(QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)]), cell);
            nameLabel->setObjectName(QStringLiteral("leftPanelFaderLabel_%1").arg(i));
            nameLabel->setAlignment(Qt::AlignCenter);
            nameLabel->setMinimumWidth(0);
            nameLabel->setMaximumWidth(58);
            nameLabel->setFixedHeight(20);
            nameLabel->setWordWrap(true);
            QFont nameFont = nameLabel->font(); nameFont.setPointSize(6); nameLabel->setFont(nameFont);
            assignableSliderNameLabels_[static_cast<std::size_t>(i)] = nameLabel;
            cellLayout->addWidget(nameLabel);
            slidersLayout->addWidget(cell, 1);
        }
        leftTopLayout->addWidget(slidersRow, 4);
        // Captions are initialized from default mappings above; normal startup refreshes them
        // after loadControllerMaps(), including any saved custom assignments.
        topLayout->addWidget(leftTop, 31);

        auto *centerTop = makePanel(topRow);
        auto *centerLayout = new QVBoxLayout(centerTop);
        centerLayout->setContentsMargins(0, 0, 0, 0);
        centerLayout->setSpacing(0);
        lcdContentStack_ = new QStackedWidget(centerTop);
        lcdContentStack_->setObjectName(QStringLiteral("lcdContentStack"));
        centerLayout->addWidget(lcdContentStack_, 1);
        lcdHomePage_ = new QWidget(lcdContentStack_);
        auto *lcdHomeLayout = new QVBoxLayout(lcdHomePage_);
        lcdHomeLayout->setContentsMargins(0, 0, 0, 0);
        lcdHomeLayout->setSpacing(0);
        lcdContentStack_->addWidget(lcdHomePage_);
        // Keep the two-line LCD tabs flush with the screen edge. The earlier
        // 14 px spacer + 33 px strip clipped the labels and looked like a second
        // empty bezel; a single full-height strip matches the original LCD.
        auto *displayTabs = new QWidget(lcdHomePage_);
        displayTabs->setFixedHeight(47);
        auto *displayTabsLayout = new QHBoxLayout(displayTabs);
        displayTabsLayout->setContentsMargins(0, 0, 0, 0);
        displayTabsLayout->setSpacing(0);
        auto *styleTab = makeDisplayTab(QStringLiteral("Style"), QStringLiteral("Memuat…"), &styleNameLabel_, displayTabs);
        auto *voiceLTab = makeDisplayTab(QStringLiteral("Voice L"), QStringLiteral("Fingered Bass"), &voiceLLabel_, displayTabs);
        auto *voiceR1Tab = makeDisplayTab(QStringLiteral("Voice R1"), QStringLiteral("Grand Piano"), &voiceR1Label_, displayTabs);
        auto *voiceR2Tab = makeDisplayTab(QStringLiteral("Voice R2"), QStringLiteral("SynthStrings 1"), &voiceR2Label_, displayTabs);
        displayTabsLayout->addWidget(styleTab, 1);
        displayTabsLayout->addWidget(voiceLTab, 1);
        displayTabsLayout->addWidget(voiceR1Tab, 1);
        displayTabsLayout->addWidget(voiceR2Tab, 1);
        connect(styleTab, &QPushButton::clicked, this, [this] {
            dataEntryStyleMode_ = true;
            if (lcdContentStack_ && lcdStylePickerPage_)
                lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
            if (lcdStyleList_ && lcdStyleList_->currentItem())
                lcdStyleList_->scrollToItem(lcdStyleList_->currentItem(), QAbstractItemView::PositionAtCenter);
        });
        auto openVoicePicker = [this](int channel) {
            // The Voice tabs now open the dedicated selector that follows the
            // SC-8820 reference: map tabs, instrument categories, two-column
            // patch grid, and 12-preset pagination.
            openVoiceSelectPage(channel);
        };
        connect(voiceLTab, &QPushButton::clicked, this, [openVoicePicker] { openVoicePicker(1); });
        connect(voiceR1Tab, &QPushButton::clicked, this, [openVoicePicker] { openVoicePicker(0); });
        connect(voiceR2Tab, &QPushButton::clicked, this, [openVoicePicker] { openVoicePicker(2); });
        lcdHomeLayout->addWidget(displayTabs);

        QString imagePath = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"));
        if (!QFileInfo::exists(imagePath)) imagePath = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("../data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"));
        if (!QFileInfo::exists(imagePath)) imagePath = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("legacy-reference/data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"));
        if (!QFileInfo::exists(imagePath)) imagePath = QDir::current().filePath(QStringLiteral("data/Images/catalin-sandru-7SxSkCvVM1U-unsplash.jpg"));
        auto *cover = new CoverPhotoWidget(imagePath, lcdHomePage_);
        cover->setFixedHeight(116);
        lcdHomeLayout->addWidget(cover);

        auto *metrics = new QWidget(lcdHomePage_);
        metrics->setStyleSheet(QStringLiteral("background:#243033;"));
        metrics->setFixedHeight(39);
        auto *metricsLayout = new QHBoxLayout(metrics);
        metricsLayout->setContentsMargins(3, 2, 3, 1);
        metricsLayout->setSpacing(1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Tempo"), &tempoValue_, metrics), 1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Measure"), &measureMetricLabel_, metrics), 1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Beat"), &beatMetricLabel_, metrics), 1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Transpose"), &transposeMetricLabel_, metrics), 1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Octave"), &octaveMetricLabel_, metrics), 1);
        metricsLayout->addWidget(makeMetric(QStringLiteral("Chord"), &chordLabel_, metrics), 1);
        tempoValue_->setText(QStringLiteral("120"));
        measureMetricLabel_->setText(QStringLiteral("0"));
        beatMetricLabel_->setText(QStringLiteral("4/4"));
        transposeMetricLabel_->setText(QStringLiteral("0"));
        octaveMetricLabel_->setText(QStringLiteral("0"));
        chordLabel_->setText(QStringLiteral("C min"));
        lcdHomeLayout->addWidget(metrics);

        auto *metersHost = new QWidget(lcdHomePage_);
        metersHost->setToolTip(QStringLiteral("Indikator aktivitas MIDI per kanal/voice. Ini bukan pengukuran peak audio RtAudio."));
        metersHost->setStyleSheet(QStringLiteral("background:#293538;"));
        auto *metersLayout = new QHBoxLayout(metersHost);
        metersLayout->setContentsMargins(3, 0, 3, 1);
        metersLayout->setSpacing(2);
        for (int i = 0; i < 19; ++i) {
            auto *column = new QWidget(metersHost);
            auto *columnLayout = new QVBoxLayout(column);
            columnLayout->setContentsMargins(0, 0, 0, 0);
            columnLayout->setSpacing(0);
            auto *bar = new QProgressBar(column);
            bar->setOrientation(Qt::Vertical);
            bar->setRange(0, 100);
            bar->setValue(0);
            bar->setTextVisible(false);
            bar->setFixedWidth(14);
            bar->setMinimumHeight(32);
            bar->setToolTip(QStringLiteral("MIDI activity indicator for this channel (events, not an audio peak meter)."));
            channelActivityMeters_[static_cast<std::size_t>(i)] = bar;
            columnLayout->addWidget(bar, 1, Qt::AlignHCenter);
            auto *trackLabel = new QLabel(i < 16 ? QString::number(i + 1) : (i == 16 ? QStringLiteral("L") : i == 17 ? QStringLiteral("R1") : QStringLiteral("R2")), column);
            trackLabel->setAlignment(Qt::AlignCenter);
            trackLabel->setStyleSheet(QStringLiteral("font-size:7pt;color:#b9d86e;"));
            columnLayout->addWidget(trackLabel);
            auto *configure = new QPushButton(QStringLiteral("⚙"), column);
            configure->setObjectName(QStringLiteral("flatButton"));
            configure->setFixedHeight(15);
            configure->setToolTip(i < 16 ? QStringLiteral("MIDI channel %1 output level is adjustable in the mixer below.").arg(i + 1) : QStringLiteral("Dedicated voice channel mixer is not yet equivalent to the original synthesizer."));
            if (i >= 16) configure->setEnabled(false);
            else connect(configure, &QPushButton::clicked, this, [this] { settingsDialog_->show(); });
            columnLayout->addWidget(configure);
            metersLayout->addWidget(column, 1);
        }
        lcdHomeLayout->addWidget(metersHost, 1);

        startupTrace("buildUi: before LCD Voice/Style picker pages");
        // The original application opens Voice and Style choosers inside the
        // central LCD itself, replacing the home/photo page rather than opening
        // a detached desktop dialog.  Keep each picker in this LCD stack so the
        // surrounding hardware controls never move when a list is opened.
        auto createLcdPickerPage = [this](const QString &title, const QString &subtitle,
                                          bool voiceMode, QListWidget **listOutput) {
            auto *page = new QWidget(lcdContentStack_);
            page->setObjectName(voiceMode ? QStringLiteral("lcdVoicePickerPage")
                                          : QStringLiteral("lcdStylePickerPage"));
            page->setStyleSheet(QStringLiteral("background:#2e2e2e;"));
            auto *pageLayout = new QVBoxLayout(page);
            pageLayout->setContentsMargins(0, 0, 0, 0);
            pageLayout->setSpacing(0);

            auto *header = new QWidget(page);
            header->setFixedHeight(47);
            header->setStyleSheet(QStringLiteral("background:#007166;"));
            auto *headerLayout = new QHBoxLayout(header);
            headerLayout->setContentsMargins(5, 2, 8, 2);
            headerLayout->setSpacing(4);
            auto *close = new QPushButton(QStringLiteral("×"), header);
            close->setObjectName(QStringLiteral("lcdPickerClose"));
            close->setFixedSize(23, 28);
            close->setStyleSheet(QStringLiteral("QPushButton{background:transparent;border:0;padding:0;font-size:17pt;font-weight:600;color:#f2ffff;} QPushButton:hover{color:#ffffff;background:#0d8276;}"));
            connect(close, &QPushButton::clicked, this, [this] {
                if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
            });

            auto *titleBox = new QWidget(header);
            auto *titleLayout = new QVBoxLayout(titleBox);
            titleLayout->setContentsMargins(0, 0, 0, 0);
            titleLayout->setSpacing(0);
            auto *titleLabel = new QLabel(title, titleBox);
            titleLabel->setObjectName(QStringLiteral("lcdPickerTitle"));
            titleLabel->setAlignment(Qt::AlignCenter);
            titleLabel->setStyleSheet(QStringLiteral("color:#ffffff;font-size:9pt;font-weight:700;background:transparent;"));
            auto *subtitleLabel = new QLabel(subtitle, titleBox);
            subtitleLabel->setObjectName(QStringLiteral("lcdPickerSubtitle"));
            subtitleLabel->setAlignment(Qt::AlignCenter);
            subtitleLabel->setStyleSheet(QStringLiteral("color:#d4efea;font-size:7pt;background:transparent;"));
            titleLayout->addWidget(titleLabel);
            titleLayout->addWidget(subtitleLabel);
            headerLayout->addWidget(close, 0, Qt::AlignVCenter);
            headerLayout->addWidget(titleBox, 1);
            auto *headerBalance = new QWidget(header);
            headerBalance->setFixedWidth(23);
            headerLayout->addWidget(headerBalance);
            pageLayout->addWidget(header);
            if (voiceMode) {
                auto *voiceFilterRow = new QWidget(page);
                voiceFilterRow->setStyleSheet(QStringLiteral("background:#242424;"));
                auto *filterLayout = new QHBoxLayout(voiceFilterRow);
                filterLayout->setContentsMargins(4, 3, 4, 3);
                filterLayout->setSpacing(4);
                lcdVoiceMapCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceMapCombo_->setObjectName(QStringLiteral("lcdVoiceMapCombo"));
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-8820"), 4);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-88Pro"), 3);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-88"), 2);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-55"), 1);
                lcdVoiceCategoryCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceCategoryCombo_->setObjectName(QStringLiteral("lcdVoiceCategoryCombo"));
                for (const char *category : {"All Voice Types", "Piano", "Crm Perc", "Organ", "Guitar", "Bass", "Strings", "Brass", "Reed/Pipe", "Synth Lead", "Synth Pad", "Drum Kit", "Extra"})
                    lcdVoiceCategoryCombo_->addItem(QString::fromLatin1(category));
                lcdVoiceBankCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceBankCombo_->setObjectName(QStringLiteral("lcdVoiceBankCombo"));
                lcdVoiceBankCombo_->addItem(QStringLiteral("Standard · Bank 0"), 0);
                lcdVoiceBankCombo_->addItem(QStringLiteral("All variations"), -1);
                lcdVoiceMapCombo_->setStyleSheet(QStringLiteral("QComboBox{background:#3a3a3a;color:#fff;border:1px solid #555;padding:3px;} QComboBox QAbstractItemView{background:#303030;color:#fff;selection-background-color:#007166;}"));
                lcdVoiceCategoryCombo_->setStyleSheet(lcdVoiceMapCombo_->styleSheet());
                lcdVoiceBankCombo_->setStyleSheet(lcdVoiceMapCombo_->styleSheet());
                filterLayout->addWidget(lcdVoiceMapCombo_, 1);
                filterLayout->addWidget(lcdVoiceCategoryCombo_, 2);
                filterLayout->addWidget(lcdVoiceBankCombo_, 2);
                pageLayout->addWidget(voiceFilterRow);
            }

            auto *list = new QListWidget(page);
            list->setObjectName(voiceMode ? QStringLiteral("lcdVoiceList") : QStringLiteral("lcdStyleList"));
            list->setFrameShape(QFrame::NoFrame);
            list->setSelectionMode(QAbstractItemView::SingleSelection);
            list->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
            list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            list->setUniformItemSizes(true);
            list->setIconSize(voiceMode ? QSize(54, 36) : QSize(50, 32));
            if (voiceMode) {
                // The legacy VoiceMenu is a vertical, wheel-scrollable catalog.
                // Do not tile/paginate voices: one full-width row per preset, with thumbnail and category.
                list->setViewMode(QListView::ListMode);
                list->setFlow(QListView::TopToBottom);
                list->setWrapping(false);
                list->setResizeMode(QListView::Adjust);
                list->setMovement(QListView::Static);
                list->setGridSize(QSize());
                list->setSpacing(0);
                list->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
                list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            }
            list->setItemDelegate(new LcdPickerItemDelegate(voiceMode, list));
            list->setStyleSheet(QStringLiteral(
                "QListWidget{background:#2e2e2e;border:0;outline:0;padding:0;color:#bdbdbd;}"
                "QListWidget::item{border:0;padding:0;}"
                "QScrollBar:vertical{background:#242424;width:8px;margin:0;}"
                "QScrollBar::handle:vertical{background:#5b5b5b;min-height:24px;border:1px solid #333;}"
                "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"));
            pageLayout->addWidget(list, 1);
            if (voiceMode) {
                auto *countRow = new QWidget(page);
                countRow->setStyleSheet(QStringLiteral("background:#242424;"));
                auto *countLayout = new QHBoxLayout(countRow);
                countLayout->setContentsMargins(6, 2, 6, 2);
                lcdVoicePageLabel_ = new QLabel(QStringLiteral("Voice catalog"), countRow);
                lcdVoicePageLabel_->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
                lcdVoicePageLabel_->setStyleSheet(QStringLiteral("color:#aaaaaa;font-size:7pt;"));
                countLayout->addWidget(lcdVoicePageLabel_);
                countLayout->addStretch(1);
                pageLayout->addWidget(countRow);
                connect(lcdVoiceMapCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
                connect(lcdVoiceCategoryCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
                connect(lcdVoiceBankCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
            }
            if (listOutput) *listOutput = list;
            return page;
        };

        // The Voice Select reference layout is hosted directly in the LCD stack.
        // It is not a QDialog and therefore never overlays the surrounding control panes.
        lcdVoicePickerPage_ = new QWidget(lcdContentStack_);
        lcdVoicePickerPage_->setObjectName(QStringLiteral("lcdVoicePickerPage"));
        lcdVoicePickerPage_->setStyleSheet(QStringLiteral("QWidget#lcdVoicePickerPage{background:#1b1b1b;color:#eeeeee;}"));
        lcdContentStack_->addWidget(lcdVoicePickerPage_);
        lcdStylePickerPage_ = createLcdPickerPage(QStringLiteral("Style"),
            QStringLiteral("Pick a Rhythm to accompany you"), false, &lcdStyleList_);
        lcdContentStack_->addWidget(lcdStylePickerPage_);

        startupTrace("buildUi: picker widgets created; loading SCVSC voice catalog");
        // Build the voice browser from the shipped Roland SCVSC tone-file catalog.
        // The TNF contains real map/program/CC0 variation names for all four maps.
        loadVoiceCatalog();
        if (voiceCatalog_.empty()) {
            for (int program = 0; program < static_cast<int>(kPatchNames.size()); ++program) {
                VoiceCatalogEntry entry; entry.program = program; entry.bank = 0; entry.map = 4;
                entry.name = QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
                entry.category = voiceCategoryForProgram(program); voiceCatalog_.push_back(entry);
            }
        }
        startupTrace("buildUi: voice catalog populated; embedded LCD Voice Select page will build on demand");

        // The reference deck reserves slightly more width for the side banks
        // than the earlier 31:37:32 split; keep the LCD centered without making
        // its tabs/photo stretch wider than the two control banks warrant.
        startupTrace("mainPanel: before adding center widget to top layout");
        topLayout->addWidget(centerTop, 36);
        startupTrace("mainPanel: center widget added to top layout");

        startupTrace("rightPanel: before makePanel");
        auto *rightTop = makePanel(topRow);
        startupTrace("rightPanel: makePanel complete");
        auto *rightTopLayout = new QVBoxLayout(rightTop);
        startupTrace("rightPanel: layout constructed");
        rightTopLayout->setContentsMargins(4, 4, 4, 3);
        rightTopLayout->setSpacing(3);
        auto *controlsTop = new QWidget(rightTop);
        startupTrace("rightPanel: controlsTop constructed");
        controlsTop->setFixedHeight(174);
        auto *controlsTopLayout = new QHBoxLayout(controlsTop);
        controlsTopLayout->setContentsMargins(0, 0, 0, 0);
        controlsTopLayout->setSpacing(4);

        // Large encoder = Data Entry / scroll through the active Voice or Style picker.
        auto *dialArea = new QWidget(controlsTop);
        auto *dialAreaLayout = new QVBoxLayout(dialArea);
        dialAreaLayout->setContentsMargins(0, 0, 0, 0);
        dialAreaLayout->setSpacing(2);
        dataEntryDial_ = new PanelDial(dialArea);
        dataEntryDial_->setObjectName(QStringLiteral("dataEntryDial"));
        dataEntryDial_->setRange(0, 127);
        dataEntryDial_->setWrapping(true);
        dataEntryDial_->setValue(dataEntryDialLastValue_);
        dataEntryDial_->setFixedSize(74, 74);
        dataEntryDial_->setToolTip(QStringLiteral("Data Entry / Scroll: putar untuk memilih Voice atau Style pada LCD. Gunakan tombol panah untuk membuka/menutup picker."));
        connect(dataEntryDial_, &QDial::valueChanged, this, [this](int value) { rotateDataEntryDial(value); });
        dialAreaLayout->addWidget(dataEntryDial_, 0, Qt::AlignHCenter);
        auto *dataEntryButtons = new QHBoxLayout;
        dataEntryButtons->setContentsMargins(0, 0, 0, 0);
        dataEntryButtons->setSpacing(2);
        auto *minusDialButton = new QPushButton(QStringLiteral("−"), dialArea);
        auto *activateDialButton = new QPushButton(QStringLiteral("→"), dialArea);
        auto *plusDialButton = new QPushButton(QStringLiteral("+"), dialArea);
        for (auto *b : {minusDialButton, activateDialButton, plusDialButton}) b->setFixedSize(24, 21);
        minusDialButton->setToolTip(QStringLiteral("Item sebelumnya"));
        plusDialButton->setToolTip(QStringLiteral("Item berikutnya"));
        activateDialButton->setToolTip(QStringLiteral("Buka picker / kembali ke LCD utama"));
        connect(minusDialButton, &QPushButton::clicked, this, [this] { if (dataEntryDial_) dataEntryDial_->setValue(dataEntryDial_->value() - 1); });
        connect(plusDialButton, &QPushButton::clicked, this, [this] { if (dataEntryDial_) dataEntryDial_->setValue(dataEntryDial_->value() + 1); });
        connect(activateDialButton, &QPushButton::clicked, this, [this] { activateDataEntryContext(); });
        dataEntryButtons->addWidget(minusDialButton);
        dataEntryButtons->addWidget(activateDialButton);
        dataEntryButtons->addWidget(plusDialButton);
        dialAreaLayout->addLayout(dataEntryButtons);
        controlsTopLayout->addWidget(dialArea, 2);

        auto *toggleColumn = new QVBoxLayout;
        toggleColumn->setSpacing(2);
        accompButton_ = new QPushButton(QStringLiteral("Chords"), controlsTop);
        layerButton_ = new QPushButton(QStringLiteral("Layer"), controlsTop);
        splitButton_ = new QPushButton(QStringLiteral("Split"), controlsTop);
        for (auto *b : {accompButton_, layerButton_, splitButton_}) {
            b->setFixedHeight(22);
            b->setCheckable(true);
            toggleColumn->addWidget(b);
        }
        connect(accompButton_, &QPushButton::toggled, this, [this](bool on) {
            accompanimentEnabled_ = on;
            if (!on) allSoundsOff();
            savePanelSettings();
            setStatus(on ? QStringLiteral("Chords aktif: style accompaniment mengikuti chord keyboard.")
                         : QStringLiteral("Chords nonaktif: keyboard memainkan Voice langsung."));
        });
        connect(layerButton_, &QPushButton::toggled, this, [this](bool on) {
            layerEnabled_ = on; savePanelSettings();
            setStatus(on ? QStringLiteral("Layer aktif: Voice kanan utama dan layer kedua dimainkan bersamaan.") : QStringLiteral("Layer nonaktif."));
        });
        connect(splitButton_, &QPushButton::toggled, this, [this](bool on) {
            splitEnabled_ = on; savePanelSettings();
            setStatus(on ? QStringLiteral("Split aktif pada key %1.").arg(splitKey_) : QStringLiteral("Split nonaktif: seluruh keyboard memakai Voice kanan."));
        });
        controlsTopLayout->addLayout(toggleColumn, 1);

        auto *rightFadersRow = new QWidget(controlsTop);
        auto *rightFadersLayout = new QHBoxLayout(rightFadersRow);
        rightFadersLayout->setContentsMargins(0, 0, 0, 0);
        rightFadersLayout->setSpacing(3);
        static const std::array<const char *, 4> rightFaderLabels = {"L", "R1", "R2", "R3"};
        static const std::array<int, 4> rightExternalChannels = {1, 0, 2, 3};
        static const std::array<int, 4> rightInternalChannels = {19, 17, 18, 3};
        QSettings rightFaderSettings;
        for (int i = 0; i < 4; ++i) {
            auto *cell = new QWidget(rightFadersRow);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(0);
            auto *slider = new QSlider(Qt::Vertical, cell);
            slider->setObjectName(QStringLiteral("rightPartFader_%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            slider->setRange(0, 127);
            slider->setValue(std::clamp(rightFaderSettings.value(QStringLiteral("panel/rightFader%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])), 100).toInt(), 0, 127));
            slider->setMinimumWidth(12);
            slider->setInvertedAppearance(true);
            slider->setToolTip(i == 3
                ? QStringLiteral("R3 extra part: MIDI channel 4 volume (CC7). The current keyboard Voice browser has L/R1/R2 presets; R3 remains an independent MIDI part.")
                : QStringLiteral("Volume Voice %1 — MIDI CC7.").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            rightVoiceFaders_[static_cast<std::size_t>(i)] = slider;
            connect(slider, &QSlider::valueChanged, this, [this, i](int value) {
                const int extChannel = rightExternalChannels[static_cast<std::size_t>(i)];
                const int intChannel = rightInternalChannels[static_cast<std::size_t>(i)];
                sendMidi(static_cast<quint8>(0xB0 | extChannel), 7, static_cast<quint8>(std::clamp(value, 0, 127)), intChannel);
                QSettings settings;
                settings.setValue(QStringLiteral("panel/rightFader%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])), value);
                settings.sync();
            });
            cellLayout->addWidget(slider, 1, Qt::AlignHCenter);
            auto *label = new QLabel(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)]), cell);
            label->setAlignment(Qt::AlignCenter);
            label->setStyleSheet(QStringLiteral("font-weight:600;color:#e7e7e7;font-size:8pt;"));
            cellLayout->addWidget(label);
            rightFadersLayout->addWidget(cell, 1);
        }
        controlsTopLayout->addWidget(rightFadersRow, 4);
        rightTopLayout->addWidget(controlsTop);
        startupTrace("rightPanel: top controls complete");

        auto *parameterPanel = new QWidget(rightTop);
        auto *parameterPanelLayout = new QVBoxLayout(parameterPanel);
        parameterPanelLayout->setContentsMargins(0, 0, 0, 0);
        parameterPanelLayout->setSpacing(3);

        // Effect buttons mirror the supplied row; detailed levels remain available in Settings.
        auto *effectsRow = new QHBoxLayout;
        effectsRow->setContentsMargins(0, 0, 0, 0);
        effectsRow->setSpacing(4);
        reverbButton_ = new QToolButton(parameterPanel);
        reverbButton_->setText(QStringLiteral("Reverb"));
        reverbButton_->setCheckable(true);
        reverbLevelSpin_ = new QSpinBox(parameterPanel);
        reverbLevelSpin_->setRange(0, 10); reverbLevelSpin_->setValue(7); reverbLevelSpin_->hide();
        auto *efxCell = new QWidget(parameterPanel);
        auto *efxCellLayout = new QVBoxLayout(efxCell);
        efxCellLayout->setContentsMargins(0, 0, 0, 0); efxCellLayout->setSpacing(0);
        nativeEfxPanelButton_ = new QToolButton(efxCell);
        nativeEfxPanelButton_->setText(QStringLiteral("EFX Setup"));
        nativeEfxPanelButton_->setCheckable(true);
        nativeEfxPanelButton_->setToolButtonStyle(Qt::ToolButtonTextOnly);
        nativeEfxPanelButton_->setFixedHeight(26);
        nativeEfxNameLabel_ = new QLabel(nativeEfxTypeCombo_ ? nativeEfxTypeCombo_->currentText() : QStringLiteral("Overdrive"), efxCell);
        nativeEfxNameLabel_->setAlignment(Qt::AlignCenter);
        nativeEfxNameLabel_->setStyleSheet(QStringLiteral("color:#d7e9e7;font-size:7pt;"));
        nativeEfxNameLabel_->setToolTip(QStringLiteral("Native SCVA insertion effect; EFX Setup opens effect type and parameters."));
        efxCellLayout->addWidget(nativeEfxPanelButton_); efxCellLayout->addWidget(nativeEfxNameLabel_);
        chorusButton_ = new QToolButton(parameterPanel);
        chorusButton_->setText(QStringLiteral("Chorus"));
        chorusButton_->setCheckable(true);
        chorusLevelSpin_ = new QSpinBox(parameterPanel);
        chorusLevelSpin_->setRange(0, 10); chorusLevelSpin_->setValue(2); chorusLevelSpin_->hide();
        for (auto *b : {static_cast<QWidget *>(reverbButton_), efxCell, static_cast<QWidget *>(chorusButton_)}) {
            if (b != efxCell) {
                b->setMinimumHeight(26);
                b->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            }
            effectsRow->addWidget(b, 1);
        }
        parameterPanelLayout->addLayout(effectsRow);

        auto makeAdjustGroup = [parameterPanel](const QString &title, QToolButton **toggleOut, QSpinBox **spinOut, int minimum, int maximum, int initial) {
            auto *group = new QWidget(parameterPanel);
            auto *layout = new QVBoxLayout(group);
            layout->setContentsMargins(0, 0, 0, 0); layout->setSpacing(1);
            auto *toggle = new QToolButton(group);
            toggle->setText(title); toggle->setCheckable(true); toggle->setFixedHeight(21);
            auto *buttons = new QWidget(group);
            auto *buttonLayout = new QHBoxLayout(buttons);
            buttonLayout->setContentsMargins(0, 0, 0, 0); buttonLayout->setSpacing(2);
            auto *minus = new QPushButton(QStringLiteral("−"), buttons);
            auto *plus = new QPushButton(QStringLiteral("+"), buttons);
            minus->setFixedHeight(20); plus->setFixedHeight(20);
            buttonLayout->addWidget(minus); buttonLayout->addWidget(plus);
            auto *spin = new QSpinBox(group);
            spin->setRange(minimum, maximum); spin->setValue(initial); spin->hide();
            connect(minus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() - 1); });
            connect(plus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() + 1); });
            layout->addWidget(toggle); layout->addWidget(buttons);
            if (toggleOut) *toggleOut = toggle;
            if (spinOut) *spinOut = spin;
            return group;
        };
        auto *adjustRow = new QHBoxLayout;
        adjustRow->setContentsMargins(0, 0, 0, 0); adjustRow->setSpacing(4);
        adjustRow->addWidget(makeAdjustGroup(QStringLiteral("TRANSPOSE"), &transposeButton_, &transposeSpin_, -12, 12, 0), 1);
        adjustRow->addWidget(makeAdjustGroup(QStringLiteral("OCTAVE"), &octaveButton_, &octaveSpin_, -2, 2, 0), 1);

        // Tempo uses the existing Settings slider as the single source of truth.
        auto *tempoGroup = new QWidget(parameterPanel);
        auto *tempoLayout = new QVBoxLayout(tempoGroup);
        tempoLayout->setContentsMargins(0, 0, 0, 0); tempoLayout->setSpacing(1);
        auto *tempoLabelButton = new QToolButton(tempoGroup);
        tempoLabelButton->setText(QStringLiteral("TEMPO")); tempoLabelButton->setFixedHeight(21);
        auto *tempoStepRow = new QWidget(tempoGroup);
        auto *tempoStepLayout = new QHBoxLayout(tempoStepRow);
        tempoStepLayout->setContentsMargins(0, 0, 0, 0); tempoStepLayout->setSpacing(2);
        auto *tempoMinus = new QPushButton(QStringLiteral("−"), tempoStepRow);
        auto *tempoPlus = new QPushButton(QStringLiteral("+"), tempoStepRow);
        tempoMinus->setFixedHeight(20); tempoPlus->setFixedHeight(20);
        connect(tempoMinus, &QPushButton::clicked, this, [this] { if (tempoSlider_) tempoSlider_->setValue(std::max(40, tempoSlider_->value() - 1)); });
        connect(tempoPlus, &QPushButton::clicked, this, [this] { if (tempoSlider_) tempoSlider_->setValue(std::min(240, tempoSlider_->value() + 1)); });
        tempoStepLayout->addWidget(tempoMinus); tempoStepLayout->addWidget(tempoPlus);
        tempoLayout->addWidget(tempoLabelButton); tempoLayout->addWidget(tempoStepRow);
        adjustRow->addWidget(tempoGroup, 1);
        adjustRow->addWidget(makeAdjustGroup(QStringLiteral("ARPEGGIATOR"), &arpButton_, &arpSpin_, 1, 12, 1), 1);
        parameterPanelLayout->addLayout(adjustRow);
        parameterPanelLayout->addStretch(1);

        nativeEfxPanelButton_->setChecked(nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        connect(nativeEfxPanelButton_, &QToolButton::toggled, this, [this](bool on) {
            if (nativeEfxCheck_ && nativeEfxCheck_->isChecked() != on) nativeEfxCheck_->setChecked(on);
        });
        connect(nativeEfxPanelButton_, &QToolButton::clicked, this, [this] { if (settingsDialog_) settingsDialog_->show(); });
        if (nativeEfxTypeCombo_) connect(nativeEfxTypeCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] {
            if (nativeEfxNameLabel_ && nativeEfxTypeCombo_) nativeEfxNameLabel_->setText(nativeEfxTypeCombo_->currentText());
        });
        if (nativeEfxCheck_) connect(nativeEfxCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (nativeEfxPanelButton_ && nativeEfxPanelButton_->isChecked() != on) nativeEfxPanelButton_->setChecked(on);
        });
        rightTopLayout->addWidget(parameterPanel, 1);
        startupTrace("rightPanel: parameter grid added");
        auto *transStatus = new QLabel(QStringLiteral(""), rightTop);
        transStatus->setVisible(false);
        transposeButton_->setCheckable(true);
        octaveButton_->setCheckable(true);
        reverbButton_->setCheckable(true);
        chorusButton_->setCheckable(true);
        arpButton_->setCheckable(true);
        // The Harmonizer card is not present in the current right-panel grid, so its
        // optional pointer remains null. Never dereference it until a real widget is added.
        if (harmonizerButton_) harmonizerButton_->setCheckable(true);
        // Arpeggiator is implemented below as a keyboard-held-note MIDI sequencer. The
        // Harmonizer remains unavailable because the original multi-note algorithm is not ported.
        arpButton_->setEnabled(true);
        arpSpin_->setEnabled(true);
        arpButton_->setToolTip(QStringLiteral("Arpeggiator aktif: tahan beberapa nada pada keyboard. Pola 1-4 naik, 5-8 turun, 9-12 naik-turun."));
        arpSpin_->setToolTip(QStringLiteral("Pola arpeggio: arah ditentukan kelompok 1-4 / 5-8 / 9-12; angka terakhir menentukan pembagian tempo."));
        if (harmonizerButton_) {
            harmonizerButton_->setEnabled(false);
            harmonizerButton_->setToolTip(QStringLiteral("Harmonizer belum tersedia: algoritma harmoni asli belum dipindahkan."));
        }
        if (harmonizerSpin_) {
            harmonizerSpin_->setEnabled(false);
            harmonizerSpin_->setToolTip(QStringLiteral("Harmonizer belum tersedia: algoritma harmoni asli belum dipindahkan."));
        }
        arpeggiatorTimer_.setSingleShot(false);
        connect(&arpeggiatorTimer_, &QTimer::timeout, this, [this] { advanceArpeggiator(); });
        connect(arpButton_, &QToolButton::toggled, this, [this](bool on) {
            if (!on) stopArpeggiator(true);
            else updateArpeggiatorTimer();
            savePanelSettings();
            setStatus(on ? QStringLiteral("Arpeggiator aktif — tahan nada untuk mulai.") : QStringLiteral("Arpeggiator nonaktif."));
        });
        connect(transposeButton_, &QToolButton::toggled, this, [this](bool on) {
            transposeActive_ = on;
            transposeButton_->setProperty("active", on);
            transposeButton_->setStyleSheet(QString());
            transposeMetricLabel_->setText(on ? QString::number(transposeAmount_) : QStringLiteral("0"));
            savePanelSettings();
        });
        connect(octaveButton_, &QToolButton::toggled, this, [this](bool on) {
            octaveShiftActive_ = on;
            octaveButton_->setProperty("active", on);
            octaveButton_->setStyleSheet(QString());
            octaveMetricLabel_->setText(on ? QString::number(octaveShiftAmount_) : QStringLiteral("0"));
            savePanelSettings();
        });
        connect(transposeSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            transposeAmount_ = value;
            if (transposeMetricLabel_) transposeMetricLabel_->setText(transposeActive_ ? QString::number(value) : QStringLiteral("0"));
            savePanelSettings();
        });
        connect(octaveSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            octaveShiftAmount_ = value;
            if (octaveMetricLabel_) octaveMetricLabel_->setText(octaveShiftActive_ ? QString::number(value) : QStringLiteral("0"));
            savePanelSettings();
        });
        connect(arpSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int) { updateArpeggiatorTimer(); savePanelSettings(); });
        if (harmonizerSpin_) connect(harmonizerSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int) { savePanelSettings(); });
        connect(reverbButton_, &QToolButton::toggled, this, [this](bool on) {
            if (reverbCheck_ && reverbCheck_->isChecked() != on) reverbCheck_->setChecked(on);
            savePanelSettings();
        });
        connect(chorusButton_, &QToolButton::toggled, this, [this](bool on) {
            if (chorusCheck_ && chorusCheck_->isChecked() != on) chorusCheck_->setChecked(on);
            savePanelSettings();
        });
        connect(reverbLevelSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            Q_UNUSED(value);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        connect(chorusLevelSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            Q_UNUSED(value);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        startupTrace("rightPanel: before adding right panel to top layout");
        topLayout->addWidget(rightTop, 32);
        startupTrace("rightPanel: added right panel to top layout");
        topRow->setFixedHeight(282);
        startupTrace("mainPanel: top row fixed height set");
        root->addWidget(topRow);
        startupTrace("mainPanel: top row added to root");

        // Secondary row mirrors voice categories, the 16-part style mixer, and sampling pads.
        startupTrace("middleRow: before row construction");
        auto *middleRow = new QWidget(central);
        auto *middleLayout = new QHBoxLayout(middleRow);
        startupTrace("middleRow: row and layout constructed");
        middleLayout->setContentsMargins(0, 0, 0, 0);
        middleLayout->setSpacing(4);
        auto *voicesPanel = makePanel(middleRow);
        startupTrace("middleRow: voices panel constructed");
        auto *voicesLayout = new QVBoxLayout(voicesPanel);
        voicesLayout->setContentsMargins(4, 3, 4, 3);
        voicesLayout->setSpacing(2);
        auto *voiceHeading = new QWidget(voicesPanel);
        auto *voiceHeadingLayout = new QHBoxLayout(voiceHeading);
        voiceHeadingLayout->setContentsMargins(0, 0, 0, 0);
        voiceHeadingLayout->setSpacing(5);
        auto *voiceHeadingLabel = makeCaption(QStringLiteral("VOICE TYPES"), voiceHeading);
        voiceHeadingLayout->addWidget(voiceHeadingLabel);
        auto *voiceSeparator = new QFrame(voiceHeading);
        voiceSeparator->setFrameShape(QFrame::HLine);
        voiceSeparator->setStyleSheet(QStringLiteral("color:#4b4b4b;background:#4b4b4b;max-height:1px;"));
        voiceHeadingLayout->addWidget(voiceSeparator, 1);
        voicesLayout->addWidget(voiceHeading);
        const std::array<std::array<const char *, 4>, 3> categories = {{{"Piano", "Crm Perc", "Organ", "Guitar"}, {"Bass", "Strings", "Brass", "Reed/Pipe"}, {"Synth Lead", "Synth Pad", "Drum Kit", "Extra"}}};
        for (int row = 0; row < 3; ++row) {
            auto *line = new QHBoxLayout;
            line->setSpacing(3);
            for (int col = 0; col < 4; ++col) {
                const int idx = row * 4 + col;
                auto *button = new QPushButton(QString::fromUtf8(categories[static_cast<std::size_t>(row)][static_cast<std::size_t>(col)]), voicesPanel);
                button->setMinimumHeight(25);
                if (idx == 10) {
                    button->setEnabled(false);
                    button->setToolTip(QStringLiteral("Drum Kit bukan preset melodic voice. Kit GM dipilih pada kanal MIDI 10; browser kit Native SCVA belum tersedia."));
                } else {
                    button->setToolTip(QStringLiteral("Buka Voice browser dan filter keluarga %1; pilih satu baris untuk mengganti suara aktif.").arg(button->text()));
                    connect(button, &QPushButton::clicked, this, [this, idx] {
                        static const std::array<const char *, 12> dialogCategories = {
                            "Piano", "Chromatic Perc", "Organ", "Guitar", "Bass", "Strings",
                            "Brass", "Reed/Pipe", "Synth", "Synth", "Percussion", "Extra"
                        };
                        const int safeIndex = std::clamp(idx, 0, static_cast<int>(dialogCategories.size()) - 1);
                        openVoiceSelectPage(selectedProgramChannel_, QString::fromLatin1(dialogCategories[static_cast<std::size_t>(safeIndex)]));
                    });
                }
                line->addWidget(button, 1);
            }
            voicesLayout->addLayout(line, 1);
        }
        startupTrace("middleRow: all voice categories built");
        middleLayout->addWidget(voicesPanel, 31);
        startupTrace("middleRow: voices panel added to layout");

        startupTrace("middleRow: before mixer panel");
        auto *mixerPanel = makePanel(middleRow);
        startupTrace("middleRow: mixer panel constructed");
        auto *mixerLayout = new QGridLayout(mixerPanel);
        startupTrace("middleRow: mixer layout constructed");
        mixerLayout->setContentsMargins(3, 3, 3, 2);
        mixerLayout->setHorizontalSpacing(2);
        mixerLayout->setVerticalSpacing(0);
        const std::array<int, 16> mixerStartValues = {74, 80, 53, 83, 36, 78, 50, 65, 72, 43, 82, 57, 70, 64, 52, 88};
        for (int i = 0; i < 20; ++i) {
            startupTrace((std::string("middleRow: before mixer lane ") + std::to_string(i)).c_str());
            auto *slider = new QSlider(Qt::Vertical, mixerPanel);
            channelMixerSliders_[static_cast<std::size_t>(i)] = slider;
            slider->setRange(0, 127);
            slider->setMinimumWidth(10);
            slider->setMinimumHeight(65);
            slider->setValue(i < 16 ? mixerStartValues[static_cast<std::size_t>(i)] : 75);
            slider->setToolTip(i < 16 ? QStringLiteral("Style MIDI channel %1 volume (CC7)").arg(i + 1)
                : i < 19 ? QStringLiteral("Volume voice %1 (internal channel)").arg(i == 16 ? QStringLiteral("L") : i == 17 ? QStringLiteral("R1") : QStringLiteral("R2"))
                         : QStringLiteral("Sampler lane is unavailable until sample playback is ported."));
            if (i < 16) {
                connect(slider, &QSlider::valueChanged, this, [this, i](int value) {
                    sendMidi(static_cast<quint8>(0xB0 | i), 7, static_cast<quint8>(std::clamp(value, 0, 127)), i);
                });
            } else if (i < 19) {
                const int slot = i == 16 ? 1 : (i == 17 ? 0 : 2);
                connect(slider, &QSlider::valueChanged, this, [this, slot](int value) {
                    sendMidi(static_cast<quint8>(0xB0 | slot), 7, static_cast<quint8>(std::clamp(value, 0, 127)), internalVoiceChannel(slot));
                });
            } else {
                slider->setEnabled(false);
            }
            mixerLayout->addWidget(slider, 0, i, 1, 1, Qt::AlignHCenter);
            const QString lane = i < 16 ? QString::number(i + 1) : (i == 16 ? QStringLiteral("L") : i == 17 ? QStringLiteral("R1") : i == 18 ? QStringLiteral("R2") : QStringLiteral("SP"));
            auto *label = new QLabel(lane, mixerPanel);
            label->setAlignment(Qt::AlignCenter);
            label->setStyleSheet(QStringLiteral("font-size:7pt;color:#aaaaaa"));
            mixerLayout->addWidget(label, 1, i);
            auto *lock = new QPushButton(QStringLiteral("♙"), mixerPanel);
            lock->setObjectName(QStringLiteral("flatButton"));
            lock->setFixedHeight(16);
            lock->setToolTip(i < 16 ? QStringLiteral("Kunci level jalur MIDI ini" ) : QStringLiteral("Lock gain voice terpisah belum ported"));
            if (i < 19) {
                lock->setCheckable(true);
                connect(lock, &QPushButton::toggled, slider, [slider](bool checked) { slider->setEnabled(!checked); });
            } else lock->setEnabled(false);
            mixerLayout->addWidget(lock, 2, i);
            mixerLayout->setColumnStretch(i, 1);
            startupTrace((std::string("middleRow: mixer lane complete ") + std::to_string(i)).c_str());
        }
        startupTrace("middleRow: all mixer lanes built");
        middleLayout->addWidget(mixerPanel, 37);
        startupTrace("middleRow: mixer panel added to layout");

        startupTrace("middleRow: before pads panel");
        auto *padsPanel = makePanel(middleRow);
        startupTrace("middleRow: pads panel constructed");
        auto *padsLayout = new QVBoxLayout(padsPanel);
        padsLayout->setContentsMargins(4, 3, 4, 3);
        padsLayout->setSpacing(2);
        auto *padTitle = makeCaption(QStringLiteral("PERCUSSION TRIGGERS · GM notes"), padsPanel);
        padsLayout->addWidget(padTitle);
        auto *padGrid = new QGridLayout;
        padGrid->setContentsMargins(0, 0, 0, 0);
        padGrid->setHorizontalSpacing(3);
        padGrid->setVerticalSpacing(3);
        const std::array<std::pair<const char *, int>, 12> padNotes = {{{"Kick",36},{"Snare",38},{"Closed Hat",42},{"Open Hat",46},{"Low Tom",45},{"Mid Tom",47},{"High Tom",50},{"Crash",49},{"Ride",51},{"Clap",39},{"Side Stick",37},{"Cowbell",56}}};
        for (int i = 0; i < static_cast<int>(padNotes.size()); ++i) {
            startupTrace((std::string("middleRow: before pad ") + std::to_string(i)).c_str());
            auto *pad = new QPushButton(QString::fromUtf8(padNotes[static_cast<std::size_t>(i)].first), padsPanel);
            pad->setToolTip(QStringLiteral("Kirim nada drum GM %1 (note %2). Ini pemicu MIDI, bukan playback file sampel.")
                .arg(QString::fromUtf8(padNotes[static_cast<std::size_t>(i)].first)).arg(padNotes[static_cast<std::size_t>(i)].second));
            pad->setMinimumHeight(25);
            pad->setStyleSheet(QStringLiteral("QPushButton{font-size:7pt;font-weight:600;padding:0;background:#555;border:1px solid #262626;color:#eee;} QPushButton:pressed{background:#176c63;border:1px solid #71c1b4;}"));
            const int note = padNotes[static_cast<std::size_t>(i)].second;
            connect(pad, &QPushButton::clicked, this, [this, note] { triggerDrum(note); });
            padGrid->addWidget(pad, i / 6, i % 6);
            startupTrace((std::string("middleRow: pad complete ") + std::to_string(i)).c_str());
        }
        startupTrace("middleRow: all pads built");
        auto *padRecord = new QPushButton(QStringLiteral("MIDI Rec"), padsPanel);
        padRecord->setObjectName(QStringLiteral("redAction"));
        padRecord->setToolTip(QStringLiteral("Buka perekam event MIDI; perekam sampel audio belum tersedia."));
        connect(padRecord, &QPushButton::clicked, recorderDialog_, &QDialog::show);
        padGrid->addWidget(padRecord, 0, 6);
        auto *padFolder = new QPushButton(QStringLiteral("Open MIDI"), padsPanel);
        padFolder->setObjectName(QStringLiteral("blueAction"));
        padFolder->setToolTip(QStringLiteral("Pilih berkas MIDI untuk diputar; bukan muat sampel pad."));
        connect(padFolder, &QPushButton::clicked, this, [this] { loadMidi(); });
        padGrid->addWidget(padFolder, 1, 6);
        auto *padStop = new QPushButton(QStringLiteral("Stop"), padsPanel);
        padStop->setToolTip(QStringLiteral("All Sounds Off"));
        connect(padStop, &QPushButton::clicked, this, [this] { allSoundsOff(); });
        padGrid->addWidget(padStop, 0, 7, 2, 1);
        padsLayout->addLayout(padGrid, 1);
        middleLayout->addWidget(padsPanel, 32);
        middleRow->setFixedHeight(116);
        startupTrace("middleRow: before adding middle row to root");
        root->addWidget(middleRow);
        startupTrace("middleRow: added middle row to root");

        // Original-style section/transport strip. Section buttons are independent from Start/Stop.
        startupTrace("transport: before panel construction");
        auto *transport = makePanel(central);
        startupTrace("transport: panel constructed");
        transport->setFixedHeight(56);
        auto *transportLayout = new QHBoxLayout(transport);
        transportLayout->setContentsMargins(3, 3, 3, 2);
        transportLayout->setSpacing(3);
        auto addSection = [&](const QString &caption, const std::vector<QString> &labels, QWidget *parent,
                              const std::function<void(int)> &clicked) {
            auto *section = new QWidget(parent);
            auto *vertical = new QVBoxLayout(section);
            vertical->setContentsMargins(0, 0, 0, 0);
            vertical->setSpacing(1);
            auto *buttons = new QHBoxLayout;
            buttons->setContentsMargins(0, 0, 0, 0);
            buttons->setSpacing(2);
            for (int i = 0; i < static_cast<int>(labels.size()); ++i) {
                auto *b = new QPushButton(labels[static_cast<std::size_t>(i)], section);
                b->setMinimumWidth(27);
                b->setFixedHeight(27);
                connect(b, &QPushButton::clicked, section, [clicked, i] { clicked(i); });
                buttons->addWidget(b, 1);
            }
            vertical->addLayout(buttons);
            auto *label = new QLabel(caption, section);
            label->setObjectName(QStringLiteral("sectionLabel"));
            label->setAlignment(Qt::AlignCenter);
            vertical->addWidget(label);
            return section;
        };
        startupTrace("transport: before INTRO section");
        transportLayout->addWidget(addSection(QStringLiteral("INTRO"), {QStringLiteral("1"), QStringLiteral("2")}, transport,
            [this](int i) { if (styleEngine_.hasStyle()) styleEngine_.queueIntro(i == 0 ? 1 : 2, i == 0 ? 2 : 3); else setStatus(QStringLiteral("Pilih style terlebih dahulu.")); }), 1);
        startupTrace("transport: INTRO section complete");
        transportLayout->addWidget(addSection(QStringLiteral("VARIATION / FILL-IN"), {QStringLiteral("A"), QStringLiteral("B"), QStringLiteral("C"), QStringLiteral("D"), QStringLiteral("Break")}, transport,
            [this](int i) { if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih style terlebih dahulu.")); return; }
                if (i == 4) styleEngine_.breakPlay(); else { const int starts[] = {3, 5, 7, 9}; const int ends[] = {4, 6, 8, 10}; styleEngine_.playLoop(starts[i], ends[i]); } }), 2);
        startupTrace("transport: variation section complete");
        transportLayout->addWidget(addSection(QStringLiteral("ENDING"), {QStringLiteral("1"), QStringLiteral("2")}, transport,
            [this](int i) { if (styleEngine_.hasStyle()) styleEngine_.queueEnding(i == 0 ? 11 : 13, i == 0 ? 12 : 14); else setStatus(QStringLiteral("Pilih style terlebih dahulu.")); }), 1);
        startupTrace("transport: ending section complete");
        auto *syncSection = new QWidget(transport);
        auto *syncLayout = new QVBoxLayout(syncSection);
        syncLayout->setContentsMargins(0, 0, 0, 0); syncLayout->setSpacing(1);
        auto *syncButtons = new QHBoxLayout; syncButtons->setContentsMargins(0, 0, 0, 0); syncButtons->setSpacing(2);
        auto *syncStart = new QPushButton(QStringLiteral("Sync Start"), syncSection);
        auto *syncStop = new QPushButton(QStringLiteral("Sync Stop"), syncSection);
        syncStart->setFixedHeight(27); syncStop->setFixedHeight(27);
        connect(syncStart, &QPushButton::clicked, this, [this] { if (styleEngine_.hasStyle()) { styleEngine_.syncStart(); setStatus(QStringLiteral("Sync Start siap: tekan chord di wilayah kiri keyboard.")); } else setStatus(QStringLiteral("Pilih style terlebih dahulu.")); });
        connect(syncStop, &QPushButton::clicked, this, [this] { styleEngine_.syncStop(); setStatus(QStringLiteral("Sync Stop dijadwalkan oleh Style Engine.")); });
        syncButtons->addWidget(syncStart, 1); syncButtons->addWidget(syncStop, 1);
        syncLayout->addLayout(syncButtons);
        auto *syncLabel = makeCaption(QStringLiteral("SYNC"), syncSection); syncLabel->setAlignment(Qt::AlignCenter); syncLayout->addWidget(syncLabel);
        transportLayout->addWidget(syncSection, 2);
        auto *startStop = new QPushButton(QStringLiteral("▶"), transport);
        startStop->setObjectName(QStringLiteral("transportPlay"));
        startStop->setFixedSize(62, 28);
        startStop->setToolTip(QStringLiteral("Start/Stop arranger — separate from section selection"));
        connect(startStop, &QPushButton::clicked, this, [this] {
            if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih style terlebih dahulu.")); return; }
            styleEngine_.togglePlay();
        });
        transportLayout->addWidget(startStop);
        auto *bankPanel = makePanel(transport);
        auto *bankLayout = new QVBoxLayout(bankPanel);
        bankLayout->setContentsMargins(3, 1, 3, 0); bankLayout->setSpacing(1);
        auto *bankButtons = new QHBoxLayout; bankButtons->setContentsMargins(0, 0, 0, 0); bankButtons->setSpacing(2);
        auto *bankPrev = new QPushButton(QStringLiteral("−"), bankPanel);
        registryBankLabel_ = new QLabel(QStringLiteral("1"), bankPanel);
        registryBankLabel_->setAlignment(Qt::AlignCenter);
        registryBankLabel_->setStyleSheet(QStringLiteral("color:#eeeeee;font-weight:700;background:#242424;border:1px solid #141414;"));
        auto *bankNext = new QPushButton(QStringLiteral("+"), bankPanel);
        bankPrev->setToolTip(QStringLiteral("Registration bank sebelumnya"));
        bankNext->setToolTip(QStringLiteral("Registration bank berikutnya"));
        connect(bankPrev, &QPushButton::clicked, this, [this] { setRegistryBank(currentRegistryBank_ - 1); });
        connect(bankNext, &QPushButton::clicked, this, [this] { setRegistryBank(currentRegistryBank_ + 1); });
        bankButtons->addWidget(bankPrev); bankButtons->addWidget(registryBankLabel_, 1); bankButtons->addWidget(bankNext);
        bankLayout->addLayout(bankButtons);
        auto *bankCaption = makeCaption(QStringLiteral("BANK"), bankPanel); bankCaption->setAlignment(Qt::AlignCenter); bankLayout->addWidget(bankCaption);
        transportLayout->addWidget(bankPanel, 1);
        auto *registry = new QWidget(transport);
        auto *registryLayout = new QVBoxLayout(registry);
        registryLayout->setContentsMargins(0, 0, 0, 0); registryLayout->setSpacing(1);
        auto *registryButtons = new QHBoxLayout; registryButtons->setContentsMargins(0, 0, 0, 0); registryButtons->setSpacing(2);
        for (int i = 0; i < static_cast<int>(registryButtons_.size()); ++i) {
            auto *b = new QPushButton(QString::number(i + 1), registry);
            b->setFixedHeight(27); b->setMinimumWidth(20);
            registryButtons_[static_cast<std::size_t>(i)] = b;
            connect(b, &QPushButton::clicked, this, [this, i] { activateRegistrySlot(i); });
            registryButtons->addWidget(b, 1);
        }
        registryMemorizeButton_ = new QPushButton(QStringLiteral("Memorize"), registry);
        registryMemorizeButton_->setCheckable(true);
        registryMemorizeButton_->setFixedHeight(27);
        registryMemorizeButton_->setToolTip(QStringLiteral("Aktifkan lalu pilih slot 1–10 untuk menyimpan keadaan panel sekarang."));
        connect(registryMemorizeButton_, &QPushButton::toggled, this, [this](bool on) {
            registryMemorizeMode_ = on;
            registryMemorizeButton_->setText(on ? QStringLiteral("Memorize ON") : QStringLiteral("Memorize"));
            setStatus(on ? QStringLiteral("Mode Memorize aktif — pilih slot registrasi untuk menyimpan keadaan saat ini.")
                         : QStringLiteral("Mode Memorize nonaktif — slot yang ada akan dipanggil."));
        });
        registryButtons->addWidget(registryMemorizeButton_);
        registryLayout->addLayout(registryButtons);
        auto *registryLabel = makeCaption(QStringLiteral("REGISTRY MEMORY"), registry); registryLabel->setAlignment(Qt::AlignCenter);
        registryLayout->addWidget(registryLabel);
        transportLayout->addWidget(registry, 4);
        startupTrace("transport: registry section complete");
        root->addWidget(transport);
        startupTrace("transport: added to root");

        startupTrace("buildUi: LCD and side panels complete; building keyboard deck");
        // Keyboard deck: left joystick assignment well, toolbar, and a live five-octave piano.
        auto *keyboardDeck = new QWidget(central);
        auto *keyboardDeckLayout = new QHBoxLayout(keyboardDeck);
        keyboardDeckLayout->setContentsMargins(0, 0, 0, 0);
        keyboardDeckLayout->setSpacing(3);
        auto *joystickWell = makePanel(keyboardDeck);
        joystickWell->setFixedWidth(145);
        auto *joystickLayout = new QVBoxLayout(joystickWell);
        joystickLayout->setContentsMargins(3, 3, 3, 3);
        joystickLayout->setSpacing(3);
        auto *xyRow = new QHBoxLayout;
        joystickXAssignButton_ = new QPushButton(QStringLiteral("X-Assign"), joystickWell);
        joystickYAssignButton_ = new QPushButton(QStringLiteral("Y-Assign"), joystickWell);
        joystickXAssignButton_->setFixedHeight(23); joystickYAssignButton_->setFixedHeight(23);
        connect(joystickXAssignButton_, &QPushButton::clicked, this, [this] { configureControlMapping(14, QStringLiteral("Joystick X")); });
        connect(joystickYAssignButton_, &QPushButton::clicked, this, [this] { configureControlMapping(15, QStringLiteral("Joystick Y")); });
        xyRow->addWidget(joystickXAssignButton_); xyRow->addWidget(joystickYAssignButton_);
        joystickLayout->addLayout(xyRow);
        joystickPad_ = new JoystickPadWidget(joystickWell);
        joystickPad_->setChangedCallback([this](int x, int y) {
            handleAssignableControlValue(14, x);
            handleAssignableControlValue(15, y);
        });
        joystickLayout->addWidget(joystickPad_, 1);
        keyboardDeckLayout->addWidget(joystickWell);

        auto *keyboardRight = new QWidget(keyboardDeck);
        auto *keyboardRightLayout = new QVBoxLayout(keyboardRight);
        keyboardRightLayout->setContentsMargins(0, 0, 0, 0);
        keyboardRightLayout->setSpacing(0);
        auto *keyboardToolbar = new QWidget(keyboardRight);
        keyboardToolbar->setFixedHeight(28);
        keyboardToolbar->setStyleSheet(QStringLiteral("background:#303030;border:1px solid #0a0a0a;"));
        auto *toolbarLayout = new QHBoxLayout(keyboardToolbar);
        toolbarLayout->setContentsMargins(6, 1, 4, 1);
        toolbarLayout->setSpacing(5);
        statusLabel_ = new QLabel(QString(), keyboardToolbar);
        statusLabel_->setObjectName(QStringLiteral("sectionLabel"));
        statusLabel_->setMinimumWidth(0);
        statusLabel_->setMaximumWidth(330);
        statusLabel_->setToolTip(QStringLiteral("Status and migration limitations are shown here."));
        statusLabel_->hide();
        toolbarLayout->addWidget(statusLabel_);
        toolbarLayout->addStretch(1);
        auto *holdLabel = makeCaption(QStringLiteral("H O L D"), keyboardToolbar);
        toolbarLayout->addWidget(holdLabel);
        auto *holdSwitch = new QCheckBox(keyboardToolbar);
        holdSwitch->setToolTip(QStringLiteral("Hold/sustain: mengirim MIDI CC64 ke voice aktif dan perangkat MIDI."));
        connect(holdSwitch, &QCheckBox::toggled, this, [this](bool on) {
            for (int slot : {0, 1, 2})
                sendMidi(static_cast<quint8>(0xB0 | slot), 64, on ? 127 : 0, internalVoiceChannel(slot));
            setStatus(on ? QStringLiteral("Hold aktif (MIDI sustain CC64=127).")
                         : QStringLiteral("Hold nonaktif (MIDI sustain CC64=0)."));
        });
        toolbarLayout->addWidget(holdSwitch);
        auto *zoomLabel = makeCaption(QStringLiteral("Z O O M"), keyboardToolbar);
        toolbarLayout->addWidget(zoomLabel);
        auto *zoomSwitch = new QCheckBox(keyboardToolbar);
        zoomSwitch->setToolTip(QStringLiteral("Zooms the five-octave keyboard and enables horizontal scrolling."));
        toolbarLayout->addWidget(zoomSwitch);
        auto *sustainButton = new QPushButton(QStringLiteral("SUST"), keyboardToolbar);
        auto *keyStopButton = new QPushButton(QStringLiteral("STOP"), keyboardToolbar);
        sustainButton->setFixedHeight(23); keyStopButton->setFixedHeight(23);
        sustainButton->setToolTip(QStringLiteral("FluidSynth sustain pedal CC64; also forwarded when hardware MIDI is enabled"));
        connect(sustainButton, &QPushButton::pressed, this, [this] {
            for (int slot : {0, 1, 2}) sendMidi(static_cast<quint8>(0xB0 | slot), 64, 127, internalVoiceChannel(slot));
        });
        connect(sustainButton, &QPushButton::released, this, [this] {
            for (int slot : {0, 1, 2}) sendMidi(static_cast<quint8>(0xB0 | slot), 64, 0, internalVoiceChannel(slot));
        });
        connect(keyStopButton, &QPushButton::clicked, this, [this] { allSoundsOff(); });
        toolbarLayout->addWidget(sustainButton); toolbarLayout->addWidget(keyStopButton);
        keyboardRightLayout->addWidget(keyboardToolbar);
        auto *keyboardScroller = new QScrollArea(keyboardRight);
        keyboardScroller->setFrameShape(QFrame::NoFrame);
        keyboardScroller->setWidgetResizable(true);
        keyboardScroller->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        keyboardScroller->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        pianoKeyboard_ = new PianoKeyboardWidget;
        pianoKeyboard_->setBaseNote(baseNote_);
        pianoKeyboard_->setNoteCallback([this](int note, bool pressed) { onKeyboardNote(note, pressed); });
        pianoKeyboard_->setSplitKey(splitKey_);
        pianoKeyboard_->setSplitKeyCallback([this](int note) {
            splitKey_ = std::clamp(note, 36, 95);
            if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
            QSettings settings; settings.setValue(QStringLiteral("panel/splitKey"), splitKey_); settings.sync();
            setStatus(QStringLiteral("Split key dipindahkan ke %1 (%2). Pengaturan disimpan.")
                .arg(splitKey_).arg(QString::fromUtf8(kNoteNames[static_cast<std::size_t>(splitKey_ % 12)])));
        });
        keyboardScroller->setWidget(pianoKeyboard_);
        connect(zoomSwitch, &QCheckBox::toggled, this, [this, keyboardScroller](bool zoomed) {
            if (zoomed) {
                keyboardScroller->setWidgetResizable(false);
                pianoKeyboard_->setMinimumWidth(3200); // Same virtual width as original KeyBed::toggle_zoom.
                pianoKeyboard_->resize(3200, std::max(125, keyboardScroller->viewport()->height()));
            } else {
                pianoKeyboard_->setMinimumWidth(0);
                keyboardScroller->setWidgetResizable(true);
                pianoKeyboard_->resize(keyboardScroller->viewport()->size());
            }
        });
        keyboardRightLayout->addWidget(keyboardScroller, 1);
        keyboardDeckLayout->addWidget(keyboardRight, 1);
        root->addWidget(keyboardDeck, 1);

        // The original app uses a custom chrome without a conventional status bar.
        startupTrace("buildUi: before setCentralWidget / event filters");
        statusBar()->hide();
        setCentralWidget(central);
        central->installEventFilter(this);
        for (QWidget *child : central->findChildren<QWidget *>()) child->installEventFilter(this);
        startupTrace("buildUi: complete");
    }

    static bool isValidSoundFontFile(const QString &path) {
        if (path.isEmpty()) return false;
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly)) return false;
        const QByteArray header = file.read(12);
        return header.size() == 12 && header.left(4) == QByteArrayLiteral("RIFF")
            && header.mid(8, 4) == QByteArrayLiteral("sfbk");
    }

    QString discoverSoundFont() const {
        if (isValidSoundFontFile(soundFontPath_)) return soundFontPath_;
        const QString appDir = QCoreApplication::applicationDirPath();
        // Prefer the original bank if a real file is installed; this checkout's
        // EnsemblesGM file is a Git-LFS pointer, so fall through to the bundled GPL fallback.
        const QStringList candidates = {
            QDir(appDir).filePath(QStringLiteral("data/SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("data/SoundFonts/TimGM6mb.sf2")),
            QDir(appDir).filePath(QStringLiteral("SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("SoundFonts/TimGM6mb.sf2")),
            QDir(appDir).filePath(QStringLiteral("../data/SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("../data/SoundFonts/TimGM6mb.sf2")),
            QDir(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation))
                .filePath(QStringLiteral("ensembles/SoundFonts/EnsemblesGM.sf2")),
            QDir(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation))
                .filePath(QStringLiteral("ensembles/SoundFonts/TimGM6mb.sf2"))
        };
        for (const QString &candidate : candidates)
            if (isValidSoundFontFile(candidate)) return candidate;
        return QString();
    }

    bool wantsInternalAudioOutput() const {
        // A loaded internal instrument (VST2 included) must always receive MIDI,
        // even if the saved route from a previous session was Windows MIDI only.
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isVst2PluginLoaded()) return true;
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        if (route == QStringLiteral("fluid") || route == QStringLiteral("both")) return true;
        return route == QStringLiteral("auto") && audioEngine_ && audioEngine_->isReady();
    }

    bool wantsWindowsMidiOutput() const {
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        // If VST2 is selected, a stale WinMM-only setting must not bypass it.
        if (audioEngine_ && audioEngine_->isVst2PluginLoaded() && route == QStringLiteral("winmm")) return false;
        if (route == QStringLiteral("winmm") || route == QStringLiteral("both")) return true;
        return route == QStringLiteral("auto") && !(audioEngine_ && audioEngine_->isReady());
    }

    RtAudio::Api selectedRtAudioApi() const {
        if (!audioApiCombo_) return RtAudio::UNSPECIFIED;
        return static_cast<RtAudio::Api>(audioApiCombo_->currentData().toInt());
    }

    std::optional<unsigned int> selectedRtAudioDeviceId() const {
        if (!audioDeviceCombo_) return std::nullopt;
        bool ok = false;
        const qlonglong value = audioDeviceCombo_->currentData().toLongLong(&ok);
        if (!ok || value < 0 || static_cast<qulonglong>(value) > std::numeric_limits<unsigned int>::max())
            return std::nullopt;
        return static_cast<unsigned int>(value);
    }

    unsigned int selectedRtAudioSampleRate() const {
        return audioSampleRateCombo_ ? std::max(8000u, audioSampleRateCombo_->currentData().toUInt()) : 44100u;
    }

    unsigned int selectedRtAudioBufferFrames() const {
        return audioBufferCombo_ ? static_cast<unsigned int>(std::max(64, audioBufferCombo_->currentData().toInt())) : 256u;
    }

    void refreshAudioOutputDevices(qint64 preferredId) {
        if (!audioDeviceCombo_) return;
        const QSignalBlocker blocker(audioDeviceCombo_);
        audioDeviceCombo_->clear();
        audioDeviceCombo_->addItem(QStringLiteral("System default output device"), QVariant::fromValue<qlonglong>(-1));
        audioOutputDevices_ = ensembles::AudioEngine::availableOutputDevices(selectedRtAudioApi());
        for (const auto &device : audioOutputDevices_) {
            QString label = QString::fromUtf8(device.name.c_str());
            if (device.isDefaultOutput) label += QStringLiteral("  (system default)");
            label += QStringLiteral("  ·  %1 channels").arg(device.outputChannels);
            audioDeviceCombo_->addItem(label, QVariant::fromValue<qulonglong>(device.id));
        }
        int selectedIndex = 0;
        if (preferredId >= 0) {
            const int match = audioDeviceCombo_->findData(QVariant::fromValue<qulonglong>(static_cast<qulonglong>(preferredId)));
            if (match >= 0) selectedIndex = match;
        }
        audioDeviceCombo_->setCurrentIndex(selectedIndex);
        if (audioOutputDevices_.empty()) {
            audioDeviceCombo_->setItemText(0, QStringLiteral("No stereo output device found for this API"));
            audioDeviceCombo_->setEnabled(false);
        } else {
            audioDeviceCombo_->setEnabled(true);
        }
    }

    void refreshAudioSampleRates(unsigned int preferredRate) {
        if (!audioSampleRateCombo_) return;
        std::vector<unsigned int> rates;
        std::optional<unsigned int> wantedId = selectedRtAudioDeviceId();
        const ensembles::AudioEngine::OutputDevice *selected = nullptr;
        if (wantedId) {
            for (const auto &d : audioOutputDevices_) if (d.id == *wantedId) { selected = &d; break; }
        } else {
            for (const auto &d : audioOutputDevices_) if (d.isDefaultOutput) { selected = &d; break; }
            if (!selected && !audioOutputDevices_.empty()) selected = &audioOutputDevices_.front();
        }
        if (selected) {
            for (const unsigned int rate : selected->sampleRates) {
                if (rate >= 8000 && rate <= 192000 &&
                    std::find(rates.begin(), rates.end(), rate) == rates.end()) rates.push_back(rate);
            }
        }
        if (rates.empty()) rates = {22050, 32000, 44100, 48000, 88200, 96000};
        std::sort(rates.begin(), rates.end());
        const QSignalBlocker blocker(audioSampleRateCombo_);
        audioSampleRateCombo_->clear();
        for (const unsigned int rate : rates)
            audioSampleRateCombo_->addItem(QStringLiteral("%1 Hz").arg(rate), rate);
        int index = audioSampleRateCombo_->findData(preferredRate);
        if (index < 0) index = audioSampleRateCombo_->findData(44100u);
        if (index < 0) index = 0;
        audioSampleRateCombo_->setCurrentIndex(index);
    }

    void persistAudioOutputSettings() {
        QSettings settings;
        settings.setValue(QStringLiteral("audio/rtaudioApi"), static_cast<int>(selectedRtAudioApi()));
        const auto device = selectedRtAudioDeviceId();
        settings.setValue(QStringLiteral("audio/outputDeviceId"), device ? static_cast<qint64>(*device) : qint64(-1));
        settings.setValue(QStringLiteral("audio/sampleRate"), selectedRtAudioSampleRate());
        settings.setValue(QStringLiteral("audio/bufferFrames"), selectedRtAudioBufferFrames());
        settings.sync();
    }

    void applyAudioOutputSettings() {
        if (!audioSettingsReady_) return;
        if (soundFontPath_.isEmpty()) {
            persistAudioOutputSettings();
            if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Pilihan audio disimpan. Pilih SoundFont SF2 yang valid untuk membuka stream RtAudio."));
            return;
        }
        if (!audioEngine_ || !audioEngine_->isReady()) {
            QString error;
            if (loadSoundFont(soundFontPath_, false, &error)) {
                persistAudioOutputSettings();
            } else {
                persistAudioOutputSettings();
                if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Belum ada stream aktif. Gagal mengaktifkan pilihan RtAudio: %1").arg(error));
            }
            return;
        }

        const RtAudio::Api oldApi = audioEngine_->outputApi();
        const unsigned int oldDevice = audioEngine_->outputDeviceId();
        const unsigned int oldRate = audioEngine_->sampleRate();
        const unsigned int oldFrames = audioEngine_->bufferFrames();
        QString error;
        if (!loadSoundFont(soundFontPath_, false, &error)) {
            audioSettingsReady_ = false;
            const int apiIndex = audioApiCombo_->findData(static_cast<int>(oldApi));
            audioApiCombo_->setCurrentIndex(apiIndex >= 0 ? apiIndex : 0);
            refreshAudioOutputDevices(static_cast<qint64>(oldDevice));
            refreshAudioSampleRates(oldRate);
            int rateIndex = audioSampleRateCombo_->findData(oldRate);
            if (rateIndex >= 0) audioSampleRateCombo_->setCurrentIndex(rateIndex);
            int frameIndex = audioBufferCombo_->findData(static_cast<int>(oldFrames));
            if (frameIndex >= 0) audioBufferCombo_->setCurrentIndex(frameIndex);
            audioSettingsReady_ = true;
            if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Perubahan gagal diterapkan; output lama tetap aktif. %1").arg(error));
            return;
        }
        persistAudioOutputSettings();
    }

    void updateAudioOutputStatus() {
        if (!audioOutputStatusLabel_) return;
        if (!audioEngine_ || !audioEngine_->isReady()) {
            audioOutputStatusLabel_->setText(QStringLiteral("RtAudio tidak aktif. Periksa SoundFont dan pilihan perangkat."));
            return;
        }
        const QString apiName = QString::fromUtf8(RtAudio::getApiDisplayName(audioEngine_->outputApi()).c_str());
        audioOutputStatusLabel_->setText(QStringLiteral("Aktif: %1 · %2 · %3 Hz · buffer %4 frames (%5 ms per buffer, perkiraan)")
            .arg(QString::fromUtf8(audioEngine_->outputDeviceName().c_str()), apiName)
            .arg(audioEngine_->sampleRate()).arg(audioEngine_->bufferFrames())
            .arg(1000.0 * audioEngine_->bufferFrames() / std::max(1u, audioEngine_->sampleRate()), 0, 'f', 1));
    }

    QString discoverBundledVst2Plugin() const {
        const QString appDir = QCoreApplication::applicationDirPath();
        QStringList candidates;
        // A previously selected user-owned plugin takes priority if it still exists.
        if (!vst2PluginPath_.isEmpty() && QFileInfo(vst2PluginPath_).isFile())
            candidates << vst2PluginPath_;
        // Portable SCVA layout: keep its companion DLLs and data files beside its main DLL.
        candidates << QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("Plugins/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("Plugins/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA.dll"));
        for (const QString &candidate : candidates) {
            const QFileInfo info(candidate);
            if (info.isFile() && info.isReadable()) return info.absoluteFilePath();
        }
        return QString();
    }

    void initializeAudioEngine() {
        // --scva-native-required (or ENSEMBLES_SCVA_NATIVE_REQUIRED=1) is a strict
        // validation mode: native failure stays silent and visible; it must never
        // hide the failure behind a VST2 or FluidSynth fallback.
        std::vector<std::string> startupArguments;
        const QStringList qtArguments = QCoreApplication::arguments();
        startupArguments.reserve(static_cast<std::size_t>(qtArguments.size()));
        for (const QString &argument : qtArguments)
            startupArguments.push_back(argument.toStdString());
        const bool nativeRequired = ensembles::scvaNativeRequired(
            startupArguments, qgetenv("ENSEMBLES_SCVA_NATIVE_REQUIRED").toStdString());

        // Try the in-process C++ SCVA engine first. The embedded SCCore.dll is
        // read as a data image by NativeTS, never loaded as executable code.
        const QString scvaPath = discoverBundledVst2Plugin();
        const QString fallbackSoundFont = isValidSoundFontFile(soundFontPath_)
            ? soundFontPath_ : discoverSoundFont();
        QString nativeScvaFailure;
#if ENSEMBLES_HAS_NATIVE_SCVA
        QFile embeddedCore(QStringLiteral(":/SCVA/SCCore.dll"));
        if (!embeddedCore.open(QIODevice::ReadOnly)) {
            nativeScvaFailure = QStringLiteral("Embedded resource :/SCVA/SCCore.dll could not be opened.");
        } else {
            const QByteArray coreBlob = embeddedCore.readAll();
            QString audioError;
            if (ensureAudioEngineForVst2(fallbackSoundFont, &audioError)) {
                std::vector<std::uint8_t> coreBytes(
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData()),
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData() + coreBlob.size()));
                std::string nativeError;
                if (audioEngine_->loadNativeScvaFromMemory(std::move(coreBytes), &nativeError)) {
                    soundFontPath_ = fallbackSoundFont; // retained only as a user fallback path
                    vst2PluginPath_.clear();
                    QSettings settings;
                    settings.setValue(QStringLiteral("audio/vst2PluginPath"), QString());
                    settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                    settings.sync();
                    setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                    applyPanelMidiSettings();
                    applyNativeEfxSettings(true);
                    updateAudioOutputStatus();
                    updateOutputStatus();
                    if (vst2PluginStatusLabel_)
                        vst2PluginStatusLabel_->setText(QStringLiteral("SCVA aktif sebagai native C++ engine (NativeTS); VST tidak digunakan."));
                    if (soundFontStatusLabel_)
                        soundFontStatusLabel_->setText(QStringLiteral("SCCore.dll tertanam sebagai data di executable; suara dirender oleh native C++ engine."));
                    setStatus(QStringLiteral("Native SCVA aktif; Voice/Style mengirim MIDI langsung ke engine C++ tertanam."));
                    return;
                }
                nativeScvaFailure = QString::fromUtf8(nativeError.data(), static_cast<qsizetype>(nativeError.size()));
            } else {
                nativeScvaFailure = audioError;
            }
        }
#endif

        if (!ensembles::scvaVst2FallbackAllowed(nativeRequired)) {
            const QString detail = nativeScvaFailure.isEmpty()
                ? QStringLiteral("Native SCVA tidak aktif dan mode native wajib sedang aktif.")
                : nativeScvaFailure;
            if (vst2PluginStatusLabel_)
                vst2PluginStatusLabel_->setText(QStringLiteral("MODE NATIVE WAJIB: VST2 dinonaktifkan. %1").arg(detail));
            if (soundFontStatusLabel_)
                soundFontStatusLabel_->setText(QStringLiteral("Native SCVA gagal; fallback VST2 dan FluidSynth sengaja tidak dijalankan."));
            setStatus(QStringLiteral("SCVA native diwajibkan tetapi gagal diaktifkan: %1").arg(detail));
            updateAudioOutputStatus();
            updateOutputStatus();
            return;
        }

        // Automatic mode only: if native initialization fails, the exact SCVA
        // instrument may be loaded through VST2. Strict native-required mode has
        // already returned above, before any VST2/FluidSynth fallback call.
        QString scvaFailure = nativeScvaFailure;
        if (!scvaPath.isEmpty()) {
            QString audioError;
            if (ensureAudioEngineForVst2(fallbackSoundFont, &audioError)) {
                std::string pluginError;
                const QByteArray pluginBytes = QDir::toNativeSeparators(scvaPath).toUtf8();
                if (audioEngine_->loadVst2Plugin(pluginBytes.constData(), &pluginError)) {
                    vst2PluginPath_ = scvaPath;
                    soundFontPath_ = fallbackSoundFont; // retained as a fallback path; not loaded into this engine
                    QSettings settings;
                    settings.setValue(QStringLiteral("audio/vst2PluginPath"), vst2PluginPath_);
                    settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                    if (audioRoutingCombo_ && audioRoutingCombo_->currentData().toString() == QStringLiteral("winmm")) {
                        const QSignalBlocker blocker(audioRoutingCombo_);
                        const int internalRoute = audioRoutingCombo_->findData(QStringLiteral("fluid"));
                        if (internalRoute >= 0) audioRoutingCombo_->setCurrentIndex(internalRoute);
                        settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_->currentData().toString());
                    }
                    settings.sync();
                    setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                    applyPanelMidiSettings();
                    updateAudioOutputStatus();
                    updateOutputStatus();
                    if (nativeScvaFailure.isEmpty()) {
                        if (vst2PluginStatusLabel_)
                            vst2PluginStatusLabel_->setText(QStringLiteral("SCVA dimuat otomatis: %1").arg(QFileInfo(scvaPath).fileName()));
                        if (soundFontStatusLabel_)
                            soundFontStatusLabel_->setText(QStringLiteral("SCVA aktif melalui host VST2 internal. SoundFont disimpan sebagai fallback dan tidak dirender."));
                        setStatus(QStringLiteral("SCVA dimuat otomatis ke host internal; Voice/Style diarahkan ke SCVA."));
                    } else {
                        if (vst2PluginStatusLabel_)
                            vst2PluginStatusLabel_->setText(QStringLiteral("Native SCVA belum aktif; SCVA asli berjalan melalui VST2. Native: %1").arg(nativeScvaFailure));
                        if (soundFontStatusLabel_)
                            soundFontStatusLabel_->setText(QStringLiteral("SCVA tetap aktif melalui VST2; native C++ menolak build SCCore.dll ini."));
                        setStatus(QStringLiteral("SCVA asli aktif via VST2; native C++ menunggu profil data yang cocok untuk SCCore.dll ini."));
                    }
                    return;
                }
                scvaFailure = QString::fromUtf8(pluginError.data(), static_cast<qsizetype>(pluginError.size()));
                if (!nativeScvaFailure.isEmpty())
                    scvaFailure += QStringLiteral("; native SCVA: ") + nativeScvaFailure;
                audioEngine_.reset();
            } else {
                scvaFailure = audioError;
                if (!nativeScvaFailure.isEmpty())
                    scvaFailure += QStringLiteral("; native SCVA: ") + nativeScvaFailure;
            }
        }

        // If a persisted SCVA path is now missing or failed at startup, avoid a
        // duplicate load attempt from loadSoundFont(); keep its path in QSettings
        // so the user can repair the portable plugin folder and retry next launch.
        const QString savedVstPath = vst2PluginPath_;
        if (!savedVstPath.isEmpty() && (scvaPath.isEmpty() || !scvaFailure.isEmpty()))
            vst2PluginPath_.clear();
        const QString candidatePath = fallbackSoundFont;
        if (candidatePath.isEmpty()) {
            if (soundFontStatusLabel_) {
                const QString detail = scvaFailure.isEmpty()
                    ? QStringLiteral("SCVA.dll tidak ditemukan di folder plugins/SCVA.")
                    : QStringLiteral("SCVA gagal dimuat: %1").arg(scvaFailure);
                soundFontStatusLabel_->setText(detail + QStringLiteral(" Tidak ada SoundFont fallback yang valid."));
            }
            if (vst2PluginStatusLabel_ && !scvaFailure.isEmpty())
                vst2PluginStatusLabel_->setText(QStringLiteral("SCVA terdeteksi tetapi gagal dimuat: %1").arg(scvaFailure));
            vst2PluginPath_ = savedVstPath;
            updateOutputStatus();
            return;
        }
        QString errorMessage;
        const bool fluidReady = loadSoundFont(candidatePath, false, &errorMessage);
        vst2PluginPath_ = savedVstPath;
        if (!fluidReady && soundFontStatusLabel_)
            soundFontStatusLabel_->setText(QStringLiteral("Gagal memuat SoundFont: %1").arg(errorMessage));
        if (!scvaFailure.isEmpty() && vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("SCVA ditemukan tetapi gagal dimuat; FluidSynth fallback. Detail: %1").arg(scvaFailure));
        else if (scvaPath.isEmpty() && !savedVstPath.isEmpty() && vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("Lokasi SCVA tersimpan tidak ditemukan; periksa plugins/SCVA/SOUND Canvas VA.dll."));
        updateOutputStatus();
    }

    bool loadSoundFont(const QString &path, bool persist, QString *errorOut = nullptr) {
        if (!isValidSoundFontFile(path)) {
            const QString message = QStringLiteral("File bukan SoundFont SF2 RIFF/SFBK yang valid. Pilih file SF2 lengkap, bukan pointer Git LFS.");
            if (errorOut) *errorOut = message;
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
            return false;
        }
        auto candidate = std::make_unique<ensembles::AudioEngine>();
        std::string error;
        const QByteArray encodedPath = QDir::toNativeSeparators(path).toUtf8();
        if (!candidate->initialize(encodedPath.constData(), &error, selectedRtAudioApi(),
                                   selectedRtAudioDeviceId(), selectedRtAudioSampleRate(),
                                   selectedRtAudioBufferFrames())) {
            const QString message = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
            if (errorOut) *errorOut = message;
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("SoundFont tidak bisa diaktifkan: %1").arg(message));
            return false;
        }
        QString vst2Failure;
        if (!vst2PluginPath_.isEmpty()) {
            const QByteArray vst2Path = QDir::toNativeSeparators(vst2PluginPath_).toUtf8();
            if (!candidate->loadVst2Plugin(vst2Path.constData(), &error))
                vst2Failure = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
        }

        // Initialize new instance completely before replacing any active engine.
        if (audioEngine_ && audioEngine_->isReady()) audioEngine_->allSoundsOff();
        audioEngine_.swap(candidate);
        soundFontPath_ = path;
        if (persist) {
            QSettings settings;
            settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
            settings.sync();
        }
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        for (int channel = 0; channel < 3; ++channel) {
            audioEngine_->sendMidi(static_cast<std::uint8_t>(0xC0 | channel),
                static_cast<std::uint8_t>(voicePrograms_[static_cast<std::size_t>(channel)]), 0, internalVoiceChannel(channel));
        }
        if (soundFontStatusLabel_) {
            soundFontStatusLabel_->setText(QStringLiteral("Aktif: %1\nRtAudio: %2")
                .arg(QFileInfo(path).fileName(), QString::fromUtf8(audioEngine_->outputDeviceName().c_str())));
        }
        if (vst2PluginStatusLabel_) {
            if (audioEngine_->isVst2PluginLoaded())
                vst2PluginStatusLabel_->setText(QStringLiteral("VST2 aktif: %1").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
            else if (!vst2PluginPath_.isEmpty())
                vst2PluginStatusLabel_->setText(QStringLiteral("VST2 gagal dimuat; FluidSynth tetap aktif. %1").arg(vst2Failure));
            else
                vst2PluginStatusLabel_->setText(QStringLiteral("Instrumen eksternal: tidak aktif (FluidSynth)"));
        }
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(audioEngine_->isVst2PluginLoaded()
            ? QStringLiteral("Instrumen VST2 %1 aktif pada RtAudio; pemilihan Voice/Style mengirim MIDI ke instrumen tersebut.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()))
            : QStringLiteral("FluidSynth aktif dengan SoundFont %1; output audio lewat RtAudio.").arg(QFileInfo(path).fileName()));
        return true;
    }

    bool ensureAudioEngineForVst2(const QString &sfPath, QString *errorOut) {
        if (audioEngine_ && audioEngine_->isReady()) return true;
        (void)sfPath; // Keep the chosen SF2 as a manual fallback; do not start FluidSynth for VST selection.

        // VST-only operation requires an RtAudio stream, not a FluidSynth synth.
        // This intentionally avoids initializing FluidSynth merely to load SCVA.
        auto candidate = std::make_unique<ensembles::AudioEngine>();
        std::string audioOnlyError;
        if (!candidate->initialize("", &audioOnlyError, selectedRtAudioApi(),
                                   selectedRtAudioDeviceId(), selectedRtAudioSampleRate(),
                                   selectedRtAudioBufferFrames())) {
            if (errorOut) *errorOut = QString::fromUtf8(audioOnlyError.data(), static_cast<qsizetype>(audioOnlyError.size()));
            return false;
        }
        audioEngine_.swap(candidate);
        soundFontPath_.clear();
        return true;
    }

    void chooseVst2Plugin() {
        const QString start = vst2PluginPath_.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::MusicLocation)
            : QFileInfo(vst2PluginPath_).absolutePath();
        const QString path = QFileDialog::getOpenFileName(this,
            QStringLiteral("Pilih instrumen VST2 64-bit"), start,
            QStringLiteral("VST2 plugin 64-bit (*.dll);;Semua file (*.*)"));
        if (path.isEmpty()) return;

        QString sfPath = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
        // Reuse the active stream, or create a device-only stream if no SF2 exists.
        QString initError;
        if (!ensureAudioEngineForVst2(sfPath, &initError)) {
            QMessageBox::warning(this, QStringLiteral("Audio engine gagal"), initError);
            return;
        }
        if (!sfPath.isEmpty()) soundFontPath_ = sfPath; // Save fallback path only; FluidSynth is not initialized by VST selection.
        if (audioEngine_->isVst2PluginLoaded()) {
            std::string unloadError;
            if (!audioEngine_->unloadVst2Plugin(&unloadError)) {
                QMessageBox::warning(this, QStringLiteral("VST2 tidak bisa diganti"),
                    QString::fromUtf8(unloadError.data(), static_cast<qsizetype>(unloadError.size())));
                return;
            }
        }
        std::string error;
        const QByteArray pluginEncoded = QDir::toNativeSeparators(path).toUtf8();
        if (!audioEngine_->loadVst2Plugin(pluginEncoded.constData(), &error)) {
            const bool fluidAvailable = !audioEngine_->soundFontPath().empty();
            if (vst2PluginStatusLabel_)
                vst2PluginStatusLabel_->setText(fluidAvailable
                    ? QStringLiteral("VST2 gagal dimuat; FluidSynth aktif.")
                    : QStringLiteral("VST2 gagal dimuat; belum ada instrumen audio aktif."));
            QMessageBox::warning(this, QStringLiteral("VST2 gagal dimuat"),
                QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size())));
            if (!fluidAvailable) {
                audioEngine_.reset();
                updateAudioOutputStatus();
                updateOutputStatus();
            }
            return;
        }

        vst2PluginPath_ = path;
        QSettings settings;
        // A VST instrument renders through the internal RtAudio engine. Replace
        // a stale WinMM-only route so the UI and actual MIDI route agree.
        if (audioRoutingCombo_ && audioRoutingCombo_->currentData().toString() == QStringLiteral("winmm")) {
            const int internalRoute = audioRoutingCombo_->findData(QStringLiteral("fluid"));
            if (internalRoute >= 0) {
                const QSignalBlocker blocker(audioRoutingCombo_);
                audioRoutingCombo_->setCurrentIndex(internalRoute);
            }
        }
        settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto"));
        settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
        settings.setValue(QStringLiteral("audio/vst2PluginPath"), vst2PluginPath_);
        settings.sync();
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        for (int channel = 0; channel < 3; ++channel) {
            audioEngine_->sendMidi(static_cast<std::uint8_t>(0xC0 | channel),
                static_cast<std::uint8_t>(voicePrograms_[static_cast<std::size_t>(channel)]), 0,
                internalVoiceChannel(channel));
        }
        if (vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("VST2 aktif: %1").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
        if (soundFontStatusLabel_)
            soundFontStatusLabel_->setText(soundFontPath_.isEmpty()
                ? QStringLiteral("Mode VST2 eksklusif: FluidSynth/SoundFont tidak dimuat.")
                : QStringLiteral("FluidSynth standby, tidak ikut merender output VST2: %1").arg(QFileInfo(soundFontPath_).fileName()));
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(QStringLiteral("VST2 %1 aktif secara eksklusif melalui RtAudio; MIDI Voice/Style hanya dikirim ke VST2.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
    }

    void disableVst2Plugin() {
        QString error;
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isVst2PluginLoaded()) {
            std::string unloadError;
            if (!audioEngine_->unloadVst2Plugin(&unloadError)) {
                QMessageBox::warning(this, QStringLiteral("VST2 tidak bisa dinonaktifkan"),
                    QString::fromUtf8(unloadError.data(), static_cast<qsizetype>(unloadError.size())));
                return;
            }
        }
        vst2PluginPath_.clear();
        QSettings settings;
        settings.setValue(QStringLiteral("audio/vst2PluginPath"), QString());
        settings.sync();
        if (!audioEngine_ || !audioEngine_->isReady()) {
            const QString path = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
            if (path.isEmpty() || !loadSoundFont(path, false, &error)) {
                if (vst2PluginStatusLabel_)
                    vst2PluginStatusLabel_->setText(QStringLiteral("VST2 dinonaktifkan, tetapi FluidSynth belum aktif: %1").arg(error));
                return;
            }
        }
        bool fluidAvailable = audioEngine_ && audioEngine_->isReady() && !audioEngine_->soundFontPath().empty();
        if (!fluidAvailable) {
            // The VST-only engine deliberately has no FluidSynth. Close its stream
            // before reopening the same exclusive RtAudio device for SoundFont mode.
            audioEngine_.reset();
            const QString fallback = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
            if (!fallback.isEmpty() && loadSoundFont(fallback, false, &error)) {
                soundFontPath_ = fallback;
                fluidAvailable = true;
            }
        }
        if (vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(fluidAvailable
                ? QStringLiteral("Instrumen eksternal: tidak aktif (FluidSynth)")
                : QStringLiteral("VST2 dinonaktifkan; pilih SoundFont untuk mengaktifkan FluidSynth."));
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(fluidAvailable ? QStringLiteral("Kembali ke FluidSynth + RtAudio.")
                                 : QStringLiteral("VST2 dinonaktifkan; tidak ada engine instrumen aktif."));
    }

    void chooseSoundFont() {
        const QString start = soundFontPath_.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::MusicLocation) : QFileInfo(soundFontPath_).absolutePath();
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Pilih SoundFont untuk FluidSynth"), start,
            QStringLiteral("SoundFont 2 (*.sf2);;All files (*.*)"));
        if (path.isEmpty()) return;
        QString error;
        if (!loadSoundFont(path, true, &error)) {
            QMessageBox::warning(this, QStringLiteral("SoundFont gagal dimuat"), error);
            return;
        }
        savePanelSettings();
    }

    void updateOutputStatus() {
        updateAudioOutputStatus();
        if (!outputLabel_) return;
        const QString deviceName = audioEngine_ && audioEngine_->isReady()
            ? QString::fromUtf8(audioEngine_->outputDeviceName().c_str()) : QString();
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isVst2PluginLoaded()) {
            outputLabel_->setText(QStringLiteral("Rute aktif: VST2 %1 eksklusif + RtAudio (%2). FluidSynth tidak menerima MIDI dan tidak merender output.")
                .arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName));
            return;
        }
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        if (route == QStringLiteral("fluid")) {
            outputLabel_->setText(audioEngine_ && audioEngine_->isReady()
                ? (audioEngine_->isVst2PluginLoaded()
                    ? QStringLiteral("Rute aktif: VST2 %1 + RtAudio (%2).\nFallback SoundFont: %3").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName, QFileInfo(soundFontPath_).fileName())
                    : QStringLiteral("Rute aktif: FluidSynth + RtAudio (%1).\nSoundFont: %2").arg(deviceName, QFileInfo(soundFontPath_).fileName()))
                : QStringLiteral("Rute internal dipilih tetapi audio engine belum siap. Pilih SoundFont SF2 yang valid."));
        } else if (route == QStringLiteral("winmm")) {
            outputLabel_->setText(midiOutputReady_ ? QStringLiteral("Rute aktif: Windows MIDI Mapper.") : QStringLiteral("Windows MIDI Mapper tidak tersedia."));
        } else if (route == QStringLiteral("both")) {
            outputLabel_->setText(QStringLiteral("Rute aktif: %1 + %2")
                .arg(audioEngine_ && audioEngine_->isReady() ? QStringLiteral("FluidSynth/RtAudio") : QStringLiteral("FluidSynth belum siap"),
                     midiOutputReady_ ? QStringLiteral("Windows MIDI Mapper") : QStringLiteral("WinMM tidak tersedia")));
        } else if (audioEngine_ && audioEngine_->isReady()) {
            outputLabel_->setText(audioEngine_->isVst2PluginLoaded()
                ? QStringLiteral("Rute otomatis: VST2 %1 + RtAudio (%2). SoundFont fallback %3.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName, QFileInfo(soundFontPath_).fileName())
                : QStringLiteral("Rute otomatis: FluidSynth + RtAudio (%1). SoundFont %2.").arg(deviceName, QFileInfo(soundFontPath_).fileName()));
        } else {
            outputLabel_->setText(midiOutputReady_
                ? QStringLiteral("Rute otomatis memakai Windows MIDI Mapper karena SoundFont/FluidSynth belum siap.")
                : QStringLiteral("Tidak ada output aktif: pilih SoundFont SF2 atau periksa perangkat MIDI Windows."));
        }
    }

    void synchronizeOutputRoutes() {
        // Clear held notes on both backends before moving subsequent notes.
        if (audioEngine_ && audioEngine_->isReady()) audioEngine_->allSoundsOff();
#ifdef _WIN32
        if (midiOut_) {
            for (int channel = 0; channel < 16; ++channel) {
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 120, 0);
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 123, 0);
            }
        }
#endif
        for (int channel = 0; channel < 3; ++channel) {
            if (audioEngine_ && audioEngine_->isReady()) {
                audioEngine_->sendMidi(static_cast<std::uint8_t>(0xC0 | channel),
                    static_cast<std::uint8_t>(voicePrograms_[static_cast<std::size_t>(channel)]), 0, internalVoiceChannel(channel));
            }
            if (wantsWindowsMidiOutput()) sendWindowsMidi(static_cast<quint8>(0xC0 | channel),
                static_cast<quint8>(voicePrograms_[static_cast<std::size_t>(channel)]), 0);
        }
    }

    void openMidiOutput() {
#ifdef _WIN32
        const UINT count = midiOutGetNumDevs();
        if (count == 0) {
            midiOutputReady_ = false;
            outputLabel_->setText(QStringLiteral("Tidak ada perangkat output MIDI Windows yang terdeteksi."));
            setStatus(QStringLiteral("Perangkat output MIDI Windows tidak ditemukan; audio internal tetap bisa digunakan."));
            return;
        }
        const MMRESULT result = midiOutOpen(&midiOut_, MIDI_MAPPER, 0, 0, CALLBACK_NULL);
        if (result != MMSYSERR_NOERROR) {
            midiOut_ = nullptr;
            midiOutputReady_ = false;
            outputLabel_->setText(QStringLiteral("Output MIDI gagal dibuka (kode %1).").arg(result));
            setStatus(QStringLiteral("Gagal membuka output MIDI Windows; audio internal tetap bisa digunakan."));
            return;
        }
        midiOutputReady_ = true;
        MIDIOUTCAPSW caps{};
        QString deviceName = QStringLiteral("Windows MIDI Mapper");
        UINT midiOutId = 0;
        if (midiOutGetID(midiOut_, &midiOutId) == MMSYSERR_NOERROR &&
            midiOutGetDevCapsW(static_cast<UINT_PTR>(midiOutId), &caps, sizeof(caps)) == MMSYSERR_NOERROR) {
            const QString candidate = QString::fromWCharArray(caps.szPname);
            if (!candidate.isEmpty()) deviceName = candidate;
        }
        outputLabel_->setText(QStringLiteral("Perangkat eksternal terdeteksi: %1").arg(deviceName));
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
#else
        midiOutputReady_ = false;
        outputLabel_->setText(QStringLiteral("Windows MIDI API hanya tersedia pada Windows."));
#endif
    }

#ifdef _WIN32
    static void CALLBACK midiInputCallback(HMIDIIN, UINT message, DWORD_PTR instance,
                                           DWORD_PTR param1, DWORD_PTR) {
        if (message != MIM_DATA) return;
        auto *self = reinterpret_cast<EnsemblesWindow *>(instance);
        if (!self) return;
        const quint32 packed = static_cast<quint32>(param1);
        // WinMM calls back from a driver thread. Never touch Qt widgets or the
        // synthesizer here; queue the compact short-message to the GUI thread.
        QMetaObject::invokeMethod(self, [self, packed] {
            self->handleMidiInputMessage(packed);
        }, Qt::QueuedConnection);
    }
#endif

    void refreshMidiInputDevices() {
        if (!midiInputDeviceList_) return;
#ifndef _WIN32
        midiInputDeviceList_->clear();
        midiInputDeviceList_->setEnabled(false);
        if (midiInputStatusLabel_) midiInputStatusLabel_->setText(QStringLiteral("WinMM MIDI Input hanya tersedia pada Windows."));
        if (refreshMidiInputDevicesButton_) refreshMidiInputDevicesButton_->setEnabled(false);
#else
        const QSignalBlocker blocker(midiInputDeviceList_);
        midiInputDeviceList_->clear();
        const UINT count = midiInGetNumDevs();
        for (UINT id = 0; id < count; ++id) {
            MIDIINCAPSW caps{};
            const MMRESULT result = midiInGetDevCapsW(static_cast<UINT_PTR>(id), &caps, sizeof(caps));
            if (result != MMSYSERR_NOERROR) continue;
            auto *item = new QListWidgetItem(QString::fromWCharArray(caps.szPname), midiInputDeviceList_);
            item->setData(Qt::UserRole, id);
            item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
            item->setCheckState(midiInputHandles_.find(id) != midiInputHandles_.end()
                ? Qt::Checked : Qt::Unchecked);
            item->setToolTip(QStringLiteral("WinMM input device ID %1").arg(id));
        }
        midiInputDeviceList_->setEnabled(count > 0);
        if (refreshMidiInputDevicesButton_) refreshMidiInputDevicesButton_->setEnabled(true);
        updateMidiInputStatus();
#endif
    }

#ifdef _WIN32
    bool connectMidiInputDevice(UINT id) {
        if (midiInputHandles_.find(id) != midiInputHandles_.end()) return true;
        HMIDIIN handle = nullptr;
        const MMRESULT openResult = midiInOpen(
            &handle, id,
            reinterpret_cast<DWORD_PTR>(&EnsemblesWindow::midiInputCallback),
            reinterpret_cast<DWORD_PTR>(this), CALLBACK_FUNCTION);
        if (openResult != MMSYSERR_NOERROR || !handle) {
            setStatus(QStringLiteral("Gagal membuka MIDI input device %1 (WinMM %2).")
                .arg(id).arg(openResult));
            return false;
        }
        const MMRESULT startResult = midiInStart(handle);
        if (startResult != MMSYSERR_NOERROR) {
            midiInReset(handle);
            midiInClose(handle);
            setStatus(QStringLiteral("Gagal memulai MIDI input device %1 (WinMM %2).")
                .arg(id).arg(startResult));
            return false;
        }
        midiInputHandles_.emplace(id, handle);
        updateMidiInputStatus();
        setStatus(QStringLiteral("MIDI input terhubung: %1.").arg(id));
        return true;
    }

    void disconnectMidiInputDevice(UINT id) {
        const auto it = midiInputHandles_.find(id);
        if (it == midiInputHandles_.end()) return;
        HMIDIIN handle = it->second;
        midiInputHandles_.erase(it);
        if (handle) {
            midiInStop(handle);
            midiInReset(handle);
            midiInClose(handle);
        }
        updateMidiInputStatus();
    }

    void closeAllMidiInputDevices() {
        std::vector<HMIDIIN> handles;
        handles.reserve(midiInputHandles_.size());
        for (const auto &entry : midiInputHandles_) handles.push_back(entry.second);
        midiInputHandles_.clear();
        for (HMIDIIN handle : handles) {
            if (!handle) continue;
            midiInStop(handle);
            midiInReset(handle);
            midiInClose(handle);
        }
    }
#endif

    void updateMidiInputStatus() {
        if (!midiInputStatusLabel_) return;
#ifdef _WIN32
        const std::size_t active = midiInputHandles_.size();
        midiInputStatusLabel_->setText(active == 0
            ? QStringLiteral("Tidak ada perangkat MIDI input terhubung. Centang perangkat untuk mulai menerima note.")
            : QStringLiteral("%1 perangkat MIDI input terhubung. Note-on/note-off aktif; pemetaan CC ke kontrol UI masih dalam tahap porting.")
                .arg(static_cast<qulonglong>(active)));
#else
        midiInputStatusLabel_->setText(QStringLiteral("WinMM MIDI Input hanya tersedia pada Windows."));
#endif
    }

    void handleMidiInputMessage(quint32 packed) {
        const auto input = ensembles::decodeMidiShortMessage(packed);
        if (!input.isNoteEvent()) return; // CC mappings are ported separately from note routing.
        const quint8 data1 = input.data1;
        const quint8 data2 = input.data2;
        const int sourceChannel = static_cast<int>(input.channel);
        const bool noteOn = input.isPressed();

        const bool splitByChannel = midiSplitByChannelCheck_ && midiSplitByChannelCheck_->isChecked()
#ifdef _WIN32
            && !midiInputHandles_.empty()
#endif
            ;
        const int velocity = noteOn ? static_cast<int>(data2) : 0;
        const bool pressed = noteOn;
        if (!splitByChannel) {
            // Original synthesizer_send_notes() without midi-split routes notes
            // through the normal keyboard split/accompaniment logic.
            onKeyboardNote(static_cast<int>(data1), pressed, velocity, true);
            return;
        }

        // Port of MidiInputHost.process_note_signal(): MIDI channels 1, 2 and 3
        // select layers 0, 1 and 2; every channel above 3 maps to layer 2.
        // The legacy synthesizer uses internal channels 17 (R1), 18 (R2), 19 (L).
        const int layer = ensembles::originalMidiInputLayerForChannel(sourceChannel);
        int note = static_cast<int>(data1);
        if (transposeActive_) note += transposeAmount_;
        if (octaveShiftActive_) note += octaveShiftAmount_ * 12;
        note = std::clamp(note, 0, 127);
        const quint8 noteType = pressed ? 0x90u : 0x80u;
        if (pianoKeyboard_) pianoKeyboard_->setActiveNote(static_cast<int>(data1), pressed, layer == 2 ? 1 : 0);

        // With channel splitting enabled, original MidiInputHost passes layer+17
        // to the synthesizer; L/channel 3 controls chords while accompaniment is on.
        if (layer == 2 && accompanimentEnabled_) {
            int detectedType = 0;
            const int detectedRoot = chord_finder_infer(note, noteType, &detectedType);
            if (detectedRoot > -6) {
                styleEngine_.changeChord(detectedRoot, detectedType);
                updateChordLabel(detectedRoot, detectedType);
            }

            // The original synthesizer emits the fallback chord voicing whenever
            // the style is not looping and sync-start is not pending. On release,
            // it always releases the matching notes and clears channel 21.
            sendFallbackChordVoicing(note, pressed, velocity, detectedRoot);
            captureEvent(static_cast<quint8>(noteType | layer), note, velocity);
            return;
        }

        const int internalChannel = 17 + layer;
        const quint8 midiStatus = static_cast<quint8>(noteType | layer);
        sendInternalMidiOnly(midiStatus, note, velocity, internalChannel);
        captureEvent(midiStatus, note, velocity);

        // Match the original synthesizer.c: Layer adds the second right-hand voice
        // on channel 18 for split-by-channel input, except for the left/split path.
        if (layerEnabled_ && !(layer == 2 && splitEnabled_ && !accompanimentEnabled_)) {
            const quint8 layerStatus = static_cast<quint8>(noteType | 2u);
            sendInternalMidiOnly(layerStatus, note, velocity, 18);
            captureEvent(layerStatus, note, velocity);
        }
    }

    void sendWindowsMidi(quint8 status, quint8 data1, quint8 data2) {
#ifdef _WIN32
        if (!midiOut_) return;
        const DWORD packed = static_cast<DWORD>(status) |
            (static_cast<DWORD>(data1 & 0x7f) << 8) |
            (static_cast<DWORD>(data2 & 0x7f) << 16);
        const MMRESULT result = midiOutShortMsg(midiOut_, packed);
        if (result != MMSYSERR_NOERROR && midiOutputReady_) {
            midiOutputReady_ = false;
            setStatus(QStringLiteral("Perintah Windows MIDI gagal dikirim (kode %1). Periksa perangkat output.").arg(result));
            updateOutputStatus();
        }
#else
        Q_UNUSED(status); Q_UNUSED(data1); Q_UNUSED(data2);
#endif
    }

    void sendInternalMidiOnly(quint8 status, int data1, int data2, int synthChannelOverride) {
        if (!audioEngine_ || !audioEngine_->isReady()) return;
        audioEngine_->sendMidi(status, static_cast<quint8>(std::clamp(data1, 0, 127)),
                               static_cast<quint8>(std::clamp(data2, 0, 127)), synthChannelOverride);
    }

    void markMidiActivity(quint8 status, quint8 data1, quint8 data2, int synthChannelOverride) {
        const int eventType = status & 0xF0;
        const int midiChannel = status & 0x0F;
        int lane = midiChannel;
        if (synthChannelOverride == 19) lane = 16; // left voice
        else if (synthChannelOverride == 17) lane = 17; // right 1
        else if (synthChannelOverride == 18) lane = 18; // right 2
        if (lane < 0 || lane >= static_cast<int>(channelActivityLevels_.size())) return;
        int level = 25;
        if (eventType == 0x90 && data2 > 0) level = 25 + (std::clamp(static_cast<int>(data2), 0, 127) * 75 / 127);
        else if (eventType == 0xB0) level = data1 == 120 || data1 == 123 ? 15 : 48;
        else if (eventType == 0x80 || (eventType == 0x90 && data2 == 0)) level = 18;
        channelActivityLevels_[static_cast<std::size_t>(lane)] = std::max(channelActivityLevels_[static_cast<std::size_t>(lane)], level);
    }

    void sendMidi(quint8 status, quint8 data1, quint8 data2, int synthChannelOverride = -1) {
        markMidiActivity(status, data1, data2, synthChannelOverride);
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady()) {
            if (!audioEngine_->sendMidi(status, data1, data2, synthChannelOverride)) {
                // Queue overflow is unlikely for ordinary UI/MIDI traffic; status is
                // not repeatedly changed here because this path may be realtime.
            }
        }
        if (wantsWindowsMidiOutput()) sendWindowsMidi(status, data1, data2);
    }

    void setMidiOutputVolume(int value) {
        const int volume = std::clamp(value, 0, 100);
        if (audioEngine_ && audioEngine_->isReady())
            audioEngine_->setMasterGain(0.6f * static_cast<float>(volume) / 100.0f * static_cast<float>(std::clamp(audioFaderVolume_, 0, 127)) / 127.0f);
#ifdef _WIN32
        if (midiOut_) {
            const WORD level = static_cast<WORD>((65535 * volume) / 100);
            const DWORD packed = static_cast<DWORD>(level) | (static_cast<DWORD>(level) << 16);
            midiOutSetVolume(midiOut_, packed);
        }
#endif
    }

    void allSoundsOff() {
        stopArpeggiator(true);
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady())
            audioEngine_->allSoundsOff();
        if (wantsWindowsMidiOutput()) {
            for (int channel = 0; channel < 16; ++channel) {
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 120, 0);
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 123, 0);
            }
        }
    }

    void captureEvent(quint8 status, int note, int velocity) {
        if (!recording_) return;
        const auto elapsedUs = static_cast<std::uint64_t>(std::max<qint64>(0, recordClock_.nsecsElapsed() / 1000));
        recordedEvents_.push_back({elapsedUs, status, static_cast<std::uint8_t>(note), static_cast<std::uint8_t>(velocity)});
        recordLabel_->setText(QStringLiteral("Merekam… %1 event").arg(static_cast<qulonglong>(recordedEvents_.size())));
    }

    void loadMidi() {
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Buka berkas MIDI"), QStandardPaths::writableLocation(QStandardPaths::MusicLocation), QStringLiteral("MIDI files (*.mid *.midi *.MID *.MIDI)"));
        if (path.isEmpty()) return;
        ensembles::MidiFile parsed;
        std::string error;
        const std::filesystem::path native = std::filesystem::path(path.toStdWString());
        if (!ensembles::load_midi_file(native, parsed, error)) {
            QMessageBox::warning(this, QStringLiteral("Gagal membuka MIDI"), QString::fromLocal8Bit(error.c_str()));
            setStatus(QStringLiteral("Gagal membuka MIDI.")); return;
        }
        stopPlayback(false);
        midiFile_ = std::move(parsed); midiPath_ = path; playbackIndex_ = 0;
        midiFileLabel_->setText(QFileInfo(path).fileName());
        setStatus(QStringLiteral("MIDI dimuat: %1 — %2 event, %3 track.").arg(nativePathMessage(path)).arg(static_cast<qulonglong>(midiFile_.events.size())).arg(midiFile_.tracks));
    }

    void togglePlayback() {
        if (playbackActive_) { stopPlayback(); return; }
        if (midiFile_.events.empty()) { setStatus(QStringLiteral("Muat berkas MIDI terlebih dahulu.")); return; }
        if (!midiOutputReady_) { setStatus(QStringLiteral("Output MIDI belum siap. Periksa perangkat MIDI Windows.")); return; }
        playbackIndex_ = 0;
        playbackClock_.start();
        playbackActive_ = true;
        playbackTimer_.start();
        playButton_->setText(QStringLiteral("Ⅱ Jeda/Stop MIDI"));
        setStatus(QStringLiteral("Memutar MIDI: %1").arg(QFileInfo(midiPath_).fileName()));
    }

    void stopPlayback(bool report = true) {
        playbackTimer_.stop(); playbackActive_ = false; playbackIndex_ = 0;
        if (playButton_) playButton_->setText(QStringLiteral("▶ Putar MIDI"));
        allSoundsOff();
        if (report) setStatus(QStringLiteral("Playback MIDI dihentikan."));
    }

    void onPlaybackTick() {
        if (!playbackActive_) { playbackTimer_.stop(); return; }
        const qint64 elapsedUs = playbackClock_.nsecsElapsed() / 1000;
        const qint64 positionUs = elapsedUs * tempo_ / 120;
        while (playbackIndex_ < midiFile_.events.size() && static_cast<qint64>(midiFile_.events[playbackIndex_].time_us) <= positionUs) {
            const auto &event = midiFile_.events[playbackIndex_++];
            int data2 = event.data2;
            const int eventType = event.status & 0xF0;
            if ((eventType == 0x90 && data2 > 0) || (eventType == 0xB0 && event.data1 == 7))
                data2 = (data2 * songVolume_ + 63) / 127;
            sendMidi(event.status, event.data1, static_cast<quint8>(std::clamp(data2, 0, 127)));
        }
        if (playbackIndex_ >= midiFile_.events.size()) {
            playbackTimer_.stop(); playbackActive_ = false;
            playButton_->setText(QStringLiteral("▶ Putar MIDI"));
            allSoundsOff(); setStatus(QStringLiteral("Playback MIDI selesai."));
        }
    }

    void toggleRecording() {
        if (!recording_) {
            recordedEvents_.clear(); recordClock_.start(); recording_ = true;
            recordButton_->setText(QStringLiteral("■ Selesaikan & Simpan"));
            recordLabel_->setText(QStringLiteral("Merekam… 0 event"));
            setStatus(QStringLiteral("Rekaman MIDI dimulai. Rekaman menangkap keyboard virtual dan pad drum."));
            return;
        }
        recording_ = false; recordButton_->setText(QStringLiteral("● Rekam MIDI"));
        if (recordedEvents_.empty()) { recordLabel_->setText(QStringLiteral("Tidak ada event direkam")); setStatus(QStringLiteral("Rekaman kosong.")); return; }
        QString path = QFileDialog::getSaveFileName(this, QStringLiteral("Simpan rekaman MIDI"), QDir::current().filePath(QStringLiteral("ensembles-recording.mid")), QStringLiteral("MIDI files (*.mid)"));
        if (path.isEmpty()) { setStatus(QStringLiteral("Penyimpanan rekaman dibatalkan.")); return; }
        if (QFileInfo(path).suffix().isEmpty()) path += QStringLiteral(".mid");
        std::string error;
        const std::filesystem::path native(path.toStdWString());
        if (!ensembles::save_midi_file(native, recordedEvents_, tempo_, error)) {
            QMessageBox::warning(this, QStringLiteral("Gagal menyimpan MIDI"), QString::fromLocal8Bit(error.c_str()));
            setStatus(QStringLiteral("Gagal menyimpan rekaman MIDI.")); return;
        }
        recordLabel_->setText(QStringLiteral("%1 event tersimpan").arg(static_cast<qulonglong>(recordedEvents_.size())));
        setStatus(QStringLiteral("Rekaman MIDI disimpan: %1").arg(nativePathMessage(path)));
    }

    void triggerDrum(int note) {
        const int velocity = std::clamp((110 * padsVolume_ + 63) / 127, 1, 127);
        sendMidi(0x99, static_cast<quint8>(note), static_cast<quint8>(velocity));
        captureEvent(0x99, note, velocity);
        QTimer::singleShot(120, this, [this, note] { sendMidi(0x89, static_cast<quint8>(note), 0); captureEvent(0x89, note, 0); });
        setStatus(QStringLiteral("GM drum pad: note %1.").arg(note));
    }

    void playShortNote(int channel, int note, int velocity, int durationMs) {
        const int internalChannel = channel == 9 ? 16 : -1; // Original metronome voice.
        sendMidi(static_cast<quint8>(0x90 | channel), static_cast<quint8>(note), static_cast<quint8>(velocity), internalChannel);
        QTimer::singleShot(durationMs, this, [this, channel, note, internalChannel] {
            sendMidi(static_cast<quint8>(0x80 | channel), static_cast<quint8>(note), 0, internalChannel);
        });
    }

    void sendStyleMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) {
        markMidiActivity(status, data1, data2, -1);
        const int type = status & 0xF0;
        const int channel = status & 0x0F;
        int styleVelocity = data2;
        // Chord fader scales melodic accompaniment notes separately from rhythm channel 10.
        if (type == 0x90 && data2 > 0 && channel != 9 && chordVolume_ < 127)
            styleVelocity = (styleVelocity * chordVolume_ + 63) / 127;
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady()) {
            // Native accompaniment channels are independent of the three dedicated keyboard voices.
            audioEngine_->sendMidi(status, data1, static_cast<std::uint8_t>(styleVelocity), -1);
        }
        if (wantsWindowsMidiOutput()) {
            int externalData2 = styleVelocity;
            if (type == 0x90 && data2 > 0 && styleVolume_ < 127)
                externalData2 = (externalData2 * styleVolume_ + 63) / 127;
            sendWindowsMidi(status, data1, static_cast<std::uint8_t>(std::clamp(externalData2, 0, 127)));
        }
    }

    void setupStyleEngine() {
        styleEngine_.setMidiSink([this](std::uint8_t status, std::uint8_t data1, std::uint8_t data2) {
            const int type = status & 0xF0;
            const int channel = status & 0x0F;
            // Original synthesizer.c suppresses melodic style note-ons when accompaniment is off;
            // drum channel 10 (zero-based channel 9) always continues.
            if (!accompanimentEnabled_ && type == 0x90 && data2 > 0 && channel != 9) return;
            sendStyleMidi(status, data1, data2);
        });
        styleEngine_.setStateSink([this](bool playing) {
            if (playing) {
                styleClock_.start();
                lastStyleElapsedUs_ = 0;
                styleTimer_.start();
                if (styleInfo_ && styleEngine_.hasStyle())
                    styleInfo_->setText(QStringLiteral("Playing · %1 BPM · %2/%3")
                        .arg(styleEngine_.tempo())
                        .arg(styleEngine_.analysis().timeSignatureNumerator)
                        .arg(styleEngine_.analysis().timeSignatureDenominator));
            } else {
                // The original CentralBus keeps its clock latch alive for 300 ms
                // after a section edge, even if a sync-ending stops the player.
                if (!styleEngine_.needsClockMaintenance()) styleTimer_.stop();
                if (styleInfo_ && styleEngine_.hasStyle())
                    styleInfo_->setText(QStringLiteral("Stopped · %1 BPM · %2/%3")
                        .arg(styleEngine_.tempo())
                        .arg(styleEngine_.analysis().timeSignatureNumerator)
                        .arg(styleEngine_.analysis().timeSignatureDenominator));
                if (!pendingStylePath_.isEmpty()) {
                    const QString requestedPath = pendingStylePath_;
                    const int requestedTempo = pendingStyleTempoBpm_;
                    QTimer::singleShot(0, this, [this, requestedPath, requestedTempo] {
                        // If the user picked a different style while this
                        // queued callback was waiting, do not apply a stale path.
                        if (pendingStylePath_ != requestedPath) return;
                        pendingStylePath_.clear();
                        if (applyStyleFile(requestedPath, requestedTempo)) {
                            // StylePlayer.vala calls play_style() after the
                            // requested style has been reloaded at the old BPM.
                            styleEngine_.play();
                        }
                    });
                }
            }
        });
        styleEngine_.setPartSink([this](int markerIndex) {
            static const std::array<const char*, 15> names = {
                "Config", "Intro A", "Intro B", "Variation A", "Fill A", "Variation B", "Fill B",
                "Variation C", "Fill C", "Variation D", "Fill D", "Ending A", "End of Style A",
                "Ending B", "End of Style B"};
            if (styleInfo_ && markerIndex >= 0 && markerIndex < static_cast<int>(names.size()))
                styleInfo_->setText(QStringLiteral("Section: %1 · %2 BPM · %3/%4")
                    .arg(QString::fromUtf8(names[static_cast<std::size_t>(markerIndex)]))
                    .arg(styleEngine_.tempo())
                    .arg(styleEngine_.analysis().timeSignatureNumerator)
                    .arg(styleEngine_.analysis().timeSignatureDenominator));
        });

        struct DiscoveredStyle {
            QString genre;
            QString name;
            QString path;
        };

        QString builtInDirectory = QDir(QCoreApplication::applicationDirPath())
            .filePath(QStringLiteral("data/StyleFiles"));
        if (!QDir(builtInDirectory).exists()) {
            const QString legacy = QDir(QCoreApplication::applicationDirPath())
                .filePath(QStringLiteral("legacy-reference/data/Styles/StyleFiles"));
            if (QDir(legacy).exists()) builtInDirectory = legacy;
        }

        // Match Application.user_data_dir + "/styles" in the original Vala
        // application: Documents/ensembles/styles on Windows.
        QString documentsDirectory = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
        if (documentsDirectory.isEmpty()) documentsDirectory = QDir::home().filePath(QStringLiteral("Documents"));
        const QString userDataDirectory = QDir(documentsDirectory).filePath(QStringLiteral("ensembles"));
        const QString userStyleDirectory = QDir(userDataDirectory).filePath(QStringLiteral("styles"));
        if (!QDir().mkpath(userStyleDirectory)) {
            styleInfo_->setText(QStringLiteral("Folder style pengguna tidak dapat dibuat: %1")
                .arg(QDir::toNativeSeparators(userStyleDirectory)));
        }

        std::vector<DiscoveredStyle> discovered;
        const auto scanStyleDirectory = [&discovered](const QString &path) {
            QDir directory(path);
            if (!directory.exists()) return;
            const QStringList files = directory.entryList({QStringLiteral("*.enstl")}, QDir::Files, QDir::Name);
            for (const QString &file : files) {
                const QString stem = QFileInfo(file).completeBaseName();
                const qsizetype separator = stem.indexOf(QLatin1Char('@'));
                // StyleDiscovery's filename contract is "genre@name.enstl".
                // Ignore malformed names instead of indexing a missing token.
                if (separator <= 0 || separator >= stem.size() - 1) continue;
                DiscoveredStyle item;
                item.genre = stem.left(separator);
                item.name = stem.mid(separator + 1);
                item.path = directory.filePath(file);
                discovered.push_back(std::move(item));
            }
        };
        scanStyleDirectory(builtInDirectory);
        scanStyleDirectory(userStyleDirectory);

        // Original StyleDiscovery sorts by genre (ASCII case-insensitive), not
        // by whole filename. stable_sort preserves directory order within a genre.
        std::stable_sort(discovered.begin(), discovered.end(), [](const auto &a, const auto &b) {
            return QString::compare(a.genre, b.genre, Qt::CaseInsensitive) < 0;
        });

        for (const auto &style : discovered) {
            QString display = style.genre + QStringLiteral(" — ") + style.name;
            display.replace(QLatin1Char('_'), QLatin1Char(' '));
            styleCombo_->addItem(display, style.path);
            styleCombo_->setItemData(styleCombo_->count() - 1, style.path, Qt::ToolTipRole);

            QString visibleName = style.name;
            visibleName.replace(QLatin1Char('_'), QLatin1Char(' '));
            auto *lcdItem = new QListWidgetItem(visibleName);
            lcdItem->setData(Qt::UserRole, style.path);
            lcdItem->setData(Qt::UserRole + 2, style.genre);

            // The style list's secondary line comes from the actual .enstl MIDI
            // metadata, not guessed defaults. The Config marker contains tempo.
            ensembles::MidiFile styleMidi;
            std::string midiError;
            QString secondary;
            if (ensembles::load_midi_file(std::filesystem::path(style.path.toStdWString()), styleMidi, midiError)) {
                secondary = QStringLiteral("%1/%2")
                    .arg(styleMidi.time_signature_numerator)
                    .arg(styleMidi.time_signature_denominator);
                int bpm = 0;
                for (const auto &meta : styleMidi.meta_events) {
                    if (meta.type != 0x06) continue;
                    const QString marker = QString::fromStdString(meta.text);
                    if (!marker.startsWith(QStringLiteral("Config:"))) continue;
                    const int separator = marker.indexOf(QLatin1Char(';'));
                    if (separator < 0) continue;
                    const int comma = marker.indexOf(QLatin1Char(','), separator + 1);
                    bool ok = false;
                    const QString bpmText = comma < 0 ? marker.mid(separator + 1)
                                                      : marker.mid(separator + 1, comma - separator - 1);
                    const int parsedBpm = bpmText.toInt(&ok);
                    if (ok && parsedBpm > 0) { bpm = parsedBpm; break; }
                }
                if (bpm > 0) secondary += QStringLiteral("  ♩ = %1").arg(bpm);
            }
            lcdItem->setData(Qt::UserRole + 1, secondary);
            lcdItem->setToolTip(QStringLiteral("%1 · %2").arg(display, secondary));
            lcdStyleList_->addItem(lcdItem);
        }
        if (discovered.empty()) {
            styleCombo_->addItem(QStringLiteral("Style .enstl tidak ditemukan"));
            styleCombo_->setEnabled(false);
            styleInfo_->setText(QStringLiteral("Style tidak ditemukan. Periksa data/StyleFiles dan Documents/ensembles/styles."));
            auto *emptyItem = new QListWidgetItem(QStringLiteral("Style .enstl tidak ditemukan"));
            emptyItem->setFlags(Qt::NoItemFlags);
            emptyItem->setData(Qt::UserRole + 1, QStringLiteral("Periksa data/StyleFiles dan Documents/ensembles/styles"));
            lcdStyleList_->addItem(emptyItem);
        } else {
            connect(styleCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int index) {
                if (lcdStyleList_ && lcdStyleList_->currentRow() != index) {
                    const QSignalBlocker blocker(lcdStyleList_);
                    lcdStyleList_->setCurrentRow(index);
                }
                if (index >= 0) loadSelectedStyle();
            });
            connect(lcdStyleList_, &QListWidget::currentRowChanged, this, [this](int row) {
                if (row >= 0 && styleCombo_ && styleCombo_->currentIndex() != row)
                    styleCombo_->setCurrentIndex(row);
            });
            {
                const QSignalBlocker blocker(lcdStyleList_);
                lcdStyleList_->setCurrentRow(styleCombo_->currentIndex());
            }
            loadSelectedStyle();
        }
    }

    bool applyStyleFile(const QString &path, int customTempoBpm) {
        std::string error;
        if (!styleEngine_.loadStyle(std::filesystem::path(path.toStdWString()), customTempoBpm, error)) {
            styleInfo_->setText(QStringLiteral("Gagal memuat style: %1").arg(QString::fromLocal8Bit(error.c_str())));
            setStatus(QStringLiteral("Style Ensembles gagal dimuat."));
            return false;
        }

        // Loading a style with customTempo=0 uses the Config marker tempo in
        // the original application. A live style change passes the current BPM.
        tempo_ = styleEngine_.tempo();
        if (tempoSlider_) {
            const QSignalBlocker blocker(tempoSlider_);
            tempoSlider_->setValue(tempo_);
        }
        if (tempoValue_) tempoValue_->setText(QString::number(tempo_));
        if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(tempo_));
        if (styleNameLabel_) {
            QString displayName = QFileInfo(path).completeBaseName();
            const qsizetype at = displayName.indexOf(QLatin1Char('@'));
            if (at >= 0) displayName = displayName.mid(at + 1);
            displayName.replace(QLatin1Char('_'), QLatin1Char(' '));
            styleNameLabel_->setText(displayName);
        }
        if (beatMetricLabel_) beatMetricLabel_->setText(QStringLiteral("%1/%2")
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator));
        styleInfo_->setText(QStringLiteral("Ready · %1 BPM · %2/%3 · %4 markers")
            .arg(styleEngine_.tempo())
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator)
            .arg(static_cast<qulonglong>(styleEngine_.analysis().markerTicks.size())));
        chordLabel_->setText(QStringLiteral("C min"));
        setStatus(QStringLiteral("Style Ensembles asli dimuat: %1").arg(QFileInfo(path).completeBaseName()));
        return true;
    }

    void loadSelectedStyle() {
        if (!styleCombo_ || styleCombo_->currentData().toString().isEmpty()) return;
        const QString path = styleCombo_->currentData().toString();
        if (styleEngine_.isPlaying()) {
            // Match StylePlayer.vala: end the current section via sync-stop,
            // then load and resume the selected style at the existing BPM.
            pendingStylePath_ = path;
            pendingStyleTempoBpm_ = tempo_;
            styleEngine_.syncStop();
            setStatus(QStringLiteral("Pergantian style dijadwalkan pada akhir section; tempo dipertahankan."));
            return;
        }
        // A direct selection made after playback stopped supersedes a queued
        // switch that has not yet run its zero-delay callback.
        pendingStylePath_.clear();
        applyStyleFile(path, 0);
    }

    void onStyleTick() {
        if (!styleClock_.isValid()) return;
        const qint64 elapsed = styleClock_.nsecsElapsed() / 1000;
        const qint64 delta = std::max<qint64>(0, elapsed - lastStyleElapsedUs_);
        lastStyleElapsedUs_ = elapsed;
        styleEngine_.advanceMicroseconds(static_cast<std::uint64_t>(delta));
        if (!styleEngine_.isPlaying() && !styleEngine_.needsClockMaintenance())
            styleTimer_.stop();
    }

    void updateChordLabel(int detectedRoot, int detectedType) {
        if (!chordLabel_ || detectedRoot <= -6 ||
            detectedType < 0 || detectedType >= static_cast<int>(kChordTypeNames.size())) return;
        const int pitchClass = ((detectedRoot % 12) + 12) % 12;
        QString type = QString::fromUtf8(kChordTypeNames[static_cast<std::size_t>(detectedType)]);
        type.replace(QStringLiteral("Major"), QStringLiteral(""));
        type.replace(QStringLiteral("Minor"), QStringLiteral("min"));
        type = type.trimmed();
        chordLabel_->setText(QStringLiteral("%1%2")
            .arg(QString::fromUtf8(kChordNames[static_cast<std::size_t>(pitchClass)]))
            .arg(type.isEmpty() ? QString() : QStringLiteral(" ") + type));
    }

    void sendFallbackChordVoicing(int alreadyTransposedNote, bool pressed, int velocity, int detectedRoot) {
        const int note = std::clamp(alreadyTransposedNote, 0, 127);
        if (pressed) {
            // This mirrors synthesizer.c: get_central_style_looping()==0 and
            // get_central_style_sync_start()==0 are both required for attacks.
            if (detectedRoot <= -6 || styleEngine_.isLooping() || styleEngine_.syncStartPending()) return;
            const int v = std::clamp(velocity, 1, 127);
            sendInternalMidiOnly(0xb0, 91, 0, 20);
            sendInternalMidiOnly(0xb0, 91, 0, 21);
            sendInternalMidiOnly(0xb0, 120, 0, 21);
            sendInternalMidiOnly(0x90, std::clamp(note + 12, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.6), 1, 127), 20);
            sendInternalMidiOnly(0x90, std::clamp(detectedRoot + 36, 0, 127), v, 21);
            sendInternalMidiOnly(0x90, std::clamp(note + 36, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.2), 1, 127), 22);
            sendInternalMidiOnly(0x90, std::clamp(note + 24, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.4), 1, 127), 22);
            return;
        }
        sendInternalMidiOnly(0x80, std::clamp(note + 12, 0, 127), 0, 20);
        sendInternalMidiOnly(0xb0, 120, 0, 21);
        sendInternalMidiOnly(0x80, std::clamp(note + 36, 0, 127), 0, 22);
        sendInternalMidiOnly(0x80, std::clamp(note + 24, 0, 127), 0, 22);
    }

    void updateArpeggiatorTimer() {
        if (!arpButton_ || !arpButton_->isChecked() || arpeggiatorHeldNotes_.empty()) {
            if (!arpButton_ || !arpButton_->isChecked()) arpeggiatorTimer_.stop();
            return;
        }
        const int pattern = arpSpin_ ? std::clamp(arpSpin_->value(), 1, 12) : 1;
        const int bpm = std::clamp(tempo_, 40, 240);
        static constexpr std::array<int, 4> divisions = {60000, 30000, 15000, 45000}; // quarter, eighth, sixteenth, dotted eighth
        const int denominator = divisions[static_cast<std::size_t>((pattern - 1) % 4)];
        arpeggiatorTimer_.setInterval(std::max(40, denominator / bpm));
        if (!arpeggiatorTimer_.isActive()) arpeggiatorTimer_.start();
    }

    void releaseArpeggiatorCurrentNote() {
        if (arpeggiatorCurrentNote_ < 0) return;
        const int slot = std::clamp(arpeggiatorCurrentVoiceSlot_, 0, 2);
        const auto noteOffStatus = static_cast<quint8>(0x80 | slot);
        if (arpeggiatorCurrentInternalOnly_) sendInternalMidiOnly(noteOffStatus, arpeggiatorCurrentNote_, 0, internalVoiceChannel(slot));
        else sendMidi(noteOffStatus, static_cast<quint8>(arpeggiatorCurrentNote_), 0, internalVoiceChannel(slot));
        captureEvent(noteOffStatus, arpeggiatorCurrentNote_, 0);
        if (arpeggiatorCurrentLayered_) {
            if (arpeggiatorCurrentInternalOnly_) sendInternalMidiOnly(0x82, arpeggiatorCurrentNote_, 0, internalVoiceChannel(2));
            else sendMidi(0x82, static_cast<quint8>(arpeggiatorCurrentNote_), 0, internalVoiceChannel(2));
            captureEvent(0x82, arpeggiatorCurrentNote_, 0);
        }
        arpeggiatorCurrentNote_ = -1;
        arpeggiatorCurrentLayered_ = false;
        arpeggiatorCurrentInternalOnly_ = false;
    }

    void stopArpeggiator(bool clearHeld) {
        arpeggiatorTimer_.stop();
        releaseArpeggiatorCurrentNote();
        if (clearHeld) arpeggiatorHeldNotes_.clear();
        arpeggiatorStep_ = 0;
    }

    void advanceArpeggiator() {
        if (!arpButton_ || !arpButton_->isChecked() || arpeggiatorHeldNotes_.empty()) {
            stopArpeggiator(false);
            return;
        }
        releaseArpeggiatorCurrentNote();
        auto notes = arpeggiatorHeldNotes_;
        std::stable_sort(notes.begin(), notes.end(), [](const auto &a, const auto &b) {
            if (a.note != b.note) return a.note < b.note;
            return a.voiceSlot < b.voiceSlot;
        });
        const int count = static_cast<int>(notes.size());
        const int pattern = arpSpin_ ? std::clamp(arpSpin_->value(), 1, 12) : 1;
        const int direction = (pattern - 1) / 4;
        int index = 0;
        if (direction == 0) index = arpeggiatorStep_ % count;
        else if (direction == 1) index = count - 1 - (arpeggiatorStep_ % count);
        else if (count == 1) index = 0;
        else {
            const int period = count * 2 - 2;
            const int phase = arpeggiatorStep_ % period;
            index = phase < count ? phase : period - phase;
        }
        const auto note = notes[static_cast<std::size_t>(index)];
        arpeggiatorCurrentNote_ = note.note;
        arpeggiatorCurrentVoiceSlot_ = note.voiceSlot;
        arpeggiatorCurrentLayered_ = layerEnabled_ && note.voiceSlot == 0;
        arpeggiatorCurrentInternalOnly_ = note.internalOnly;
        const auto status = static_cast<quint8>(0x90 | note.voiceSlot);
        if (note.internalOnly) sendInternalMidiOnly(status, note.note, std::clamp(note.velocity, 1, 127), internalVoiceChannel(note.voiceSlot));
        else sendMidi(status, static_cast<quint8>(note.note), static_cast<quint8>(std::clamp(note.velocity, 1, 127)), internalVoiceChannel(note.voiceSlot));
        captureEvent(status, note.note, note.velocity);
        if (arpeggiatorCurrentLayered_) {
            if (note.internalOnly) sendInternalMidiOnly(0x92, note.note, std::clamp(note.velocity, 1, 127), internalVoiceChannel(2));
            else sendMidi(0x92, static_cast<quint8>(note.note), static_cast<quint8>(std::clamp(note.velocity, 1, 127)), internalVoiceChannel(2));
            captureEvent(0x92, note.note, note.velocity);
        }
        ++arpeggiatorStep_;
        updateArpeggiatorTimer();
    }

    void applyInitialMixerLevels() {
        for (int i = 0; i < 16; ++i) {
            const auto *slider = channelMixerSliders_[static_cast<std::size_t>(i)];
            if (!slider) continue;
            sendMidi(static_cast<quint8>(0xB0 | i), 7, static_cast<quint8>(slider->value()), i);
        }
        for (int lane = 16; lane < 19; ++lane) {
            const auto *slider = channelMixerSliders_[static_cast<std::size_t>(lane)];
            if (!slider) continue;
            const int slot = lane == 16 ? 1 : (lane == 17 ? 0 : 2);
            sendMidi(static_cast<quint8>(0xB0 | slot), 7, static_cast<quint8>(slider->value()), internalVoiceChannel(slot));
        }
    }

    void onKeyboardNote(int note, bool pressed, int velocity = 100, bool internalInputOnly = false) {
        const int statusType = pressed ? 0x90 : 0x80;
        const auto emitNote = [this, internalInputOnly](quint8 status, quint8 noteValue, quint8 noteVelocity, int channel) {
            if (internalInputOnly) sendInternalMidiOnly(status, noteValue, noteVelocity, channel);
            else sendMidi(status, noteValue, noteVelocity, channel);
        };
        const bool chordRegion = accompanimentEnabled_ && note <= splitKey_;
        const int visualNoteType = chordRegion ? 1 : 0;
        if (pianoKeyboard_) pianoKeyboard_->setActiveNote(note, pressed, visualNoteType);

        int outputNote = note;
        if (transposeActive_) outputNote += transposeAmount_;
        if (octaveShiftActive_) outputNote += octaveShiftAmount_ * 12;
        outputNote = std::clamp(outputNote, 0, 127);
        const int effectiveVelocity = pressed ? std::clamp(velocity, 1, 127) : 0;

        if (chordRegion) {
            // The original Synthesizer sends the transposed key to chord_finder,
            // even when no style file is loaded; a style is not a prerequisite
            // for chord detection or the fallback chord voice.
            int detectedType = 0;
            const int detectedRoot = chord_finder_infer(outputNote, statusType, &detectedType);
            if (detectedRoot > -6) {
                styleEngine_.changeChord(detectedRoot, detectedType);
                updateChordLabel(detectedRoot, detectedType);
            }
            sendFallbackChordVoicing(outputNote, pressed, effectiveVelocity, detectedRoot);
            return; // Original lower keyboard region is chord control while accompaniment is enabled.
        }

        const int primarySlot = (splitEnabled_ && note <= splitKey_) ? 1 : 0; // slot 1 is voice L, internally channel 19
        if (arpButton_ && arpButton_->isChecked()) {
            const auto found = std::find_if(arpeggiatorHeldNotes_.begin(), arpeggiatorHeldNotes_.end(),
                [outputNote, primarySlot](const ArpeggiatorHeldNote &held) { return held.note == outputNote && held.voiceSlot == primarySlot; });
            if (pressed) {
                if (found == arpeggiatorHeldNotes_.end())
                    arpeggiatorHeldNotes_.push_back({outputNote, primarySlot, effectiveVelocity, internalInputOnly});
                updateArpeggiatorTimer();
            } else if (found != arpeggiatorHeldNotes_.end()) {
                arpeggiatorHeldNotes_.erase(found);
                if (arpeggiatorHeldNotes_.empty()) stopArpeggiator(false);
            }
            return;
        }
        const auto status = static_cast<quint8>(statusType | primarySlot);
        emitNote(status, static_cast<quint8>(outputNote), static_cast<quint8>(effectiveVelocity), internalVoiceChannel(primarySlot));
        captureEvent(status, outputNote, effectiveVelocity);
        // Original synthesizer layers the second right-hand voice only on the right side.
        if (layerEnabled_ && primarySlot == 0) {
            const auto layerStatus = static_cast<quint8>(statusType | 2);
            emitNote(layerStatus, static_cast<quint8>(outputNote), static_cast<quint8>(effectiveVelocity), internalVoiceChannel(2));
            captureEvent(layerStatus, outputNote, effectiveVelocity);
        }
    }
    void loadVoiceCatalog() {
        voiceCatalog_.clear();
        const QString appDir = QCoreApplication::applicationDirPath();
        const QStringList candidates = {
            QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SCVSC.tnf")),
            QDir(appDir).filePath(QStringLiteral("../plugins/SCVA/SCVSC.tnf")),
            QDir::current().filePath(QStringLiteral("plugins/SCVA/SCVSC.tnf")),
            QDir::current().filePath(QStringLiteral("../plugins/SCVA/SCVSC.tnf"))
        };
        QString tnfPath;
        for (const QString &candidate : candidates) if (QFileInfo::exists(candidate)) { tnfPath = candidate; break; }
        if (tnfPath.isEmpty()) return;
        QFile file(tnfPath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
        const QString text = QString::fromLocal8Bit(file.readAll());
        int currentMap = 0;
        const auto lines = text.split(QLatin1Char('\n'));
        for (const QString &line : lines) {
            const QString trimmed = line.trimmed();
            if (trimmed.startsWith(QStringLiteral("PAGE="))) {
                const QString page = trimmed.mid(5).trimmed().section(QLatin1Char('\t'), 0, 0).section(QLatin1Char(' '), 0, 0).trimmed();
                bool ok = false; const int p = page.toInt(&ok);
                currentMap = ok ? p : 0;
                continue;
            }
            if (currentMap < 1 || currentMap > 4 || !trimmed.contains(QLatin1Char('\t'))) continue;
            const QStringList cells = line.split(QLatin1Char('\t'), Qt::KeepEmptyParts);
            if (cells.size() < 2) continue;
            bool programOk = false;
            const int oneBasedProgram = cells[0].trimmed().toInt(&programOk);
            if (!programOk || oneBasedProgram < 1 || oneBasedProgram > 128 || cells[1].trimmed().isEmpty()) continue;
            // TNF column 1 is bank 0; each following cell is CC0 variation bank 1..127.
            for (int column = 1; column < cells.size() && column <= 128; ++column) {
                const QString name = cells[column].trimmed();
                if (name.isEmpty()) continue;
                VoiceCatalogEntry entry;
                entry.program = oneBasedProgram - 1;
                entry.bank = column - 1;
                entry.map = currentMap;
                entry.name = name;
                entry.category = voiceCategoryForProgram(entry.program);
                voiceCatalog_.push_back(std::move(entry));
            }
        }
    }

    bool voiceMatchesPickerFamily(const VoiceCatalogEntry &entry, const QString &family) const {
        const int p = entry.program;
        if (family == QStringLiteral("All Voice Types")) return true;
        if (family == QStringLiteral("Piano")) return p >= 0 && p <= 7;
        if (family == QStringLiteral("Crm Perc")) return p >= 8 && p <= 15;
        if (family == QStringLiteral("Organ")) return p >= 16 && p <= 23;
        if (family == QStringLiteral("Guitar")) return p >= 24 && p <= 31;
        if (family == QStringLiteral("Bass")) return p >= 32 && p <= 39;
        if (family == QStringLiteral("Strings")) return p >= 40 && p <= 55; // Strings + Ensemble, matching the legacy 12-button surface.
        if (family == QStringLiteral("Brass")) return p >= 56 && p <= 63;
        if (family == QStringLiteral("Reed/Pipe")) return p >= 64 && p <= 79;
        if (family == QStringLiteral("Synth Lead")) return p >= 80 && p <= 87;
        if (family == QStringLiteral("Synth Pad")) return p >= 88 && p <= 95;
        if (family == QStringLiteral("Extra")) return p >= 96 && p <= 127;
        return false; // A drum kit is a percussion bank/channel, not a melodic program family.
    }

    QString voiceThumbnailPath(const VoiceCatalogEntry &entry) const {
        const QString appDir = QCoreApplication::applicationDirPath();
        QStringList roots = {
            QDir(appDir).filePath(QStringLiteral("data/Images/Instruments")),
            QDir(appDir).filePath(QStringLiteral("../data/Images/Instruments")),
            QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("legacy-reference/data/Images/Instruments")),
            QDir::current().filePath(QStringLiteral("data/Images/Instruments")),
            QDir::current().filePath(QStringLiteral("legacy-reference/data/Images/Instruments"))
        };
        QString familyAsset = entry.category;
        if (familyAsset == QStringLiteral("Chromatic Percussion")) familyAsset = QStringLiteral("Chromatic Perc");
        else if (familyAsset == QStringLiteral("Reed") || familyAsset == QStringLiteral("Pipe")) familyAsset = QStringLiteral("Reed_Pipe");
        else if (familyAsset == QStringLiteral("Ensemble")) familyAsset = QStringLiteral("Strings");
        else if (familyAsset == QStringLiteral("Synth Effects") || familyAsset == QStringLiteral("Sound Effects")) familyAsset = QStringLiteral("GM Extra");
        else familyAsset.replace(QLatin1Char('/'), QLatin1Char('_'));
        for (const QString &root : roots) {
            const QString exact = QDir(root).filePath(entry.name + QStringLiteral(".jpg"));
            if (QFileInfo::exists(exact)) return exact;
        }
        for (const QString &root : roots) {
            const QString family = QDir(root).filePath(familyAsset + QStringLiteral(".jpg"));
            if (QFileInfo::exists(family)) return family;
        }
        return {};
    }

    static QString voiceSelectCategoryForProgram(int program) {
        // Canonical GM program-family fallback (program is zero-based).
        // The Voice Select UI deliberately keeps the reference's category names.
        const int p = std::clamp(program, 0, 127);
        if (p <= 3) return QStringLiteral("Piano");
        if (p <= 7) return QStringLiteral("E.Piano");
        if (p <= 15) return QStringLiteral("Chromatic Perc");
        if (p <= 23) return QStringLiteral("Organ");
        if (p <= 31) return QStringLiteral("Guitar");
        if (p <= 39) return QStringLiteral("Bass");
        if (p <= 55) return QStringLiteral("Strings");
        if (p <= 63) return QStringLiteral("Brass");
        if (p <= 79) return QStringLiteral("Reed/Pipe");
        if (p <= 95) return QStringLiteral("Synth");
        return QStringLiteral("Extra");
    }

    static QString voiceSelectCategoryForEntry(const VoiceCatalogEntry &entry) {
        // SCVA variation-bank names are not guaranteed to match the GM family
        // of their program number. Classify recognizable instrument names first;
        // use the canonical GM family only when the name is ambiguous.
        const QString n = entry.name.trimmed().toLower();
        auto has = [&n](std::initializer_list<const char *> words) {
            for (const char *word : words) if (n.contains(QString::fromLatin1(word))) return true;
            return false;
        };
        if (has({"bass", "finger", "slap", "fretless", "upright bass"})) return QStringLiteral("Bass");
        if (has({"piano", "grand piano", "bright piano", "honky-tonk", "honky tonk"})) {
            if (has({"electric", "e.piano", "epiano", "rhodes", "wurli", "wurlitzer", "fm piano", "dx piano"})) return QStringLiteral("E.Piano");
            return QStringLiteral("Piano");
        }
        if (has({"e.piano", "epiano", "electric piano", "rhodes", "wurli", "wurlitzer", "dx piano", "fm piano", "clavinet", "clavi", "harpsichord"})) return QStringLiteral("E.Piano");
        if (has({"organ", "orgen", "church organ", "drawbar", "percussive organ", "rotary", "accordion", "harmonica"})) return QStringLiteral("Organ");
        if (has({"guitar", "nylon", "steel guitar", "strat", "telecaster", "overdrive guitar", "distortion guitar"})) return QStringLiteral("Guitar");
        if (has({"violin", "viola", "cello", "string", "strings", "ensemble", "orchestra", "harp", "tremolo", "pizzicato", "choir", "aahs"})) return QStringLiteral("Strings");
        if (has({"trumpet", "trombone", "tuba", "brass", "horn", "cornet", "flugel"})) return QStringLiteral("Brass");
        if (has({"sax", "oboe", "english horn", "bassoon", "clarinet", "piccolo", "flute", "recorder", "pan flute", "whistle", "pipe", "shakuhachi", "ocarina", "bag pipe", "shanai"})) return QStringLiteral("Reed/Pipe");
        if (has({"synth", "synth.", "syn.", "lead", "pad", "impulse", "saw", "square", "polysynth", "fx ", "soundtrack", "rain", "halo", "sweep", "funny vox", "voice", "vox"})) return QStringLiteral("Synth");
        if (has({"celesta", "glockenspiel", "music box", "vibraphone", "marimba", "xylophone", "tubular bell", "dulcimer", "bell", "chime", "kalimba", "steel drum", "agogo", "woodblock", "taiko", "tom", "cymbal", "percussion"})) return QStringLiteral("Chromatic Perc");
        if (has({"sitar", "banjo", "shamisen", "koto", "fiddle", "ethnic", "bagpipe"})) return QStringLiteral("Extra");
        return voiceSelectCategoryForProgram(entry.program);
    }

    void ensureVoiceSelectPage() {
        if (voiceSelectPageWidget_) return;
        if (!lcdVoicePickerPage_) return;

        // Everything is attached to lcdVoicePickerPage_ inside lcdContentStack_.
        // No QDialog/QWindow is created here: the selector takes over the central
        // LCD surface while all mixer, transport, keyboard, and side panels stay put.
        auto *page = lcdVoicePickerPage_;
        voiceSelectPageWidget_ = page;
        auto *root = new QVBoxLayout(page);
        root->setContentsMargins(5, 5, 5, 5);
        root->setSpacing(5);
        page->setStyleSheet(QStringLiteral(
            "QWidget#lcdVoicePickerPage{background:#1b1b1b;color:#eeeeee;}"
            "QFrame#voiceSelectHeader{background:#182c4b;border:0;border-radius:7px;}"
            "QLabel#voiceSelectTitle{color:#f5f7fb;font-size:10pt;font-weight:700;background:transparent;border:0;}"
            "QLabel#voiceSelectSectionTitle{color:#e4e6ea;font-size:8pt;font-weight:700;background:transparent;border:0;}"
            "QLabel#voiceSelectFooter{color:#b9bec6;font-size:7pt;background:transparent;border:0;}"
            "QPushButton#voiceSelectClose{color:#e8eef7;background:transparent;border:0;font-size:12pt;font-weight:600;padding:0;}"
            "QPushButton#voiceSelectClose:hover{color:#ffffff;background:#293b59;border-radius:4px;}"
            "QPushButton#voiceSelectModelButton{background:#35465f;color:#f3f5fa;border:0;border-radius:4px;padding:3px 3px;min-height:25px;font-size:8pt;}"
            "QPushButton#voiceSelectModelButton[active=\"true\"]{background:#168db6;color:white;}"
            "QPushButton#voiceSelectModelButton:hover{background:#426080;}"
            "QPushButton#voiceSelectModelButton[active=\"true\"]:hover{background:#1a9bc7;}"
            "QListWidget#voiceSelectCategoryList{background:transparent;color:#eeeeee;border:0;outline:0;padding:0;font-size:8pt;}"
            "QListWidget#voiceSelectCategoryList::item{background:transparent;color:#eeeeee;border:0;border-radius:5px;padding:0 6px;margin:1px 0;min-height:25px;}"
            "QListWidget#voiceSelectCategoryList::item:hover{background:#2a3541;}"
            "QListWidget#voiceSelectCategoryList::item:selected{background:#197da5;color:#ffffff;}"
            "QScrollBar:vertical{background:#1b1b1b;width:6px;margin:0;}"
            "QScrollBar::handle:vertical{background:#424e60;min-height:20px;border-radius:3px;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
            "QPushButton#voiceSelectPatchButton{background:#1d1d1d;color:#e8e8e8;border:1px solid #5d6b80;border-radius:5px;text-align:left;padding:0 6px;min-height:29px;font-size:8pt;}"
            "QPushButton#voiceSelectPatchButton:hover{background:#2a3039;border-color:#7e96b4;}"
            "QPushButton#voiceSelectPatchButton[selected=\"true\"]{background:#e7e7e7;color:#102033;border:1px solid #2097c3;font-weight:600;}"
            "QPushButton#voiceSelectPatchButton[selected=\"true\"]:hover{background:#f0f0f0;}"
            "QPushButton#voiceSelectPageButton{background:#303030;color:#d8dce2;border:0;border-radius:10px;min-width:23px;min-height:21px;padding:0 4px;font-size:7pt;font-weight:600;}"
            "QPushButton#voiceSelectPageButton[active=\"true\"]{background:#0d3155;color:#4ebdff;}"
            "QPushButton#voiceSelectPageButton:disabled{color:#777777;background:transparent;}"
            "QPushButton#voiceSelectArrow{background:transparent;color:#dedede;border:0;min-width:16px;min-height:20px;font-size:12pt;}"
            "QPushButton#voiceSelectArrow:disabled{color:#4c4c4c;}"
            "QLabel#voiceSelectEmpty{color:#adb4be;background:transparent;font-size:8pt;}") );

        auto *header = new QFrame(page);
        header->setObjectName(QStringLiteral("voiceSelectHeader"));
        auto *headerLayout = new QVBoxLayout(header);
        headerLayout->setContentsMargins(8, 5, 8, 6);
        headerLayout->setSpacing(4);
        auto *titleRow = new QHBoxLayout;
        titleRow->setContentsMargins(0, 0, 0, 0);
        titleRow->setSpacing(4);
        voiceSelectTitleLabel_ = new QLabel(QStringLiteral("VOICE SELECT — SC-8820"), header);
        voiceSelectTitleLabel_->setObjectName(QStringLiteral("voiceSelectTitle"));
        titleRow->addWidget(voiceSelectTitleLabel_, 1);
        auto *closeButton = new QPushButton(QStringLiteral("×"), header);
        closeButton->setObjectName(QStringLiteral("voiceSelectClose"));
        closeButton->setFixedSize(20, 20);
        closeButton->setToolTip(QStringLiteral("Kembali ke LCD utama"));
        connect(closeButton, &QPushButton::clicked, this, [this] {
            if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
        });
        titleRow->addWidget(closeButton, 0, Qt::AlignRight | Qt::AlignVCenter);
        headerLayout->addLayout(titleRow);

        auto *modelRow = new QHBoxLayout;
        modelRow->setContentsMargins(0, 0, 0, 0);
        modelRow->setSpacing(4);
        voiceSelectModelButtons_.clear();
        const std::array<std::pair<const char *, int>, 4> maps = {{{"SC-8820", 4}, {"SC-88Pro", 3}, {"SC-88", 2}, {"SC-55", 1}}};
        for (const auto &mapInfo : maps) {
            auto *button = new QPushButton(QString::fromLatin1(mapInfo.first), header);
            button->setObjectName(QStringLiteral("voiceSelectModelButton"));
            button->setCheckable(true);
            button->setAutoExclusive(true);
            button->setProperty("map", mapInfo.second);
            const int mapValue = mapInfo.second;
            connect(button, &QPushButton::clicked, this, [this, mapValue] {
                voiceSelectMap_ = mapValue;
                voiceSelectPage_ = 0;
                refreshVoiceSelectPage();
            });
            voiceSelectModelButtons_.push_back(button);
            modelRow->addWidget(button, 1);
        }
        headerLayout->addLayout(modelRow);
        root->addWidget(header, 0);

        auto *body = new QWidget(page);
        auto *bodyLayout = new QHBoxLayout(body);
        bodyLayout->setContentsMargins(0, 0, 0, 0);
        bodyLayout->setSpacing(5);
        auto *categoryColumn = new QWidget(body);
        categoryColumn->setMinimumWidth(88);
        categoryColumn->setMaximumWidth(112);
        auto *categoryColumnLayout = new QVBoxLayout(categoryColumn);
        categoryColumnLayout->setContentsMargins(0, 0, 0, 0);
        categoryColumnLayout->setSpacing(2);
        auto *categoryHeading = new QLabel(QStringLiteral("CATEGORY"), categoryColumn);
        categoryHeading->setObjectName(QStringLiteral("voiceSelectSectionTitle"));
        categoryColumnLayout->addWidget(categoryHeading);
        voiceSelectCategoryList_ = new QListWidget(categoryColumn);
        voiceSelectCategoryList_->setObjectName(QStringLiteral("voiceSelectCategoryList"));
        voiceSelectCategoryList_->setSelectionMode(QAbstractItemView::SingleSelection);
        voiceSelectCategoryList_->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        voiceSelectCategoryList_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        voiceSelectCategoryList_->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        const std::array<const char *, 11> categoryNames = {
            "Piano", "E.Piano", "Organ", "Guitar", "Bass", "Strings", "Brass", "Synth",
            "Chromatic Perc", "Reed/Pipe", "Extra"
        };
        for (const char *category : categoryNames) {
            auto *item = new QListWidgetItem(QString::fromLatin1(category));
            item->setSizeHint(QSize(90, 26));
            voiceSelectCategoryList_->addItem(item);
        }
        categoryColumnLayout->addWidget(voiceSelectCategoryList_, 1);
        bodyLayout->addWidget(categoryColumn, 0);

        voiceSelectGridHost_ = new QWidget(body);
        voiceSelectGridHost_->setObjectName(QStringLiteral("voiceSelectGridHost"));
        auto *gridHostLayout = new QVBoxLayout(voiceSelectGridHost_);
        gridHostLayout->setContentsMargins(0, 0, 0, 0);
        gridHostLayout->setSpacing(0);
        voiceSelectGridLayout_ = new QGridLayout;
        voiceSelectGridLayout_->setContentsMargins(0, 0, 0, 0);
        voiceSelectGridLayout_->setHorizontalSpacing(2);
        voiceSelectGridLayout_->setVerticalSpacing(2);
        voiceSelectGridLayout_->setColumnStretch(0, 1);
        voiceSelectGridLayout_->setColumnStretch(1, 1);
        gridHostLayout->addLayout(voiceSelectGridLayout_, 1);
        bodyLayout->addWidget(voiceSelectGridHost_, 1);
        root->addWidget(body, 1);

        auto *footer = new QHBoxLayout;
        footer->setContentsMargins(1, 0, 1, 0);
        footer->setSpacing(3);
        voiceSelectPageSummaryLabel_ = new QLabel(QStringLiteral("12 Voice per halaman"), page);
        voiceSelectPageSummaryLabel_->setObjectName(QStringLiteral("voiceSelectFooter"));
        footer->addWidget(voiceSelectPageSummaryLabel_);
        footer->addStretch(1);
        voiceSelectPreviousPageButton_ = new QPushButton(QStringLiteral("‹"), page);
        voiceSelectPreviousPageButton_->setObjectName(QStringLiteral("voiceSelectArrow"));
        voiceSelectPreviousPageButton_->setToolTip(QStringLiteral("Halaman sebelumnya"));
        footer->addWidget(voiceSelectPreviousPageButton_);
        voiceSelectPageButtonsLayout_ = new QHBoxLayout;
        voiceSelectPageButtonsLayout_->setContentsMargins(0, 0, 0, 0);
        voiceSelectPageButtonsLayout_->setSpacing(3);
        footer->addLayout(voiceSelectPageButtonsLayout_);
        voiceSelectNextPageButton_ = new QPushButton(QStringLiteral("›"), page);
        voiceSelectNextPageButton_->setObjectName(QStringLiteral("voiceSelectArrow"));
        voiceSelectNextPageButton_->setToolTip(QStringLiteral("Halaman berikutnya"));
        footer->addWidget(voiceSelectNextPageButton_);
        root->addLayout(footer);

        connect(voiceSelectCategoryList_, &QListWidget::currentTextChanged, this, [this](const QString &category) {
            if (category.isEmpty()) return;
            voiceSelectCategory_ = category;
            voiceSelectPage_ = 0;
            refreshVoiceSelectPage();
        });
        connect(voiceSelectPreviousPageButton_, &QPushButton::clicked, this, [this] {
            if (voiceSelectPage_ > 0) { --voiceSelectPage_; refreshVoiceSelectPage(); }
        });
        connect(voiceSelectNextPageButton_, &QPushButton::clicked, this, [this] {
            const int pages = std::max(1, static_cast<int>((voiceSelectFilteredEntries_.size() + 11) / 12));
            if (voiceSelectPage_ + 1 < pages) { ++voiceSelectPage_; refreshVoiceSelectPage(); }
        });
        const QSignalBlocker blocker(voiceSelectCategoryList_);
        voiceSelectCategoryList_->setCurrentRow(0);
    }

    void openVoiceSelectPage(int channel, const QString &preferredCategory = QString()) {
        dataEntryStyleMode_ = false;
        selectedProgramChannel_ = std::clamp(channel, 0, 2);
        const auto slot = static_cast<std::size_t>(selectedProgramChannel_);
        voiceSelectMap_ = std::clamp(voiceMaps_[slot], 1, 4);
        voiceSelectCategory_ = preferredCategory.isEmpty()
            ? voiceSelectCategoryForProgram(voicePrograms_[slot]) : preferredCategory;
        if (voiceSelectCategory_ == QStringLiteral("Crm Perc")) voiceSelectCategory_ = QStringLiteral("Chromatic Perc");
        else if (voiceSelectCategory_ == QStringLiteral("Synth Lead") || voiceSelectCategory_ == QStringLiteral("Synth Pad")) voiceSelectCategory_ = QStringLiteral("Synth");
        else if (voiceSelectCategory_ == QStringLiteral("Drum Kit")) voiceSelectCategory_ = QStringLiteral("Extra");
        voiceSelectPage_ = 0;
        ensureVoiceSelectPage();
        if (!voiceSelectCategoryList_) return;
        {
            const QSignalBlocker blocker(voiceSelectCategoryList_);
            auto items = voiceSelectCategoryList_->findItems(voiceSelectCategory_, Qt::MatchExactly);
            const int row = items.isEmpty() ? 0 : voiceSelectCategoryList_->row(items.front());
            voiceSelectCategoryList_->setCurrentRow(row);
            voiceSelectCategory_ = voiceSelectCategoryList_->currentItem()
                ? voiceSelectCategoryList_->currentItem()->text() : QStringLiteral("Piano");
        }
        refreshVoiceSelectPage();

        int selectedIndex = -1;
        for (std::size_t i = 0; i < voiceSelectFilteredEntries_.size(); ++i) {
            const auto &entry = voiceSelectFilteredEntries_[i];
            if (entry.program == voicePrograms_[slot] && entry.bank == voiceBanks_[slot] && entry.map == voiceMaps_[slot]) {
                selectedIndex = static_cast<int>(i);
                break;
            }
        }
        if (selectedIndex >= 0) {
            voiceSelectPage_ = selectedIndex / 12;
            refreshVoiceSelectPage();
        }
        if (lcdContentStack_ && lcdVoicePickerPage_)
            lcdContentStack_->setCurrentWidget(lcdVoicePickerPage_);
    }

    void refreshVoiceSelectPage() {
        if (!voiceSelectPageWidget_ || !voiceSelectCategoryList_ || !voiceSelectGridLayout_) return;
        const std::array<const char *, 4> mapNames = {"", "SC-55", "SC-88", "SC-88Pro"};
        const QString mapName = voiceSelectMap_ == 4 ? QStringLiteral("SC-8820")
            : QString::fromLatin1(mapNames[static_cast<std::size_t>(std::clamp(voiceSelectMap_, 1, 3))]);
        if (voiceSelectTitleLabel_) voiceSelectTitleLabel_->setText(QStringLiteral("VOICE SELECT — %1").arg(mapName));
        for (auto *button : voiceSelectModelButtons_) {
            if (!button) continue;
            const bool active = button->property("map").toInt() == voiceSelectMap_;
            button->setProperty("active", active);
            button->setChecked(active);
            if (button->style()) { button->style()->unpolish(button); button->style()->polish(button); }
        }
        if (voiceSelectCategoryList_->currentItem()) voiceSelectCategory_ = voiceSelectCategoryList_->currentItem()->text();

        voiceSelectFilteredEntries_.clear();
        for (const auto &entry : voiceCatalog_) {
            if (entry.map != voiceSelectMap_) continue;
            if (voiceSelectCategoryForEntry(entry) != voiceSelectCategory_) continue;
            voiceSelectFilteredEntries_.push_back(entry);
        }
        std::stable_sort(voiceSelectFilteredEntries_.begin(), voiceSelectFilteredEntries_.end(), [](const auto &a, const auto &b) {
            if (a.program != b.program) return a.program < b.program;
            if (a.bank != b.bank) return a.bank < b.bank;
            return a.name.compare(b.name, Qt::CaseInsensitive) < 0;
        });
        const int pageCount = std::max(1, static_cast<int>((voiceSelectFilteredEntries_.size() + 11) / 12));
        voiceSelectPage_ = std::clamp(voiceSelectPage_, 0, pageCount - 1);

        while (auto *item = voiceSelectGridLayout_->takeAt(0)) {
            if (auto *widget = item->widget()) { widget->hide(); widget->deleteLater(); }
            delete item;
        }
        const auto selectedSlot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        const std::size_t start = static_cast<std::size_t>(voiceSelectPage_ * 12);
        const std::size_t end = std::min(start + 12, voiceSelectFilteredEntries_.size());
        int localIndex = 0;
        for (std::size_t i = start; i < end; ++i, ++localIndex) {
            const VoiceCatalogEntry entry = voiceSelectFilteredEntries_[i];
            auto *button = new QPushButton(entry.name, voiceSelectGridHost_);
            button->setObjectName(QStringLiteral("voiceSelectPatchButton"));
            const bool selected = entry.program == voicePrograms_[selectedSlot]
                && entry.bank == voiceBanks_[selectedSlot] && entry.map == voiceMaps_[selectedSlot];
            button->setProperty("selected", selected);
            if (button->style()) { button->style()->unpolish(button); button->style()->polish(button); }
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            button->setToolTip(QStringLiteral("%1\nProgram %2 · CC0 bank %3 · %4").arg(entry.name).arg(entry.program + 1).arg(entry.bank).arg(mapName));
            connect(button, &QPushButton::clicked, this, [this, entry] {
                applyVoiceCatalogEntry(entry);
                refreshVoiceSelectPage();
            });
            voiceSelectGridLayout_->addWidget(button, localIndex / 2, localIndex % 2);
        }
        if (localIndex == 0) {
            auto *empty = new QLabel(QStringLiteral("Tidak ada Voice pada kategori ini untuk map %1.").arg(mapName), voiceSelectGridHost_);
            empty->setObjectName(QStringLiteral("voiceSelectEmpty"));
            empty->setAlignment(Qt::AlignCenter);
            voiceSelectGridLayout_->addWidget(empty, 0, 0, 1, 2);
        }
        // Always occupy the same 6 x 2 matrix. Without these empty cells Qt
        // distributes the full LCD height among only the final 1-2 entries,
        // making the last page's buttons much larger than the rest.
        if (localIndex == 0) {
            // Empty-category message already spans the grid; keep its height stable.
            for (int row = 0; row < 6; ++row) voiceSelectGridLayout_->setRowStretch(row, 1);
        } else {
            while (localIndex < 12) {
                const int row = localIndex / 2;
                const int col = localIndex % 2;
                auto *spacerCell = new QWidget(voiceSelectGridHost_);
                spacerCell->setObjectName(QStringLiteral("voiceSelectEmptyCell"));
                spacerCell->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
                spacerCell->setAttribute(Qt::WA_TransparentForMouseEvents, true);
                voiceSelectGridLayout_->addWidget(spacerCell, row, col);
                ++localIndex;
            }
            for (int row = 0; row < 6; ++row) voiceSelectGridLayout_->setRowStretch(row, 1);
        }
        if (voiceSelectPageSummaryLabel_)
            voiceSelectPageSummaryLabel_->setText(QStringLiteral("12 Voice/page · %1 voices").arg(voiceSelectFilteredEntries_.size()));
        if (voiceSelectPreviousPageButton_) voiceSelectPreviousPageButton_->setEnabled(voiceSelectPage_ > 0);
        if (voiceSelectNextPageButton_) voiceSelectNextPageButton_->setEnabled(voiceSelectPage_ + 1 < pageCount);

        if (voiceSelectPageButtonsLayout_) {
            while (auto *item = voiceSelectPageButtonsLayout_->takeAt(0)) {
                if (auto *widget = item->widget()) { widget->hide(); widget->deleteLater(); }
                delete item;
            }
            int firstPage = 0;
            if (pageCount > 3) firstPage = std::clamp(voiceSelectPage_ - 1, 0, pageCount - 3);
            const int lastPage = std::min(pageCount, firstPage + 3);
            for (int pageNo = firstPage; pageNo < lastPage; ++pageNo) {
                auto *pageButton = new QPushButton(QStringLiteral("P%1").arg(pageNo + 1), voiceSelectPageWidget_);
                pageButton->setObjectName(QStringLiteral("voiceSelectPageButton"));
                pageButton->setProperty("active", pageNo == voiceSelectPage_);
                pageButton->setCheckable(true);
                pageButton->setChecked(pageNo == voiceSelectPage_);
                if (pageButton->style()) { pageButton->style()->unpolish(pageButton); pageButton->style()->polish(pageButton); }
                connect(pageButton, &QPushButton::clicked, this, [this, pageNo] {
                    voiceSelectPage_ = pageNo;
                    refreshVoiceSelectPage();
                });
                voiceSelectPageButtonsLayout_->addWidget(pageButton);
            }
        }
    }

    void refreshVoicePickerPage() {
        startupTrace("voicePicker: refresh entered");
        if (!lcdVoiceList_ || !lcdVoiceMapCombo_ || !lcdVoiceCategoryCombo_ || !lcdVoiceBankCombo_) {
            startupTrace("voicePicker: required widget pointer missing; return");
            return;
        }
        const int map = lcdVoiceMapCombo_->currentData().toInt();
        const QString family = lcdVoiceCategoryCombo_->currentText();
        const int bankFilter = lcdVoiceBankCombo_->currentData().toInt(); // 0 = standard bank; -1 = all SCVA variations.
        const int selectedSlot = std::clamp(selectedProgramChannel_, 0, 2);
        filteredVoiceCatalog_.clear();
        for (const auto &entry : voiceCatalog_) {
            if (entry.map != map) continue;
            if (bankFilter >= 0 && entry.bank != bankFilter) continue;
            if (!voiceMatchesPickerFamily(entry, family)) continue;
            filteredVoiceCatalog_.push_back(entry);
        }
        std::stable_sort(filteredVoiceCatalog_.begin(), filteredVoiceCatalog_.end(), [](const auto &a, const auto &b) {
            if (a.program != b.program) return a.program < b.program;
            return a.bank < b.bank;
        });
        startupTrace((std::string("voicePicker: filtered count=") + std::to_string(filteredVoiceCatalog_.size()) +
                      ", vertical list, bank filter=" + std::to_string(bankFilter)).c_str());
        const QSignalBlocker blocker(lcdVoiceList_);
        lcdVoiceList_->clear();
        int selectedRow = -1;
        for (std::size_t i = 0; i < filteredVoiceCatalog_.size(); ++i) {
            const auto &entry = filteredVoiceCatalog_[i];
            auto *item = new QListWidgetItem(entry.name);
            item->setData(Qt::UserRole, entry.program);
            item->setData(Qt::UserRole + 1, QStringLiteral("Program %1 · Bank %2").arg(entry.program + 1).arg(entry.bank));
            item->setData(Qt::UserRole + 2, entry.category);
            item->setData(Qt::UserRole + 3, entry.bank);
            item->setData(Qt::UserRole + 4, entry.map);
            const QString thumbPath = voiceThumbnailPath(entry);
            if (!thumbPath.isEmpty()) item->setIcon(QIcon(QPixmap(thumbPath).scaled(54, 36, Qt::KeepAspectRatio, Qt::FastTransformation)));
            item->setToolTip(QStringLiteral("%1 · %2 · CC0 bank %3 · Program %4 · %5 map")
                .arg(entry.category, entry.name).arg(entry.bank).arg(entry.program + 1).arg(entry.map));
            lcdVoiceList_->addItem(item);
            if (entry.program == voicePrograms_[static_cast<std::size_t>(selectedSlot)] &&
                entry.bank == voiceBanks_[static_cast<std::size_t>(selectedSlot)] &&
                entry.map == voiceMaps_[static_cast<std::size_t>(selectedSlot)])
                selectedRow = static_cast<int>(i);
        }
        if (selectedRow >= 0 && selectedRow < lcdVoiceList_->count())
            lcdVoiceList_->setCurrentRow(selectedRow);
        if (lcdVoicePageLabel_) {
            const QString bankLabel = bankFilter == 0 ? QStringLiteral("Standard bank · CC0=0") : QStringLiteral("All SCVA variations");
            lcdVoicePageLabel_->setText(QStringLiteral("%1 voices · %2 · map %3")
                .arg(filteredVoiceCatalog_.size()).arg(bankLabel).arg(map));
        }
        startupTrace("voicePicker: refresh completed");
    }

    void applyVoiceCatalogSelection(int row) {
        if (row < 0 || !lcdVoiceList_ || !audioEngine_) return;
        auto *item = lcdVoiceList_->item(row);
        if (!item) return;
        VoiceCatalogEntry entry;
        entry.program = item->data(Qt::UserRole).toInt();
        entry.name = item->text();
        entry.category = item->data(Qt::UserRole + 2).toString();
        entry.bank = item->data(Qt::UserRole + 3).toInt();
        entry.map = item->data(Qt::UserRole + 4).toInt();
        applyVoiceCatalogEntry(entry);
    }

    void applyVoiceCatalogEntry(const VoiceCatalogEntry &entry) {
        if (!audioEngine_) return;
        const int program = std::clamp(entry.program, 0, 127);
        const int bank = std::clamp(entry.bank, 0, 127);
        const int map = std::clamp(entry.map, 1, 4);
        const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        voicePrograms_[slot] = program;
        voiceBanks_[slot] = bank;
        voiceMaps_[slot] = map;
        const int channel = selectedProgramChannel_;
        const int nativeChannel = internalVoiceChannel(channel);
        sendMidi(static_cast<quint8>(0xB0 | channel), 32, static_cast<quint8>(map), nativeChannel);
        sendMidi(static_cast<quint8>(0xB0 | channel), 0, static_cast<quint8>(bank), nativeChannel);
        sendMidi(static_cast<quint8>(0xC0 | channel), static_cast<quint8>(program), 0, nativeChannel);
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(program); }
        const QString name = entry.name.isEmpty() ? QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]) : entry.name;
        if (channel == 0 && voiceR1Label_) voiceR1Label_->setText(name);
        if (channel == 1 && voiceLLabel_) voiceLLabel_->setText(name);
        if (channel == 2 && voiceR2Label_) voiceR2Label_->setText(name);
        QSettings settings;
        settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]);
        settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]);
        settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
        settings.setValue(QStringLiteral("voiceNameR1"), voiceR1Label_ ? voiceR1Label_->text() : QString());
        settings.setValue(QStringLiteral("voiceNameL"), voiceLLabel_ ? voiceLLabel_->text() : QString());
        settings.setValue(QStringLiteral("voiceNameR2"), voiceR2Label_ ? voiceR2Label_->text() : QString());
        settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]);
        settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]);
        settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
        settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]);
        settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]);
        settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
        settings.sync();
        setStatus(QStringLiteral("Voice %1 · program %2 · bank %3 · %4").arg(name).arg(program + 1).arg(bank).arg(
            map == 4 ? QStringLiteral("SC-8820") : map == 3 ? QStringLiteral("SC-88Pro") : map == 2 ? QStringLiteral("SC-88") : QStringLiteral("SC-55")));
    }

    void sendGsDt1(std::uint8_t ah, std::uint8_t am, std::uint8_t al, std::uint8_t value) {
        if (!audioEngine_) return;
        const auto packet = makeGsDt1(ah, am, al, value);
        audioEngine_->sendSysEx(std::span<const std::uint8_t>(packet.data(), packet.size()));
    }

    void applyNativeEfxSettings(bool resetParameters = false) {
        if (!nativeEfxTypeCombo_) return;
        const int index = std::clamp(nativeEfxTypeCombo_->currentIndex(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1);
        const int key = kNativeEfxChoices[static_cast<std::size_t>(index)].key;
        sendGsDt1(0x40, 0x03, 0x00, static_cast<std::uint8_t>((key >> 8) & 0x7f));
        sendGsDt1(0x40, 0x03, 0x01, static_cast<std::uint8_t>(key & 0x7f));
        if (resetParameters) {
            for (auto *parameter : nativeEfxParams_) {
                if (!parameter || parameter->value() == -1) continue;
                const QSignalBlocker blocker(parameter);
                parameter->setValue(-1); // Changing algorithms restores the effect's own ROM defaults.
            }
        }
        // GS part block 40 4x 22: 00=bypass, 01=EFX. Route all 16 parts.
        const std::uint8_t route = nativeEfxCheck_ && nativeEfxCheck_->isChecked() && key != 0 ? 1 : 0;
        for (int channel = 0; channel < 16; ++channel) {
            const int partNibble = channel == 9 ? 0 : (channel < 9 ? channel + 1 : channel); // GS block order: 1..9, 0, A..F.
            sendGsDt1(0x40, static_cast<std::uint8_t>(0x40 | partNibble), 0x22, route);
        }
        QSettings settings;
        settings.setValue(QStringLiteral("nativeEfxOn"), nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        settings.setValue(QStringLiteral("nativeEfxType"), index);
        settings.sync();
    }

    void updateModulationTimer() {
        const bool needTimer = metronomeCheck_->isChecked() || lfoCheck_->isChecked();
        if (needTimer && !modulationTimer_.isActive()) {
            modulationClock_.start(); nextBeatUs_ = 0; lastLfoUs_ = 0; beatCount_ = 0; modulationTimer_.start();
        } else if (!needTimer) {
            modulationTimer_.stop();
        }
    }

    void onModulationTick() {
        if (!modulationClock_.isValid()) return;
        const qint64 nowUs = modulationClock_.nsecsElapsed() / 1000;
        const qint64 beatUs = 60000000LL / std::max(1, tempo_);
        if (metronomeCheck_->isChecked() && nowUs >= nextBeatUs_) {
            nextBeatUs_ = nowUs + beatUs;
            ++beatCount_;
            if (metronomeCheck_->isChecked()) {
                const int note = (beatCount_ % 4 == 1) ? 76 : 77;
                playShortNote(9, note, (beatCount_ % 4 == 1) ? 115 : 78, 55);
            }
        }
        if (lfoCheck_->isChecked() && nowUs - lastLfoUs_ >= 40000) {
            lastLfoUs_ = nowUs;
            const double phase = static_cast<double>(nowUs) / 1000000.0 * 0.7 * 2.0 * 3.14159265358979323846;
            const int value = static_cast<int>(64.0 + 63.0 * std::sin(phase));
            sendMidi(0xB0, 1, static_cast<quint8>(std::clamp(value, 0, 127)));
            captureEvent(0xB0, 1, value);
        }
    }
};
} // namespace

int main(int argc, char *argv[]) {
    startupTrace("main: entry; next QApplication construction");
    QApplication app(argc, argv);
    startupTrace("main: QApplication constructed");
    QCoreApplication::setOrganizationName(QStringLiteral("Ensembles"));
    QCoreApplication::setApplicationName(QStringLiteral("Ensembles C++"));
    startupTrace("main: before EnsemblesWindow construction");
    EnsemblesWindow window;
    startupTrace("main: EnsemblesWindow constructed");
    window.show();
    if (QCoreApplication::arguments().contains(QStringLiteral("--voice-select-preview"))) {
        QTimer::singleShot(0, &window, [&window] { window.showVoiceSelectPreview(); });
    }
    startupTrace("main: window.show returned; entering Qt event loop");
    return app.exec();
}
