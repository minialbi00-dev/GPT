#include "performance_runtime.hpp"
#include <iostream>
#include <string>
#include <vector>

using arranger::PerformanceRuntime;

static bool expect(const PerformanceRuntime& p, int root, int type, const char* name,
                   const char* label, int held) {
    const auto& s = p.state();
    const bool ok = static_cast<int>(s.chord_root_pc) == root &&
                    static_cast<int>(s.chord_type) == type &&
                    s.chord_name == name &&
                    static_cast<int>(s.held_notes.size()) == held;
    std::cout << label << "=" << (ok ? "PASS" : "FAIL")
              << " CHORD=" << s.chord_name << " ROOT=" << int(s.chord_root_pc)
              << " TYPE=" << int(s.chord_type) << " HELD=" << s.held_notes.size() << "\n";
    return ok;
}

int main() {
    int fail = 0;
    PerformanceRuntime p;
    p.set_split_point(127); // unit-test the full synthetic keyboard range

    // Fingered compatibility + C++ native chord detection.
    p.note_on(60, 100); // C4
    if (!expect(p, 0, 0, "No Chord", "SINGLE_NOTE_FINGERED", 1)) ++fail;
    p.note_on(64, 100); // E4 — 1+3 alone is not a Yamaha Fingered chord; retain prior C.
    if (!expect(p, 0, 0, "No Chord", "TWO_NOTE_1_PLUS_3_WAITING_FOR_VALID", 2)) ++fail;
    p.note_on(67, 100); // G4
    if (!expect(p, 0, 0, "C", "C_MAJOR_TRIAD", 3)) ++fail;
    p.note_off(64);
    if (!expect(p, 0, 0, "C1+5", "C_AFTER_E_OFF_1_PLUS_5", 2)) ++fail;
    p.clear_notes();
    if (!expect(p, 0, 0, "C", "CLEAR", 0)) ++fail;

    p.note_on(60, 100); p.note_on(63, 100); p.note_on(67, 100);
    if (!expect(p, 0, 1, "Cm", "C_MINOR", 3)) ++fail;
    p.clear_notes();

    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100); p.note_on(70, 100);
    if (!expect(p, 0, 2, "C7", "C_7", 4)) ++fail;
    p.clear_notes();

    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100); p.note_on(71, 100);
    if (!expect(p, 0, 3, "CM7", "C_MAJ7", 4)) ++fail;
    p.clear_notes();

    // Inversion/bass tie-break: E-G-C is still C major because the Python
    // matcher gives a one-point bass preference to the candidate root only;
    // exact template still dominates the score.
    p.note_on(64, 100); p.note_on(67, 100); p.note_on(72, 100);
    if (!expect(p, 0, 0, "C", "C_INVERSION", 3)) ++fail;
    p.clear_notes();

    // Single Finger follows the physical adjacent left-key shapes documented by Yamaha.
    p.set_finger_mode(0);
    p.note_on(58, 100); p.note_on(60, 100);
    if (!expect(p, 0, 1, "Cm", "SINGLE_MINOR", 2)) ++fail;
    p.clear_notes();
    p.note_on(60, 100);
    if (!expect(p, 0, 0, "C", "SINGLE_MAJOR", 1)) ++fail;
    p.clear_notes();
    p.note_on(59, 100); p.note_on(60, 100);
    if (!expect(p, 0, 2, "C7", "SINGLE_7", 2)) ++fail;
    p.clear_notes();
    p.note_on(58, 100); p.note_on(59, 100); p.note_on(60, 100);
    if (!expect(p, 0, 4, "Cm7", "SINGLE_M7", 3)) ++fail;

    p.set_transpose(99);
    if (p.state().transpose != 12) { std::cout << "TRANSPOSE_CLAMP=FAIL\n"; ++fail; }
    else std::cout << "TRANSPOSE_CLAMP=PASS\n";
    p.set_transpose(-99);
    if (p.state().transpose != -12) { std::cout << "TRANSPOSE_CLAMP_NEG=FAIL\n"; ++fail; }
    else std::cout << "TRANSPOSE_CLAMP_NEG=PASS\n";

    p.set_acmp(true);
    if (!p.state().acmp_enabled) { std::cout << "ACMP_STATE=FAIL\n"; ++fail; }
    else std::cout << "ACMP_STATE=PASS\n";
    p.feed_midi(0x90, 60, 100);
    p.feed_midi(0x80, 60, 0);
    if (p.state().note_on_count != 26 || p.state().note_off_count != 2) {
        std::cout << "MIDI_DECODER_COUNTS=FAIL on=" << p.state().note_on_count
                  << " off=" << p.state().note_off_count << "\n";
        ++fail;
    } else std::cout << "MIDI_DECODER_COUNTS=PASS\n";

    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
