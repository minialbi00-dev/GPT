#include "native_gui_ppf_audio.hpp"
#include "ppf_reader.hpp"
#include "voice_install_catalog.hpp"

#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace arranger {
struct NativeGuiPpfAudioTestAccess {
    static bool handle(NativeGuiPpfAudio& a, const NativeGuiAudioEvent& e) noexcept { return a.handle_event(e); }
    static bool render(NativeGuiPpfAudio& a, float* dst, std::size_t frames, int rate) noexcept { return a.render_audio(dst, frames, rate); }
};
}

namespace {
struct E { std::uint32_t tick; std::uint8_t status,d1,d2; };
int hx(const std::string& s){ unsigned v=0; std::istringstream ss(s); ss>>std::hex>>v; return ss.fail()||v>255?-1:(int)v; }
std::vector<E> load(const std::string& path, std::uint16_t& div, std::string& err){
    std::ifstream f(path); if(!f){err="cannot open fixture: "+path; return {};}
    std::vector<E> out; std::string line; bool begin=false; div=480;
    while(std::getline(f,line)){
        if(line=="EVENTS_BEGIN"){begin=true;continue;} if(line=="EVENTS_END") break; if(!begin){
            if(line.rfind("DIVISION\t",0)==0) {
                div=(std::uint16_t)std::stoul(line.substr(9));
            }
            continue;
        }
        std::istringstream ss(line); std::string a,b,c,d;
        if(!std::getline(ss,a,'\t')||!std::getline(ss,b,'\t')||!std::getline(ss,c,'\t')||!std::getline(ss,d,'\t')) continue;
        long long t=std::stoll(a); int s=hx(b),d1=hx(c),d2=hx(d); if(t<0||t>0xffffffffLL||s<0||d1<0||d2<0){err="bad fixture line: "+line;return{};}
        out.push_back({(std::uint32_t)t,(std::uint8_t)s,(std::uint8_t)d1,(std::uint8_t)d2});
    }
    if(out.empty()) {
        err="fixture contains no events";
    }
    return out;
}
struct Addr { std::uint8_t msb=0,lsb=0,pc=0; bool operator<(const Addr& o)const{return std::tie(msb,lsb,pc)<std::tie(o.msb,o.lsb,o.pc);} };
}

int main(int argc,char** argv){
    const std::string ppf=argc>1?argv[1]:"tests/@YOGI MUSIC STUDIO (26).ppf";
    const std::string fixture=argc>2?argv[2]:"cpp_audio/tests/fixtures/baseline_timed_midi_replay.tsv";
    std::uint16_t division=480; std::string err; auto ev=load(fixture,division,err); if(ev.empty()){std::cerr<<"[FAIL] "<<err<<"\n";return 10;}
    arranger::PpfReader reader; if(!reader.open(ppf,err)){std::cerr<<"[FAIL] PPF open: "<<err<<"\n";return 11;}
    arranger::InstalledVoiceCatalog cat; if(!cat.install_ppf(reader,ppf,{0xFF,0xFF,0},err)){std::cerr<<"[FAIL] install: "<<err<<"\n";return 12;}
    std::array<std::uint8_t,16> msb{},lsb{},pc{}; std::set<Addr> ppf_addrs;
    for(const auto&e:ev){auto ch=(std::uint8_t)(e.status&0x0f); auto cmd=(std::uint8_t)(e.status&0xf0); if(ch>=16)continue; if(cmd==0xb0&&e.d1==0)msb[ch]=e.d2&127; else if(cmd==0xb0&&e.d1==32)lsb[ch]=e.d2&127; else if(cmd==0xc0)pc[ch]=e.d1&127; else if(cmd==0x90&&e.d2>0){arranger::StyleVoiceCall c{e.tick,ch,msb[ch],lsb[ch],pc[ch]}; arranger::InstalledVoiceResolution r; std::string re; if(cat.resolve_style_call(c,r,re)&&r.voice&&r.voice->format==arranger::InstalledVoiceFormat::PPF) ppf_addrs.insert({c.msb,c.lsb,c.program});}}
    if(ppf_addrs.empty()){std::cerr<<"[FAIL] no PPF addresses found in baseline stream\n";return 13;}

    std::size_t mapped=0, fail=0, preload_ok=0;
    for(const auto&a:ppf_addrs){
        arranger::StyleVoiceCall c{}; c.channel=0;c.msb=a.msb;c.lsb=a.lsb;c.program=a.pc;
        arranger::InstalledVoiceResolution r;
        if(!cat.resolve_style_call(c,r,err)||!r.voice){++fail; std::cerr<<"[FAIL] unresolved source "<<int(a.msb)<<"/"<<int(a.lsb)<<"/"<<int(a.pc)<<"\n"; continue;}
        const auto& v=*r.voice;
        const bool ok=v.format==arranger::InstalledVoiceFormat::PPF && v.source_address_valid && v.installed_address_valid &&
                      v.source_address.msb==a.msb&&v.source_address.lsb==a.lsb&&v.source_address.program==a.pc&&
                      v.installed_address.msb==a.msb&&v.installed_address.lsb==a.lsb&&v.installed_address.program==a.pc;
        std::cout<<"SOURCE="<<int(a.msb)<<"/"<<int(a.lsb)<<"/"<<int(a.pc)
                 <<" -> INSTALLED="<<int(v.installed_address.msb)<<"/"<<int(v.installed_address.lsb)<<"/"<<int(v.installed_address.program)
                 <<" SOURCE_INDEX="<<v.source_index<<" TITLE="<<v.title<<" "<<(ok?"PASS":"FAIL")<<"\n";
        if(!ok){++fail;continue;} ++mapped;
        arranger::NativeGuiPpfAudio audio; if(!audio.install_ppf_bank_audio_only(ppf,{0xFF,0xFF,0},err)){std::cerr<<"[FAIL] audio install: "<<err<<"\n";return 14;}
        if(audio.preload_style_voice(c,err)<0){++fail; std::cerr<<"[FAIL] preload source address: "<<err<<"\n"; continue;} ++preload_ok;
        arranger::NativeGuiAudioEvent pc_ev{0,(std::uint8_t)(0xc0u|0),a.pc,0};
        arranger::NativeGuiAudioEvent msb_ev{0,(std::uint8_t)(0xb0u|0),0,a.msb};
        arranger::NativeGuiAudioEvent lsb_ev{0,(std::uint8_t)(0xb0u|0),32,a.lsb};
        arranger::NativeGuiAudioEvent on{0,(std::uint8_t)0x90u,60,100};
        arranger::NativeGuiAudioEvent off{240,(std::uint8_t)0x80u,60,0};
        if(!arranger::NativeGuiPpfAudioTestAccess::handle(audio,msb_ev)||!arranger::NativeGuiPpfAudioTestAccess::handle(audio,lsb_ev)||!arranger::NativeGuiPpfAudioTestAccess::handle(audio,pc_ev)||!arranger::NativeGuiPpfAudioTestAccess::handle(audio,on)){
            ++fail; std::cerr<<"[FAIL] runtime source->installed note-on route\n"; continue;
        }
        std::vector<float> buf(480*2); if(!arranger::NativeGuiPpfAudioTestAccess::render(audio,buf.data(),480,48000)){++fail;std::cerr<<"[FAIL] render\n";continue;}
        const auto m=audio.metrics(); if(m.nonzero_samples==0||m.nonfinite_samples!=0){++fail;std::cerr<<"[FAIL] audio output after mapped PPF route\n";continue;}
        arranger::NativeGuiPpfAudioTestAccess::handle(audio,off);
    }
    const bool pass=fail==0&&mapped==ppf_addrs.size()&&preload_ok==ppf_addrs.size();
    std::cout<<"============================================================\n"
             <<"V0.79 BASELINE SOURCE -> INSTALLED PPF MAPPING GATE\n"
             <<"============================================================\n"
             <<"PPF_VOICES="<<reader.voices().size()<<"\n"
             <<"PPF_ZONES="<<reader.voice_zones().size()<<"\n"
             <<"INSTALLED_BANK=SOURCE_SLOT\n"
             <<"UNIQUE_BASELINE_PPF_ADDRESSES="<<ppf_addrs.size()<<"\n"
             <<"MAPPED_SOURCE_TO_INSTALLED="<<mapped<<"\n"
             <<"PRELOAD_OK="<<preload_ok<<"\n"
             <<"FAILURES="<<fail<<"\n"
             <<"RESULT="<<(pass?"PASS":"FAIL")<<"\n";
    return pass?0:20;
}
