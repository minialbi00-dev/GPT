#include "arranger_control_bridge.h"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

static void be16(std::vector<std::uint8_t>& out, std::uint16_t x) {
    out.push_back(static_cast<std::uint8_t>((x >> 8) & 0xFF));
    out.push_back(static_cast<std::uint8_t>(x & 0xFF));
}
static void be32(std::vector<std::uint8_t>& out, std::uint32_t x) {
    out.push_back(static_cast<std::uint8_t>((x >> 24) & 0xFF));
    out.push_back(static_cast<std::uint8_t>((x >> 16) & 0xFF));
    out.push_back(static_cast<std::uint8_t>((x >> 8) & 0xFF));
    out.push_back(static_cast<std::uint8_t>(x & 0xFF));
}
static void vlq(std::vector<std::uint8_t>& out, std::uint32_t v) {
    std::uint8_t tmp[5]{}; int n = 1; tmp[4] = static_cast<std::uint8_t>(v & 0x7F);
    while ((v >>= 7) != 0) tmp[4 - n++] = static_cast<std::uint8_t>((v & 0x7F) | 0x80);
    for (int i = 5 - n; i < 5; ++i) out.push_back(tmp[i]);
}
static void meta_text(std::vector<std::uint8_t>& tr, std::uint32_t delta, const std::string& s) {
    vlq(tr, delta); tr.push_back(0xFF); tr.push_back(0x06); vlq(tr, static_cast<std::uint32_t>(s.size()));
    tr.insert(tr.end(), s.begin(), s.end());
}
static void note(std::vector<std::uint8_t>& tr, std::uint32_t delta, std::uint8_t status, std::uint8_t n) {
    vlq(tr, delta); tr.push_back(status); tr.push_back(n); tr.push_back(90);
}
static std::vector<std::uint8_t> track(const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out{'M','T','r','k'};
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

int main() {
    const auto path = fs::temp_directory_path() / "cpp_arranger_control_bridge_gate.mid";
    std::vector<std::uint8_t> conductor;
    meta_text(conductor, 0, "CONTROL BRIDGE");
    // Four-bar sections so all control requests are observed on a real barline.
    meta_text(conductor, 0, "MAIN A");
    meta_text(conductor, 1920, "MAIN B");
    meta_text(conductor, 1920, "MAIN C");
    meta_text(conductor, 1920, "FILL AA");
    meta_text(conductor, 1920, "INTRO A");
    meta_text(conductor, 1920, "ENDING A");
    vlq(conductor, 1920); conductor.push_back(0xFF); conductor.push_back(0x2F); conductor.push_back(0);

    std::vector<std::uint8_t> music;
    note(music, 0, 0x90, 60); // MAIN A tick 0
    note(music, 480, 0x80, 60);
    note(music, 1440, 0x90, 61); // MAIN B tick 1920
    note(music, 480, 0x80, 61);
    note(music, 1440, 0x90, 62); // MAIN C tick 3840
    note(music, 480, 0x80, 62);
    note(music, 1440, 0x90, 67); // FILL AA tick 5760
    note(music, 480, 0x80, 67);
    note(music, 1440, 0x90, 65); // INTRO A tick 7680
    note(music, 480, 0x80, 65);
    note(music, 1440, 0x90, 72); // ENDING A tick 9600
    note(music, 480, 0x80, 72);
    vlq(music, 1440); music.push_back(0xFF); music.push_back(0x2F); music.push_back(0);

    std::vector<std::uint8_t> smf{'M','T','h','d'};
    be32(smf, 6); be16(smf, 1); be16(smf, 2); be16(smf, 480);
    auto t0 = track(conductor); smf.insert(smf.end(), t0.begin(), t0.end());
    auto t1 = track(music); smf.insert(smf.end(), t1.begin(), t1.end());
    { std::ofstream f(path, std::ios::binary); f.write(reinterpret_cast<const char*>(smf.data()), static_cast<std::streamsize>(smf.size())); }

    char err[1024]{};
    void* h = yac_arranger_create(err, sizeof(err));
    if (!h) { std::cerr << "CREATE_FAIL=" << err << "\n"; return 2; }

    if (!yac_arranger_load_style(h, path.string().c_str(), err, sizeof(err))) {
        std::cerr << "LOAD_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 3;
    }

    // Python parity: selecting MAIN while stopped is honored by the next start.
    if (!yac_arranger_queue_main(h, "MAIN B", err, sizeof(err))) {
        std::cerr << "PRESTART_MAIN_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 4;
    }
    if (!yac_arranger_start(h, err, sizeof(err))) {
        std::cerr << "START_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 5;
    }
    YacArrangerState st{};
    if (!yac_arranger_get_state(h, &st) || std::string(st.current_section) != "MAIN B") {
        std::cerr << "START_SELECTED_MAIN_FAIL current=" << st.current_section << "\n"; yac_arranger_destroy(h); return 6;
    }

    YacArrangerEvent out[128]{}; size_t count = 0;
    if (!yac_arranger_advance_to(h, 1920, out, 128, &count, err, sizeof(err))) {
        std::cerr << "ADVANCE_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 7;
    }
    bool saw_b = false;
    for (size_t i = 0; i < count; ++i) if (out[i].global_tick == 1920 && out[i].data1 == 61 && (out[i].status & 0xF0u) == 0x90u) saw_b = true;
    if (!saw_b) { std::cerr << "MAIN_B_EVENT_FAIL\n"; yac_arranger_destroy(h); return 8; }

    // Command precedence parity: FILL then MAIN => newest MAIN cancels stale FILL.
    if (!yac_arranger_queue_fill(h, "FILL AA", err, sizeof(err)) ||
        !yac_arranger_queue_main(h, "MAIN C", err, sizeof(err))) {
        std::cerr << "PRECEDENCE_QUEUE_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 9;
    }
    if (!yac_arranger_advance_to(h, 3840, out, 128, &count, err, sizeof(err))) {
        std::cerr << "PRECEDENCE_ADVANCE_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 10;
    }
    bool saw_c = false, saw_fill = false;
    for (size_t i = 0; i < count; ++i) {
        if (out[i].global_tick == 3840 && out[i].data1 == 62 && (out[i].status & 0xF0u) == 0x90u) saw_c = true;
        if (out[i].global_tick == 3840 && out[i].data1 == 67 && (out[i].status & 0xF0u) == 0x90u) saw_fill = true;
    }
    if (!saw_c || saw_fill) { std::cerr << "MAIN_PRECEDENCE_FAIL c=" << saw_c << " fill=" << saw_fill << "\n"; yac_arranger_destroy(h); return 11; }

    yac_arranger_set_acmp(h, 1);
    yac_arranger_set_chord(h, 7, 2);
    yac_arranger_set_transpose(h, 12);
    yac_arranger_set_tempo(h, 300.0);
    if (!yac_arranger_get_state(h, &st) || !st.acmp_enabled || st.transpose != 12 || st.bpm != 300.0) {
        std::cerr << "CONTROL_STATE_FAIL acmp=" << int(st.acmp_enabled) << " transpose=" << st.transpose << " bpm=" << st.bpm << "\n";
        yac_arranger_destroy(h); return 12;
    }
    yac_arranger_set_transpose(h, 48);
    if (!yac_arranger_get_state(h, &st) || st.transpose != 12) {
        std::cerr << "TRANSPOSE_RANGE_FAIL got=" << st.transpose << "\n"; yac_arranger_destroy(h); return 13;
    }

    if (!yac_arranger_queue_ending(h, "ENDING A", err, sizeof(err))) {
        std::cerr << "ENDING_QUEUE_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 14;
    }
    if (!yac_arranger_advance_to(h, 7680, out, 128, &count, err, sizeof(err))) {
        std::cerr << "ENDING_ADVANCE_FAIL=" << err << "\n"; yac_arranger_destroy(h); return 15;
    }
    yac_arranger_stop(h);
    if (yac_arranger_running(h)) { std::cerr << "STOP_FAIL\n"; yac_arranger_destroy(h); return 16; }

    std::cout << "CPP_ARRANGER_CONTROL_BRIDGE=PASS\n";
    std::cout << "START_SELECTED_MAIN=PASS\n";
    std::cout << "COMMAND_PRECEDENCE=PASS\n";
    std::cout << "ACMP_CHORD_TEMPO_STATE=PASS\n";
    std::cout << "TRANSPOSE_RANGE_PARITY=PASS\n";
    std::cout << "STOP_RESET=PASS\n";
    std::cout << "RESULT=PASS\n";
    yac_arranger_destroy(h);
    std::error_code ec; fs::remove(path, ec);
    return 0;
}
