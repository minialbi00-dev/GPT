from __future__ import annotations

import ctypes
import os
import random
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from cpp_casm_native import get_native_casm  # noqa: E402


def py_ref(rule, note, root, ctype):
    slots = rule.get("slots") or []
    if not slots:
        return None
    idx = 0
    if ctype in (1, 4, 5):
        idx = 1
    elif ctype in (2, 3):
        idx = 2
    slot = slots[idx] if idx < len(slots) else None
    if slot is None or (slot.get("ntr") == 0 and slot.get("ntt") == 0):
        slot = slots[0] if slots else None
    if slot is None:
        return None
    ntr = slot.get("ntr", 0)
    ntt = slot.get("ntt", 0)
    new_note = int(note)
    source_root = int(rule.get("source_root", 0)) % 12
    if ntr != 2:
        shift = root - source_root
        if shift > 6:
            shift -= 12
        elif shift < -5:
            shift += 12
    else:
        shift = 0
    new_note += shift
    if ntt > 0 or ntr == 2:
        rel = (new_note - root) % 12
        octave = new_note - rel
        tight = (ntt == 2)
        if ctype == 0:
            rel = ({0:0,1:0,2:0,3:4,4:4,5:4,6:7,7:7,8:7,9:7,10:0,11:0}[rel]
                   if tight else {0:0,1:0,2:2,3:4,4:4,5:5,6:7,7:7,8:7,9:9,10:0,11:0}[rel])
        elif ctype == 1:
            rel = ({0:0,1:0,2:3,3:3,4:3,5:7,6:7,7:7,8:7,9:7,10:0,11:0}[rel]
                   if tight else {0:0,1:0,2:2,3:3,4:3,5:5,6:7,7:7,8:8,9:7,10:0,11:0}[rel])
        elif ctype == 2:
            rel = ({0:0,1:0,2:0,3:4,4:4,5:4,6:7,7:7,8:7,9:10,10:10,11:10}[rel]
                   if tight else {0:0,1:0,2:2,3:4,4:4,5:5,6:7,7:7,8:7,9:9,10:10,11:10}[rel])
        elif ctype == 3:
            rel = ({0:0,1:0,2:0,3:4,4:4,5:4,6:7,7:7,8:7,9:11,10:11,11:11}[rel]
                   if tight else {0:0,1:0,2:2,3:4,4:4,5:5,6:7,7:7,8:7,9:9,10:11,11:11}[rel])
        elif ctype == 4:
            rel = ({0:0,1:0,2:3,3:3,4:3,5:7,6:7,7:7,8:10,9:10,10:10,11:10}[rel]
                   if tight else {0:0,1:0,2:2,3:3,4:3,5:5,6:7,7:7,8:8,9:10,10:10,11:10}[rel])
        elif ctype == 5:
            rel = ({0:0,1:0,2:3,3:3,4:3,5:6,6:6,7:6,8:6,9:0,10:0,11:0}[rel]
                   if tight else {0:0,1:0,2:2,3:3,4:3,5:5,6:6,7:6,8:8,9:9,10:0,11:0}[rel])
        elif ctype == 6:
            rel = ({0:0,1:0,2:0,3:4,4:4,5:4,6:8,7:8,8:8,9:8,10:0,11:0}[rel]
                   if tight else {0:0,1:0,2:2,3:4,4:4,5:6,6:6,7:8,8:8,9:10,10:10,11:0}[rel])
        else:
            raise AssertionError(ctype)
        new_note = octave + rel
    lo = int(slots[0].get("note_lo", 0)) if slot is slots[0] else int(slot.get("note_lo", 0))
    hi = int(slots[0].get("note_hi", 127)) if slot is slots[0] else int(slot.get("note_hi", 127))
    if hi == 0 or hi <= lo:
        lo, hi = 0, 127
    if (0 < hi < 127) or lo > 0:
        failsafe = 10
        while new_note < lo and failsafe > 0:
            new_note += 12; failsafe -= 1
        while new_note > hi and failsafe > 0:
            new_note -= 12; failsafe -= 1
    return max(0, min(127, new_note))


def make_rule(source_root, slots):
    return {"source_root": source_root, "source_type": 0, "dst": 8, "slots": slots}


def main() -> int:
    native = get_native_casm()
    cases = 0
    # Boundary/coverage matrix for all chord types, NTR/NTT combinations,
    # roots, note limits and MIDI extremes.
    for source_root in range(12):
        for ctype in range(7):
            for ntr in range(4):
                for ntt in range(4):
                    slots = [
                        {"ntr": ntr, "ntt": ntt, "high_key": 127, "note_lo": 0, "note_hi": 127, "rtr": 0},
                        {"ntr": 1, "ntt": 2, "high_key": 100, "note_lo": 20, "note_hi": 100, "rtr": 1},
                        {"ntr": 2, "ntt": 1, "high_key": 90, "note_lo": 40, "note_hi": 110, "rtr": 0},
                    ]
                    rule = make_rule(source_root, slots)
                    for root in range(12):
                        for note in (0, 1, 11, 12, 60, 119, 126, 127):
                            expect = py_ref(rule, note, root, ctype)
                            got = native.transform(rule=rule, input_note=note, root_pc=root, chord_type=ctype)
                            cases += 1
                            if got != expect:
                                print(f"MISMATCH matrix source_root={source_root} ctype={ctype} ntr={ntr} ntt={ntt} root={root} note={note} expected={expect} got={got}")
                                return 1
    rng = random.Random(0x83CA5A)
    for _ in range(20000):
        source_root = rng.randrange(12)
        slots = []
        for _i in range(rng.randrange(1, 4)):
            slots.append({
                "ntr": rng.randrange(8), "ntt": rng.randrange(8),
                "high_key": rng.randrange(128), "note_lo": rng.randrange(128),
                "note_hi": rng.randrange(128), "rtr": rng.randrange(8),
            })
        rule = make_rule(source_root, slots)
        ctype = rng.randrange(7)
        root = rng.randrange(12)
        note = rng.randrange(128)
        expect = py_ref(rule, note, root, ctype)
        got = native.transform(rule=rule, input_note=note, root_pc=root, chord_type=ctype)
        cases += 1
        if got != expect:
            print(f"MISMATCH random case={cases} rule={rule} ctype={ctype} root={root} note={note} expected={expect} got={got}")
            return 2
    print("CPP_CASM_PYTHON_PARITY=PASS")
    print(f"CASES={cases}")
    print("RESULT=PASS")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
