#include "arranger_engine.hpp"
#include "yamaha_style_runtime.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

static void be16(std::vector<std::uint8_t>& b, std::uint16_t v) {
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
    b.push_back(static_cast<std::uint8_t>(v & 0xFF));
}
static void be32(std::vector<std::uint8_t>& b, std::uint32_t v) {
    b.push_back(static_cast<std::uint8_t>((v >> 24) & 0xFF));
    b.push_back(static_cast<std::uint8_t>((v >> 16) & 0xFF));
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
    b.push_back(static_cast<std::uint8_t>(v & 0xFF));
}
static void vlq(std::vector<std::uint8_t>& b, std::uint32_t v) {
    std::uint8_t tmp[5]{};
    int n = 1;
    tmp[4] = static_cast<std::uint8_t>(v & 0x7F);
    while ((v >>= 7) != 0) tmp[4 - n++] = static_cast<std::uint8_t>((v & 0x7F) | 0x80);
    for (int i = 5 - n; i < 5; ++i) b.push_back(tmp[i]);
}
static void meta_text(std::vector<std::uint8_t>& track, std::uint32_t delta,
                      std::uint8_t type, const std::string& text) {
    vlq(track, delta);
    track.push_back(0xFF); track.push_back(type);
    vlq(track, static_cast<std::uint32_t>(text.size()));
    track.insert(track.end(), text.begin(), text.end());
}
static void meta3(std::vector<std::uint8_t>& track, std::uint32_t delta,
                  std::uint8_t type, std::uint8_t a, std::uint8_t c, std::uint8_t d) {
    vlq(track, delta); track.push_back(0xFF); track.push_back(type); track.push_back(3);
    track.push_back(a); track.push_back(c); track.push_back(d);
}
static void meta4(std::vector<std::uint8_t>& track, std::uint32_t delta,
                  std::uint8_t type, const std::array<std::uint8_t,4>& p) {
    vlq(track, delta); track.push_back(0xFF); track.push_back(type); track.push_back(4);
    track.insert(track.end(), p.begin(), p.end());
}
static void marker(std::vector<std::uint8_t>& track, std::uint32_t delta, const std::string& name) {
    meta_text(track, delta, 0x06, name);
}
static void note(std::vector<std::uint8_t>& track, std::uint32_t delta,
                 std::uint8_t status, std::uint8_t n, std::uint8_t v) {
    vlq(track, delta); track.push_back(status); track.push_back(n); track.push_back(v);
}
static void program(std::vector<std::uint8_t>& track, std::uint32_t delta,
                    std::uint8_t ch, std::uint8_t pc) {
    vlq(track, delta); track.push_back(static_cast<std::uint8_t>(0xC0 | ch)); track.push_back(pc);
}
static std::vector<std::uint8_t> make_track(const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out{'M','T','r','k'}; be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end()); return out;
}

int main() {
    const auto path = fs::temp_directory_path() / "cpp_style_scheduler_gate.mid";

    std::vector<std::uint8_t> conductor;
    meta_text(conductor, 0, 0x03, "SCHEDULER TEST");
    meta3(conductor, 0, 0x51, 0x07, 0xA1, 0x20); // 120 BPM
    meta4(conductor, 0, 0x58, {4,2,24,8});       // 4/4
    marker(conductor, 0, "MAIN A");
    marker(conductor, 1920, "MAIN B");
    marker(conductor, 1920, "FILL AA");
    marker(conductor, 1920, "ENDING A");
    vlq(conductor, 1920); conductor.push_back(0xFF); conductor.push_back(0x2F); conductor.push_back(0);

    std::vector<std::uint8_t> music;
    // MAIN A: event at pattern start and another later in the bar.
    program(music, 0, 0, 5);
    note(music, 0, 0x90, 60, 90);
    note(music, 240, 0x80, 60, 0);
    note(music, 240, 0x90, 62, 80);
    note(music, 240, 0x80, 62, 0);
    // Late-fill discriminator material in MAIN A at phase 720:
    // melodic note should survive late fill; rhythm note should be suppressed.
    note(music, 0, 0x90, 65, 83);
    note(music, 0, 0x99, 36, 91);
    note(music, 240, 0x80, 65, 0);
    note(music, 0, 0x89, 36, 0);
    // MAIN B region starts at 1920.
    note(music, 1680, 0x90, 64, 85);
    note(music, 240, 0x80, 64, 0);
    // FILL AA region starts at 3840: first event is phase 0, then an interior hit.
    note(music, 960, 0x99, 67, 95);
    note(music, 240, 0x89, 67, 0);
    // Late-fill discriminator material at FILL AA phase 720:
    // rhythm note should survive; melodic note should be suppressed.
    note(music, 480, 0x99, 38, 88);
    note(music, 0, 0x90, 69, 77);
    note(music, 240, 0x89, 38, 0);
    note(music, 0, 0x80, 69, 0);
    // ENDING A region starts at 5760.
    note(music, 960, 0x90, 72, 100);
    note(music, 480, 0x80, 72, 0);
    // Keep max tick at 7680.
    vlq(music, 1440); music.push_back(0xFF); music.push_back(0x2F); music.push_back(0);

    std::vector<std::uint8_t> smf{'M','T','h','d'};
    be32(smf, 6); be16(smf, 1); be16(smf, 2); be16(smf, 480);
    auto t0 = make_track(conductor); smf.insert(smf.end(), t0.begin(), t0.end());
    auto t1 = make_track(music); smf.insert(smf.end(), t1.begin(), t1.end());
    {
        std::ofstream f(path, std::ios::binary);
        if (!f) { std::cerr << "OPEN_WRITE_FAIL\n"; return 2; }
        f.write(reinterpret_cast<const char*>(smf.data()), static_cast<std::streamsize>(smf.size()));
    }

    arranger::YamahaStyleRuntime style;
    std::string error;
    if (!style.load(path.string(), error)) {
        std::cerr << "STYLE_LOAD_FAIL=" << error << "\n";
        return 3;
    }
    if (style.summary().division != 480 || style.summary().time_numerator != 4 || style.summary().time_denominator != 4) {
        std::cerr << "STYLE_TIMING_FAIL\n"; return 4;
    }

    arranger::CppArrangerEngine engine(style);
    if (!engine.start(error)) { std::cerr << "START_FAIL=" << error << "\n"; return 5; }

    std::vector<arranger::ArrangerOutputEvent> out;
    if (!engine.advance_to(0, out, error)) { std::cerr << "TICK0_FAIL=" << error << "\n"; return 6; }
    if (out.size() != 2 || out[0].global_tick != 0 || out[1].global_tick != 0 || (out[1].status & 0xF0u) != 0x90u) {
        std::cerr << "TICK0_EVENT_ORDER_FAIL count=" << out.size() << "\n"; return 7;
    }

    if (!engine.advance_to(60, out, error)) { std::cerr << "ADVANCE_60_FAIL=" << error << "\n"; return 8; }
    if (!engine.queue_fill("FILL AA", error)) { std::cerr << "QUEUE_FILL_FAIL=" << error << "\n"; return 9; }
    if (!engine.advance_to(1920, out, error)) { std::cerr << "FILL_ADVANCE_FAIL=" << error << "\n"; return 10; }

    bool saw_fill = false, saw_main_after_fill = false;
    std::uint32_t first_fill_tick = 0;
    for (const auto& e : out) {
        if (e.global_tick < 60) continue;
        if (e.section == "FILL AA" && (e.status & 0xF0u) == 0x90u && e.data2 > 0) {
            saw_fill = true; if (!first_fill_tick) first_fill_tick = e.global_tick;
        }
        if (e.section == "MAIN A" && e.global_tick >= 240 && (e.status & 0xF0u) == 0x90u)
            saw_main_after_fill = true;
    }
    // Python parity: when the fill completes on a barline, the destination
    // MAIN may emit its rel=0 event on that same barline.
    if (!saw_fill || first_fill_tick < 60 || !saw_main_after_fill) {
        std::cerr << "FILL_PHASE_FILTER_FAIL fill=" << saw_fill
                  << " first=" << first_fill_tick << " main_boundary=" << saw_main_after_fill << "\n";
        return 11;
    }

    // Python parity: when FILL and MAIN are both pending before the fill starts,
    // the newer MAIN command cancels the stale FILL request.
    arranger::CppArrangerEngine precedence(style);
    if (!precedence.start(error)) { std::cerr << "PRECEDENCE_START_FAIL=" << error << "\n"; return 111; }
    if (!precedence.advance_to(60, out, error)) { std::cerr << "PRECEDENCE_ADVANCE_60_FAIL=" << error << "\n"; return 112; }
    if (!precedence.queue_fill("FILL AA", error) || !precedence.queue_main("MAIN B", error)) {
        std::cerr << "PRECEDENCE_QUEUE_FAIL=" << error << "\n"; return 113;
    }
    if (!precedence.advance_to(1920, out, error)) { std::cerr << "PRECEDENCE_ADVANCE_FAIL=" << error << "\n"; return 114; }
    // The fixture does not place a MAIN B NOTE-ON at rel=0. Validate the
    // command precedence through the scheduler state itself: MAIN won over the
    // still-pending FILL request at the barline.
    if (precedence.current_section() != "MAIN B") {
        std::cerr << "COMMAND_PRECEDENCE_FAIL current=" << precedence.current_section() << "\n";
        return 115;
    }

    // Separate late-fill pass: melodic MAIN survives; rhythm MAIN is suppressed;
    // rhythm FILL survives; melodic FILL is suppressed.
    arranger::CppArrangerEngine late_engine(style);
    if (!late_engine.start(error)) { std::cerr << "LATE_START_FAIL=" << error << "\n"; return 12; }
    if (!late_engine.advance_to(600, out, error)) { std::cerr << "LATE_ADVANCE_600_FAIL=" << error << "\n"; return 121; }
    if (!late_engine.queue_fill("FILL AA", error)) { std::cerr << "LATE_QUEUE_FILL_FAIL=" << error << "\n"; return 122; }
    if (!late_engine.advance_to(840, out, error)) { std::cerr << "LATE_ADVANCE_840_FAIL=" << error << "\n"; return 123; }
    bool late_main_melodic=false, late_main_rhythm=false, late_fill_rhythm=false, late_fill_melodic=false;
    for (const auto& e : out) {
        if (e.global_tick != 720 || (e.status & 0xF0u) != 0x90u || e.data2 == 0) continue;
        if (e.section == "MAIN A" && e.data1 == 65) late_main_melodic = true;
        if (e.section == "MAIN A" && e.data1 == 36) late_main_rhythm = true;
        if (e.section == "FILL AA" && e.data1 == 38) late_fill_rhythm = true;
        if (e.section == "FILL AA" && e.data1 == 69) late_fill_melodic = true;
    }
    if (!late_main_melodic || late_main_rhythm || !late_fill_rhythm || late_fill_melodic) {
        std::cerr << "LATE_FILL_FILTER_FAIL main_mel=" << late_main_melodic
                  << " main_rhy=" << late_main_rhythm
                  << " fill_rhy=" << late_fill_rhythm
                  << " fill_mel=" << late_fill_melodic << "\n";
        return 124;
    }

    // Quantized MAIN selection is tested on a clean scheduler instance so the
    // preceding FILL scenario cannot contaminate the state.
    arranger::CppArrangerEngine quant_engine(style);
    if (!quant_engine.start(error)) { std::cerr << "QUANT_START_FAIL=" << error << "\n"; return 14; }
    if (!quant_engine.advance_to(600, out, error)) { std::cerr << "QUANT_ADVANCE_FAIL=" << error << "\n"; return 140; }
    if (!quant_engine.queue_main("MAIN B", error)) { std::cerr << "QUANT_QUEUE_MAIN_FAIL=" << error << "\n"; return 141; }
    if (!quant_engine.advance_to(1920, out, error)) { std::cerr << "QUANT_BARLINE_FAIL=" << error << "\n"; return 142; }
    if (quant_engine.current_section() != "MAIN B") {
        std::cerr << "MAIN_QUANTIZE_FAIL current=" << quant_engine.current_section() << "\n"; return 143;
    }
    if (!quant_engine.advance_to(2640, out, error)) { std::cerr << "MAIN_B_EVENT_FAIL=" << error << "\n"; return 144; }
    bool saw_main_b = false;
    for (const auto& e : out) if (e.section == "MAIN B" && e.global_tick == 2640 && (e.status & 0xF0u) == 0x90u) saw_main_b = true;
    if (!saw_main_b) {
        std::cerr << "MAIN_B_EVENT_FAIL current=" << quant_engine.current_section() << " count=" << out.size() << "\n";
        for (const auto& e : out) std::cerr << " OUT " << e.global_tick << " sec=" << e.section << " st=" << std::hex << int(e.status) << std::dec << " n=" << int(e.data1) << " v=" << int(e.data2) << "\n";
        return 145;
    }
    if (quant_engine.advance_to(2639, out, error)) {
        std::cerr << "BACKWARD_TIME_NOT_REJECTED\n"; return 146;
    }

    if (!quant_engine.queue_ending("ENDING A", error)) { std::cerr << "QUEUE_ENDING_FAIL=" << error << "\n"; return 15; }
    if (!quant_engine.advance_to(8000, out, error)) { std::cerr << "ENDING_ADVANCE_FAIL=" << error << "\n"; return 16; }
    bool saw_ending = false;
    for (const auto& e : out) if (e.section == "ENDING A" && e.global_tick == 3840 && (e.status & 0xF0u) == 0x90u) saw_ending = true;
    if (!saw_ending || quant_engine.running()) {
        std::cerr << "ENDING_ONESHOT_FAIL ending=" << saw_ending << " running=" << quant_engine.running() << "\n"; return 17;
    }

    std::cout << "CPP_STYLE_SCHEDULER=PASS\n";
    std::cout << "BAR_TICKS=" << quant_engine.bar_ticks() << "\n";
    std::cout << "TICK0_SETUP_AND_NOTE=PASS\n";
    std::cout << "FILL_START_AT_CURRENT_PHASE=" << first_fill_tick << " PASS\n";
    std::cout << "MAIN_QUANTIZED_SWITCH=PASS\n";
    std::cout << "LATE_FILL_FILTER=PASS\n";
    std::cout << "ENDING_ONE_SHOT=PASS\n";
    std::cout << "RESULT=PASS\n";
    std::error_code ec; fs::remove(path, ec);
    return 0;
}
