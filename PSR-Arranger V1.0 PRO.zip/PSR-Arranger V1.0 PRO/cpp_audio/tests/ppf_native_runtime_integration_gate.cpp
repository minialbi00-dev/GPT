#include "native_gui_ppf_audio.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using arranger::InstalledVoiceAddress;
using arranger::NativeGuiPpfAudio;
using arranger::PpfRuntimeZone;

#ifdef ARRANGER_ENABLE_TEST_ACCESS
struct arranger::NativeGuiPpfAudioTestAccess {
    static const PpfRuntimeZone* choose(const NativeGuiPpfAudio& audio,
                                        std::size_t bank_id,
                                        std::size_t voice_index,
                                        int note,
                                        int velocity) {
        return audio.choose_zone(bank_id, voice_index, note, velocity);
    }
};
#endif

static void be32(std::vector<std::uint8_t>& out, std::uint32_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 24));
    out.push_back(static_cast<std::uint8_t>(v >> 16));
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}

static std::vector<std::uint8_t> field(const char tag[4], const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out(tag, tag + 4);
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

static std::vector<std::uint8_t> textf(const char tag[4], const std::string& s) {
    return field(tag, std::vector<std::uint8_t>(s.begin(), s.end()));
}

static std::vector<std::uint8_t> blob(const std::vector<std::vector<std::uint8_t>>& fields) {
    std::vector<std::uint8_t> payload;
    for (const auto& f : fields) payload.insert(payload.end(), f.begin(), f.end());
    std::vector<std::uint8_t> out{'B','L','O','B'};
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

static std::vector<std::uint8_t> pcm_block(const std::vector<std::uint8_t>& pcm) {
    std::vector<std::uint8_t> ssnd{'S','S','N','D'};
    be32(ssnd, 16u);
    ssnd.insert(ssnd.end(), 8u, 0u);
    ssnd.insert(ssnd.end(), pcm.begin(), pcm.end());
    return ssnd;
}

static bool make_ppf(const std::filesystem::path& path) {
    const std::string xml =
        "<?xml version=\"1.0\"?><uvf:voiceData><voiceType>UNIVERSAL</voiceType>"
        "<information><voiceName>Native Runtime Velocity Gate</voiceName>"
        "<voiceMsb>62</voiceMsb><voiceLsb>3</voiceLsb><voicePcNum>9</voicePcNum></information>"
        "<voiceElement number=\"0\"><noteLimitLo>C4</noteLimitLo><noteLimitHi>C4</noteLimitHi></voiceElement>"
        "<waveform number=\"0\"><keybank><noteLimitLo>C4</noteLimitLo><noteLimitHi>C4</noteLimitHi>"
        "<velocityLimitLo>1</velocityLimitLo><velocityLimitHi>63</velocityLimitHi><centerNote>C4</centerNote>"
        "<sample position=\"MONO\"><waveFilePath>LOW_UID</waveFilePath></sample></keybank>"
        "<keybank><noteLimitLo>C4</noteLimitLo><noteLimitHi>C4</noteLimitHi>"
        "<velocityLimitLo>64</velocityLimitLo><velocityLimitHi>127</velocityLimitHi><centerNote>C4</centerNote>"
        "<sample position=\"MONO\"><waveFilePath>HIGH_UID</waveFilePath></sample></keybank>"
        "</waveform></uvf:voiceData>";

    auto uvf = blob({textf("EEXT", "UVF"), textf("ETIT", "Native Runtime Velocity Gate"),
                     std::vector<std::uint8_t>(xml.begin(), xml.end())});
    auto low = blob({textf("EEXT", "apcp"), textf("EUID", "LOW_UID"), pcm_block({0,1,0,2,0,3,0,4})});
    auto high = blob({textf("EEXT", "apcp"), textf("EUID", "HIGH_UID"), pcm_block({0,5,0,6,0,7,0,8})});

    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(uvf.data()), static_cast<std::streamsize>(uvf.size()));
    out.write(reinterpret_cast<const char*>(low.data()), static_cast<std::streamsize>(low.size()));
    out.write(reinterpret_cast<const char*>(high.data()), static_cast<std::streamsize>(high.size()));
    return static_cast<bool>(out);
}

int main() {
#ifndef ARRANGER_ENABLE_TEST_ACCESS
    std::cerr << "[FAIL] test access disabled\n";
    return 90;
#else
    const auto path = std::filesystem::temp_directory_path() / "ppf_native_runtime_velocity_gate.ppf";
    std::error_code ec;
    std::filesystem::remove(path, ec);
    if (!make_ppf(path)) {
        std::cerr << "[FAIL] fixture create\n";
        return 1;
    }

    NativeGuiPpfAudio audio;
    std::string error;
    if (!audio.install_ppf_bank_audio_only(path.string(), InstalledVoiceAddress{0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] native PPF install: " << error << "\n";
        return 2;
    }

    const auto banks = audio.installed_ppf_banks();
    const auto voices = audio.installed_ppf_voices();
    if (banks.size() != 1u || voices.size() != 1u || voices[0].resident_zone_count != 2u) {
        std::cerr << "[FAIL] expected two resident velocity zones\n";
        return 3;
    }

    const auto* low = arranger::NativeGuiPpfAudioTestAccess::choose(audio, banks[0].bank_id, voices[0].source_index, 72, 32);
    const auto* high = arranger::NativeGuiPpfAudioTestAccess::choose(audio, banks[0].bank_id, voices[0].source_index, 72, 96);
    const auto* miss = arranger::NativeGuiPpfAudioTestAccess::choose(audio, banks[0].bank_id, voices[0].source_index, 72, 0);

    if (!low || low->zone.sample_uid != "LOW_UID") {
        std::cerr << "[FAIL] velocity 32 did not resolve LOW_UID\n";
        return 4;
    }
    if (!high || high->zone.sample_uid != "HIGH_UID") {
        std::cerr << "[FAIL] velocity 96 did not resolve HIGH_UID\n";
        return 5;
    }
    if (miss != nullptr) {
        std::cerr << "[FAIL] velocity miss unexpectedly used a key fallback\n";
        return 6;
    }

    std::cout << "NATIVE_CXX_PPF_RUNTIME_INTEGRATION=PASS\n"
              << "LOW_VELOCITY_32=LOW_UID PASS\n"
              << "HIGH_VELOCITY_96=HIGH_UID PASS\n"
              << "NO_KEY_ONLY_FALLBACK=PASS\n";

    std::filesystem::remove(path, ec);
    return 0;
#endif
}
