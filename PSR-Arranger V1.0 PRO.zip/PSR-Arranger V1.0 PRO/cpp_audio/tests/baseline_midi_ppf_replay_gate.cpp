#include "native_gui_ppf_audio.hpp"
#include "ppf_reader.hpp"
#include "voice_install_catalog.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>

namespace arranger {
struct NativeGuiPpfAudioTestAccess {
    static bool handle(NativeGuiPpfAudio& a, const NativeGuiAudioEvent& e) noexcept {
        return a.handle_event(e);
    }
    static bool render(NativeGuiPpfAudio& a, float* dst, std::size_t frames, int rate) noexcept {
        return a.render_audio(dst, frames, rate);
    }
};
}

namespace {
struct TimedEvent {
    std::uint32_t tick = 0;
    std::uint8_t status = 0;
    std::uint8_t d1 = 0;
    std::uint8_t d2 = 0;
};

static int hex_byte(const std::string& s) {
    unsigned v = 0;
    std::istringstream ss(s);
    ss >> std::hex >> v;
    if (ss.fail() || v > 255u) return -1;
    return static_cast<int>(v);
}

static bool load_fixture(const std::string& path, double& bpm, std::uint16_t& division,
                         std::vector<TimedEvent>& out, std::string& error) {
    std::ifstream f(path);
    if (!f) { error = "cannot open fixture: " + path; return false; }
    std::string line;
    bool begin = false;
    bpm = 120.0;
    division = 480;
    while (std::getline(f, line)) {
        if (line == "EVENTS_BEGIN") { begin = true; continue; }
        if (line == "EVENTS_END") break;
        if (!begin) {
            if (line.rfind("BPM\t", 0) == 0) bpm = std::stod(line.substr(4));
            else if (line.rfind("DIVISION\t", 0) == 0) division = static_cast<std::uint16_t>(std::stoul(line.substr(9)));
            continue;
        }
        std::istringstream ss(line);
        std::string a,b,c,d;
        if (!std::getline(ss,a,'\t') || !std::getline(ss,b,'\t') ||
            !std::getline(ss,c,'\t') || !std::getline(ss,d,'\t')) continue;
        const long long tick = std::stoll(a);
        const int st = hex_byte(b), d1 = hex_byte(c), d2 = hex_byte(d);
        if (tick < 0 || tick > std::numeric_limits<std::uint32_t>::max() ||
            st < 0 || d1 < 0 || d2 < 0) {
            error = "invalid event line: " + line; return false;
        }
        out.push_back(TimedEvent{static_cast<std::uint32_t>(tick),
                                 static_cast<std::uint8_t>(st),
                                 static_cast<std::uint8_t>(d1),
                                 static_cast<std::uint8_t>(d2)});
    }
    if (out.empty()) { error = "fixture contains no events"; return false; }
    return true;
}

static std::uint64_t addr_key(std::uint8_t msb, std::uint8_t lsb, std::uint8_t pc) {
    return (static_cast<std::uint64_t>(msb) << 16) |
           (static_cast<std::uint64_t>(lsb) << 8) |
           pc;
}
}

int main(int argc, char** argv) {
    const std::string ppf = argc > 1 ? argv[1] : "tests/@YOGI MUSIC STUDIO (26).ppf";
    const std::string fixture = argc > 2 ? argv[2] : "cpp_audio/tests/fixtures/baseline_timed_midi_replay.tsv";

    double bpm = 120.0;
    std::uint16_t division = 480;
    std::vector<TimedEvent> events;
    std::string error;
    if (!load_fixture(fixture, bpm, division, events, error)) {
        std::cerr << "[FAIL] " << error << "\n";
        return 10;
    }

    arranger::PpfReader reader;
    if (!reader.open(ppf, error)) {
        std::cerr << "[FAIL] PPF open: " << error << "\n";
        return 11;
    }
    arranger::InstalledVoiceCatalog catalog;
    if (!catalog.install_ppf(reader, ppf, arranger::InstalledVoiceAddress{0xFF,0xFF,0}, error)) {
        std::cerr << "[FAIL] PPF install catalog: " << error << "\n";
        return 12;
    }

    arranger::NativeGuiPpfAudio audio;
    if (!audio.install_ppf_bank_audio_only(ppf, arranger::InstalledVoiceAddress{0xFF,0xFF,0}, error)) {
        std::cerr << "[FAIL] PPF audio install: " << error << "\n";
        return 13;
    }
    audio.set_timing(bpm, division);

    std::array<std::uint8_t,16> msb{};
    std::array<std::uint8_t,16> lsb{};
    std::array<std::uint8_t,16> pc{};
    std::unordered_set<std::uint64_t> unique_calls;
    std::size_t resolved = 0, unresolved = 0, source_exact = 0, installed_mapped = 0, installed_exact = 0, aliases = 0;
    std::size_t ppf_note_on_expected = 0, nonppf_note_on = 0;
    std::size_t note_on = 0, note_off = 0, preload_ok = 0, preload_fail = 0;

    // Preload only the Voices actually emitted by the ORIGINAL BASELINE MIDI stream.
    for (const auto& e : events) {
        const auto ch = static_cast<std::uint8_t>(e.status & 0x0Fu);
        const auto cmd = static_cast<std::uint8_t>(e.status & 0xF0u);
        if (ch >= 16) continue;
        if (cmd == 0xB0u && e.d1 == 0u) msb[ch] = e.d2 & 0x7Fu;
        else if (cmd == 0xB0u && e.d1 == 32u) lsb[ch] = e.d2 & 0x7Fu;
        else if (cmd == 0xC0u) pc[ch] = e.d1 & 0x7Fu;
        else if (cmd == 0x90u && e.d2 > 0u) {
            ++note_on;
            arranger::StyleVoiceCall call{e.tick,ch,msb[ch],lsb[ch],pc[ch]};
            const auto key = addr_key(call.msb, call.lsb, call.program);
            arranger::InstalledVoiceResolution r;
            std::string re;
            const bool has_ppf = catalog.resolve_style_call(call, r, re) && r.voice &&
                                  r.voice->format == arranger::InstalledVoiceFormat::PPF;
            if (has_ppf) ++ppf_note_on_expected; else ++nonppf_note_on;
            if (unique_calls.insert(key).second) {
                if (has_ppf) {
                    ++resolved;
                    installed_mapped += (r.mapped_to_installed && r.installed_address_valid &&
                                         r.voice->installed_address.msb == 63u &&
                                         r.voice->installed_address.lsb == 62u) ? 1 : 0;
                    installed_exact += r.installed_exact ? 1 : 0;
                    source_exact += r.source_exact ? 1 : 0;
                    aliases += (!r.installed_exact && !r.source_exact) ? 1 : 0;
                    std::string pe;
                    const int pr = audio.preload_style_voice(call, pe);
                    if (pr == 1 || pr == 0) ++preload_ok;
                    else { ++preload_fail; std::cerr << "[FAIL] preload " << int(call.msb) << "/" << int(call.lsb) << "/" << int(call.program) << ": " << pe << "\n"; }
                } else {
                    ++unresolved;
                }
            }
        } else if (cmd == 0x80u || (cmd == 0x90u && e.d2 == 0u)) {
            ++note_off;
        }
    }

    // Reset controller state before actual replay.
    msb.fill(0); lsb.fill(0); pc.fill(0);

    constexpr int kRate = 48000;
    constexpr std::size_t kChunk = 480;
    std::vector<float> buffer(kChunk * 2u, 0.0f);
    std::uint64_t rendered_frames = 0;
    std::uint64_t nonzero = 0, nonfinite = 0;
    float peak = 0.0f;
    std::uint64_t max_render_us = 0;

    auto render_frames = [&](std::uint64_t frames) -> bool {
        while (frames) {
            const std::size_t n = static_cast<std::size_t>(std::min<std::uint64_t>(frames, kChunk));
            const auto t0 = std::chrono::steady_clock::now();
            if (!arranger::NativeGuiPpfAudioTestAccess::render(audio, buffer.data(), n, kRate)) return false;
            const auto t1 = std::chrono::steady_clock::now();
            const auto us = static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(t1-t0).count());
            max_render_us = std::max(max_render_us, us);
            for (std::size_t i=0;i<n*2u;++i) {
                const float v = buffer[i];
                if (!std::isfinite(v)) ++nonfinite;
                else { if (v != 0.0f) ++nonzero; peak = std::max(peak, std::fabs(v)); }
            }
            rendered_frames += n;
            frames -= n;
        }
        return true;
    };

    for (const auto& e : events) {
        const double frames_per_tick = static_cast<double>(kRate) * 60.0 /
            (bpm * static_cast<double>(std::max<std::uint16_t>(1, division)));
        const auto target_signed = std::llround(static_cast<double>(e.tick) * frames_per_tick);
        const std::uint64_t target = target_signed > 0 ? static_cast<std::uint64_t>(target_signed) : 0u;
        if (target > rendered_frames && !render_frames(target - rendered_frames)) {
            std::cerr << "[FAIL] render_audio returned false during replay at tick " << e.tick << "\n";
            return 14;
        }
        const arranger::NativeGuiAudioEvent ne{e.tick,e.status,e.d1,e.d2};
        if (!arranger::NativeGuiPpfAudioTestAccess::handle(audio, ne)) {
            std::cerr << "[FAIL] handle_event returned false at tick " << e.tick << "\n";
            return 15;
        }
    }

    // Give released voices one second of tail without injecting new MIDI.
    if (!render_frames(kRate)) {
        std::cerr << "[FAIL] tail render failed\n";
        return 16;
    }

    const auto m = audio.metrics();
    const bool clean = m.nonfinite_samples == 0 && nonfinite == 0 && m.dropped_events == 0 &&
                       preload_fail == 0 && resolved > 0 && ppf_note_on_expected > 0 &&
                       note_on == ppf_note_on_expected + nonppf_note_on &&
                       installed_mapped == resolved && nonzero > 0;

    std::cout << "============================================================\n";
    std::cout << "V0.79 V0.64 AUDIO ENGINE + ORIGINAL BASELINE MIDI REPLAY\n";
    std::cout << "============================================================\n";
    std::cout << "PPF_VOICES=" << reader.voices().size() << "\n";
    std::cout << "PPF_ZONES=" << reader.voice_zones().size() << "\n";
    std::cout << "INSTALLED_BANK=63/62\n";
    std::cout << "INSTALLED_VOICES=" << catalog.voices().size() << "\n";
    std::cout << "BASELINE_FINAL_EVENTS=" << events.size() << "\n";
    std::cout << "BASELINE_NOTE_ON=" << note_on << "\n";
    std::cout << "BASELINE_NOTE_OFF=" << note_off << "\n";
    std::cout << "UNIQUE_PPF_CALLS=" << unique_calls.size() << "\n";
    std::cout << "PPF_CALLS_RESOLVED=" << resolved << "\n";
    std::cout << "PPF_CALLS_UNRESOLVED_NONPPF=" << unresolved << "\n";
    std::cout << "PPF_NOTE_ON_EXPECTED=" << ppf_note_on_expected << "\n";
    std::cout << "NONPPF_NOTE_ON=" << nonppf_note_on << "\n";
    std::cout << "INSTALLED_MAPPED=" << installed_mapped << "\n";
    std::cout << "INSTALLED_EXACT=" << installed_exact << "\n";
    std::cout << "SOURCE_EXACT=" << source_exact << "\n";
    std::cout << "ALIAS_RESOLVED=" << aliases << "\n";
    std::cout << "PRELOAD_OK=" << preload_ok << "\n";
    std::cout << "PRELOAD_FAIL=" << preload_fail << "\n";
    std::cout << "RESIDENT_ZONES=" << audio.metrics().resident_zone_count << "\n";
    std::cout << "UNIQUE_PCM=" << audio.metrics().unique_pcm_count << "\n";
    std::cout << "RENDERED_FRAMES=" << rendered_frames << "\n";
    std::cout << "NONZERO_SAMPLES=" << nonzero << "\n";
    std::cout << "NONFINITE_SAMPLES=" << nonfinite << "\n";
    std::cout << "PEAK=" << std::fixed << std::setprecision(6) << peak << "\n";
    std::cout << "MAX_RENDER_US_480=" << max_render_us << "\n";
    std::cout << "AUDIO_ENGINE_PPF_REPLAY=" << (clean ? "PASS" : "FAIL") << "\n";
    return clean ? 0 : 20;
}
