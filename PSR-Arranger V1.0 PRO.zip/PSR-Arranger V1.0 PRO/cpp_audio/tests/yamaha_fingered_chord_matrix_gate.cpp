#include "performance_runtime.hpp"

#include <initializer_list>
#include <iostream>
#include <string>
#include <vector>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

struct Case { const char* name; const char* intervals; int type; };

static bool run_case(PerformanceRuntime& p, const Case& c, int& fail) {
    p.clear_notes();
    for (const char* q = c.intervals; *q; ++q) {
        if (*q == ',') continue;
        int v = 0;
        if (*q >= '0' && *q <= '9') v = *q - '0';
        else if (*q == 'A') v = 10;
        else if (*q == 'B') v = 11;
        else continue;
        p.note_on(static_cast<std::uint8_t>(60 + v), 100);
    }
    const auto& s = p.state();
    const bool ok = s.chord_name == c.name && static_cast<int>(s.chord_type) == c.type;
    std::cout << "MATRIX_" << c.name << "=" << (ok ? "PASS" : "FAIL")
              << " GOT=" << s.chord_name << " TYPE=" << int(s.chord_type) << "\n";
    if (!ok) ++fail;
    return ok;
}

int main() {
    int fail = 0;
    PerformanceRuntime p;
    p.set_split_point(127);
    p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::Fingered));

    // Root-C exact required-note shapes from the Yamaha PSR-SX920 chord table.
    const Case cases[] = {
        {"C",        "047",     0},
        {"C6",       "079",     0},
        {"CM7",      "04B",     3},
        {"CM7(b5)",    "046B",    3},
        {"CM7(#11)", "0467B",   3},
        {"Cadd9",    "0247",    0},
        {"CM7(9)",    "024B",    3},
        {"C6(9)",     "0249",    0},
        {"Cb5",       "046",     0},
        {"Caug",     "048",     6},
        {"C7aug",    "048A",    2},
        {"CM7aug",   "08B",     3},
        {"Cm",       "037",     1},
        {"Cm6",      "0379",    1},
        {"Cm7",      "03A",     4},
        {"Cm7(b5)",    "036A",     4},
        {"Cm add9",    "0237",    1},
        {"Cm7(9)",   "023A",    4},
        {"Cm7(11)",  "0357",    4},
        {"CmM7(b5)",   "036B",    3},
        {"CmM7",     "03B",     3},
        {"CmM7(9)",  "023B",    3},
        {"Cdim",     "036",     5},
        {"Cdim7",    "0369",    5},
        {"C7",       "04A",     2},
        {"C7sus4",   "057A",    2},
        {"C7(9)",    "024A",    2},
        {"C7(#11)",  "0467A",   2},
        {"C7(13)",   "049A",    2},
        {"C7(b5)",     "046A",    2},
        {"C7(b9)",   "014A",    2},
        {"C7(b13)",  "0478A",   2},
        {"C7(#9)",   "034A",    2},
        {"Csus4",    "057",     0},
        {"Csus2",    "027",     0},
    };
    for (const auto& c : cases) run_case(p, c, fail);

    // Yamaha optional notes: 3rd is optional for C6; 5th is optional for C7/M7/m7.
    p.clear_notes();
    for (int n : {60, 67, 69}) p.note_on(static_cast<std::uint8_t>(n), 100);
    if (p.state().chord_name != "C6") { std::cout << "OPTIONAL_C6=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "OPTIONAL_C6=PASS\n";

    p.clear_notes();
    for (int n : {60, 64, 70}) p.note_on(static_cast<std::uint8_t>(n), 100);
    if (p.state().chord_name != "C7") { std::cout << "OPTIONAL_C7_5=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "OPTIONAL_C7_5=PASS\n";

    p.clear_notes();
    for (int n : {60, 62, 64, 71}) p.note_on(static_cast<std::uint8_t>(n), 100);
    if (p.state().chord_name != "CM7(9)") { std::cout << "OPTIONAL_CM7_9_5=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "OPTIONAL_CM7_9_5=PASS\n";

    p.clear_notes();
    for (int n : {60, 62, 64, 69}) p.note_on(static_cast<std::uint8_t>(n), 100);
    if (p.state().chord_name != "C6(9)") { std::cout << "OPTIONAL_C6_9_5=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "OPTIONAL_C6_9_5=PASS\n";

    // 1+5 is only the root in the bass + fifth. The inverse fifth is not
    // silently re-labeled as the upper note's root.
    p.clear_notes();
    p.note_on(60, 100); p.note_on(67, 100);
    if (p.state().chord_name != "C1+5") { std::cout << "ONE_PLUS_FIVE=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "ONE_PLUS_FIVE=PASS\n";

    PerformanceRuntime inverse_probe;
    inverse_probe.set_split_point(127);
    inverse_probe.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::Fingered));
    inverse_probe.note_on(67, 100);
    inverse_probe.note_on(72, 100);
    const auto inverse = inverse_probe.state().chord_name;
    if (inverse == "C1+5") { std::cout << "INVERSE_ONE_PLUS_FIVE=FAIL GOT=C1+5\n"; ++fail; }
    else std::cout << "INVERSE_ONE_PLUS_FIVE=PASS GOT=" << inverse << "\n";

    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
