#include "native_gui_ppf_audio.hpp"
#include "ppf_reader.hpp"
#include "voice_install_catalog.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using arranger::InstalledVoiceAddress;
using arranger::NativeGuiPpfAudio;
using arranger::PpfReader;
using arranger::InstalledVoiceCatalog;

static void append_ascii(std::ofstream& out, const std::string& s) {
    out.write(s.data(), static_cast<std::streamsize>(s.size()));
}

static void be32(std::vector<std::uint8_t>& out, std::uint32_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 24));
    out.push_back(static_cast<std::uint8_t>(v >> 16));
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}

static std::vector<std::uint8_t> field(const char tag[4], const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out(tag, tag + 4);
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

static std::vector<std::uint8_t> field_text(const char tag[4], const std::string& text) {
    return field(tag, std::vector<std::uint8_t>(text.begin(), text.end()));
}

static std::vector<std::uint8_t> blob(const std::vector<std::vector<std::uint8_t>>& fields) {
    std::vector<std::uint8_t> payload;
    for (const auto& f : fields) payload.insert(payload.end(), f.begin(), f.end());
    std::vector<std::uint8_t> out{'B','L','O','B'};
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

static bool make_test_ppf(const std::filesystem::path& path,
                          std::uint8_t msb,
                          std::uint8_t lsb,
                          std::uint8_t pc,
                          const std::string& title) {
    const std::string uid = "UID_" + title;
    const std::string xml =
        "<?xml version=\"1.0\"?><uvf:voiceData><voiceType>UNIVERSAL</voiceType>"
        "<information><voiceName>" + title + "</voiceName><voiceMsb>" + std::to_string(msb) +
        "</voiceMsb><voiceLsb>" + std::to_string(lsb) + "</voiceLsb><voicePcNum>" +
        std::to_string(pc) + "</voicePcNum></information>"
        "<voiceCommon/><voiceElement number=\"0\"><noteLimitLo>C-2</noteLimitLo><noteLimitHi>G8</noteLimitHi>"
        "<pitchBlock><tuneCoarse>0</tuneCoarse><tuneFine>0</tuneFine></pitchBlock></voiceElement>"
        "<waveform number=\"0\"><keybank><noteLimitLo>C-2</noteLimitLo><noteLimitHi>G8</noteLimitHi>"
        "<velocityLimitLo>1</velocityLimitLo><velocityLimitHi>127</velocityLimitHi>"
        "<centerNote>C4</centerNote><sample position='MONO'><waveFilePath>" + uid + "</waveFilePath>"
        "</sample></keybank></waveform>"
        "</uvf:voiceData>";

    const auto uvf = blob({
        field_text("EEXT", "UVF"),
        field_text("ETIT", title),
        std::vector<std::uint8_t>(xml.begin(), xml.end())
    });

    const std::vector<std::uint8_t> pcm{0, 1, 0, 2, 0, 3, 0, 4};
    std::vector<std::uint8_t> ssnd{'S','S','N','D'};
    be32(ssnd, 16u);
    ssnd.insert(ssnd.end(), 8, 0);
    ssnd.insert(ssnd.end(), pcm.begin(), pcm.end());
    const auto apcp = blob({field_text("EEXT", "apcp"), field_text("EUID", uid), ssnd});

    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(uvf.data()), static_cast<std::streamsize>(uvf.size()));
    out.write(reinterpret_cast<const char*>(apcp.data()), static_cast<std::streamsize>(apcp.size()));
    return static_cast<bool>(out);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: PpfMultiBankLifecycleGate64 <directory-or-file.ppf>\n";
        return 2;
    }

    const std::filesystem::path arg(argv[1]);
    const auto temp_dir = std::filesystem::temp_directory_path() / "yogi_ppf_lifecycle_gate";
    std::error_code ec;
    std::filesystem::create_directories(temp_dir, ec);
    if (ec) {
        std::cerr << "[FAIL] temp directory: " << ec.message() << "\n";
        return 3;
    }

    const auto ppf0 = temp_dir / "slot62_0.ppf";
    const auto ppf3 = temp_dir / "slot62_3.ppf";
    if (!make_test_ppf(ppf0, 62, 0, 7, "Lifecycle Slot 0") ||
        !make_test_ppf(ppf3, 62, 3, 7, "Lifecycle Slot 3")) {
        std::cerr << "[FAIL] create synthetic PPF fixtures\n";
        return 4;
    }

    // First prove that the parser exposes the source slot and that the install
    // catalog does not remap it.
    PpfReader r0;
    std::string error;
    if (!r0.open(ppf0.string(), error)) {
        std::cerr << "[FAIL] PPF open slot0: " << error << "\n";
        return 10;
    }
    std::uint8_t source_msb = 0, source_lsb = 0;
    if (!r0.source_bank_slot(source_msb, source_lsb, error) || source_msb != 62u || source_lsb != 0u) {
        std::cerr << "[FAIL] source slot0 not authoritative\n";
        return 11;
    }

    InstalledVoiceCatalog catalog;
    if (!catalog.install_ppf(r0, ppf0.string(), InstalledVoiceAddress{0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] catalog install slot0: " << error << "\n";
        return 12;
    }
    const auto catalog_voice0 = catalog.bank_voice_records(catalog.banks().back().bank_id);
    if (catalog_voice0.size() != 1u || catalog_voice0[0].installed_address.msb != 62u ||
        catalog_voice0[0].installed_address.lsb != 0u || catalog_voice0[0].installed_address.program != 7u) {
        std::cerr << "[FAIL] catalog remapped source slot0\n";
        return 13;
    }

    PpfReader r3;
    if (!r3.open(ppf3.string(), error)) {
        std::cerr << "[FAIL] PPF open slot3: " << error << "\n";
        return 14;
    }

    // Native multi-bank path must preserve each source slot independently.
    NativeGuiPpfAudio audio;
    if (!audio.install_ppf_bank_audio_only(ppf0.string(), InstalledVoiceAddress{0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] first native install: " << error << "\n";
        return 15;
    }
    if (!audio.install_ppf_bank_audio_only(ppf3.string(), InstalledVoiceAddress{0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] second native install: " << error << "\n";
        return 16;
    }

    auto banks = audio.installed_ppf_banks();
    if (banks.size() != 2u || banks[0].lsb != 0u || banks[1].lsb != 3u) {
        std::cerr << "[FAIL] native banks did not preserve 62/0 and 62/3\n";
        return 17;
    }

    const auto voices = audio.installed_ppf_voices();
    if (voices.size() != 2u || voices[0].installed_address.lsb != 0u || voices[1].installed_address.lsb != 3u) {
        std::cerr << "[FAIL] installed voice list does not preserve source slots\n";
        return 18;
    }

    // A partial/incorrect slot is rejected rather than reassigned.
    if (audio.install_ppf_bank_audio_only(ppf3.string(), InstalledVoiceAddress{62, 1, 0}, error)) {
        std::cerr << "[FAIL] engine accepted an explicitly wrong slot\n";
        return 19;
    }
    if (error.find("will not renumber") == std::string::npos) {
        std::cerr << "[FAIL] wrong-slot error is not explicit: " << error << "\n";
        return 20;
    }

    const auto metrics = audio.metrics();
    if (metrics.ppf_bank_count != 2u || metrics.ppf_voice_count != 2u || metrics.resident_zone_count == 0u || metrics.unique_pcm_count == 0u) {
        std::cerr << "[FAIL] resident metrics after two authoritative installs\n";
        return 21;
    }

    const auto first_id = banks[0].bank_id;
    if (!audio.uninstall_ppf_bank(first_id, error)) {
        std::cerr << "[FAIL] uninstall first bank: " << error << "\n";
        return 22;
    }
    banks = audio.installed_ppf_banks();
    if (banks.size() != 1u || banks[0].lsb != 3u) {
        std::cerr << "[FAIL] wrong remaining bank after uninstall\n";
        return 23;
    }

    // Reload into the same source-defined slot after uninstall.
    if (!audio.install_ppf_bank_audio_only(ppf0.string(), InstalledVoiceAddress{0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] reinstall source-defined 62/0: " << error << "\n";
        return 24;
    }
    banks = audio.installed_ppf_banks();
    if (banks.size() != 2u) {
        std::cerr << "[FAIL] final bank count is not two\n";
        return 25;
    }

    std::cout << "PPF_MULTI_BANK_LIFECYCLE=PASS\n"
              << "BANKS_FINAL=" << banks.size() << "\n"
              << "SLOT0=" << int(banks[0].msb) << "/" << int(banks[0].lsb) << "\n"
              << "SLOT1=" << int(banks[1].msb) << "/" << int(banks[1].lsb) << "\n"
              << "RESIDENT_ZONES=" << audio.metrics().resident_zone_count << "\n"
              << "UNIQUE_PCM=" << audio.metrics().unique_pcm_count << "\n";

    std::filesystem::remove(ppf0, ec);
    std::filesystem::remove(ppf3, ec);
    std::filesystem::remove(temp_dir, ec);
    return 0;
}
