#include "ppf_runtime.hpp"
#include <cassert>
#include <iostream>
#include <memory>
#include <string>

using namespace arranger;

static ResidentSamplePtr sample(const char* uid) {
    auto s = std::make_shared<ResidentSample>();
    s->uid_full = uid;
    s->sample_rate = 44100;
    s->channels = 1;
    s->pcm = {0.25f, -0.25f, 0.125f};
    return s;
}

static PpfRuntimeZone zone(int key_lo, int key_hi, int vel_lo, int vel_hi,
                          std::size_t kb, const char* uid) {
    PpfRuntimeZone r;
    r.zone.key_lo = key_lo;
    r.zone.key_hi = key_hi;
    r.zone.velocity_lo = vel_lo;
    r.zone.velocity_hi = vel_hi;
    r.zone.keybank_index = kb;
    r.zone.waveform_index = kb;
    r.zone.sample_uid = uid;
    r.sample = sample(uid);
    return r;
}

int main() {
    PpfRuntimeVoice voice;
    voice.bank_id = 7;
    voice.source_index = 11;
    voice.zones.push_back(zone(60, 60, 1, 63, 0, "LOW"));
    voice.zones.push_back(zone(60, 60, 64, 127, 1, "HIGH"));
    voice.zones.push_back(zone(59, 61, 1, 127, 2, "WIDE"));

    auto* low = voice.resolve(60, 32);
    assert(low && low->zone.sample_uid == "LOW");

    auto* high = voice.resolve(60, 96);
    assert(high && high->zone.sample_uid == "HIGH");

    // Exact velocity matching: there is no key-only fallback.
    voice.zones.clear();
    voice.zones.push_back(zone(60, 60, 1, 50, 0, "ONLY_LOW"));
    assert(voice.resolve(60, 51) == nullptr);

    // Overlapping ranges are deterministic: narrowest key span wins.
    voice.zones.clear();
    voice.zones.push_back(zone(59, 61, 1, 127, 4, "WIDE"));
    voice.zones.push_back(zone(60, 60, 1, 127, 3, "NARROW"));
    auto* narrow = voice.resolve(60, 80);
    assert(narrow && narrow->zone.sample_uid == "NARROW");

    PpfRuntime runtime;
    std::string error;
    voice.zones = {zone(60, 60, 1, 63, 0, "LOW"), zone(60, 60, 64, 127, 1, "HIGH")};
    assert(runtime.upsert_voice(std::move(voice), error));
    assert(runtime.voice_count() == 1);
    assert(runtime.zone_count() == 2);
    assert(runtime.find_voice(7, 11) != nullptr);
    assert(runtime.resolve(7, 11, 60, 100) != nullptr);
    assert(runtime.resolve(7, 11, 60, 0) == nullptr);
    assert(runtime.remove_voice(7, 11));
    assert(runtime.voice_count() == 0);

    std::cout << "PPF_RUNTIME_ZONE_RESOLVER=PASS\n";
    std::cout << "EXACT_VELOCITY_NO_KEY_FALLBACK=PASS\n";
    std::cout << "DETERMINISTIC_OVERLAP_SELECTION=PASS\n";
    std::cout << "RUNTIME_BANK_LIFECYCLE=PASS\n";
    return 0;
}
