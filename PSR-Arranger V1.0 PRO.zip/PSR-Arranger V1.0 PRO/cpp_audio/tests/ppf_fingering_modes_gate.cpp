#include "performance_runtime.hpp"
#include "yamaha_style_runtime.hpp"

#include <iostream>
#include <string>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

static bool expect(const PerformanceRuntime& p, int root, int type, const char* name,
                   const char* label, int held, int bass_pc = -1) {
    const auto& s = p.state();
    const bool ok = static_cast<int>(s.chord_root_pc) == root &&
                    static_cast<int>(s.chord_type) == type &&
                    s.chord_name == name &&
                    static_cast<int>(s.held_notes.size()) == held &&
                    (bass_pc < 0 || (s.chord_bass_valid && static_cast<int>(s.chord_bass_pc) == bass_pc));
    std::cout << label << "=" << (ok ? "PASS" : "FAIL")
              << " MODE=" << PerformanceRuntime::finger_mode_name(s.finger_mode)
              << " CHORD=" << s.chord_name
              << " ROOT=" << int(s.chord_root_pc)
              << " TYPE=" << int(s.chord_type)
              << " BASS=" << (s.chord_bass_valid ? std::to_string(int(s.chord_bass_pc)) : "-")
              << " HELD=" << s.held_notes.size() << "\n";
    return ok;
}

static void clear(PerformanceRuntime& p) { p.clear_notes(); }

int main() {
    int fail = 0;
    PerformanceRuntime p;
    p.set_split_point(127);

    // 0: Single Finger: physical adjacent left keys, not hard-coded intervals.
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::SingleFinger));
    p.note_on(60, 100); // C4
    if (!expect(p, 0, 0, "C", "SINGLE_MAJOR", 1, 0)) ++fail;
    clear(p);
    p.note_on(58, 100); p.note_on(60, 100); // Bb3 + C4
    if (!expect(p, 0, 1, "Cm", "SINGLE_MINOR", 2, 0)) ++fail;
    clear(p);
    p.note_on(59, 100); p.note_on(60, 100); // B3 + C4
    if (!expect(p, 0, 2, "C7", "SINGLE_7TH", 2, 0)) ++fail;
    clear(p);
    p.note_on(58, 100); p.note_on(59, 100); p.note_on(60, 100);
    if (!expect(p, 0, 4, "Cm7", "SINGLE_M7", 3, 0)) ++fail;

    // 1: Fingered triad matching.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::Fingered));
    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100);
    if (!expect(p, 0, 0, "C", "FINGERED_MAJOR", 3, 0)) ++fail;

    // Fingered must recognize inversions by chord content, not by lowest note.
    clear(p);
    p.note_on(64, 100); p.note_on(67, 100); p.note_on(72, 100); // C/E inversion
    if (!expect(p, 0, 0, "C", "FINGERED_INVERSION_C_OVER_E", 3, 0)) ++fail;

    // 2: Fingered On Bass preserves chord root and reports the lowest chord note.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::FingeredOnBass));
    p.note_on(64, 100); p.note_on(67, 100); p.note_on(72, 100);
    if (!expect(p, 0, 0, "C", "FINGERED_ON_BASS_E", 3, 4)) ++fail;

    // 3: Multi Finger accepts a Fingered 1+5 shape as well as Single Finger.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::MultiFinger));
    p.note_on(60, 100); p.note_on(67, 100);
    if (!expect(p, 0, 0, "C1+5", "MULTI_FINGER_1_5", 2, 0)) ++fail;

    // 4: AI Fingered can resolve a single note using the previous chord type.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::AIFingered));
    p.note_on(60, 100); p.note_on(63, 100); p.note_on(67, 100); // Cm context
    if (!expect(p, 0, 1, "Cm", "AI_CONTEXT_SOURCE", 3, 0)) ++fail;
    clear(p);
    p.note_on(62, 100); // D -> inferred Dm from previous minor context
    if (!expect(p, 2, 1, "Dm", "AI_ONE_NOTE_CONTEXT", 1, 2)) ++fail;

    // 5: Full Keyboard tolerates a melody extra above a valid triad.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::FullKeyboard));
    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100); p.note_on(62, 100);
    if (!expect(p, 0, 0, "Cadd9", "FULL_KEYBOARD_MELODY_EXTRA_ADD9", 4, 0)) ++fail;

    // 6: AI Full Keyboard inherits previous context for short input and does not accept 9/11/13 chords.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::AIFullKeyboard));
    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100); // C context
    clear(p);
    p.note_on(65, 100); // F -> inferred F major from previous major context
    if (!expect(p, 5, 0, "F", "AI_FULL_ONE_NOTE", 1, 5)) ++fail;
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::AIFullKeyboard));
    p.note_on(60, 100); p.note_on(64, 100); p.note_on(67, 100); p.note_on(62, 100); // 9th shape must not be labeled as a 9th chord in AI Full Keyboard
    {
        const auto n = p.state().chord_name;
        const bool ok = n.find("9") == std::string::npos && n.find("11") == std::string::npos && n.find("13") == std::string::npos && n == "C";
        std::cout << "AI_FULL_NO_EXTENDED_LABEL=" << (ok ? "PASS" : "FAIL") << " GOT=" << n << "\n";
        if (!ok) ++fail;
    }

    // 7: Smart Chord with a C-major key signature and Standard chart.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::SmartChord));
    p.set_smart_chord_key(0); // C major
    p.set_smart_chord_type(0); // Standard
    p.note_on(67, 100); // G root -> G7
    if (!expect(p, 7, 2, "G7", "SMART_C_STANDARD_G", 1, 7)) ++fail;

    // Smart Chord Pop in F major: C is V, therefore C7 in the documented chart.
    clear(p);
    p.set_smart_chord_key(5); // F major
    p.set_smart_chord_type(1); // Pop
    p.note_on(60, 100); // C4
    if (!expect(p, 0, 2, "C7", "SMART_F_POP_C", 1, 0)) ++fail;
    clear(p);
    p.set_smart_chord_key(0);
    p.set_smart_chord_type(0);
    p.note_on(71, 100); // B is VII: V on VII -> G7/B
    if (!expect(p, 7, 2, "G7/B", "SMART_C_V_ON_VII", 1, 11)) ++fail;
    clear(p);
    p.set_smart_chord_key(9); // A minor
    p.set_smart_chord_type(0); // Standard
    p.set_smart_chord_minor(true);
    p.note_on(71, 100); // B is II in A minor -> Bm7b5
    if (!expect(p, 11, 4, "Bm7b5", "SMART_A_MINOR_STANDARD_II", 1, 11)) ++fail;
    clear(p);
    p.set_smart_chord_type(1); // Pop
    p.note_on(71, 100); // B is II in A minor -> bVII on II = G/B
    if (!expect(p, 7, 0, "G/B", "SMART_A_MINOR_POP_BVII_ON_II", 1, 11)) ++fail;

    // 8: Legacy Fingered 1/2 = Fingered detection + bass awareness.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::Fingered12));
    p.note_on(64, 100); p.note_on(67, 100); p.note_on(72, 100);
    if (!expect(p, 0, 0, "C", "FINGERED_1_2_BASS", 3, 4)) ++fail;

    // Split point gate: in strict Fingered mode notes above split are not chord notes.
    clear(p);
    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::Fingered));
    p.set_split_point(42);
    p.note_on(31, 100); p.note_on(36, 100); p.note_on(40, 100);
    if (!expect(p, 0, 0, "C", "SPLIT_FALLBACK_PREVIOUS", 3, 0)) ++fail;

    // Bass output path: Bass-role CASM uses the detected inversion bass, while normal roles retain chord root.
    arranger::YamahaStyleCasmRule bass_rule;
    bass_rule.role = "Bass"; bass_rule.source_channel = 0; bass_rule.destination_channel = 0;
    bass_rule.source_root = 0; bass_rule.slots.push_back(arranger::YamahaStyleCasmSlot{});
    std::uint8_t bass_out = 0, bass_dest = 0;
    if (!arranger::YamahaStyleRuntime::transform_note_with_rule(bass_rule, 60, 0, 0, 4, true, bass_out, bass_dest) || bass_out != 64) {
        std::cout << "FINGERED_ON_BASS_AUDIO_PATH=FAIL OUT=" << int(bass_out) << "\n"; ++fail;
    } else {
        std::cout << "FINGERED_ON_BASS_AUDIO_PATH=PASS OUT=" << int(bass_out) << "\n";
    }

    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
