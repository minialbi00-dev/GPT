#include "performance_runtime.hpp"

#include <array>
#include <cstdint>
#include <iostream>
#include <string>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

static std::string expected_name(const std::string& key, const std::array<const char*, 12>& names, int slot) {
    return names[static_cast<std::size_t>(slot)];
}

static bool run_table(const char* label, int table, bool minor, int key_pc,
                      const std::array<std::string, 12>& expected) {
    int fail = 0;
    for (int rel = 0; rel < 12; ++rel) {
        PerformanceRuntime p;
        p.set_split_point(42);
        p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::SmartChord));
        p.set_smart_chord_key(key_pc);
        p.set_smart_chord_type(static_cast<std::uint8_t>(table));
        p.set_smart_chord_minor(minor);
        const int note = (key_pc + rel + 12) % 12 + 24; // keep trigger below F#1 boundary
        p.note_on(static_cast<std::uint8_t>(note), 100);
        const auto& s = p.state();
        const bool ok = s.chord_name == expected[static_cast<std::size_t>(rel)] && s.held_notes.size() == 1;
        if (!ok) {
            ++fail;
            std::cout << label << "_SLOT" << rel << "=FAIL GOT=" << s.chord_name
                      << " EXPECTED=" << expected[static_cast<std::size_t>(rel)] << "\n";
        }
    }
    std::cout << label << "=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0;
}

int main() {
    // C major (key_pc=0).
    const std::array<std::string,12> maj_std = {{"C","C#dim","Dm","Eb","Em","F","F#dim","G7","Abdim","Am","Bb","G7/B"}};
    const std::array<std::string,12> maj_pop = {{"Cadd9","C#dim7","Dm7","Ebdim7","Em7","FM7","F#dim","G7","Abdim","Am7","Bb","G7/B"}};
    const std::array<std::string,12> maj_jazz = {{"CM7(9)","C#dim7","Dm7(9)","Ebdim7","Em7","F6(9)","F#dim7","G7(9)","Abdim","Am7(11)","Bb7","Bm7b5"}};
    const std::array<std::string,12> maj_dance = {{"C","C#dim","Dm","Eb","Em","F","F#dim","G","Abdim","Am","Bb","G/B"}};
    const std::array<std::string,12> maj_basic = {{"C","C#dim","Dm","Eb","E1+5","F1+5","F#dim","G7","Abdim","A","Bb","G7/B"}};

    // A minor (key_pc=9).
    const std::array<std::string,12> min_std = {{"Am","Bb","Bm7b5","C","C#dim","Dm","Ebdim7","E7","F","F#dim","G7","E7/Ab"}};
    const std::array<std::string,12> min_pop = {{"Am7","Bb","G/B","C","C#dim7","Dm7","Ebdim7","E7","FM7","F#dim","G7","E7/Ab"}};
    const std::array<std::string,12> min_jazz = {{"Am add9","Bb7","Bm7b5","CM7(9)","C#dim7","Dm7(9)","Ebdim7","E7","FM7(9)","F#m7b5","G7(9)","Ab7"}};
    const std::array<std::string,12> min_dance = {{"Am","Bb","Bm","Cm","C#m","Dm","Ebm","Em","Fm","F#m","Gm","Ab"}};
    const std::array<std::string,12> min_basic = {{"Am","Bb","Bm7b5","C","C#dim7","Dm","Ebdim7","E1+5","F","F#dim","G7","E7/Ab"}};

    int fail = 0;
    fail += !run_table("SMART_MAJOR_STANDARD",0,false,0,maj_std);
    fail += !run_table("SMART_MAJOR_POP",1,false,0,maj_pop);
    fail += !run_table("SMART_MAJOR_JAZZ",2,false,0,maj_jazz);
    fail += !run_table("SMART_MAJOR_DANCE",3,false,0,maj_dance);
    fail += !run_table("SMART_MAJOR_BASIC",4,false,0,maj_basic);
    fail += !run_table("SMART_MINOR_STANDARD",0,true,9,min_std);
    fail += !run_table("SMART_MINOR_POP",1,true,9,min_pop);
    fail += !run_table("SMART_MINOR_JAZZ",2,true,9,min_jazz);
    fail += !run_table("SMART_MINOR_DANCE",3,true,9,min_dance);
    fail += !run_table("SMART_MINOR_BASIC",4,true,9,min_basic);
    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
