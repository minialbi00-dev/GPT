#include "native_gui_ppf_audio.hpp"
#include "ppf_reader.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace arranger {
struct NativeGuiPpfAudioTestAccess {
    static bool handle(NativeGuiPpfAudio& a, const NativeGuiAudioEvent& e) noexcept { return a.handle_event(e); }
    static bool render(NativeGuiPpfAudio& a, float* dst, std::size_t frames, int rate) noexcept { return a.render_audio(dst, frames, rate); }
};
}

namespace {
void be32(std::vector<std::uint8_t>& out, std::uint32_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 24));
    out.push_back(static_cast<std::uint8_t>(v >> 16));
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}

std::vector<std::uint8_t> field(const char tag[4], const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out(tag, tag + 4);
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

std::vector<std::uint8_t> textf(const char tag[4], const std::string& text) {
    return field(tag, std::vector<std::uint8_t>(text.begin(), text.end()));
}

std::vector<std::uint8_t> blob(const std::vector<std::vector<std::uint8_t>>& fields) {
    std::vector<std::uint8_t> payload;
    for (const auto& f : fields) payload.insert(payload.end(), f.begin(), f.end());
    std::vector<std::uint8_t> out{'B','L','O','B'};
    be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

std::vector<std::uint8_t> ssnd(std::size_t frames, std::int16_t value) {
    std::vector<std::uint8_t> out{'S','S','N','D'};
    be32(out, static_cast<std::uint32_t>(8 + frames * 2));
    out.insert(out.end(), 8, 0);
    for (std::size_t i = 0; i < frames; ++i) {
        out.push_back(static_cast<std::uint8_t>(value & 0xFF));
        out.push_back(static_cast<std::uint8_t>(static_cast<std::uint16_t>(value) >> 8));
    }
    return out;
}

std::string note_name(int midi_note) {
    static const char* names[] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    const int octave = midi_note / 12 - 2; // Yamaha UVF convention: C-2 = MIDI 0.
    return std::string(names[midi_note % 12]) + std::to_string(octave);
}

struct Layer {
    int vlo;
    int vhi;
    int alternate_group;
    int receive_note_off;
    std::string uid;
};

std::string keybank_xml(const std::string& note, const Layer& layer) {
    return std::string("<keybank><noteLimitLo>") + note + "</noteLimitLo><noteLimitHi>" + note +
           "</noteLimitHi><velocityLimitLo>" + std::to_string(layer.vlo) +
           "</velocityLimitLo><velocityLimitHi>" + std::to_string(layer.vhi) +
           "</velocityLimitHi><centerNote>" + note + "</centerNote>"+
           "<drumSetup><alternateGroup>" + std::to_string(layer.alternate_group) +
           "</alternateGroup><rcvNoteOff>" + std::to_string(layer.receive_note_off) +
           "</rcvNoteOff><rcvNoteOn>1</rcvNoteOn></drumSetup>"+
           "<sample position=\"MONO\"><waveFilePath>" + layer.uid + "</waveFilePath></sample></keybank>";
}

std::string drum_element(int number, int note, const std::vector<Layer>& layers) {
    const std::string nn = note_name(note);
    std::string xml =
        std::string("<voiceElement xsi:type=\"uvf:VOICE_ELEMENT_DRUM_KIT\" number=\"") +
        std::to_string(number) + "\"><name></name><volume>0</volume><pan>0</pan>"+
        "<noteLimitHi>" + nn + "</noteLimitHi><noteLimitLo>" + nn +
        "</noteLimitLo><velocityLimitHi>127</velocityLimitHi><velocityLimitLo>1</velocityLimitLo>"+
        "<blockComposition><oscillatorBlock xsi:type=\"uvf:OSCILLATOR_BLOCK_DRUM_KIT\"><waveformNum>"+
        std::to_string(number) + "</waveformNum><releaseOnlyAEG>ON</releaseOnlyAEG></oscillatorBlock>"+
        "<amplitudeBlock xsi:type=\"uvf:AMPLITUDE_BLOCK_DRUM_KIT\"><releaseRate>0.900000</releaseRate></amplitudeBlock></blockComposition>"+
        "<drumSetup><alternateGroup>0</alternateGroup><keyAssign>1</keyAssign><rcvNoteOff>0</rcvNoteOff><rcvNoteOn>1</rcvNoteOn>"+
        "<egAttack>64</egAttack><egDecay1>64</egDecay1><egDecay2>64</egDecay2></drumSetup>"+
        "<waveform number=\"" + std::to_string(number) + "\">";
    for (const auto& layer : layers) xml += keybank_xml(nn, layer);
    xml += "</waveform></voiceElement>";
    return xml;
}

bool make_ppf(const std::filesystem::path& path) {
    // F#1 (MIDI 42) contains TWO KeyBanks on one waveform:
    //   1..63  -> Alternate Group 1
    //  64..127 -> Alternate Group 2
    // A#1 (MIDI 46) is the open-hat layer -> Alternate Group 1.
    // This proves Alternate Group is a KeyBank/velocity-layer property, not a Voice-wide constant.
    const std::string xml =
        std::string("<?xml version=\"1.0\"?><uvf:voiceData xmlns:uvf=\"http://www.yamaha.com/uvf\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">") +
        "<voiceType>DRUM_KIT</voiceType>"+
        "<information><voiceName>Drum Release Alternate Group Gate</voiceName><voiceMsb>62</voiceMsb><voiceLsb>7</voiceLsb><voicePcNum>12</voicePcNum></information>"+
        drum_element(42, 42, {
            {1, 63, 1, 0, "UID_FSHARP_LOW"},
            {64, 127, 2, 0, "UID_FSHARP_HIGH"}
        }) +
        drum_element(46, 46, {
            {1, 127, 1, 0, "UID_ASHARP_OPEN"}
        }) +
        drum_element(50, 50, {
            {1, 127, 0, 1, "UID_RCV_NOTE_OFF_ON"}
        }) +
        "</uvf:voiceData>";

    const auto uvf = blob({textf("EEXT", "UVF"), textf("ETIT", "Drum Release Alternate Group Gate"),
                           std::vector<std::uint8_t>(xml.begin(), xml.end())});
    const auto a = blob({textf("EEXT", "apcp"), textf("EUID", "UID_FSHARP_LOW"), ssnd(60000, 1000)});
    const auto b = blob({textf("EEXT", "apcp"), textf("EUID", "UID_FSHARP_HIGH"), ssnd(60000, 2000)});
    const auto c = blob({textf("EEXT", "apcp"), textf("EUID", "UID_ASHARP_OPEN"), ssnd(60000, 3000)});
    const auto d = blob({textf("EEXT", "apcp"), textf("EUID", "UID_RCV_NOTE_OFF_ON"), ssnd(12000, 4000)});

    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(uvf.data()), static_cast<std::streamsize>(uvf.size()));
    out.write(reinterpret_cast<const char*>(a.data()), static_cast<std::streamsize>(a.size()));
    out.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size()));
    out.write(reinterpret_cast<const char*>(c.data()), static_cast<std::streamsize>(c.size()));
    out.write(reinterpret_cast<const char*>(d.data()), static_cast<std::streamsize>(d.size()));
    return static_cast<bool>(out);
}

void set_voice(arranger::NativeGuiPpfAudio& audio) {
    arranger::NativeGuiPpfAudioTestAccess::handle(audio, {0, 0xB0, 0, 62});
    arranger::NativeGuiPpfAudioTestAccess::handle(audio, {0, 0xB0, 32, 7});
    arranger::NativeGuiPpfAudioTestAccess::handle(audio, {0, 0xC0, 12, 0});
}
}

int main() {
    const auto path = std::filesystem::temp_directory_path() / "ppf_drum_release_alt_group_gate.ppf";
    std::error_code ec;
    std::filesystem::remove(path, ec);
    if (!make_ppf(path)) { std::cerr << "[FAIL] fixture create\n"; return 1; }

    arranger::PpfReader reader;
    std::string error;
    if (!reader.open(path.string(), error)) { std::cerr << "[FAIL] parser open: " << error << "\n"; return 2; }
    if (reader.summary().voice_zone_count != 4 || reader.voice_zones().size() != 4) {
        std::cerr << "[FAIL] expected 3 KeyBank zones, got " << reader.voice_zones().size() << "\n";
        return 3;
    }
    const auto& low = reader.voice_zones()[0];
    const auto& high = reader.voice_zones()[1];
    const auto& open = reader.voice_zones()[2];
    const auto& rcv_on = reader.voice_zones()[3];
    if (low.key_lo != 42 || low.key_hi != 42 || low.velocity_lo != 1 || low.velocity_hi != 63 || low.alternate_group != 1 || low.receive_note_off ||
        high.key_lo != 42 || high.key_hi != 42 || high.velocity_lo != 64 || high.velocity_hi != 127 || high.alternate_group != 2 || high.receive_note_off ||
        open.key_lo != 46 || open.key_hi != 46 || open.velocity_lo != 1 || open.velocity_hi != 127 || open.alternate_group != 1 || open.receive_note_off ||
        rcv_on.key_lo != 50 || rcv_on.key_hi != 50 || rcv_on.velocity_lo != 1 || rcv_on.velocity_hi != 127 || rcv_on.alternate_group != 0 || !rcv_on.receive_note_off) {
        std::cerr << "[FAIL] parsed per-KeyBank drum metadata incorrect\n";
        return 4;
    }

    arranger::NativeGuiPpfAudio audio;
    if (!audio.install_ppf_bank_audio_only(path.string(), {0xFF, 0xFF, 0}, error)) {
        std::cerr << "[FAIL] install: " << error << "\n";
        return 5;
    }
    set_voice(audio);
    arranger::StyleVoiceCall call{};
    call.channel = 0; call.msb = 62; call.lsb = 7; call.program = 12;
    if (audio.preload_style_voice(call, error) != 1) {
        std::cerr << "[FAIL] preload: " << error << "\n";
        return 5;
    }

    std::vector<float> one_frame(2);
    // F#1 velocity 40 -> low KeyBank / Group 1.
    if (!arranger::NativeGuiPpfAudioTestAccess::handle(audio, {0, 0x90, 42, 40})) return 6;
    arranger::NativeGuiPpfAudioTestAccess::render(audio, one_frame.data(), 1, 48000);
    if (audio.metrics().active_voices != 1) { std::cerr << "[FAIL] low KeyBank did not start\n"; return 7; }

    // A#1 open hat Group 1 must immediately choke F#1 low layer Group 1.
    if (!arranger::NativeGuiPpfAudioTestAccess::handle(audio, {0, 0x90, 46, 100})) return 8;
    arranger::NativeGuiPpfAudioTestAccess::render(audio, one_frame.data(), 1, 48000);
    if (audio.metrics().active_voices != 1) {
        std::cerr << "[FAIL] Group 1 open hat did not choke the Group 1 low F# KeyBank\n";
        return 9;
    }

    // rcvNoteOff=0: Note-Off must NOT invoke the generic 50 ms release.
    if (!arranger::NativeGuiPpfAudioTestAccess::handle(audio, {1, 0x80, 46, 0})) return 10;
    std::vector<float> tail(4800 * 2);
    if (!arranger::NativeGuiPpfAudioTestAccess::render(audio, tail.data(), 4800, 48000)) return 11;
    std::size_t nonzero = 0;
    for (float sample : tail) if (sample != 0.0f) ++nonzero;
    if (audio.metrics().active_voices != 1 || nonzero == 0) {
        std::cerr << "[FAIL] rcvNoteOff=0 drum tail was cut after Note-Off\n";
        return 12;
    }

    // F#1 velocity 100 -> HIGH KeyBank / Group 2. It must coexist with Group 1 open hat.
    if (!arranger::NativeGuiPpfAudioTestAccess::handle(audio, {2, 0x90, 42, 100})) return 13;
    arranger::NativeGuiPpfAudioTestAccess::render(audio, one_frame.data(), 1, 48000);
    if (audio.metrics().active_voices != 2) {
        std::cerr << "[FAIL] high F# velocity layer Group 2 was incorrectly choked by Group 1\n";
        return 14;
    }

    // A separate drum key with rcvNoteOff=1 must retain the normal release path.
    arranger::NativeGuiPpfAudioTestAccess::handle(audio, {3, 0x90, 50, 100});
    arranger::NativeGuiPpfAudioTestAccess::render(audio, one_frame.data(), 1, 48000);
    if (audio.metrics().active_voices != 3) {
        std::cerr << "[FAIL] rcvNoteOff=1 drum did not start\n";
        return 15;
    }
    arranger::NativeGuiPpfAudioTestAccess::handle(audio, {4, 0x80, 50, 0});
    std::vector<float> release_buf(3000 * 2);
    arranger::NativeGuiPpfAudioTestAccess::render(audio, release_buf.data(), 3000, 48000);
    if (audio.metrics().active_voices != 2) {
        std::cerr << "[FAIL] rcvNoteOff=1 drum did not enter/complete the normal release path\n";
        return 16;
    }

    std::cout << "PPF_DRUM_RELEASE_ALTERNATEGROUP=PASS\n";
    std::cout << "F_SHARP_LOW_VEL=1..63 ALT_GROUP=1\n";
    std::cout << "F_SHARP_HIGH_VEL=64..127 ALT_GROUP=2\n";
    std::cout << "A_SHARP_OPEN_VEL=1..127 ALT_GROUP=1\n";
    std::cout << "RCV_NOTE_OFF_DRUM_LAYERS=OFF\n";
    std::cout << "LONG_TAIL_AFTER_NOTE_OFF=PASS\n";
    std::cout << "PER_KEYBANK_PER_VELOCITY_ALTERNATEGROUP=PASS\n";
    std::filesystem::remove(path, ec);
    return 0;
}
