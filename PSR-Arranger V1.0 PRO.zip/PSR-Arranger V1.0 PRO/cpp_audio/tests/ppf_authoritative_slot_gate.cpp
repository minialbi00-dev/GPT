#include "ppf_reader.hpp"
#include "voice_install_catalog.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {
void be32(std::vector<std::uint8_t>& out, std::uint32_t v) {
    out.push_back(static_cast<std::uint8_t>(v >> 24));
    out.push_back(static_cast<std::uint8_t>(v >> 16));
    out.push_back(static_cast<std::uint8_t>(v >> 8));
    out.push_back(static_cast<std::uint8_t>(v));
}
std::vector<std::uint8_t> field(const char tag[4], const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out(tag, tag + 4); be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end()); return out;
}
std::vector<std::uint8_t> field_text(const char tag[4], const std::string& text) {
    return field(tag, std::vector<std::uint8_t>(text.begin(), text.end()));
}
std::vector<std::uint8_t> blob(const std::vector<std::vector<std::uint8_t>>& fields) {
    std::vector<std::uint8_t> payload;
    for (const auto& f : fields) payload.insert(payload.end(), f.begin(), f.end());
    std::vector<std::uint8_t> out{'B','L','O','B'}; be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end()); return out;
}
void append(std::vector<std::uint8_t>& dst, const std::vector<std::uint8_t>& src) { dst.insert(dst.end(), src.begin(), src.end()); }
std::string make_ppf(std::uint8_t msb, std::uint8_t lsb, const std::string& name, bool utf16 = false) {
    const std::string xml = "<?xml version=\"1.0\"?><uvf:voiceData><voiceType>UNIVERSAL</voiceType><information>"
                          "<voiceName>" + name + "</voiceName><voiceMsb>" + std::to_string(msb) +
                          "</voiceMsb><voiceLsb>" + std::to_string(lsb) + "</voiceLsb><voicePcNum>7</voicePcNum>"
                          "</information><voiceCommon/></uvf:voiceData>";
    std::vector<std::uint8_t> xml_bytes;
    if (utf16) {
        xml_bytes.reserve(xml.size() * 2u + 2u);
        xml_bytes.push_back(0xFF); xml_bytes.push_back(0xFE);
        for (unsigned char c : xml) { xml_bytes.push_back(c); xml_bytes.push_back(0x00); }
    } else {
        xml_bytes.assign(xml.begin(), xml.end());
    }
    auto uvf = blob({field_text("EEXT", utf16 ? "uVf" : "UVF"), field_text("ETIT", name), xml_bytes});
    const std::vector<std::uint8_t> pcm{0,1,0,2,0,3,0,4};
    std::vector<std::uint8_t> ssnd{'S','S','N','D'}; be32(ssnd, 16u); ssnd.insert(ssnd.end(), 8, 0); ssnd.insert(ssnd.end(), pcm.begin(), pcm.end());
    auto apcp = blob({field_text("EEXT", "apcp"), field_text("EUID", "UID_" + name), ssnd});
    const auto path = (std::filesystem::temp_directory_path() / ("ppf_slot_" + std::to_string(msb) + "_" + std::to_string(lsb) + ".ppf")).string();
    std::ofstream f(path, std::ios::binary); append(uvf, {}); f.write(reinterpret_cast<const char*>(uvf.data()), static_cast<std::streamsize>(uvf.size())); f.write(reinterpret_cast<const char*>(apcp.data()), static_cast<std::streamsize>(apcp.size())); return path;
}
}
int main() {
    std::string error;
    const auto p0 = make_ppf(62, 0, "Slot0");
    const auto p3 = make_ppf(62, 3, "Slot3", true);
    const auto p6 = make_ppf(62, 6, "Slot6");
    arranger::InstalledVoiceCatalog cat;
    for (const auto& path : {p0, p3, p6}) {
        arranger::PpfReader reader;
        if (!reader.open(path, error)) { std::cerr << "[FAIL] open " << path << ": " << error << "\n"; return 10; }
        std::uint8_t msb = 0, lsb = 0;
        if (!reader.source_bank_slot(msb, lsb, error)) { std::cerr << "[FAIL] source slot: " << error << "\n"; return 11; }
        if (msb != 62u) { std::cerr << "[FAIL] source MSB " << int(msb) << "\n"; return 12; }
        if (!cat.install_ppf(reader, path, {0xFF,0xFF,0}, error)) { std::cerr << "[FAIL] install: " << error << "\n"; return 13; }
        const auto recs = cat.bank_voice_records(cat.banks().back().bank_id);
        if (recs.size() != 1u || !recs[0].installed_address_valid || recs[0].installed_address.msb != 62u || recs[0].installed_address.lsb != lsb || recs[0].installed_address.program != 7u) {
            std::cerr << "[FAIL] source address not preserved for " << int(lsb) << "\n"; return 14;
        }
        std::cout << "SOURCE_SLOT=62/" << int(lsb) << " -> INSTALLED=62/" << int(recs[0].installed_address.lsb) << "/7 PASS\n";
    }
    const auto p_bad = make_ppf(62, 9, "Slot9");
    arranger::PpfReader bad_reader;
    if (!bad_reader.open(p_bad, error)) { std::cerr << "[FAIL] bad-reader open: " << error << "\n"; return 15; }
    if (cat.install_ppf(bad_reader, p_bad, {62, 1, 0}, error)) { std::cerr << "[FAIL] mismatched explicit slot was accepted\n"; return 16; }
    std::cout << "MISMATCH_SLOT_REJECTED=PASS\nPPF_AUTHORITATIVE_SLOT_GATE=PASS\n";
    std::error_code ec; for (const auto& p : {p0,p3,p6,p_bad}) std::filesystem::remove(p, ec);
    return 0;
}
