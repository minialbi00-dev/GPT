#include "performance_runtime.hpp"
#include <iostream>
#include <string>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

static void clear(PerformanceRuntime& p) { p.clear_notes(); }

int main() {
    int fail = 0;
    PerformanceRuntime p;
    p.set_split_point(42); // Yamaha F#1 boundary (C3 = MIDI 60).

    // A normal C3-E3-G3 chord is above F#1. AI Full Keyboard/Full Keyboard
    // are expected to see it; split-bound modes must not. This reproduces the
    // user's observation and proves it is caused by the split zone, not by
    // the Fingered recognizer itself.
    const unsigned char hi[] = {60,64,67};
    for (auto m : {PerformanceFingerMode::SingleFinger,
                   PerformanceFingerMode::Fingered,
                   PerformanceFingerMode::FingeredOnBass,
                   PerformanceFingerMode::MultiFinger,
                   PerformanceFingerMode::AIFingered,
                   PerformanceFingerMode::SmartChord,
                   PerformanceFingerMode::Fingered12}) {
        clear(p); p.set_finger_mode(static_cast<unsigned char>(m));
        for (auto n : hi) p.note_on(n,100);
        // With split F#1, these notes are intentionally invisible.
        const bool filtered = p.state().held_notes.empty();
        if (!filtered) ++fail;
    }
    clear(p); p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::FullKeyboard));
    for (auto n : hi) p.note_on(n,100);
    if (p.state().chord_name != "C") { std::cerr << "FULL_KEYBOARD_HIGH_CHORD=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "FULL_KEYBOARD_HIGH_CHORD=PASS\n";
    clear(p); p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::AIFullKeyboard));
    for (auto n : hi) p.note_on(n,100);
    if (p.state().chord_name != "C") { std::cerr << "AI_FULL_HIGH_CHORD=FAIL GOT=" << p.state().chord_name << "\n"; ++fail; }
    else std::cout << "AI_FULL_HIGH_CHORD=PASS\n";

    // A C0-E0-G0 chord is fully inside the F#1 chord zone, so the non-full
    // modes must actually respond according to their selected fingering.
    const unsigned char lo[] = {24,28,31};
    for (auto [mode, label] : std::initializer_list<std::pair<PerformanceFingerMode,const char*>>{
        {PerformanceFingerMode::Fingered,"FINGERED_LOW_ZONE"},
        {PerformanceFingerMode::FingeredOnBass,"FINGERED_ON_BASS_LOW_ZONE"},
        {PerformanceFingerMode::MultiFinger,"MULTI_FINGER_LOW_ZONE"},
        {PerformanceFingerMode::AIFingered,"AI_FINGERED_LOW_ZONE"},
        {PerformanceFingerMode::Fingered12,"FINGERED_1_2_LOW_ZONE"}}) {
        clear(p); p.set_finger_mode(static_cast<unsigned char>(mode));
        for (auto n : lo) p.note_on(n,100);
        const bool ok = p.state().chord_name == "C" && p.state().held_notes.size() == 3u;
        std::cout << label << "=" << (ok ? "PASS" : "FAIL") << " GOT=" << p.state().chord_name << "\n";
        if (!ok) ++fail;
    }

    // Single Finger and Smart Chord are one-note modes in this zone test.
    clear(p); p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::SingleFinger));
    p.note_on(31,100); // G0, inside F#1 boundary.
    const bool sf_ok = p.state().chord_name == "G";
    std::cout << "SINGLE_FINGER_LOW_ZONE=" << (sf_ok ? "PASS" : "FAIL") << " GOT=" << p.state().chord_name << "\n";
    if (!sf_ok) ++fail;

    clear(p); p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::SmartChord));
    p.set_smart_chord_key(0); p.set_smart_chord_type(0); p.note_on(31,100); // G0 => G7 in C Standard.
    const bool sc_ok = p.state().chord_name == "G7";
    std::cout << "SMART_CHORD_LOW_ZONE=" << (sc_ok ? "PASS" : "FAIL") << " GOT=" << p.state().chord_name << "\n";
    if (!sc_ok) ++fail;

    std::cout << "RESULT=" << (fail==0 ? "PASS" : "FAIL") << "\n";
    return fail==0 ? 0 : 1;
}
