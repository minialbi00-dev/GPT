#include "performance_runtime.hpp"
#include <iostream>
#include <string>
#include <vector>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

static bool expect(const char* label, const PerformanceRuntime& p, const std::string& name,
                   int root, int type, int bass = -1, bool bass_valid = false) {
    const auto& s = p.state();
    bool ok = s.chord_name == name && int(s.chord_root_pc) == root && int(s.chord_type) == type;
    if (bass_valid) ok = ok && bool(s.chord_bass_valid) && int(s.chord_bass_pc) == bass;
    std::cout << label << "=" << (ok ? "PASS" : "FAIL")
              << " MODE=" << PerformanceRuntime::finger_mode_name(s.finger_mode)
              << " CHORD=" << s.chord_name
              << " ROOT=" << int(s.chord_root_pc)
              << " TYPE=" << int(s.chord_type)
              << " BASS=" << int(s.chord_bass_pc) << "\n";
    return ok;
}

static void clear(PerformanceRuntime& p) { p.clear_notes(); }
static void on(PerformanceRuntime& p, std::initializer_list<int> notes) {
    for (int n : notes) p.note_on(static_cast<std::uint8_t>(n), 100);
}

int main() {
    int fail = 0;

    auto fresh = []() {
        PerformanceRuntime p;
        p.set_split_point(127); // neutralize split only for fingering isolation
        return p;
    };

    // 0 Single Finger: C + Bb to the left => Cm; this is NOT Fingered input.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::SingleFinger));
      on(p, {58,60}); if (!expect("MODE0_SINGLE_Cm", p, "Cm", 0, 1, 0, true)) ++fail; }

    // 1 Fingered: the same two-note Single Finger shape is not promoted to Cm.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::Fingered));
      on(p, {58,60}); if (!expect("MODE1_FINGERED_REJECT_SF", p, "No Chord", 0, 0)) ++fail; }

    // 2 Fingered On Bass: same Fingered recognition, lowest chord-section note is bass.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::FingeredOnBass));
      on(p, {52,55,60}); if (!expect("MODE2_ON_BASS_C_E", p, "C", 0, 0, 4, true)) ++fail; }

    // 3 Multi Finger: accepts either Single Finger or Fingered.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::MultiFinger));
      on(p, {58,60}); if (!expect("MODE3_MULTI_SF", p, "Cm", 0, 1, 0, true)) ++fail;
      clear(p); on(p, {60,64,67}); if (!expect("MODE3_MULTI_FINGERED", p, "C", 0, 0)) ++fail; }

    // 4 AI Fingered: strict Fingered first, then context for a one-note trigger.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::AIFingered));
      on(p, {60,63,67}); clear(p); on(p, {62});
      if (!expect("MODE4_AI_CONTEXT", p, "Dm", 2, 1, 2, true)) ++fail; }

    // 5 Full Keyboard: same Fingered recognition but entire key range is used.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::FullKeyboard));
      on(p, {36,60,64,67}); if (!expect("MODE5_FULL_C_WITH_LOW_BASS", p, "C", 0, 0)) ++fail; }

    // 6 AI Full Keyboard: Full Keyboard + short-note context, extended chords disallowed.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::AIFullKeyboard));
      on(p, {60,64,67}); clear(p); on(p, {65});
      if (!expect("MODE6_AI_FULL_CONTEXT", p, "F", 5, 0, 5, true)) ++fail; }

    // 7 Smart Chord: one trigger key is mapped by the selected Smart Chord chart.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::SmartChord));
      p.set_smart_chord_key(0); p.set_smart_chord_type(0); p.set_smart_chord_minor(false);
      on(p, {67}); if (!expect("MODE7_SMART_G", p, "G7", 7, 2, 7, true)) ++fail; }

    // 8 project compatibility: same detection core as Fingered, plus bass state.
    { auto p = fresh(); p.set_finger_mode(static_cast<std::uint8_t>(PerformanceFingerMode::Fingered12));
      on(p, {64,67,72}); if (!expect("MODE8_FINGERED12", p, "C", 0, 0, 4, true)) ++fail; }

    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
