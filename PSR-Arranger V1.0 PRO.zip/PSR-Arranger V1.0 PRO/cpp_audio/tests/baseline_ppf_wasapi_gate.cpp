#include "native_gui_ppf_audio.hpp"
#include "ppf_reader.hpp"
#include "voice_install_catalog.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <set>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>

namespace {
struct TimedEvent { std::uint32_t tick; std::uint8_t status; std::uint8_t d1; std::uint8_t d2; };
int hb(const std::string& s) { unsigned v=0; std::istringstream ss(s); ss>>std::hex>>v; return ss.fail()||v>255? -1:(int)v; }

bool load_fixture(const std::string& path, double& bpm, std::uint16_t& division,
                  std::vector<TimedEvent>& events, std::string& err) {
    std::ifstream f(path);
    if (!f) { err="cannot open fixture: "+path; return false; }
    std::string line; bool begin=false; bpm=120.0; division=480;
    while (std::getline(f,line)) {
        if (line=="EVENTS_BEGIN") { begin=true; continue; }
        if (line=="EVENTS_END") break;
        if (!begin) {
            if (line.rfind("BPM\t",0)==0) bpm=std::stod(line.substr(4));
            else if (line.rfind("DIVISION\t",0)==0) division=(std::uint16_t)std::stoul(line.substr(9));
            continue;
        }
        std::istringstream ss(line); std::string a,b,c,d;
        if(!std::getline(ss,a,'\t')||!std::getline(ss,b,'\t')||!std::getline(ss,c,'\t')||!std::getline(ss,d,'\t')) continue;
        long long tick=std::stoll(a); int st=hb(b),d1=hb(c),d2=hb(d);
        if(tick<0||tick>std::numeric_limits<std::uint32_t>::max()||st<0||d1<0||d2<0){err="invalid event";return false;}
        events.push_back({(std::uint32_t)tick,(std::uint8_t)st,(std::uint8_t)d1,(std::uint8_t)d2});
    }
    if(events.empty()){err="fixture has no events";return false;} return true;
}
std::uint64_t key(std::uint8_t msb,std::uint8_t lsb,std::uint8_t pc){return ((std::uint64_t)msb<<16)|((std::uint64_t)lsb<<8)|pc;}
}

int main(int argc,char**argv){
#ifndef _WIN32
    std::cerr << "[FAIL] Physical WASAPI gate must be run on Windows.\n"; return 90;
#else
    const std::string ppf=argc>1?argv[1]:"tests/@YOGI MUSIC STUDIO (26).ppf";
    const std::string fixture=argc>2?argv[2]:"cpp_audio/tests/fixtures/baseline_timed_midi_replay.tsv";
    double bpm; std::uint16_t division; std::vector<TimedEvent> events; std::string err;
    if(!load_fixture(fixture,bpm,division,events,err)){std::cerr<<"[FAIL] "<<err<<"\n";return 10;}

    arranger::PpfReader reader;
    if(!reader.open(ppf,err)){std::cerr<<"[FAIL] PPF open: "<<err<<"\n";return 11;}
    arranger::InstalledVoiceCatalog catalog;
    if(!catalog.install_ppf(reader,ppf,{0xFF,0xFF,0},err)){std::cerr<<"[FAIL] PPF catalog install: "<<err<<"\n";return 12;}

    arranger::NativeGuiPpfAudio audio;
    if(!audio.install_ppf_bank_audio_only(ppf,{0xFF,0xFF,0},err)){std::cerr<<"[FAIL] PPF audio install: "<<err<<"\n";return 13;}
    audio.set_timing(bpm,division);

    std::array<std::uint8_t,16> msb{},lsb{},pc{};
    std::unordered_set<std::uint64_t> unique;
    std::size_t ppf_calls=0, nonppf_calls=0, preloads=0, preload_fail=0, mapped_to_installed=0, mapping_fail=0;
    std::size_t ppf_note_on=0, nonppf_note_on=0;
    for(const auto&e:events){
        const auto ch=(std::uint8_t)(e.status&0x0F), cmd=(std::uint8_t)(e.status&0xF0);
        if(ch>=16) continue;
        if(cmd==0xB0 && e.d1==0) msb[ch]=e.d2&0x7F;
        else if(cmd==0xB0 && e.d1==32) lsb[ch]=e.d2&0x7F;
        else if(cmd==0xC0) pc[ch]=e.d1&0x7F;
        else if(cmd==0x90 && e.d2){
            arranger::StyleVoiceCall c{e.tick,ch,msb[ch],lsb[ch],pc[ch]};
            arranger::InstalledVoiceResolution r; std::string re;
            const bool p= catalog.resolve_style_call(c,r,re) && r.voice && r.voice->format==arranger::InstalledVoiceFormat::PPF;
            if(p) ++ppf_note_on; else ++nonppf_note_on;
            if(unique.insert(key(c.msb,c.lsb,c.program)).second){
                if(p){
                    if (!r.mapped_to_installed || !r.installed_address_valid ||
                        r.voice->installed_address.msb != 63u ||
                        r.voice->installed_address.lsb != 62u ||
                        r.voice->installed_address.program != r.voice->source_index) {
                        ++mapping_fail;
                    } else {
                        ++mapped_to_installed;
                    }
                    ++ppf_calls; std::string pe; int pr=audio.preload_style_voice(c,pe); if(pr==1||pr==0) ++preloads; else {++preload_fail; std::cerr<<"[FAIL] preload "<<(int)c.msb<<"/"<<(int)c.lsb<<"/"<<(int)c.program<<": "<<pe<<"\n";}}
                else ++nonppf_calls;
            }
        }
    }
    if(preload_fail||mapping_fail||ppf_calls==0||mapped_to_installed!=ppf_calls||ppf_note_on==0){std::cerr<<"[FAIL] baseline PPF mapping preflight failed\n";return 14;}

    if(!audio.start(bpm,division,err)){std::cerr<<"[FAIL] WASAPI start: "<<err<<"\n";return 15;}

    const auto wall0=std::chrono::steady_clock::now();
    const double sec_per_tick=60.0/(bpm*(double)division);
    std::size_t enqueue_fail=0;
    for(const auto&e:events){
        const auto target=wall0+std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>((double)e.tick*sec_per_tick));
        std::this_thread::sleep_until(target);
        arranger::ArrangerOutputEvent out{}; out.global_tick=e.tick; out.status=e.status; out.data1=e.d1; out.data2=e.d2;
        if(!audio.enqueue(out)) ++enqueue_fail;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    const auto m=audio.metrics();
    const bool active_before_stop=m.active;
    audio.stop();

    std::cout<<"============================================================\n";
    std::cout<<"V0.79 PHYSICAL WINDOWS WASAPI - V0.64 PPF + BASELINE MIDI\n";
    std::cout<<"============================================================\n";
    std::cout<<"PPF_VOICES="<<reader.voices().size()<<"\n";
    std::cout<<"PPF_ZONES="<<reader.voice_zones().size()<<"\n";
    std::cout<<"INSTALLED_BANK=63/62\n";
    std::cout<<"INSTALLED_VOICES="<<catalog.voices().size()<<"\n";
    std::cout<<"BASELINE_FINAL_EVENTS="<<events.size()<<"\n";
    std::cout<<"UNIQUE_VOICE_CALLS="<<unique.size()<<"\n";
    std::cout<<"UNIQUE_PPF_CALLS="<<ppf_calls<<"\n";
    std::cout<<"UNIQUE_NONPPF_CALLS="<<nonppf_calls<<"\n";
    std::cout<<"PPF_NOTE_ON_EXPECTED="<<ppf_note_on<<"\n";
    std::cout<<"NONPPF_NOTE_ON="<<nonppf_note_on<<"\n";
    std::cout<<"PRELOAD_OK="<<preloads<<"\n";
    std::cout<<"MAPPED_SOURCE_TO_INSTALLED="<<mapped_to_installed<<"\n";
    std::cout<<"MAPPING_FAILURES="<<mapping_fail<<"\n";
    std::cout<<"PRELOAD_FAIL="<<preload_fail<<"\n";
    std::cout<<"OUTPUT_RATE="<<m.output_rate<<"\n";
    std::cout<<"BUFFER_FRAMES="<<m.buffer_frames<<"\n";
    std::cout<<"BUFFER_LATENCY_MS="<<std::fixed<<std::setprecision(3)<<m.buffer_latency_ms<<"\n";
    std::cout<<"RENDERED_FRAMES="<<m.rendered_frames<<"\n";
    std::cout<<"EVENTS_PROCESSED="<<m.events_processed<<"\n";
    std::cout<<"ENQUEUE_FAILURES="<<enqueue_fail<<"\n";
    std::cout<<"DROPPED_EVENTS="<<m.dropped_events<<"\n";
    std::cout<<"DEADLINE_MISSES="<<m.render_deadline_misses<<"\n";
    std::cout<<"MAX_RENDER_US="<<m.max_render_us<<"\n";
    std::cout<<"NONZERO_SAMPLES="<<m.nonzero_samples<<"\n";
    std::cout<<"NONFINITE_SAMPLES="<<m.nonfinite_samples<<"\n";
    std::cout<<"PEAK="<<std::setprecision(6)<<m.peak<<"\n";
    std::cout<<"ACTIVE_BEFORE_STOP="<<(active_before_stop?1:0)<<"\n";
    const double budget_us=m.output_rate?1000000.0*(double)std::max<std::uint32_t>(1,m.buffer_frames)/(double)m.output_rate:0.0;
    std::cout<<"BUFFER_BUDGET_US="<<std::setprecision(1)<<budget_us<<"\n";
    const bool pass = active_before_stop && preload_fail==0 && enqueue_fail==0 && m.events_processed==events.size() &&
                      m.dropped_events==0 && m.render_deadline_misses==0 && mapping_fail==0 && mapped_to_installed==ppf_calls && m.nonfinite_samples==0 && m.nonzero_samples>0;
    std::cout<<"BASELINE_PPF_WASAPI_RUNTIME="<<(pass?"PASS":"FAIL")<<"\n";
    return pass?0:20;
#endif
}
