#include "native_arranger_runtime.hpp"
#include "arranger_engine.hpp"
#include "yamaha_style_runtime.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <thread>
#include <chrono>
#include <string>
#include <vector>

namespace fs = std::filesystem;

static void be16(std::vector<std::uint8_t>& b, std::uint16_t v) {
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
    b.push_back(static_cast<std::uint8_t>(v & 0xFF));
}
static void be32(std::vector<std::uint8_t>& b, std::uint32_t v) {
    b.push_back(static_cast<std::uint8_t>((v >> 24) & 0xFF));
    b.push_back(static_cast<std::uint8_t>((v >> 16) & 0xFF));
    b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
    b.push_back(static_cast<std::uint8_t>(v & 0xFF));
}
static void vlq(std::vector<std::uint8_t>& b, std::uint32_t v) {
    std::uint8_t tmp[5]{};
    int n = 1;
    tmp[4] = static_cast<std::uint8_t>(v & 0x7F);
    while ((v >>= 7) != 0) tmp[4 - n++] = static_cast<std::uint8_t>((v & 0x7F) | 0x80);
    for (int i = 5 - n; i < 5; ++i) b.push_back(tmp[i]);
}
static void meta_text(std::vector<std::uint8_t>& track, std::uint32_t delta,
                      std::uint8_t type, const std::string& text) {
    vlq(track, delta);
    track.push_back(0xFF); track.push_back(type);
    vlq(track, static_cast<std::uint32_t>(text.size()));
    track.insert(track.end(), text.begin(), text.end());
}
static void meta3(std::vector<std::uint8_t>& track, std::uint32_t delta,
                  std::uint8_t type, std::uint8_t a, std::uint8_t c, std::uint8_t d) {
    vlq(track, delta); track.push_back(0xFF); track.push_back(type); track.push_back(3);
    track.push_back(a); track.push_back(c); track.push_back(d);
}
static void meta4(std::vector<std::uint8_t>& track, std::uint32_t delta,
                  std::uint8_t type, const std::array<std::uint8_t,4>& p) {
    vlq(track, delta); track.push_back(0xFF); track.push_back(type); track.push_back(4);
    track.insert(track.end(), p.begin(), p.end());
}
static void marker(std::vector<std::uint8_t>& track, std::uint32_t delta, const std::string& name) {
    meta_text(track, delta, 0x06, name);
}
static void note(std::vector<std::uint8_t>& track, std::uint32_t delta,
                 std::uint8_t status, std::uint8_t n, std::uint8_t v) {
    vlq(track, delta); track.push_back(status); track.push_back(n); track.push_back(v);
}
static void program(std::vector<std::uint8_t>& track, std::uint32_t delta,
                    std::uint8_t ch, std::uint8_t pc) {
    vlq(track, delta); track.push_back(static_cast<std::uint8_t>(0xC0 | ch)); track.push_back(pc);
}
static std::vector<std::uint8_t> make_track(const std::vector<std::uint8_t>& payload) {
    std::vector<std::uint8_t> out{'M','T','r','k'}; be32(out, static_cast<std::uint32_t>(payload.size()));
    out.insert(out.end(), payload.begin(), payload.end()); return out;
}

int main() {
    const auto path = fs::temp_directory_path() / "native_arranger_runtime_gate.mid";

    std::vector<std::uint8_t> conductor;
    meta_text(conductor, 0, 0x03, "NATIVE ARRANGER RUNTIME");
    meta3(conductor, 0, 0x51, 0x07, 0xA1, 0x20);
    meta4(conductor, 0, 0x58, {4,2,24,8});
    marker(conductor, 0, "MAIN A");
    marker(conductor, 1920, "MAIN B");
    marker(conductor, 1920, "FILL AA");
    marker(conductor, 1920, "ENDING A");
    vlq(conductor, 1920); conductor.push_back(0xFF); conductor.push_back(0x2F); conductor.push_back(0);

    std::vector<std::uint8_t> music;
    program(music, 0, 0, 5);
    note(music, 0, 0x90, 60, 90);
    note(music, 240, 0x80, 60, 0);
    note(music, 240, 0x90, 62, 80);
    note(music, 240, 0x80, 62, 0);
    note(music, 240, 0x90, 65, 83);
    note(music, 0, 0x99, 36, 91);
    note(music, 240, 0x80, 65, 0);
    note(music, 0, 0x89, 36, 0);
    note(music, 1680, 0x90, 64, 85);
    note(music, 240, 0x80, 64, 0);
    note(music, 960, 0x99, 67, 95);
    note(music, 240, 0x89, 67, 0);
    note(music, 480, 0x99, 38, 88);
    note(music, 0, 0x90, 69, 77);
    note(music, 240, 0x89, 38, 0);
    note(music, 0, 0x80, 69, 0);
    note(music, 960, 0x90, 72, 100);
    note(music, 480, 0x80, 72, 0);
    vlq(music, 1440); music.push_back(0xFF); music.push_back(0x2F); music.push_back(0);

    std::vector<std::uint8_t> smf{'M','T','h','d'};
    be32(smf, 6); be16(smf, 1); be16(smf, 2); be16(smf, 480);
    const auto t0 = make_track(conductor); const auto t1 = make_track(music);
    smf.insert(smf.end(), t0.begin(), t0.end()); smf.insert(smf.end(), t1.begin(), t1.end());
    { std::ofstream f(path, std::ios::binary); if (!f) return 2; f.write(reinterpret_cast<const char*>(smf.data()), static_cast<std::streamsize>(smf.size())); }

    arranger::NativeArrangerRuntime runtime;
    std::string error;
    if (!runtime.load_style(path.string(), error)) { std::cerr << "STYLE_LOAD_FAIL=" << error << "\n"; fs::remove(path); return 3; }
    auto s = runtime.state();
    if (s.division != 480 || s.bar_ticks != 1920) { std::cerr << "TIMING_FAIL\n"; fs::remove(path); return 4; }
    runtime.set_transpose(12); runtime.set_chord(7, 2); runtime.set_acmp(true);
#ifdef ARRANGER_ENABLE_TEST_ACCESS
    if (!runtime.start_scheduler_only_for_test(error)) { std::cerr << "SCHEDULER_START_FAIL=" << error << "\n"; fs::remove(path); return 5; }
    auto threaded_state = runtime.state();
    const auto scheduler_deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(500);
    while (threaded_state.transport_tick == 0 && std::chrono::steady_clock::now() < scheduler_deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        threaded_state = runtime.state();
    }
    runtime.stop();
    if (!threaded_state.scheduler_active || threaded_state.transport_tick == 0) {
        std::cerr << "TIMING_LOOP_FAIL tick=" << threaded_state.transport_tick
                  << " active=" << threaded_state.scheduler_active << "\n";
        fs::remove(path); return 6;
    }
#endif
    // Deterministic event generation remains the same C++ scheduler contract;
    // start MAIN A, advance into the bar, then queue MAIN B exactly as the GUI
    // does while running.
    arranger::YamahaStyleRuntime check_style;
    if (!check_style.load(path.string(), error)) { std::cerr << "CHECK_STYLE_LOAD_FAIL=" << error << "\n"; fs::remove(path); return 8; }
    arranger::CppArrangerEngine check_engine(check_style);
    if (!check_engine.start(error)) {
        std::cerr << "CHECK_ENGINE_START_FAIL=" << error << "\n"; fs::remove(path); return 8;
    }
    std::vector<arranger::ArrangerOutputEvent> out;
    if (!check_engine.advance_to(600, out, error) || !check_engine.queue_main("MAIN B", error)) {
        std::cerr << "CHECK_QUEUE_MAIN_FAIL=" << error << "\n"; fs::remove(path); return 9;
    }
    if (!check_engine.advance_to(2880, out, error)) { std::cerr << "CHECK_ADVANCE_FAIL=" << error << "\n"; fs::remove(path); return 10; }
    bool saw_main_b = false;
    for (const auto& e : out) if (e.section == "MAIN B" && e.global_tick == 2880 && (e.status & 0xF0u) == 0x90u) saw_main_b = true;
    if (!saw_main_b) { std::cerr << "MAIN_B_EVENT_FAIL count=" << out.size() << "\n"; for (const auto& e : out) std::cerr << " OUT tick=" << e.global_tick << " sec=" << e.section << " st=" << std::hex << int(e.status) << std::dec << " n=" << int(e.data1) << "\n"; fs::remove(path); return 11; }
    const auto state = runtime.state();
    if (state.transpose != 12 || !state.acmp_enabled) { std::cerr << "STATE_FAIL\n"; fs::remove(path); return 8; }

    std::cout << "NATIVE_ARRANGER_RUNTIME=PASS\n";
    std::cout << "CPP_OWNS_STYLE_STATE=PASS\n";
    std::cout << "CPP_OWNS_SECTION_COMMANDS=PASS\n";
    std::cout << "CPP_OWNS_TIMING_LOOP=PASS\n";
    std::cout << "CPP_OWNS_TEMPO_TRANSPOSE_CHORD=PASS\n";
    std::cout << "WASAPI_NATIVE_BOUNDARY=" <<
#ifdef _WIN32
        "AVAILABLE" << "\n";
#else
        "ENVIRONMENT_LIMITED_LINUX" << "\n";
#endif
    std::cout << "RESULT=PASS\n";
    runtime.stop(); fs::remove(path); return 0;
}
