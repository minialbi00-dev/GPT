#include "yamaha_style_runtime.hpp"

#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using Bytes = std::vector<std::uint8_t>;

static void be16(Bytes& out, std::uint16_t value) {
	out.push_back(static_cast<std::uint8_t>(value >> 8));
	out.push_back(static_cast<std::uint8_t>(value));
}

static void be32(Bytes& out, std::uint32_t value) {
	out.push_back(static_cast<std::uint8_t>(value >> 24));
	out.push_back(static_cast<std::uint8_t>(value >> 16));
	out.push_back(static_cast<std::uint8_t>(value >> 8));
	out.push_back(static_cast<std::uint8_t>(value));
}

static void vlq(Bytes& out, std::uint32_t value) {
	std::uint8_t data[5]{};
	int count = 1;
	data[4] = static_cast<std::uint8_t>(value & 0x7f);
	while ((value >>= 7) != 0) data[4 - count++] = static_cast<std::uint8_t>((value & 0x7f) | 0x80);
	for (int i = 5 - count; i < 5; ++i) out.push_back(data[i]);
}

static void meta(Bytes& track, std::uint32_t delta, std::uint8_t type, const Bytes& payload) {
	vlq(track, delta);
	track.push_back(0xff);
	track.push_back(type);
	vlq(track, static_cast<std::uint32_t>(payload.size()));
	track.insert(track.end(), payload.begin(), payload.end());
}

static Bytes chunk(const char* tag, const Bytes& payload) {
	Bytes out(tag, tag + 4);
	be32(out, static_cast<std::uint32_t>(payload.size()));
	out.insert(out.end(), payload.begin(), payload.end());
	return out;
}

static Bytes track_chunk(const Bytes& payload) { return chunk("MTrk", payload); }

static Bytes casm_table(std::uint8_t source_channel, std::size_t size, std::uint8_t root, std::uint8_t type) {
	Bytes table(size, 0);
	if (size > 0) table[0] = source_channel;
	if (size >= 10) {
		const std::string role = "ACMP    ";
		std::copy(role.begin(), role.end(), table.begin() + 1);
		table[9] = 8;
	}
	if (size > 10) table[10] = 1;
	if (size > 11) table[11] = 2;
	if (size > 18) table[18] = root;
	if (size > 19) table[19] = type;
	return table;
}

static void append_chunk(Bytes& out, const char* tag, const Bytes& payload) {
	const auto value = chunk(tag, payload);
	out.insert(out.end(), value.begin(), value.end());
}

int main() {
	Bytes conductor;
	meta(conductor, 0, 0x03, Bytes{'T', 'E', 'S', 'T'});
	meta(conductor, 0, 0x51, Bytes{0x07, 0xa1, 0x20});
	meta(conductor, 0, 0x58, Bytes{4, 2, 24, 8});
	meta(conductor, 0, 0x06, Bytes{'M', 'A', 'I', 'N', ' ', 'A'});
	meta(conductor, 1000, 0x51, Bytes{0x0f, 0x42, 0x40});
	meta(conductor, 0, 0x58, Bytes{3, 2, 24, 8});
	meta(conductor, 3000, 0x51, Bytes{0x0f, 0x42, 0x40});
	meta(conductor, 0, 0x2f, {});

	Bytes music;
	vlq(music, 0); music.insert(music.end(), {0x90, 60, 90});
	vlq(music, 2000); music.insert(music.end(), {0x80, 60, 0});
	meta(music, 0, 0x2f, {});

	Bytes smf{'M', 'T', 'h', 'd'};
	be32(smf, 6); be16(smf, 1); be16(smf, 2); be16(smf, 480);
	const auto conductor_track = track_chunk(conductor);
	const auto music_track = track_chunk(music);
	smf.insert(smf.end(), conductor_track.begin(), conductor_track.end());
	smf.insert(smf.end(), music_track.begin(), music_track.end());

	Bytes cseg;
	append_chunk(cseg, "Sdec", Bytes{'M', 'A', 'I', 'N', ' ', 'A', ',', 'U', 'N', 'K', 'N', 'O', 'W', 'N'});
	append_chunk(cseg, "Ctb2", casm_table(0, 26, 7, 3));
	append_chunk(cseg, "Ctab", casm_table(1, 27, 7, 3));
	Bytes casm;
	append_chunk(casm, "CSEG", cseg);
	append_chunk(smf, "CASM", casm);

	const auto path = fs::temp_directory_path() / "yamaha_style_parser_parity_gate.sty";
	{
		std::ofstream file(path, std::ios::binary);
		if (!file) return 1;
		file.write(reinterpret_cast<const char*>(smf.data()), static_cast<std::streamsize>(smf.size()));
	}

	arranger::YamahaStyleRuntime style;
	std::string error;
	if (!style.load(path.string(), error)) {
		std::cerr << "STYLE_LOAD_FAIL=" << error << '\n';
		fs::remove(path);
		return 2;
	}
	fs::remove(path);

	if (style.summary().tempo_bpm != 120.0 || style.summary().time_numerator != 4 || style.summary().time_denominator != 4) {
		std::cerr << "EARLIEST_TIMING_METADATA_MISMATCH\n";
		return 3;
	}
	if (style.events().size() != 7 || style.events().front().tick != 0 || style.events().back().tick != 4000) {
		std::cerr << "SORTED_META_EVENTS_OR_MAX_TICK_MISMATCH events=" << style.events().size() << '\n';
		return 4;
	}
	const auto* section = style.find_section("MAIN A");
	if (!section || section->end_tick != 4000 || style.find_section("UNKNOWN")) {
		std::cerr << "SECTION_BOUNDARY_OR_UNKNOWN_MARKER_MISMATCH\n";
		return 5;
	}
	const auto* short_table = style.find_casm_rule("MAIN A", 0);
	if (!short_table || short_table->source_root != 0 || short_table->source_type != 0 || short_table->slots.size() != 3 || short_table->slots[0].ntt != 2) {
		std::cerr << "CASM_SHORT_TABLE_FALLBACK_MISMATCH\n";
		return 6;
	}
	const auto* legacy_table = style.find_casm_rule("MAIN A", 1);
	if (!legacy_table || legacy_table->source_root != 7 || legacy_table->source_type != 3 || legacy_table->slots.size() != 1 || legacy_table->slots[0].ntr != 1 || legacy_table->slots[0].ntt != 2) {
		std::cerr << "CASM_SFF1_SLOT_MISMATCH\n";
		return 7;
	}

	std::cout << "YamahaStyleParserParityGate=PASS\n";
	return 0;
}
