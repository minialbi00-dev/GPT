#include "ppf_note_engine.hpp"

#include <cmath>
#include <cstdint>
#include <iostream>
#include <memory>
#include <vector>

namespace {

arranger::ResidentSamplePtr sample(const char* uid, float value, std::size_t frames = 4096) {
    auto s = std::make_shared<arranger::ResidentSample>();
    s->uid_full = uid;
    s->sample_rate = 48000;
    s->channels = 1;
    s->pcm.assign(frames, value);
    return s;
}

arranger::VoiceZone zone(int note, int vlo, int vhi, const char* uid,
                         const arranger::ResidentSamplePtr& pcm,
                         std::uint8_t alt_group = 0,
                         bool rcv_note_off = true,
                         bool one_shot = false) {
    arranger::VoiceZone z{};
    z.voice_index = 0;
    z.waveform_index = 7;
    z.keybank_index = 0;
    z.voice_title = "C++ Note Engine Gate";
    z.sample_uid = uid;
    z.sample_position = "MONO";
    z.root_note = note;
    z.key_lo = note;
    z.key_hi = note;
    z.velocity_lo = vlo;
    z.velocity_hi = vhi;
    z.sample_rate = 48000;
    z.volume = 0.0;
    z.pan = 0.0;
    z.tune_coarse = 0;
    z.tune_fine = 0.0;
    z.pitch_scaling_sens = 100;
    z.one_shot = one_shot;
    z.alternate_group = alt_group;
    z.receive_note_off = rcv_note_off;
    z.receive_note_on = true;
    z.loop_start_frame = 0;
    z.loop_end_frame = 0;
    return z;
}

bool near(float a, float b, float eps = 0.015f) { return std::fabs(a - b) <= eps; }

} // namespace

int main() {
    arranger::PpfRuntime runtime;
    arranger::ResidentSampler sampler;
    arranger::PpfNoteEngine engine(runtime, sampler);

    const auto low_pcm = sample("LOW_PCM", 0.25f);
    const auto high_pcm = sample("HIGH_PCM", 0.75f, 20000);
    const auto hat_pcm = sample("HAT_PCM", 0.50f, 20000);

    arranger::PpfRuntimeVoice voice{};
    voice.bank_id = 1;
    voice.source_index = 9;
    voice.zones.push_back({zone(60, 1, 63, "LOW_PCM", low_pcm, 1), low_pcm});
    voice.zones.push_back({zone(61, 64, 127, "HIGH_PCM", high_pcm, 2), high_pcm});
    voice.zones.push_back({zone(62, 1, 127, "HAT_PCM", hat_pcm, 1, false, true), hat_pcm});

    std::string error;
    if (!runtime.upsert_voice(std::move(voice), error)) {
        std::cerr << "[FAIL] runtime setup: " << error << "\n";
        return 1;
    }

    // 1) Exact velocity path produces the requested voice instance.
    if (!engine.note_on({1, 9, 0, 60, 32})) return 2;
    const auto slot_low = engine.active_slot(0, 60);
    if (slot_low < 0 || sampler.active_voice_count() != 1) {
        std::cerr << "[FAIL] low velocity instance not active\n";
        return 3;
    }
    float frame[2]{};
    sampler.render(frame, 1, 48000);
    const float expected_low = 0.25f * (32.0f / 127.0f) * 0.70710678f;
    if (!near(frame[0], expected_low)) {
        std::cerr << "[FAIL] low layer gain/instance mismatch: got " << frame[0] << " expected " << expected_low << "\n";
        return 4;
    }

    // 2) A different velocity layer on a different note is independent.
    if (!engine.note_on({1, 9, 0, 61, 100})) return 5;
    if (engine.active_slot(0, 61) < 0 || sampler.active_voice_count() != 2) {
        std::cerr << "[FAIL] high velocity instance not active\n";
        return 6;
    }

    // 3) Alternate Group 1 immediately chokes the Group 1 low layer.
    if (!engine.note_on({1, 9, 0, 62, 100})) return 7;
    if (engine.active_slot(0, 60) >= 0 || engine.active_slot(0, 62) < 0 || sampler.active_voice_count() != 2) {
        std::cerr << "[FAIL] alternate-group choke/lifecycle mismatch\n";
        return 8;
    }

    // 4) rcvNoteOff=0 consumes Note-Off and preserves the tail.
    if (!engine.note_off(0, 62)) return 9;
    std::vector<float> tail(4800 * 2);
    sampler.render(tail.data(), 4800, 48000);
    std::size_t nonzero = 0;
    for (float x : tail) if (std::fabs(x) > 1.0e-7f) ++nonzero;
    if (nonzero == 0 || sampler.active_voice_count() != 2) {
        std::cerr << "[FAIL] rcvNoteOff=0 tail was cut\n";
        return 10;
    }

    // 5) Same Alternate Group starts a fresh normal-release note and chokes the tail.
    if (!engine.note_on({1, 9, 0, 60, 32})) return 11;
    if (sampler.active_voice_count() != 2) return 12;
    if (!engine.note_off(0, 60)) return 13;
    if (!engine.note_off(0, 61)) return 14;
    std::vector<float> rel(3000 * 2);
    sampler.render(rel.data(), 3000, 48000);
    if (sampler.active_voice_count() != 0) {
        std::cerr << "[FAIL] normal Note-Off release did not finish\n";
        return 15;
    }

    // 6) Sustain is owned by the native note engine: Note-Off is deferred until pedal-up.
    if (!engine.note_on({1, 9, 0, 61, 100})) return 16;
    if (!engine.control_change(0, 64, 127)) return 17;
    if (!engine.note_off(0, 61)) return 18;
    if (sampler.active_voice_count() != 1) return 19;
    if (!engine.control_change(0, 64, 0)) return 20;
    sampler.render(rel.data(), 3000, 48000);
    if (sampler.active_voice_count() != 0) {
        std::cerr << "[FAIL] sustain release did not finish\n";
        return 21;
    }

    std::cout << "PPF_NOTE_ENGINE=PASS\n";
    std::cout << "EXACT_VELOCITY_VOICE_INSTANCE=PASS\n";
    std::cout << "GAIN_PAN_PITCH_INITIALIZATION=PASS\n";
    std::cout << "ALTERNATEGROUP_INSTANCE_CHOKE=PASS\n";
    std::cout << "RCV_NOTE_OFF_TAIL_INSTANCE=PASS\n";
    std::cout << "NOTE_OFF_RELEASE_INSTANCE=PASS\n";
    std::cout << "SUSTAIN_DEFER_RELEASE=PASS\n";
    return 0;
}
