#include "performance_runtime.hpp"

#include <iostream>

using arranger::PerformanceFingerMode;
using arranger::PerformanceRuntime;

int main() {
    int fail = 0;
    PerformanceRuntime p;

    // Project target: the Style/Chord split boundary is F#1 = MIDI 42 (Yamaha C3 = MIDI 60).
    if (p.state().split_point != 42) {
        std::cerr << "DEFAULT_SPLIT_EXPECTED_FSHARP1_MIDI42=FAIL GOT="
                  << static_cast<int>(p.state().split_point) << "\n";
        ++fail;
    } else {
        std::cout << "DEFAULT_SPLIT_FSHARP1_MIDI42=PASS\n";
    }

    p.set_finger_mode(static_cast<unsigned char>(PerformanceFingerMode::SingleFinger));
    p.set_split_point(42);
    p.note_on(42, 100); // F#1: boundary key must still belong to chord area.
    if (p.state().chord_name != "F#") {
        std::cerr << "FSHARP1_INCLUDED=FAIL CHORD=" << p.state().chord_name << "\n";
        ++fail;
    } else {
        std::cout << "FSHARP1_INCLUDED=PASS\n";
    }

    p.clear_notes();
    p.note_on(43, 100); // G1: one semitone above boundary, must be outside chord area.
    if (p.state().chord_name != "C" || p.state().chord_bass_valid) {
        std::cerr << "G1_EXCLUDED=FAIL CHORD=" << p.state().chord_name
                  << " BASS_VALID=" << p.state().chord_bass_valid << "\n";
        ++fail;
    } else {
        std::cout << "G1_EXCLUDED=PASS\n";
    }

    p.clear_notes();
    p.note_on(42, 100);
    p.note_on(43, 100);
    if (p.state().chord_name != "F#" || p.state().held_notes.size() != 1u || p.state().held_notes[0] != 42) {
        std::cerr << "BOUNDARY_FILTER=FAIL CHORD=" << p.state().chord_name
                  << " HELD_COUNT=" << p.state().held_notes.size() << "\n";
        ++fail;
    } else {
        std::cout << "BOUNDARY_FILTER=PASS\n";
    }

    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
