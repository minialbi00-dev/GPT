#include "native_gui_ppf_audio.hpp"
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using arranger::InstalledVoiceAddress;
using arranger::NativeGuiPpfAudio;
static void be32(std::vector<std::uint8_t>& o, std::uint32_t v){o.push_back(v>>24);o.push_back(v>>16);o.push_back(v>>8);o.push_back(v);}
static std::vector<std::uint8_t> field(const char t[4], const std::vector<std::uint8_t>& p){std::vector<std::uint8_t> o(t,t+4);be32(o,(std::uint32_t)p.size());o.insert(o.end(),p.begin(),p.end());return o;}
static std::vector<std::uint8_t> textf(const char t[4], const std::string& s){return field(t,std::vector<std::uint8_t>(s.begin(),s.end()));}
static std::vector<std::uint8_t> blob(const std::vector<std::vector<std::uint8_t>>& fs){std::vector<std::uint8_t> p;for(auto&f:fs)p.insert(p.end(),f.begin(),f.end());std::vector<std::uint8_t>o{'B','L','O','B'};be32(o,(std::uint32_t)p.size());o.insert(o.end(),p.begin(),p.end());return o;}
static bool make_ppf(const std::filesystem::path& path){
 const std::string uid="GOOD_UID";
 const std::string xml="<?xml version=\"1.0\"?><uvf:voiceData><voiceType>UNIVERSAL</voiceType><information><voiceName>Partial Voice</voiceName><voiceMsb>62</voiceMsb><voiceLsb>3</voiceLsb><voicePcNum>7</voicePcNum></information><voiceElement number=\"0\"><noteLimitLo>C-2</noteLimitLo><noteLimitHi>G8</noteLimitHi></voiceElement><waveform number=\"0\"><keybank><noteLimitLo>C-2</noteLimitLo><noteLimitHi>G8</noteLimitHi><velocityLimitLo>1</velocityLimitLo><velocityLimitHi>127</velocityLimitHi><centerNote>C4</centerNote><sample position='MONO'><waveFilePath>"+uid+"</waveFilePath></sample></keybank></waveform></uvf:voiceData>";
 auto uvf=blob({textf("EEXT","UVF"),textf("ETIT","Partial Voice"),std::vector<std::uint8_t>(xml.begin(),xml.end())});
 std::vector<std::uint8_t> ssnd{'S','S','N','D'};be32(ssnd,16);ssnd.insert(ssnd.end(),8,0);const std::vector<std::uint8_t> pcm{0,1,0,2,0,3,0,4};ssnd.insert(ssnd.end(),pcm.begin(),pcm.end());
 auto apcp=blob({textf("EEXT","apcp"),textf("EUID","MISSING_UID"),ssnd});
 std::ofstream f(path,std::ios::binary);if(!f)return false;f.write((char*)uvf.data(),uvf.size());f.write((char*)apcp.data(),apcp.size());return (bool)f;
}
int main(){
 auto path=std::filesystem::temp_directory_path()/"ppf_partial_voice_gate.ppf";std::error_code ec;std::filesystem::remove(path,ec);if(!make_ppf(path)){std::cerr<<"[FAIL] fixture create\n";return 1;}
 NativeGuiPpfAudio audio; std::string error;
 if(!audio.install_ppf_bank_audio_only(path.string(),InstalledVoiceAddress{0xFF,0xFF,0},error)){std::cerr<<"[FAIL] bank install: "<<error<<"\n";return 2;}
 if(error.find("partial Voice residency")==std::string::npos){std::cerr<<"[FAIL] partial warning missing: "<<error<<"\n";return 3;}
 auto banks=audio.installed_ppf_banks(); auto voices=audio.installed_ppf_voices();
 if(banks.size()!=1||banks[0].msb!=62||banks[0].lsb!=3){std::cerr<<"[FAIL] bank not visible at source slot\n";return 4;}
 if(voices.size()!=1||voices[0].installed_address.msb!=62||voices[0].installed_address.lsb!=3||voices[0].resident_zone_count!=0||voices[0].zone_count==0){std::cerr<<"[FAIL] Voice List partial residency metadata invalid\n";return 5;}
 std::cout<<"PPF_PARTIAL_VOICE_INSTALL=PASS\nBANK_SLOT=62/3\nVOICE_ZONES="<<voices[0].zone_count<<"\nRESIDENT_ZONES="<<voices[0].resident_zone_count<<"\n";
 std::filesystem::remove(path,ec);return 0;
}
