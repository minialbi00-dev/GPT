#include "arranger_control_bridge.h"

#include <cstdint>
#include <iostream>
#include <string>

static bool get_state(void* h, YacPerformanceState& s, const char* label) {
    const bool ok = yac_arranger_get_performance_state(h, &s) != 0;
    std::cout << label << "=" << (ok ? "PASS" : "FAIL") << "\n";
    return ok;
}

static void note_on(void* h, int note) {
    yac_arranger_midi_input(h, 0x90, static_cast<std::uint8_t>(note), 100);
}

static void clear(void* h) {
    yac_arranger_clear_performance_notes(h);
}

static bool expect(void* h, std::uint8_t mode, const char* name, const char* label) {
    yac_arranger_set_finger_mode(h, mode);
    YacPerformanceState s{};
    if (!get_state(h, s, label)) return false;
    const bool ok = std::string(s.chord_name) == name && s.finger_mode == mode;
    std::cout << label << "_RESULT=" << (ok ? "PASS" : "FAIL")
              << " MODE=" << int(s.finger_mode)
              << " CHORD=" << s.chord_name << "\n";
    return ok;
}

int main() {
    char err[512]{};
    void* h = yac_arranger_create(err, sizeof(err));
    if (!h) {
        std::cerr << "CREATE_FAIL=" << err << "\n";
        return 2;
    }

    // Keep the split configured by the runtime; this gate uses low synthetic
    // notes so it exercises the same chord-section filter as live operation.
    yac_arranger_set_split_point(h, 42);

    int fail = 0;

    // 0 Single Finger: C + Bb immediately to the left of C -> Cm.
    clear(h); note_on(h, 34); note_on(h, 36);
    if (!expect(h, 0, "Cm", "LIVE_MODE0_SINGLE")) ++fail;

    // 1 Fingered: the same 2-note Single Finger gesture is NOT Cm.
    clear(h); note_on(h, 34); note_on(h, 36);
    if (!expect(h, 1, "No Chord", "LIVE_MODE1_FINGERED_REJECT_SF")) ++fail;

    // 1 Fingered proper triad.
    clear(h); note_on(h, 24); note_on(h, 28); note_on(h, 31);
    if (!expect(h, 1, "C", "LIVE_MODE1_FINGERED")) ++fail;

    // 2 Fingered On Bass: C/E inversion.
    clear(h); note_on(h, 28); note_on(h, 31); note_on(h, 36);
    yac_arranger_set_finger_mode(h, 2);
    YacPerformanceState s{};
    get_state(h, s, "LIVE_MODE2_STATE");
    const bool onbass = std::string(s.chord_name) == "C" && s.finger_mode == 2 &&
                        s.chord_bass_valid && s.chord_bass_pc == 4;
    std::cout << "LIVE_MODE2_RESULT=" << (onbass ? "PASS" : "FAIL")
              << " CHORD=" << s.chord_name << " BASS=" << int(s.chord_bass_pc) << "\n";
    if (!onbass) ++fail;

    // 3 Multi Finger: Fingered first, then Single Finger fallback.
    clear(h); note_on(h, 24); note_on(h, 31);
    if (!expect(h, 3, "C1+5", "LIVE_MODE3_MULTI_15")) ++fail;
    clear(h); note_on(h, 34); note_on(h, 36);
    if (!expect(h, 3, "Cm", "LIVE_MODE3_MULTI_SF")) ++fail;

    // 4 AI Fingered: previous confirmed Cm supplies the quality for a new D.
    clear(h); yac_arranger_set_finger_mode(h, 4);
    note_on(h, 24); note_on(h, 27); note_on(h, 31);
    clear(h); note_on(h, 26);
    if (!expect(h, 4, "Dm", "LIVE_MODE4_AI_CONTEXT")) ++fail;

    // 5 Full Keyboard: whole range; low bass may accompany C-E-G.
    clear(h); note_on(h, 24); note_on(h, 36); note_on(h, 40); note_on(h, 43);
    if (!expect(h, 5, "C", "LIVE_MODE5_FULL")) ++fail;

    // 6 AI Full Keyboard: seed context in the same mode, then move by one key.
    clear(h); yac_arranger_set_finger_mode(h, 6);
    note_on(h, 60); note_on(h, 63); note_on(h, 67); // Cm
    clear(h); note_on(h, 38); // Dm from context
    if (!expect(h, 6, "Dm", "LIVE_MODE6_AI_FULL_CONTEXT")) ++fail;

    // Smart Chord: C-major Standard + G trigger -> G7.
    clear(h); yac_arranger_set_smart_chord_key(h, 0); yac_arranger_set_smart_chord_type(h, 0);
    yac_arranger_set_smart_chord_minor(h, 0);
    note_on(h, 31); // G0, still <= split 42
    if (!expect(h, 7, "G7", "LIVE_MODE7_SMART")) ++fail;

    // Mode 8 compatibility: Fingered 1/2 = Fingered with lowest note as bass.
    clear(h); note_on(h, 28); note_on(h, 31); note_on(h, 36);
    yac_arranger_set_finger_mode(h, 8);
    if (!get_state(h, s, "LIVE_MODE8_STATE")) ++fail;
    const bool f12 = std::string(s.chord_name) == "C" && s.finger_mode == 8 &&
                     s.chord_bass_valid && s.chord_bass_pc == 4;
    std::cout << "LIVE_MODE8_RESULT=" << (f12 ? "PASS" : "FAIL")
              << " CHORD=" << s.chord_name << " BASS=" << int(s.chord_bass_pc) << "\n";
    if (!f12) ++fail;

    yac_arranger_destroy(h);
    std::cout << "RESULT=" << (fail == 0 ? "PASS" : "FAIL") << "\n";
    return fail == 0 ? 0 : 1;
}
