# V0.64 + ORIGINAL BASELINE: C++ PPF AUDIO BRANCH

This branch keeps the Original Baseline Python arranger as the sole musical
authority. The native C++ side is an AUDIO runtime only:

- PPF/YEP internal Voice primitives retained from V0.64.
- PPF installed bank mapping is `MSB 63 / LSB 62` by default.
- PPF source addresses remain unchanged (for example `62/3/0`).
- The C++ runtime receives the final MIDI bytes emitted by the Original
  Baseline. It does not generate Style/CASM/chord/section events.
- Voice residency is preloaded from exact baseline `MSB/LSB/PC` calls before
  realtime audio starts, so disk I/O is not performed in the WASAPI callback.
- PPF mix uses the proven V0.58 `0.362` headroom path and a final finite/clamp
  safety pass. No compressor/limiter is introduced.
- WASAPI uses shared-mode event callback with the existing V0.64 native audio
  implementation.
- The VST2 MIDI bridge is retained as an independent VST2 surface; it is not
  the arranger clock and is not used to replace the Python arranger engine.

The 11 locked arranger files are copied byte-identically from
`🔒YAMAHA_STYLE_ARRANGER_V88_1_10 ORIGINAL BASELINE.zip`. The GUI adapter is the
only baseline source file modified in this branch, and its changes are limited
to wiring the native audio runtime underneath the unchanged arranger engine.
