cmake_minimum_required(VERSION 3.24)
project(V079OriginalBaselinePpfAudio LANGUAGES CXX)

find_package(Threads REQUIRED)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

set(PPF_AUDIO_SOURCES
    src/ppf_reader.cpp
    src/arranger_engine.cpp
    src/ppf_voice_bank.cpp
    src/ppf_runtime.cpp
    src/ppf_note_engine.cpp
    src/resident_sampler.cpp
    src/style_voice_router.cpp
    src/yamaha_style_runtime.cpp
    src/yep_reader.cpp
    src/voice_install_catalog.cpp
    src/installed_style_voice_router.cpp
    src/soundfont_bank.cpp
    src/native_gui_ppf_audio.cpp
    src/style_ppf_audio_runtime.cpp
    src/native_arranger_runtime.cpp
    src/performance_runtime.cpp
    src/casm_transform.cpp
)

add_library(YamahaPpfAudioEngineCore STATIC ${PPF_AUDIO_SOURCES})
target_include_directories(YamahaPpfAudioEngineCore PUBLIC include)
target_link_libraries(YamahaPpfAudioEngineCore PUBLIC Threads::Threads)
set_target_properties(YamahaPpfAudioEngineCore PROPERTIES POSITION_INDEPENDENT_CODE ON)
if(MSVC)
    target_compile_definitions(YamahaPpfAudioEngineCore PRIVATE WIN32_LEAN_AND_MEAN _CRT_SECURE_NO_WARNINGS NOMINMAX)
    target_compile_options(YamahaPpfAudioEngineCore PRIVATE /W4 /permissive-)
endif()
if(WIN32)
    target_link_libraries(YamahaPpfAudioEngineCore PUBLIC ole32 uuid mmdevapi winmm)
endif()

# Public DLL wrapper. The gate executables link the same core statically so
# their C++ class references are resolved deterministically on Windows; the
# public C ABI remains exported by this DLL.
add_library(YamahaPpfAudioEngine SHARED src/ppf_audio_bridge.cpp src/arranger_control_bridge.cpp src/native_arranger_runtime_bridge.cpp src/casm_transform_bridge.cpp)
target_include_directories(YamahaPpfAudioEngine PRIVATE include)
target_link_libraries(YamahaPpfAudioEngine PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
if(WIN32)
    target_link_libraries(YamahaPpfAudioEngine PRIVATE propsys)
endif()
set_target_properties(YamahaPpfAudioEngine PROPERTIES
    OUTPUT_NAME "YamahaPpfAudioEngine"
    PREFIX ""
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
    LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)
if(CMAKE_CONFIGURATION_TYPES)
    set_target_properties(YamahaPpfAudioEngine PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin/Release"
        LIBRARY_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin/Release"
    )
endif()
if(MSVC)
    target_compile_definitions(YamahaPpfAudioEngine PRIVATE WIN32_LEAN_AND_MEAN _CRT_SECURE_NO_WARNINGS NOMINMAX)
    target_compile_options(YamahaPpfAudioEngine PRIVATE /W4 /permissive-)
endif()

# Retain the already-validated VST2 MIDI bridge as an independent plugin
# surface. It does not generate arranger events and is never the arranger clock.
if(WIN32)
    add_library(YamahaArrangerVST2MidiBridge MODULE src/vst2_midi_bridge.cpp)
    target_include_directories(YamahaArrangerVST2MidiBridge PRIVATE include)
    target_compile_definitions(YamahaArrangerVST2MidiBridge PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN _CRT_SECURE_NO_WARNINGS)
    set_target_properties(YamahaArrangerVST2MidiBridge PROPERTIES
        OUTPUT_NAME "YamahaArrangerVST2MidiBridge"
        PREFIX ""
        RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
        LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
    )
    if(CMAKE_CONFIGURATION_TYPES)
        set_target_properties(YamahaArrangerVST2MidiBridge PROPERTIES
            RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin/Release"
            LIBRARY_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin/Release"
        )
    endif()
endif()

add_executable(PpfMultiBankLifecycleGate64 tests/ppf_multi_bank_lifecycle_gate.cpp)
target_include_directories(PpfMultiBankLifecycleGate64 PRIVATE include)
target_link_libraries(PpfMultiBankLifecycleGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfMultiBankLifecycleGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(V079BaselinePpfMappingGate64 tests/baseline_ppf_source_to_installed_gate.cpp)
target_include_directories(V079BaselinePpfMappingGate64 PRIVATE include)
target_compile_definitions(V079BaselinePpfMappingGate64 PRIVATE ARRANGER_ENABLE_TEST_ACCESS)
target_link_libraries(V079BaselinePpfMappingGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(V079BaselinePpfMappingGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(PpfAuthoritativeSlotGate64 tests/ppf_authoritative_slot_gate.cpp)
target_include_directories(PpfAuthoritativeSlotGate64 PRIVATE include)
target_link_libraries(PpfAuthoritativeSlotGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfAuthoritativeSlotGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(PpfPartialVoiceInstallGate64 tests/ppf_partial_voice_install_gate.cpp)
target_include_directories(PpfPartialVoiceInstallGate64 PRIVATE include)
target_link_libraries(PpfPartialVoiceInstallGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfPartialVoiceInstallGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(V079BaselinePpfAudioReplayGate64 tests/baseline_midi_ppf_replay_gate.cpp)
target_include_directories(V079BaselinePpfAudioReplayGate64 PRIVATE include)
target_compile_definitions(V079BaselinePpfAudioReplayGate64 PRIVATE ARRANGER_ENABLE_TEST_ACCESS)
target_link_libraries(V079BaselinePpfAudioReplayGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(V079BaselinePpfAudioReplayGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

# The physical WASAPI gate source contains a non-Windows guard, so the target
# can safely exist on every host. On Windows it exercises the real WASAPI path;
# on non-Windows it exits with an explicit platform-unavailable status.
add_executable(V079BaselinePpfWasapiGate64 tests/baseline_ppf_wasapi_gate.cpp)
target_include_directories(V079BaselinePpfWasapiGate64 PRIVATE include)
target_link_libraries(V079BaselinePpfWasapiGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
if(WIN32)
    target_link_libraries(V079BaselinePpfWasapiGate64 PRIVATE ole32 uuid mmdevapi)
endif()
set_target_properties(V079BaselinePpfWasapiGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(PpfDrumReleaseAlternateGroupGate64 tests/ppf_drum_release_alternate_group_gate.cpp)
target_include_directories(PpfDrumReleaseAlternateGroupGate64 PRIVATE include)
target_link_libraries(PpfDrumReleaseAlternateGroupGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
target_compile_definitions(PpfDrumReleaseAlternateGroupGate64 PRIVATE ARRANGER_ENABLE_TEST_ACCESS)
set_target_properties(PpfDrumReleaseAlternateGroupGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(PpfRuntimeZoneResolverGate64 tests/ppf_runtime_zone_resolver_gate.cpp)
target_include_directories(PpfRuntimeZoneResolverGate64 PRIVATE include)
target_link_libraries(PpfRuntimeZoneResolverGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfRuntimeZoneResolverGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(PpfNoteEngineGate64 tests/ppf_note_engine_gate.cpp)
target_include_directories(PpfNoteEngineGate64 PRIVATE include)
target_link_libraries(PpfNoteEngineGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfNoteEngineGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfNativeRuntimeIntegrationGate64 tests/ppf_native_runtime_integration_gate.cpp)
target_include_directories(PpfNativeRuntimeIntegrationGate64 PRIVATE include)
target_compile_definitions(PpfNativeRuntimeIntegrationGate64 PRIVATE ARRANGER_ENABLE_TEST_ACCESS)
target_link_libraries(PpfNativeRuntimeIntegrationGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfNativeRuntimeIntegrationGate64 PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)

add_executable(CppStyleSchedulerGate64 tests/cpp_style_scheduler_gate.cpp)
target_include_directories(CppStyleSchedulerGate64 PRIVATE include)
target_link_libraries(CppStyleSchedulerGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(CppStyleSchedulerGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(CppArrangerControlBridgeGate64 tests/arranger_control_bridge_gate.cpp src/arranger_control_bridge.cpp)
target_include_directories(CppArrangerControlBridgeGate64 PRIVATE include)
target_link_libraries(CppArrangerControlBridgeGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(CppArrangerControlBridgeGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(NativeArrangerRuntimeGate64 tests/native_arranger_runtime_gate.cpp)
target_include_directories(NativeArrangerRuntimeGate64 PRIVATE include)
target_compile_definitions(NativeArrangerRuntimeGate64 PRIVATE ARRANGER_ENABLE_TEST_ACCESS)
target_link_libraries(NativeArrangerRuntimeGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(NativeArrangerRuntimeGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

if(BUILD_TESTING)
    add_executable(YamahaStyleParserParityGate64 tests/yamaha_style_parser_parity_gate.cpp)
    target_include_directories(YamahaStyleParserParityGate64 PRIVATE include)
    target_link_libraries(YamahaStyleParserParityGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
    set_target_properties(YamahaStyleParserParityGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
    add_test(NAME YamahaStyleParserParityGate64 COMMAND YamahaStyleParserParityGate64)

    add_test(NAME CppStyleSchedulerGate64 COMMAND $<TARGET_FILE:CppStyleSchedulerGate64>)
    add_test(NAME NativeArrangerRuntimeGate64 COMMAND $<TARGET_FILE:NativeArrangerRuntimeGate64>)
endif()


add_executable(CppPerformanceInputGate64 tests/cpp_performance_input_gate.cpp)
target_include_directories(CppPerformanceInputGate64 PRIVATE include)
target_link_libraries(CppPerformanceInputGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(CppPerformanceInputGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfFingeringModesGate64 tests/ppf_fingering_modes_gate.cpp)
target_include_directories(PpfFingeringModesGate64 PRIVATE include)
target_link_libraries(PpfFingeringModesGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfFingeringModesGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(YamahaFingeredChordMatrixGate64 tests/yamaha_fingered_chord_matrix_gate.cpp)
target_include_directories(YamahaFingeredChordMatrixGate64 PRIVATE include)
target_link_libraries(YamahaFingeredChordMatrixGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(YamahaFingeredChordMatrixGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfSplitF1BoundaryGate64 tests/ppf_split_f1_boundary_gate.cpp)
target_include_directories(PpfSplitF1BoundaryGate64 PRIVATE include)
target_link_libraries(PpfSplitF1BoundaryGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfSplitF1BoundaryGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfFingeringSplitIntegrationGate64 tests/ppf_fingering_split_integration_gate.cpp)
target_include_directories(PpfFingeringSplitIntegrationGate64 PRIVATE include)
target_link_libraries(PpfFingeringSplitIntegrationGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfFingeringSplitIntegrationGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfFingeringBehaviorMatrixGate64 tests/ppf_fingering_behavior_matrix_gate.cpp)
target_include_directories(PpfFingeringBehaviorMatrixGate64 PRIVATE include)
target_link_libraries(PpfFingeringBehaviorMatrixGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfFingeringBehaviorMatrixGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfFingeringLiveModeGate64 tests/ppf_fingering_live_mode_gate.cpp src/arranger_control_bridge.cpp)
target_include_directories(PpfFingeringLiveModeGate64 PRIVATE include)
target_link_libraries(PpfFingeringLiveModeGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfFingeringLiveModeGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

add_executable(PpfSmartChordFullTableGate64 tests/ppf_smart_chord_full_table_gate.cpp)
target_include_directories(PpfSmartChordFullTableGate64 PRIVATE include)
target_link_libraries(PpfSmartChordFullTableGate64 PRIVATE YamahaPpfAudioEngineCore Threads::Threads)
set_target_properties(PpfSmartChordFullTableGate64 PROPERTIES RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
