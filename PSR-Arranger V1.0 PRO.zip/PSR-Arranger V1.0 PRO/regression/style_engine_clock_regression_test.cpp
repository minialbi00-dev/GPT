#include "style_engine.hpp"

#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
struct EventStamp {
    std::uint64_t targetUs = 0;
    int status = 0;
    int data1 = 0;
    int data2 = 0;
    int engineTick = 0;

    bool operator==(const EventStamp&) const = default;
};

std::vector<EventStamp> runTimeline(const std::filesystem::path& stylePath,
                                    const std::vector<std::uint64_t>& callbackPattern,
                                    std::uint64_t playbackDurationUs) {
    ensembles::StyleEngine engine;
    std::string error;
    if (!engine.loadStyle(stylePath, 0, error))
        throw std::runtime_error("Failed to load regression STYLE: " + error);

    const int tempoBpm = engine.tempo();
    const auto& analysis = engine.analysis();
    const std::uint64_t loopStartTick = static_cast<std::uint64_t>(analysis.markerTicks[3]);
    const std::uint64_t loopEndTick = static_cast<std::uint64_t>(analysis.markerTicks[4]);
    const std::uint64_t loopLengthTicks = loopEndTick - loopStartTick;
    const std::uint64_t ticksPerQuarter = static_cast<std::uint64_t>(analysis.ticksPerQuarter);
    if (tempoBpm <= 0 || loopLengthTicks == 0 || ticksPerQuarter == 0)
        throw std::runtime_error("STYLE timing metadata is invalid for the clock regression");

    std::vector<EventStamp> events;
    engine.setTimedMidiSink([&](std::uint8_t status, std::uint8_t data1,
                                std::uint8_t data2, std::uint64_t targetUs) {
        events.push_back({targetUs, static_cast<int>(status), static_cast<int>(data1),
                          static_cast<int>(data2), engine.currentTick()});
    });
    engine.play();
    if (!engine.isPlaying()) throw std::runtime_error("StyleEngine did not enter playback state");

    // Mirrors MainWindow::onStyleTick(): use steady-clock absolute timestamps,
    // a 15 ms look-ahead on the first advance, and the same look-ahead thereafter.
    constexpr std::uint64_t kSyntheticSteadyOriginUs = 10'000'000;
    constexpr std::uint64_t kMidiLookAheadUs = 15'000;
    std::uint64_t elapsedWallUs = 0;
    std::size_t callbackIndex = 0;
    bool firstAdvance = true;

    while (elapsedWallUs < playbackDurationUs && engine.isPlaying()) {
        const std::uint64_t requested = callbackPattern[callbackIndex++ % callbackPattern.size()];
        const std::uint64_t deltaUs = std::min(requested, playbackDurationUs - elapsedWallUs);
        const std::uint64_t intervalStartUs = firstAdvance
            ? kSyntheticSteadyOriginUs
            : kSyntheticSteadyOriginUs + elapsedWallUs + kMidiLookAheadUs;
        const std::uint64_t advanceUs = deltaUs + (firstAdvance ? kMidiLookAheadUs : 0);
        engine.advanceMicroseconds(advanceUs, intervalStartUs);
        firstAdvance = false;
        elapsedWallUs += deltaUs;
    }
    return events;
}

bool compare(const std::vector<EventStamp>& reference,
             const std::vector<EventStamp>& candidate, const char* label) {
    if (reference.size() != candidate.size()) {
        std::cerr << "FAIL " << label << ": event count differs ("
                  << reference.size() << " vs " << candidate.size() << ")\n";
        return false;
    }
    for (std::size_t i = 0; i < reference.size(); ++i) {
        if (!(reference[i] == candidate[i])) {
            std::cerr << "FAIL " << label << ": first timing mismatch at event " << i
                      << " reference(target_us,tick,status,note,velocity)="
                      << reference[i].targetUs << ',' << reference[i].engineTick << ','
                      << reference[i].status << ',' << reference[i].data1 << ',' << reference[i].data2
                      << " candidate=" << candidate[i].targetUs << ',' << candidate[i].engineTick << ','
                      << candidate[i].status << ',' << candidate[i].data1 << ',' << candidate[i].data2 << '\n';
            return false;
        }
    }
    return true;
}

bool metricalDeadlines(const std::vector<EventStamp>& events, std::uint64_t steadyOriginUs,
                       std::uint64_t loopStartTick, std::uint64_t loopLengthTicks,
                       std::uint64_t tempoBpm, std::uint64_t ticksPerQuarter) {
    std::uint64_t loopEpochTicks = 0;
    int previousTick = static_cast<int>(loopStartTick);
    constexpr std::uint64_t kMicrosPerMinute = 60'000'000ULL;
    const std::uint64_t tickRate = tempoBpm * ticksPerQuarter;
    bool ok = true;
    for (const auto& event : events) {
        if (event.targetUs == 0) continue; // synchronous downbeat dispatch from play()
        if (event.engineTick < previousTick) loopEpochTicks += loopLengthTicks;
        previousTick = event.engineTick;
        const std::uint64_t elapsedTicks = loopEpochTicks +
            static_cast<std::uint64_t>(event.engineTick) - loopStartTick;
        const std::uint64_t numerator = elapsedTicks * kMicrosPerMinute;
        const std::uint64_t expectedOffsetUs = (numerator + tickRate - 1) / tickRate;
        const std::uint64_t expectedTargetUs = steadyOriginUs + expectedOffsetUs;
        const std::uint64_t errorUs = event.targetUs > expectedTargetUs
            ? event.targetUs - expectedTargetUs : expectedTargetUs - event.targetUs;
        if (errorUs > 1) {
            std::cerr << "FAIL metrical deadline at event tick=" << event.engineTick
                      << ": target=" << event.targetUs << " expected=" << expectedTargetUs
                      << " error_us=" << errorUs << '\n';
            ok = false;
            break;
        }
    }
    return ok;
}

bool monotonicTargets(const std::vector<EventStamp>& events) {
    std::uint64_t previous = 0;
    bool first = true;
    for (const auto& event : events) {
        // Zero is reserved for start-up events dispatched synchronously by play().
        if (event.targetUs == 0) continue;
        if (!first && event.targetUs < previous) {
            std::cerr << "FAIL event target timestamps went backward: " << previous
                      << " -> " << event.targetUs << '\n';
            return false;
        }
        previous = event.targetUs;
        first = false;
    }
    return true;
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: style-engine-clock-regression <style.stl>\n";
        return 2;
    }

    try {
        const std::filesystem::path stylePath(argv[1]);
        constexpr std::uint64_t kPlaybackDurationUs = 8'000'000;
        const auto regular3ms = runTimeline(stylePath, {3'000}, kPlaybackDurationUs);
        const auto mixedJitter = runTimeline(stylePath,
            {1'000, 2'000, 5'000, 7'000, 13'000, 3'000, 11'000}, kPlaybackDurationUs);
        const auto delayed17ms = runTimeline(stylePath, {17'000, 17'000, 17'000, 1'000}, kPlaybackDurationUs);

        bool ok = true;
        ok &= compare(regular3ms, mixedJitter, "3 ms vs mixed timer intervals");
        ok &= compare(regular3ms, delayed17ms, "3 ms vs 17 ms timer intervals");
        ensembles::StyleEngine metadataEngine;
        std::string metadataError;
        if (!metadataEngine.loadStyle(stylePath, 0, metadataError))
            throw std::runtime_error("Failed to reload timing metadata: " + metadataError);
        const auto& analysis = metadataEngine.analysis();
        const auto tempo = static_cast<std::uint64_t>(metadataEngine.tempo());
        const auto tpq = static_cast<std::uint64_t>(analysis.ticksPerQuarter);
        const auto loopStart = static_cast<std::uint64_t>(analysis.markerTicks[3]);
        const auto loopLength = static_cast<std::uint64_t>(analysis.markerTicks[4] - analysis.markerTicks[3]);
        ok &= metricalDeadlines(regular3ms, 10'000'000, loopStart, loopLength, tempo, tpq);
        ok &= metricalDeadlines(mixedJitter, 10'000'000, loopStart, loopLength, tempo, tpq);
        ok &= metricalDeadlines(delayed17ms, 10'000'000, loopStart, loopLength, tempo, tpq);
        ok &= monotonicTargets(regular3ms);
        ok &= monotonicTargets(mixedJitter);
        ok &= monotonicTargets(delayed17ms);
        if (!ok) return 1;

        std::cout << "PASS: " << regular3ms.size()
                  << " STYLE MIDI events retained identical target timestamps and tick order"
                     " under 3 ms, mixed-jitter, and 17 ms callbacks.\n";
        std::cout << "PASS: event deadlines match the absolute tempo/TPQ tick formula within 1 microsecond.\n";
        std::cout << "NOTE: this verifies the software tick-to-deadline path only; it does not"
                     " certify STL interpretation or physical MIDI/audio output latency.\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "FAIL exception: " << ex.what() << '\n';
        return 1;
    }
}
