#include "style_engine.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace fs = std::filesystem;

static std::vector<std::uint64_t> markerTicks(const ensembles::MidiFile& midi) {
    std::vector<std::uint64_t> ticks;
    for (const auto& meta : midi.meta_events)
        if (meta.type == 0x06) ticks.push_back(meta.tick);
    std::stable_sort(ticks.begin(), ticks.end());
    return ticks;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: roland-stl-corpus-audit <style-folder>\n";
        return 2;
    }
    const fs::path folder(argv[1]);
    if (!fs::is_directory(folder)) {
        std::cerr << "Not a directory: " << folder.string() << '\n';
        return 2;
    }

    std::size_t supported = 0, loadedCount = 0, unsupported = 0, failed = 0;
    std::size_t events = 0, offBeatOns = 0, emptyStyles = 0;
    std::map<std::uint64_t, std::size_t> variationBarHistogram;
    std::vector<std::string> failures;
    for (const auto& entry : fs::directory_iterator(folder)) {
        if (!entry.is_regular_file()) continue;
        std::string ext = entry.path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (ext != ".stl") continue;

        std::array<ensembles::MidiFile, 3> families{};
        std::string error;
        if (!ensembles::load_roland_style_chord_families(entry.path(), families, error)) {
            const auto name = entry.path().filename().string();
            std::ifstream in(entry.path(), std::ios::binary);
            char sig[2]{};
            in.read(sig, 2);
            if (sig[0] != 'G' || (sig[1] != '8' && sig[1] != 'V')) {
                ++unsupported;
                continue;
            }
            ++failed;
            if (failures.size() < 20) failures.push_back(name + ": " + error);
            continue;
        }
        ++supported;
        ++loadedCount;
        const auto referenceMarkers = markerTicks(families[0]);
        if (referenceMarkers.size() != 15) {
            ++failed;
            if (failures.size() < 20) failures.push_back(entry.path().filename().string() + ": marker count != 15");
            continue;
        }
        const auto tpq = families[0].ticks_per_quarter;
        const auto numerator = families[0].time_signature_numerator;
        const auto denominator = families[0].time_signature_denominator;
        if (tpq == 0 || numerator == 0 || denominator == 0) {
            ++failed;
            if (failures.size() < 20) failures.push_back(entry.path().filename().string() + ": invalid time signature");
            continue;
        }
        const std::uint64_t ticksPerBar = static_cast<std::uint64_t>(tpq) * 4u * numerator / denominator;
        bool bad = false;
        for (const auto pair : {std::pair<std::size_t, std::size_t>{3, 4}, {5, 6}, {7, 8}, {9, 10}}) {
            if (pair.second < referenceMarkers.size()) {
                const auto span = referenceMarkers[pair.second] - referenceMarkers[pair.first];
                if (ticksPerBar > 0 && span % ticksPerBar == 0)
                    ++variationBarHistogram[span / ticksPerBar];
            }
        }
        for (int f = 0; f < 3; ++f) {
            if (markerTicks(families[static_cast<std::size_t>(f)]) != referenceMarkers) bad = true;
            if (families[static_cast<std::size_t>(f)].events.empty()) ++emptyStyles;
            events += families[static_cast<std::size_t>(f)].events.size();
            for (const auto& event : families[static_cast<std::size_t>(f)].events) {
                if ((event.status & 0xf0) == 0x90 && event.data2 > 0 && ticksPerBar > 0) {
                    const auto beatTicks = static_cast<std::uint64_t>(tpq) * 4u / denominator;
                    if (beatTicks > 0 && event.tick % beatTicks != 0) ++offBeatOns;
                }
            }
        }
        for (const auto tick : referenceMarkers) {
            if (ticksPerBar > 0 && tick % ticksPerBar != 0) bad = true;
        }
        if (bad) {
            ++failed;
            if (failures.size() < 20) failures.push_back(entry.path().filename().string() + ": chord-family markers or bar grid diverged");
        }
    }

    std::cout << "STL corpus audit\n"
              << "supported and loaded: " << loadedCount << "\n"
              << "unsupported signature/legacy STL: " << unsupported << "\n"
              << "failed: " << failed << "\n"
              << "empty family timelines: " << emptyStyles << "\n"
              << "events across all families: " << events << "\n"
              << "off-beat Note On events preserved: " << offBeatOns << "\n"
              << "variation section lengths in bars:";
    for (const auto& [bars, count] : variationBarHistogram) std::cout << " " << bars << "=" << count;
    std::cout << "\n";
    for (const auto& failure : failures) std::cout << "FAIL " << failure << '\n';
    return failed == 0 ? 0 : 1;
}
