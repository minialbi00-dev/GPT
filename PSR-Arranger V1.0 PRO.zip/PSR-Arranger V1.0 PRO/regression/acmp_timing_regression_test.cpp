#include <utility>
#include <filesystem>
#include <array>
#include "style_engine.hpp"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <set>
#include <string>
#include <vector>

static std::uint64_t marker(const ensembles::MidiFile& m, const std::string& name) {
    for (const auto& e : m.meta_events) if (e.text.rfind(name + ":", 0) == 0) return e.tick;
    return UINT64_MAX;
}
static std::vector<std::uint64_t> onsets(const ensembles::MidiFile& m, std::uint64_t start,
                                         std::uint64_t end, int channel, int pitch) {
    std::vector<std::uint64_t> result;
    for (const auto& e : m.events) {
        if ((e.status & 0xf0) == 0x90 && e.data2 > 0 && (e.status & 0x0f) == channel &&
            e.data1 == pitch && e.tick >= start && e.tick < end) result.push_back(e.tick);
    }
    std::sort(result.begin(), result.end());
    return result;
}
static bool require(const char* label, const std::vector<std::uint64_t>& actual,
                    const std::vector<std::uint64_t>& expected) {
    if (actual == expected) return true;
    std::cerr << "FAIL " << label << " expected:";
    for (auto x : expected) std::cerr << ' ' << x;
    std::cerr << " actual:";
    for (auto x : actual) std::cerr << ' ' << x;
    std::cerr << '\n';
    return false;
}

static bool loadPrimaryRolandStyle(const std::filesystem::path& path, ensembles::MidiFile& out, std::string& error) {
    std::array<ensembles::MidiFile, 3> families{};
    if (!ensembles::load_roland_style_chord_families(path, families, error)) return false;
    out = std::move(families[0]);
    return true;
}

int main(int argc, char **argv) {
    if (argc != 2) { std::cerr << "usage: test_stl file.stl\n"; return 2; }
    std::array<ensembles::MidiFile,3> out{};
    std::string error;
    if (!ensembles::load_roland_style_chord_families(argv[1], out, error)) {
        std::cerr << error << "\n"; return 1;
    }
    const auto va = marker(out[0], "Variation A");
    const auto fa = marker(out[0], "Fill A");
    const auto vc = marker(out[0], "Variation C");
    const auto fc = marker(out[0], "Fill C");
    if (va == UINT64_MAX || fa == UINT64_MAX || vc == UINT64_MAX || fc == UINT64_MAX) {
        std::cerr << "FAIL required section markers missing\n"; return 1;
    }
    bool ok = true;
    // In these ACMP streams, 0xFF ends a multi-note chord group and the next
    // group is another multi-note chord at a raw-period-aligned two-beat cadence.
    // Normalize only these confirmed gaps from 255 to 240 source ticks (1020 ->
    // 960 Ensembles ticks). The separate synthetic regression covers isolated
    // 0xFF deltas and guarantees those remain untouched.
    ok &= require("Variation A ACMP ch2 pitch64 chord grid", onsets(out[0], va, fa, 2, 64),
                  {va, va+960, va+1920, va+2880});
    ok &= require("Fill A ACMP ch2 pitch64 chord grid", onsets(out[0], fa, marker(out[0], "Variation B"), 2, 64),
                  {fa, fa+960});
    // Second ACMP part in the same Fill exercises another stream.
    ok &= require("Fill A ACMP ch4 pitch72 chord grid", onsets(out[0], fa, marker(out[0], "Variation B"), 4, 72),
                  {fa, fa+960});
    // Advanced Fill must follow the same chord-grid rule as Basic parts.
    ok &= require("Fill C ACMP ch5 pitch64 chord grid", onsets(out[0], fc, marker(out[0], "Variation D"), 5, 64),
                  {fc, fc+960});
    // The parser must not change the drum track's source timing.
    const auto drum = onsets(out[0], va, fa, 9, 36);
    if (drum.empty()) { std::cerr << "FAIL drum reference events missing\n"; ok=false; }
    for (auto t : drum) if ((t - va) % 240 != 0) {
        std::cerr << "FAIL drum event unexpectedly shifted off the source grid at " << t << '\n'; ok=false; break;
    }
    const auto compensatedPath = std::filesystem::path(argv[1]).parent_path() / "16B Pop1 G1000.STL";
    if (std::filesystem::exists(compensatedPath)) {
        std::array<ensembles::MidiFile, 3> pop1{};
        if (!ensembles::load_roland_style_chord_families(compensatedPath, pop1, error)) {
            std::cerr << "FAIL 16B Pop1 G1000.STL load: " << error << '\n';
            ok = false;
        } else {
            const auto popVa = marker(pop1[0], "Variation A");
            const auto popFa = marker(pop1[0], "Fill A");
            if (popVa == UINT64_MAX || popFa == UINT64_MAX) {
                std::cerr << "FAIL 16B Pop1 markers missing\n";
                ok = false;
            } else {
                // Acc part encoded 255/225/255/225: late hits must lock to 240, not stay at 255.
                const auto locked = onsets(pop1[0], popVa, popFa, 4, 60);
                ok &= require("16B Pop1 compensated ACMP ch4 pitch60 grid", locked,
                              {popVa, popVa + 960, popVa + 1920, popVa + 2880});
                const auto drums = onsets(pop1[0], popVa, popFa, 9, 35);
                if (drums.empty() || drums.front() != popVa) {
                    std::cerr << "FAIL 16B Pop1 drum downbeat missing at Variation A\n";
                    ok = false;
                }
            }
        }
    }

    if (!ok) return 1;
    std::cout << "PASS: confirmed saturated ACMP chord groups are grid-aligned; isolated deltas and drum event timing remain unchanged.\n";
    for (std::size_t f=0; f<out.size(); ++f)
        std::cout << "family=" << f << " events=" << out[f].events.size() << " duration_ticks=" << out[f].duration_ticks << '\n';
    return 0;
}
