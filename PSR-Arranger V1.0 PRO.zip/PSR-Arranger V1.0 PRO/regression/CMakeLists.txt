cmake_minimum_required(VERSION 3.20)
project(ACMPBeatSyncRegression LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

set(PATCH_SRC "${CMAKE_CURRENT_LIST_DIR}/../src")
add_executable(acmp-timing-regression
    acmp_timing_regression_test.cpp
    "${PATCH_SRC}/midi_file.cpp"
    "${PATCH_SRC}/roland_stl.cpp"
    "${PATCH_SRC}/yamaha_style_runtime.cpp"
    "${PATCH_SRC}/yamaha_arranger_engine.cpp"
    "${PATCH_SRC}/style_engine.cpp"
    "${PATCH_SRC}/chord_finder.cpp"
)
target_include_directories(acmp-timing-regression PRIVATE "${PATCH_SRC}")
enable_testing()
add_test(NAME acmp_timing_regression
    COMMAND acmp-timing-regression "${CMAKE_CURRENT_LIST_DIR}/../data/StyleFiles/Roland G-1000/8B Pop7 G1000.STL")

# Optional whole-library audit. Run it against a folder of real Roland .STL files:
# roland-stl-corpus-audit <style-folder>
add_executable(roland-stl-corpus-audit
    roland_stl_corpus_audit.cpp
    "${PATCH_SRC}/midi_file.cpp"
    "${PATCH_SRC}/roland_stl.cpp"
    "${PATCH_SRC}/yamaha_style_runtime.cpp"
    "${PATCH_SRC}/yamaha_arranger_engine.cpp"
    "${PATCH_SRC}/style_engine.cpp"
    "${PATCH_SRC}/chord_finder.cpp"
)
target_include_directories(roland-stl-corpus-audit PRIVATE "${PATCH_SRC}")

# Deterministic StyleEngine timing regression: event deadlines must not drift
# when the Qt transport callback interval varies. This is not a hardware test.
add_executable(style-engine-clock-regression
    style_engine_clock_regression_test.cpp
    "${PATCH_SRC}/midi_file.cpp"
    "${PATCH_SRC}/roland_stl.cpp"
    "${PATCH_SRC}/yamaha_style_runtime.cpp"
    "${PATCH_SRC}/yamaha_arranger_engine.cpp"
    "${PATCH_SRC}/style_engine.cpp"
    "${PATCH_SRC}/chord_finder.cpp"
)
target_include_directories(style-engine-clock-regression PRIVATE "${PATCH_SRC}")
add_test(NAME style_engine_clock_regression
    COMMAND style-engine-clock-regression "${CMAKE_CURRENT_LIST_DIR}/../data/StyleFiles/Roland G-1000/8B Pop7 G1000.STL")

# Full parser/engine regression from the existing fixture-generator suite.
add_executable(roland-stl-reader-regression
    "${PATCH_SRC}/../tests/roland_stl_reader_test.cpp"
    "${PATCH_SRC}/midi_file.cpp"
    "${PATCH_SRC}/roland_stl.cpp"
    "${PATCH_SRC}/yamaha_style_runtime.cpp"
    "${PATCH_SRC}/yamaha_arranger_engine.cpp"
    "${PATCH_SRC}/style_engine.cpp"
    "${PATCH_SRC}/chord_finder.cpp"
)
target_include_directories(roland-stl-reader-regression PRIVATE "${PATCH_SRC}")
add_test(NAME roland_stl_reader_regression COMMAND roland-stl-reader-regression)
