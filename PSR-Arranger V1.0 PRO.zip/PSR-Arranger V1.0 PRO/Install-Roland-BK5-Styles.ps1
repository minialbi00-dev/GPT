$ErrorActionPreference = 'Stop'

$ProjectRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$StyleDir = Join-Path $ProjectRoot 'data\StyleFiles'
$StyleZipUrl = 'https://raw.githubusercontent.com/minialbi00-dev/YW/main/STYLE%20ROLLAND%20BK-5.zip'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir = Join-Path (Join-Path $ProjectRoot 'data') ("StyleFiles_Backup_" + $Stamp)
$WorkDir = Join-Path $env:TEMP ("RolandBK5Styles_" + $Stamp)
$ZipPath = Join-Path $WorkDir 'STYLE_ROLLAND_BK5.zip'
$ExtractDir = Join-Path $WorkDir 'extracted'
$StageDir = Join-Path $WorkDir 'stage'

function Fail([string]$Message) {
    Write-Host "`n[ERROR] $Message" -ForegroundColor Red
    exit 1
}

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host 'Ensembles 6.8.7 - Replace Built-in Styles with Roland BK-5 STL' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'CMakeLists.txt'))) {
    Fail 'Letakkan file skrip ini di root proyek PSR-Arranger (folder yang berisi CMakeLists.txt).'
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'src\roland_stl.cpp'))) {
    Fail 'src\roland_stl.cpp belum ada. Ekstrak overlay kompatibilitas Roland V18.3 ke root proyek terlebih dahulu.'
}

try {
    New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null
    New-Item -ItemType Directory -Path $ExtractDir -Force | Out-Null
    New-Item -ItemType Directory -Path $StageDir -Force | Out-Null

    Write-Host '[1/5] Mengunduh arsip style Roland BK-5 dari repositori yang Anda berikan...'
    Invoke-WebRequest -Uri $StyleZipUrl -OutFile $ZipPath -UseBasicParsing
    if (-not (Test-Path -LiteralPath $ZipPath) -or (Get-Item -LiteralPath $ZipPath).Length -lt 1000) {
        Fail 'Unduhan arsip Roland gagal atau hasil unduhan terlalu kecil.'
    }

    Write-Host '[2/5] Memeriksa dan mengekstrak arsip...'
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $ExtractDir -Force
    $StlFiles = @(Get-ChildItem -LiteralPath $ExtractDir -Recurse -File | Where-Object { $_.Extension -ieq '.STL' })
    if ($StlFiles.Count -eq 0) {
        Fail 'Arsip berhasil dibuka tetapi tidak berisi file .STL. Folder StyleFiles lama tidak diubah.'
    }

    Write-Host '[3/5] Menyiapkan semua file .STL di folder staging...'
    $UsedNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($File in $StlFiles) {
        $BaseName = [System.IO.Path]::GetFileNameWithoutExtension($File.Name)
        $Candidate = $File.Name
        $Suffix = 2
        while (-not $UsedNames.Add($Candidate)) {
            $Candidate = '{0}_{1}.STL' -f $BaseName, $Suffix
            $Suffix++
        }
        Copy-Item -LiteralPath $File.FullName -Destination (Join-Path $StageDir $Candidate)
    }
    $StagedCount = @(Get-ChildItem -LiteralPath $StageDir -File -Filter '*.STL').Count
    if ($StagedCount -ne $StlFiles.Count -or $StagedCount -eq 0) {
        Fail 'Validasi staging gagal. Folder StyleFiles lama tidak diubah.'
    }

    Write-Host '[4/5] Membuat cadangan folder StyleFiles yang lama...'
    New-Item -ItemType Directory -Path (Split-Path -Parent $BackupDir) -Force | Out-Null
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    if (Test-Path -LiteralPath $StyleDir) {
        Get-ChildItem -LiteralPath $StyleDir -Force | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $BackupDir -Recurse -Force
        }
    } else {
        New-Item -ItemType Directory -Path $StyleDir -Force | Out-Null
    }

    Write-Host '[5/5] Mengganti isi data\StyleFiles dengan koleksi Roland STL...'
    Get-ChildItem -LiteralPath $StyleDir -Force | Remove-Item -Recurse -Force
    Get-ChildItem -LiteralPath $StageDir -File | Copy-Item -Destination $StyleDir -Force
    $FinalCount = @(Get-ChildItem -LiteralPath $StyleDir -File | Where-Object { $_.Extension -ieq '.STL' }).Count
    if ($FinalCount -ne $StlFiles.Count) {
        Fail "Jumlah file hasil salin tidak cocok (sumber $($StlFiles.Count), tujuan $FinalCount). Cadangan berada di $BackupDir"
    }

    Write-Host ''
    Write-Host '[OK] Penggantian folder style selesai.' -ForegroundColor Green
    Write-Host ("File Roland STL dipasang: {0}" -f $FinalCount) -ForegroundColor Green
    Write-Host ("Folder aktif: {0}" -f $StyleDir)
    Write-Host ("Cadangan style lama: {0}" -f $BackupDir)
    Write-Host 'Style lama tidak dihapus permanen; salinannya disimpan pada folder cadangan di atas.'
    Write-Host 'Selesai staging. Bangun ulang aplikasi dengan perintah CMake di README.md agar data STL yang baru digunakan.'
} catch {
    Write-Host ''
    Write-Host '[ERROR] Penggantian style gagal.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'Folder lama tidak dihapus sebelum unduhan, ekstraksi, dan staging lolos pemeriksaan.'
    exit 1
} finally {
    if (Test-Path -LiteralPath $WorkDir) {
        Remove-Item -LiteralPath $WorkDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
