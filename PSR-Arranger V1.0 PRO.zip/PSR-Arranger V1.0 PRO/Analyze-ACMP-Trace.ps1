param(
    [string]$TracePath = (Join-Path $env:TEMP 'Ensembles_ACMP_RuntimeTrace.csv')
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $TracePath)) {
    Write-Error "Trace not found: $TracePath`nRun V19.0-Apply-Build-Run.bat, play a problematic STYLE for 10-20 seconds, then close the app."
}
$rows = @(Import-Csv -LiteralPath $TracePath | Where-Object { $_.stage -and $_.stage -notlike '#*' })
if ($rows.Count -eq 0) { Write-Error "Trace contains no data rows: $TracePath" }

Write-Host "Trace: $TracePath"
Write-Host "Rows:  $($rows.Count)"
Write-Host "Styles loaded:"
$rows | Where-Object { $_.stage -eq 'STYLE_LOAD' -and $_.aux -ne '0' } |
    ForEach-Object { Write-Host ("  TPQ={0}  {1}" -f $_.aux, $_.text) }

$timed = @($rows | Where-Object {
    $_.target_us -match '^\d+$' -and [uint64]$_.target_us -gt 0 -and
    $_.observed_us -match '^\d+$' -and $_.stage -in @('ENGINE_DISPATCH','OUTPUT_QUEUE','AUDIO_APPLY_ESTIMATE','WINMM_SEND','AUDIO_FALLBACK','WINMM_FALLBACK','QUEUE_DROP')
})
if ($timed.Count -eq 0) { Write-Warning 'No timed events found. Check whether the app was built with trace support and the trace env var was enabled.'; exit 0 }
foreach ($r in $timed) {
    $r | Add-Member -NotePropertyName delta_us -NotePropertyValue ([int64]$r.observed_us - [int64]$r.target_us) -Force
}

$parserEdits = @($rows | Where-Object { $_.stage -eq 'PARSER_TICK_CORRECTION' })
Write-Host "`nParser corrections applied before playback: $($parserEdits.Count) event(s)"
if ($parserEdits.Count -gt 0) {
    $parserEdits | ForEach-Object {
        $_ | Add-Member -NotePropertyName tick_shift -NotePropertyValue ([int64]$_.source_tick - [int64]$_.style_tick) -Force
    }
    $parserEdits | Group-Object source_track,source_family,source_part,source_advanced | ForEach-Object {
        $g = $_.Group
        $shifts = @($g | ForEach-Object { [int64]$_.tick_shift } | Sort-Object)
        [pscustomobject]@{
            SourceTrack_Family_Part_Advanced = $_.Name
            AdjustedEvents = $shifts.Count
            MinShiftTicks = $shifts[0]
            MaxShiftTicks = $shifts[-1]
        }
    } | Sort-Object SourceTrack_Family_Part_Advanced | Format-Table -AutoSize
}

Write-Host "`nTiming summary (delta_us = observed/effective time - requested deadline):"
$timed | Group-Object stage | ForEach-Object {
    $values = @($_.Group | ForEach-Object { [int64]$_.delta_us } | Sort-Object)
    $p95Index = [Math]::Min($values.Count - 1, [Math]::Floor(0.95 * ($values.Count - 1)))
    $late2ms = @($values | Where-Object { $_ -gt 2000 }).Count
    [pscustomobject]@{
        Stage = $_.Name
        Count = $values.Count
        Median_us = $values[[int][Math]::Floor(($values.Count - 1) / 2)]
        P95_us = $values[$p95Index]
        Max_us = $values[-1]
        Over_2ms_late = $late2ms
    }
} | Format-Table -AutoSize

Write-Host "`nChannel-level output timing (channels 0-8 = melodic parts incl. ACMP/bass; channel 9 = drums):"
$timed | Where-Object { $_.stage -in @('AUDIO_APPLY_ESTIMATE','WINMM_SEND') } | Group-Object stage,channel | ForEach-Object {
    $g = $_.Group
    $values = @($g | ForEach-Object { [int64]$_.delta_us } | Sort-Object)
    $p95Index = [Math]::Min($values.Count - 1, [Math]::Floor(0.95 * ($values.Count - 1)))
    [pscustomobject]@{
        StageChannel = $_.Name
        Count = $values.Count
        Median_us = $values[[int][Math]::Floor(($values.Count - 1) / 2)]
        P95_us = $values[$p95Index]
        Max_us = $values[-1]
        Over_2ms_late = @($values | Where-Object { $_ -gt 2000 }).Count
    }
} | Sort-Object StageChannel | Format-Table -AutoSize

$problemRows = @($timed | Where-Object {
    $_.stage -in @('QUEUE_DROP','AUDIO_FALLBACK','WINMM_FALLBACK') -or
    ($_.stage -in @('AUDIO_APPLY_ESTIMATE','WINMM_SEND') -and [int64]$_.delta_us -gt 2000)
})
Write-Host "Problem rows (dropped/fallback or output more than 2 ms past deadline): $($problemRows.Count)"
if ($problemRows.Count -gt 0) {
    $problemRows | Select-Object -First 30 stage,observed_us,target_us,delta_us,style_tick,channel,status_decimal,data1,data2,aux,route,text | Format-Table -AutoSize
}
Write-Host "`nReminder: AUDIO_APPLY_ESTIMATE is the target sample's estimated position inside RtAudio block, not acoustic loopback. This trace separates engine deadline/queue problems from renderer/DAC latency; it does not by itself measure speaker output."
