#include <Windows.h>
#include "../include/LCDDisplay.h"

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	LCDDisplay display(hInstance);

	if (!display.Create(L"LCDDisplayClass", L"Ensembles LCD Display", 100, 100, 1000, 350)) {
		MessageBoxW(nullptr, L"Failed to create display window", L"Error", MB_ICONERROR);
		return 1;
	}

	// Setup the display
	display.SetTempo("♩=125  E001.1");
	display.SetRegisterName("New Bank");
	display.SetVocalHarmony("StandardHarmony");
	display.SetMIDIInfo("4/4  ♩=120  001/001");
	display.SetAudioInfo("New Audio");
	display.SetStyleInfo("Style", "SkyPop");

	// Add menu items (representing the 4 main buttons)
	display.AddMenuItem("Left", "VP Soft");
	display.AddMenuItem("Right1", "ConcertGrand");
	display.AddMenuItem("Right2", "SeattleStrings");
	display.AddMenuItem("Right3", "SteelAcousticPick");

	display.UpdateDisplay();

	// Main message loop
	MSG msg = {};
	while (GetMessageW(&msg, nullptr, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessageW(&msg);
	}

	return 0;
}
