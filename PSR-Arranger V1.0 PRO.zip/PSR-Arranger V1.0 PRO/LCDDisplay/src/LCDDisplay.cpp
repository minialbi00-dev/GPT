#include "../include/LCDDisplay.h"
#include <cmath>
#include <sstream>

LCDDisplay::LCDDisplay(HINSTANCE hInstance)
	: hwnd(nullptr), hInstance(hInstance), selectedIndex(0),
	  displayWidth(800), displayHeight(300),
	  bgColor(RGB(45, 45, 45)), borderColor(RGB(0, 128, 128)),
	  tempo("♩=125"), register_name("New Bank"), vocal_harmony("StandardHarmony"),
	  midiInfo("New Song"), audioInfo("New Audio"),
	  styleLabel("Style"), styleName("SkyPop") {}

LCDDisplay::~LCDDisplay() {
	if (hwnd) {
		DestroyWindow(hwnd);
	}
}

bool LCDDisplay::Create(LPCWSTR className, LPCWSTR windowName, int x, int y, int width, int height) {
	displayWidth = width;
	displayHeight = height;

	WNDCLASSW wc = {};
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = className;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.hCursor = LoadCursor(nullptr, IDC_ARROW);

	if (!RegisterClassW(&wc)) {
		return false;
	}

	hwnd = CreateWindowW(className, windowName,
		WS_OVERLAPPEDWINDOW,
		x, y, width, height,
		nullptr, nullptr, hInstance, this);

	if (!hwnd) {
		return false;
	}

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);
	return true;
}

void LCDDisplay::AddMenuItem(const std::string& label, const std::string& value) {
	menuItems.emplace_back(label, value);
}

void LCDDisplay::SelectNext() {
	if (!menuItems.empty()) {
		selectedIndex = (selectedIndex + 1) % menuItems.size();
		UpdateDisplay();
	}
}

void LCDDisplay::SelectPrevious() {
	if (!menuItems.empty()) {
		selectedIndex = (selectedIndex - 1 + menuItems.size()) % menuItems.size();
		UpdateDisplay();
	}
}

void LCDDisplay::UpdateDisplay() {
	if (hwnd) {
		InvalidateRect(hwnd, nullptr, FALSE);
		UpdateWindow(hwnd);
	}
}

void LCDDisplay::CalculateMenuItemRects() {
	int menuAreaHeight = displayHeight / 2;
	int itemWidth = displayWidth / 4;
	int itemHeight = menuAreaHeight;

	for (int i = 0; i < menuItems.size() && i < 4; ++i) {
		menuItems[i].rect.left = i * itemWidth + 10;
		menuItems[i].rect.top = 40;
		menuItems[i].rect.right = (i + 1) * itemWidth - 10;
		menuItems[i].rect.bottom = menuItems[i].rect.top + itemHeight - 20;
	}
}

void LCDDisplay::OnPaint(HDC hdc) {
	RECT clientRect;
	GetClientRect(hwnd, &clientRect);

	// Draw background
	HBRUSH hBrush = CreateSolidBrush(bgColor);
	FillRect(hdc, &clientRect, hBrush);
	DeleteObject(hBrush);

	// Draw border
	HPEN hPen = CreatePen(PS_SOLID, 2, borderColor);
	HPEN oldPen = (HPEN)SelectObject(hdc, hPen);
	Rectangle(hdc, 0, 0, displayWidth - 1, displayHeight - 1);
	SelectObject(hdc, oldPen);
	DeleteObject(hPen);

	DrawStatusBar(hdc);
	DrawMenuBar(hdc);
	DrawThumbnails(hdc);
	DrawBottomBar(hdc);
}

void LCDDisplay::DrawStatusBar(HDC hdc) {
	// Top status bar with tempo and volume
	HBRUSH hBrush = CreateSolidBrush(RGB(40, 40, 40));
	RECT statusRect = { 0, 0, displayWidth, 25 };
	FillRect(hdc, &statusRect, hBrush);
	DeleteObject(hBrush);

	// Draw border
	HPEN hPen = CreatePen(PS_SOLID, 1, borderColor);
	HPEN oldPen = (HPEN)SelectObject(hdc, hPen);
	MoveToEx(hdc, 0, 25, nullptr);
	LineTo(hdc, displayWidth, 25);
	SelectObject(hdc, oldPen);
	DeleteObject(hPen);

	SetTextColor(hdc, RGB(255, 255, 0));
	SetBkMode(hdc, TRANSPARENT);

	HFONT hFont = CreateFontW(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Courier");
	HFONT oldFont = (HFONT)SelectObject(hdc, hFont);

	std::wstring tempoW(tempo.begin(), tempo.end());
	TextOutW(hdc, 5, 5, tempoW.c_str(), tempoW.length());

	SelectObject(hdc, oldFont);
	DeleteObject(hFont);
}

void LCDDisplay::DrawMenuBar(HDC hdc) {
	int menuBarY = 25;
	int menuBarHeight = 30;

	HBRUSH hBrush = CreateSolidBrush(RGB(35, 35, 35));
	RECT menuBarRect = { 0, menuBarY, displayWidth, menuBarY + menuBarHeight };
	FillRect(hdc, &menuBarRect, hBrush);
	DeleteObject(hBrush);

	SetTextColor(hdc, RGB(200, 200, 200));
	SetBkMode(hdc, TRANSPARENT);

	HFONT hFont = CreateFontW(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Arial");
	HFONT oldFont = (HFONT)SelectObject(hdc, hFont);

	std::wstring registerW(register_name.begin(), register_name.end());
	TextOutW(hdc, 10, 30, registerW.c_str(), registerW.length());

	std::wstring harmonyW(vocal_harmony.begin(), vocal_harmony.end());
	TextOutW(hdc, displayWidth - 200, 30, harmonyW.c_str(), harmonyW.length());

	SelectObject(hdc, oldFont);
	DeleteObject(hFont);
}

void LCDDisplay::DrawThumbnails(HDC hdc) {
	int thumbnailsY = 60;
	int thumbnailsHeight = 120;
	int itemWidth = displayWidth / 4;
	int spacing = 5;

	for (int i = 0; i < 4; ++i) {
		int x = i * itemWidth + spacing;
		int y = thumbnailsY;
		int w = itemWidth - (2 * spacing);
		int h = thumbnailsHeight;

		// Draw thumbnail background
		HBRUSH hBrush;
		if (i == selectedIndex) {
			hBrush = CreateSolidBrush(RGB(0, 100, 100));
		} else {
			hBrush = CreateSolidBrush(RGB(50, 50, 50));
		}

		RECT thumbnailRect = { x, y, x + w, y + h };
		FillRect(hdc, &thumbnailRect, hBrush);
		DeleteObject(hBrush);

		// Draw border
		HPEN hPen = CreatePen(PS_SOLID, 1, borderColor);
		HPEN oldPen = (HPEN)SelectObject(hdc, hPen);
		Rectangle(hdc, x, y, x + w, y + h);
		SelectObject(hdc, oldPen);
		DeleteObject(hPen);

		// Draw text label
		if (i < menuItems.size()) {
			SetTextColor(hdc, RGB(0, 200, 200));
			SetBkMode(hdc, TRANSPARENT);

			HFONT hFont = CreateFontW(10, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Arial");
			HFONT oldFont = (HFONT)SelectObject(hdc, hFont);

			std::wstring labelW(menuItems[i].label.begin(), menuItems[i].label.end());
			TextOutW(hdc, x + 5, y + 5, labelW.c_str(), labelW.length());

			SelectObject(hdc, oldFont);
			DeleteObject(hFont);
		}
	}
}

void LCDDisplay::DrawBottomBar(HDC hdc) {
	int bottomBarY = 190;
	int bottomBarHeight = 110;

	// MIDI/Audio section
	HBRUSH hBrush = CreateSolidBrush(RGB(25, 25, 25));
	RECT bottomRect = { 0, bottomBarY, displayWidth / 2, bottomBarY + 40 };
	FillRect(hdc, &bottomRect, hBrush);
	DeleteObject(hBrush);

	SetTextColor(hdc, RGB(150, 150, 150));
	SetBkMode(hdc, TRANSPARENT);

	HFONT hFont = CreateFontW(11, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Arial");
	HFONT oldFont = (HFONT)SelectObject(hdc, hFont);

	// MIDI info
	std::wstring midiLabelW(L"MIDI");
	TextOutW(hdc, 10, bottomBarY + 5, midiLabelW.c_str(), midiLabelW.length());

	std::wstring midiW(midiInfo.begin(), midiInfo.end());
	TextOutW(hdc, 10, bottomBarY + 20, midiW.c_str(), midiW.length());

	// Audio info
	std::wstring audioLabelW(L"Audio");
	TextOutW(hdc, displayWidth / 2, bottomBarY + 5, audioLabelW.c_str(), audioLabelW.length());

	std::wstring audioW(audioInfo.begin(), audioInfo.end());
	TextOutW(hdc, displayWidth / 2, bottomBarY + 20, audioW.c_str(), audioW.length());

	// Style section
	HBRUSH hBrush2 = CreateSolidBrush(RGB(30, 0, 50));
	RECT styleRect = { 0, bottomBarY + 45, displayWidth, bottomBarY + bottomBarHeight };
	FillRect(hdc, &styleRect, hBrush2);
	DeleteObject(hBrush2);

	SetTextColor(hdc, RGB(200, 100, 200));
	HFONT hFontBold = CreateFontW(12, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, L"Arial");
	HFONT oldFont2 = (HFONT)SelectObject(hdc, hFontBold);

	std::wstring styleLabelW(styleLabel.begin(), styleLabel.end());
	TextOutW(hdc, 10, bottomBarY + 50, styleLabelW.c_str(), styleLabelW.length());

	std::wstring styleNameW(styleName.begin(), styleName.end());
	TextOutW(hdc, 10, bottomBarY + 70, styleNameW.c_str(), styleNameW.length());

	SelectObject(hdc, oldFont2);
	DeleteObject(hFontBold);
	SelectObject(hdc, oldFont);
	DeleteObject(hFont);
}

LRESULT CALLBACK LCDDisplay::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LCDDisplay* pThis = nullptr;

	if (msg == WM_CREATE) {
		CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
		pThis = reinterpret_cast<LCDDisplay*>(pCreate->lpCreateParams);
		SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)pThis);
	} else {
		pThis = reinterpret_cast<LCDDisplay*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
	}

	if (!pThis) {
		return DefWindowProcW(hwnd, msg, wParam, lParam);
	}

	switch (msg) {
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			pThis->OnPaint(hdc);
			EndPaint(hwnd, &ps);
			return 0;
		}
		case WM_KEYDOWN:
			if (wParam == VK_LEFT) pThis->SelectPrevious();
			else if (wParam == VK_RIGHT) pThis->SelectNext();
			return 0;
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
		default:
			return DefWindowProcW(hwnd, msg, wParam, lParam);
	}
}
