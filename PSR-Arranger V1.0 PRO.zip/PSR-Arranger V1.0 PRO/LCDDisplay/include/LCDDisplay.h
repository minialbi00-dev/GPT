#pragma once
#include <Windows.h>
#include <string>
#include <vector>

class MenuItem {
public:
	std::string label;
	std::string value;
	RECT rect;
	COLORREF bgColor;
	COLORREF textColor;
	bool isSelected;

	MenuItem(const std::string& label, const std::string& value)
		: label(label), value(value), bgColor(RGB(0, 0, 0)), 
		  textColor(RGB(255, 255, 255)), isSelected(false) {}
};

class LCDDisplay {
private:
	HWND hwnd;
	HINSTANCE hInstance;
	std::vector<MenuItem> menuItems;
	int selectedIndex;

	// Display properties
	int displayWidth;
	int displayHeight;
	COLORREF bgColor;
	COLORREF borderColor;

	// Metronome/Status display
	std::string tempo;
	std::string register_name;
	std::string vocal_harmony;

	// MIDI/Audio info
	std::string midiInfo;
	std::string audioInfo;

	// Style display
	std::string styleLabel;
	std::string styleName;

public:
	LCDDisplay(HINSTANCE hInstance);
	~LCDDisplay();

	bool Create(LPCWSTR className, LPCWSTR windowName, int x, int y, int width, int height);
	HWND GetHWND() const { return hwnd; }

	void SetTempo(const std::string& t) { tempo = t; }
	void SetRegisterName(const std::string& r) { register_name = r; }
	void SetVocalHarmony(const std::string& v) { vocal_harmony = v; }
	void SetMIDIInfo(const std::string& m) { midiInfo = m; }
	void SetAudioInfo(const std::string& a) { audioInfo = a; }
	void SetStyleInfo(const std::string& label, const std::string& name) { 
		styleLabel = label; 
		styleName = name; 
	}

	void AddMenuItem(const std::string& label, const std::string& value);
	void SelectNext();
	void SelectPrevious();
	void UpdateDisplay();

private:
	void OnPaint(HDC hdc);
	void DrawMenuBar(HDC hdc);
	void DrawThumbnails(HDC hdc);
	void DrawBottomBar(HDC hdc);
	void DrawStatusBar(HDC hdc);
	void CalculateMenuItemRects();

public:
	static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
};
