# V20 full package — build fix V2

This is the complete V20 project source tree with the requested SoundFont folder naming and the Windows CMake source-path correction applied.

Changes from the archived V20 baseline:
- Renamed `src/ls_gm/` to `src/SoundFont/` to match the source paths in `CMakeLists.txt` and the `SoundFont/...` header includes.
- Consolidated the native bank at `data/SoundFont/LS-GM.sf2` (capital F); the old `data/Soundfont/` directory is no longer included.
- Updated the CMake post-build copy and native LS-GM lookup/error messages to use `data/SoundFont/`.
- Kept `data/SoundFonts/` (plural) unchanged; it is a separate directory for the general FluidSynth GM bank and notices.
- Preserved the remaining V20 project files, data, tests, scripts, and bundled NativeTS source.

The original GitHub `main` branch and original multipart RAR files were not modified by this package build. This package has not been compiled on the user's Windows/Qt/MSVC machine; rerun the included `V19.0-Apply-Build-Run.bat` from a fresh extraction to verify the full build.
