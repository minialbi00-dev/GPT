# Yamaha CASM RTR — Held Notes on Chord Changes

Date: 2026-11-06
Project: Ensembles 6.8.7 V20
Status: **held-note chord update implemented with a MIDI 1.0 fallback; not Genos2 1:1 certified**

## Root cause

`CppArrangerEngine::apply_rtr_to_sounding_notes()` previously skipped RTR values 1 (Pitch Shift) and 2 (Pitch Shift to Root). Those values are common in the supplied PSR-S corpus. New notes were transformed against the current chord, but already-sounding notes could remain at the previous chord pitch. This made accompaniment appear not to follow chord changes while a pattern note was sustaining.

## Changes

- RTR 1 recalculates the held note from the original source note using the active CASM NTR/NTT transform for the new chord.
- RTR 2 recalculates the held note at the new chord root, retaining the existing octave policy and respecting configured NTT Bass/slash-bass selection.
- Because the current output contract is MIDI 1.0 short messages, a per-note continuous pitch bend cannot be expressed using ordinary channel Pitch Bend without also affecting other simultaneous notes on that channel. The runtime therefore uses a same-tick Note-Off/Note-On revoice as a deterministic fallback. It does not send a global channel bend.
- Active-note mapping is updated to the new pitch/channel. The later source Note-Off releases the updated voice rather than the old pitch.
- Generated revoice events retain the original MIDI source track so per-part routing/debugging does not collapse those events onto track zero.
- The public `StyleEngine::changeChord()` route is covered, not just the lower-level `CppArrangerEngine::set_chord()` API.

## Verification

- C++17 runtime test: RTR 0–4 behavior, held-note C→D→G transition, no channel-wide Pitch Bend, and final Note-Off pairing.
- StyleEngine wrapper test: start a sustained C note, call `StyleEngine::changeChord(D, Major)`, advance the timer, and verify Note-Off(C) plus Note-On(D) arrive at the actual MIDI sink.
- CASM corpus test: 642 files loaded, 92,234 expanded Ctb2 rules, zero malformed rules.
- Recursive StyleEngine playback corpus: 642 files loaded and all 642 produced note-ons and bank/program/controller setup events; aggregate 11,882 note-ons and 97,520 setup events.

## Remaining Genos2 gap

Yamaha documents RTR 1 and 2 as continuous pitch movement without a new attack. The same-tick revoice fallback introduces a new attack and therefore is not behaviorally identical. A true implementation needs a per-note expression-capable output/rendering path or safe independent channel allocation for every simultaneously sustained note, followed by event/audio A/B comparison against a physical Genos2. Until then, describe this as held-note chord-following compatibility, not 1:1 Genos2.

## Scope boundaries

This change is limited to the Yamaha arranger/CASM path and tests/documentation. LCD/window geometry and LS-GM/Native SCVA subsystems were not changed.
