# Left Mixer – Reference Fader Skin (2026-11-05)

## Visual reference
The supplied public GitHub PNG (`Cuplikan layar 2026-11-05 200857.png`) was inspected directly from the repository. It shows narrow vertical fader wells, dark recessed channels, amber/yellow scale marks along both sides, and silver-white rectangular fader caps.

## Applied to Ensembles
- Applied the visual treatment to the six existing left-panel function faders: STYLE, SONG, AUDIO, PADS, DRUM/PERC, and CHORD.
- Added a `ReferenceMixerSlider` painter layer for 17 pairs of amber scale ticks per fader.
- Added recessed charcoal fader tracks and silver/white rectangular caps through Qt stylesheets.
- Added a dark, individually beveled backing strip for each fader cell.
- Kept the six fader roles, value range, initial value, control signals, MIDI/audio handling, labels, and existing assignment behavior unchanged.
- The reference PNG is not bundled and is not loaded as a runtime UI asset. The application draws the details using Qt/QPainter and Qt stylesheets.

## Validation
Source-level tests verify the new paint/style declarations and unchanged fader mapping. This environment does not have Qt6Widgets development files available via `pkg-config`, so no native Qt build or runtime screenshot was produced here. Exact on-screen rendering should still be checked in the Windows build.
