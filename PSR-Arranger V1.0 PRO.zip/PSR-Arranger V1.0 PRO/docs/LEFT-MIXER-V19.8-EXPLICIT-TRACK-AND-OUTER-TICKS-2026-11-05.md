# Left Mixer V19.8 — Explicit Groove + Outer Scale Ticks

## Purpose
Correct the repeated defect where amber scale marks visually overlap the recessed dark track.

## Root correction
The V19.5–V19.7 implementation delegated groove painting to Qt/QSS while deriving tick x-coordinates from either assumed or style-reported groove geometry. The reported groove sub-control rectangle is not guaranteed to describe the final painted border box in the same way as the visible QSS box (content width, border, margins). The ticks could therefore remain inside the visible dark edge.

V19.8 removes that ambiguity:
- The QSS groove retains the same layout geometry (14 px content width, 1 px border, 9 px side margins) but is made fully transparent.
- The recessed 16 px outer track is painted explicitly in `ReferenceMixerSlider::paintEvent`.
- The amber ticks are painted in widget coordinates relative to that exact `trackRect`, not Qt's style sub-control rectangle.
- For the fixed 34 px slider, track pixels are x=9..24. Major left ticks are x=0..7; major right ticks are x=26..33. Pixels x=8 and x=25 stay clear, giving one full pixel of separation on both sides.
- The silver handle remains Qt/QSS-painted after the custom track and tick marks; QSlider range, value model, signals, keyboard/wheel behavior, and MIDI/controller routing are unchanged.

## Preserved from V19.4 appearance
- 21 px fader handle width and 13 px height.
- Existing silver gradient, borders, groove gradient and side bevel appearance.
- 34 px slider widget width, panel cell spacing, slider order and labels.
- Range 0–127, startup value 100, and existing signals/routing.

## Verification
- Added `tests/panel_v27_explicit_track_tick_gutters_test.py` for geometry and regression checks.
- Source-level checks do not replace a native Windows Qt runtime screenshot. The included PNG is a design preview of the corrected mixer geometry, not a screenshot captured from the compiled application.
