Ensembles 6.8.7 — Native SCVA integration attempt

What changed
------------
- Added a NativeTS-backed C++ audio engine path in src/native_scva_engine.*.
- Added data/native_scva.qrc so plugins/SCVA/SCCore.dll is embedded into the Qt executable as a resource.
- Startup tries the native C++ engine before the existing SCVA VST2 host.
- The native path passes SCCore.dll to NativeTS as an in-memory data image. It does not call LoadLibrary on SCCore.dll or SOUND Canvas VA.dll.
- If the supplied SCCore build is unsupported, the native loader rejects it instead of applying a mismatched offset map. The existing SCVA VST2 host then remains available so the app can still play SCVA itself.

Important current compatibility result
--------------------------------------
The uploaded SCCore.dll is 27,358,208 bytes with SHA-256:
0635cc2bfced7876694f362f29719bae58e4539d576af9321673f6ffc31f6735
Its PE timestamp is 1506560051 (2017-09-28 00:54:11 UTC).

The current NativeTS public build registry/embedded mapping does not recognize this SCCore build; its documented reference build is SCVA 1.1.6 with a different size/hash/timestamp. The native path therefore fails closed for the user's supplied SCVA 1.1.2. Forcing RomVerification::none would explicitly use the wrong build's offsets and is not enabled in this project, because that can read wave ROM/table data from the wrong locations and generate invalid audio.

This means this source now contains the native C++ integration path and embedded SCCore payload, but native playback from the exact uploaded SCCore.dll is NOT yet verified or active. The next technical dependency is a correct NativeTS BuildProfile/TableManifest for this 2017 SCCore build (or a supported SCCore build). Do not describe the present output as a completed, tested native SCVA runtime.

Build notes
-----------
- CMake requires 3.24+ and a C++20 toolchain.
- First configure fetches NativeTS from https://github.com/TabulaSonora/NativeTS.git; network access is needed unless the dependency is already cached.
- The in-container environment could not download dependencies or build the Windows/Qt application, so a Windows compile/audio test has not been completed.
- SCCore.dll remains packaged as data for the native path; the original VST2 files remain alongside it for the same SCVA instrument's non-native runtime route.
