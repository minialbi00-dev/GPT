# Yamaha CASM Phrase-Voicing Improvement — Stage 1

Date: 2026-11-16
Baseline: `PSR-Arranger_V20_LeftMixerPanel_Reference_Alignment.zip`
Status: **implemented and locally tested; not Genos 1:1 certified**

## Scope of this stage

This stage targets one identifiable source of unnatural chord accompaniment: chord-oriented CASM parts were transformed one MIDI note at a time. Independent nearest-tone choices can collapse multiple voices onto one pitch or invert voice order. The runtime now attempts a phrase-aware fit for simultaneous notes belonging to the same Style section, track, and source MIDI channel when the selected CASM slot is:

- NTR Guitar with Guitar NTT selector 0, 1, or 2; or
- NTR Root Fixed with NTT Melody or Chord.

The engine gathers the simultaneous source notes at the event tick and submits them as one voicing. The fitter:

1. selects the applicable Ctb2 slot and declines the phrase path if voices cross different range/policy slots;
2. constrains target pitches to the active Genos chord-control pitch vocabulary;
3. observes the slot's Note Low/High bounds;
4. uses the CASM Source Chord Type as a soft source-degree identity cost, instead of discarding that metadata during voicing selection;
5. solves a monotonic, minimum-movement voicing with a spacing-preservation penalty;
6. when Guitar NTT Bass is enabled and a slash bass is known, maps only the bottom guitar voice to that bass pitch class.

Output note order is preserved relative to the incoming events. Existing Note-On/Note-Off remapping continues to pair the transformed pitch and channel.

## Additional source-integrity fixes

- The new test diagnostics in `tests/yamaha_style_runtime_test.cpp` had three unterminated string literals in the prior baseline ZIP. They are corrected so the C++17 runtime test target compiles.
- The candidate matrix used by the phrase fitter is explicitly initialized before its allowed-pitch entries are populated.
- NTT selector interpretation is now format-aware: legacy Ctab NTT 3 retains its Bass meaning, while SFF2 Ctb2 NTT 3..10 map to Melodic Minor, Melodic Minor 5th, Harmonic Minor, Harmonic Minor 5th, Natural Minor, Natural Minor 5th, Dorian and Dorian 5th. The paired 5th variants use the same scale mapping, consistent with the open YamJJazz reference implementation. Ctb2 Bass On is read only from its explicit per-range/channel flag and is no longer inferred from NTT value 3.

## Verification performed

Commands executed from the project root:

```sh
g++ -std=c++17 -Wall -Wextra -Wpedantic -Isrc \
  src/midi_file.cpp src/roland_stl.cpp src/yamaha_style_runtime.cpp \
  src/yamaha_arranger_engine.cpp src/style_engine.cpp src/chord_finder.cpp \
  tests/yamaha_style_runtime_test.cpp -o /tmp/yamaha_style_runtime_test
/tmp/yamaha_style_runtime_test
```

Result: PASS.

```sh
g++ -std=c++17 -Wall -Wextra -Wpedantic -Isrc \
  src/yamaha_style_runtime.cpp tests/yamaha_casm_corpus_test.cpp \
  -o /tmp/yamaha_casm_corpus_test
/tmp/yamaha_casm_corpus_test "data/StyleFiles/Yamaha PSR-S"
```

Result: `files=642 loaded=642 failed=0 Ctb2 rules=92234 malformed=0`.

```sh
g++ -std=c++17 -Wall -Wextra -Wpedantic -Isrc \
  src/midi_file.cpp src/roland_stl.cpp src/yamaha_style_runtime.cpp \
  src/yamaha_arranger_engine.cpp src/style_engine.cpp src/chord_finder.cpp \
  tests/yamaha_sty_playback_corpus_test.cpp -o /tmp/yamaha_sty_playback_corpus_test
/tmp/yamaha_sty_playback_corpus_test "data/StyleFiles"
```

Result: PASS — 642 styles, 0 failures, 12,621 Note-On events, 97,897 setup events.

The runtime test also includes voicing assertions for common Genos chord-control IDs (major, minor, dominant seventh, 7sus4, 7b9, sus4, sus2), strictly ascending output, and the Guitar NTT Bass bottom-voice slash-bass rule. It separately verifies all eight SFF2 Ctb2 NTT 3..10 selectors and checks that the legacy Ctab NTT 3 Bass behavior remains intact.

## Known limitations — do not describe as 1:1

This is a first phrase-aware improvement, not a complete reverse-engineering of the Genos accompaniment engine.

- Guitar All Purpose, Stroke, and Arpeggio currently share the same phrase-level fitting strategy. Their distinct proprietary guitar fingering, stroke direction, articulation, and note-selection tables are not implemented.
- The source-degree penalty is a soft pitch-class-rank heuristic, not Yamaha's complete source-degree mapping tables.
- Root Fixed and Guitar phrase fit is only activated for simultaneous same-tick notes in the same section/track/source channel. Phrases split across MIDI tracks or asynchronous arpeggio patterns do not yet receive a unified phrase context.
- NTT Melody/Chord and minor/Dorian variants now have format-aware routing and degree-preserving scale mapping, but are not yet a complete per-source-note Yamaha table implementation for every chord ID and source pattern.
- RTR Pitch Shift and Pitch Shift to Root still use the existing event-level revoice fallback for held notes; this is not the continuous, no-new-attack pitch bend behavior documented by Yamaha.
- No physical Genos MIDI OUT capture or controlled Genos audio recording was supplied for A/B comparison. Identical sound also depends on the target instrument's Voice samples, DSP/effects and mixing.

The Yamaha reference manual distinguishes Guitar NTR's All Purpose/Stroke/Arpeggio tables, says Guitar NTT Bass affects only the lowest guitar voice, and describes Pitch Shift RTR modes without a new attack. The YamJJazz open-source parser independently enumerates Ctb2 NTT values 0..10 as Bypass, Melody, Chord, Melodic Minor/5th, Harmonic Minor/5th, Natural Minor/5th and Dorian/5th. These distinctions remain explicit acceptance criteria for later stages.

## Next fidelity stages

1. Capture a controlled Genos MIDI OUT reference for the same Style, section, source chord, destination chord, inversion, slash bass, and chord-change timing.
2. Implement and test separate Guitar NTT mode behavior from a verified reference corpus instead of aliasing all three to one fitter.
3. Replace soft source-degree ranks with explicit source/destination chord-degree mapping and Yamaha-style voicing selection for melody/chord/bass parts.
4. Implement true sustained-note pitch bend semantics for RTR 1/2, with channel allocation and bend-range handling validated against hardware capture.
5. Re-run event-level and audio A/B tests on the same Genos hardware and Sound/Style settings.
