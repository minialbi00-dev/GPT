# Ensembles 6.8.7 — Yamaha PSR-S Arranger Indicator Patch

## Reference behavior used

The baseline is the official Yamaha PSR-S950/S750 Owner's Manual (Indonesian edition), page 46:

- Red: the section currently selected.
- Red flashing: the section queued to play after the current section.
- Main Variation A–D also flash during Fill In playback.
- Green: the section contains data but is not selected.
- Off: the section has no data and cannot be played.

The same manual describes the transport functions separately:

- START/STOP starts and stops Style playback.
- SYNC START arms Style playback; the next chord starts it. Pressing it during playback stops the Style and returns it to standby.
- SYNC STOP is a chord-hold function and is effective only with ACMP enabled.

The PSR-S950/S750 manual defines the transport functions but does not give a separate text table for their LED cadence. Yamaha's PSR-style operating guidance shows the START/STOP beat indicator pulsing in time while Style playback runs, and pulsing while Sync Start is armed; SYNC START itself indicates standby. Ensembles therefore keeps SYNC START steadily lit while armed and tempo-pulses START/STOP during playback or Sync Start standby. SYNC STOP is shown steadily lit while Ensembles has a stop request pending. This avoids falsely assigning the section-button pending blink pattern to every transport lamp.

PSR-SX900/SX700 manuals use a different section-lamp palette (orange/blue rather than PSR-S950/S750 red/green). This patch uses the PSR-S950/S750 palette because that is the directly verified red/green PSR-S reference. The state semantics are kept separate from the palette.

## Changes

1. Replaced the old always-red section LED with four real states: Off, Available, Active, Pending.
2. Intro/Main Variation/Ending LEDs now use the loaded Style's actual available-section map. Active section is steady red; a queued destination is red blinking; unselected sections with data are green; absent sections are off.
3. Main Variation destination flashes while a fill is playing.
4. Yamaha Fill In XY maps to destination Y (the second letter): Fill AB flashes Main B; Fill BA flashes Main A.
5. BREAK LED reflects whether a break exists, is pending, or is currently playing.
6. SYNC START LED is steadily lit while armed. A second SYNC START press cancels standby. Pressing SYNC START during playback stops the arranger and arms standby.
7. SYNC STOP LED is steadily lit while the engine has a stop pending. START/STOP LED pulses at the current Style beat rate while playback is active or Sync Start is armed.
8. Indicator refresh is driven by engine state and a tempo-derived phase timer, not only by the button-click callback.
9. The four Intro/Ending panel caps remain compatible with the legacy STL aliases while reflecting the actual selected source Intro/Ending.

## Scope and limitation

This patch changes arranger indicator state presentation and the Sync Start standby toggle. It does not rewrite the current Sync Stop audio/arranger behavior: the existing Ensembles engine still schedules Sync Stop at its existing section boundary. Yamaha's documented chord-hold Sync Stop behavior is a separate engine feature and should not be represented as already implemented by this indicator patch.

The full Qt application was not built here because Qt6Widgets development files are unavailable in this Linux environment. The core style engine and parser/runtime regression executables were compiled directly and passed; the Qt UI source was covered by source-level tests but not a Windows/MSVC GUI build or live panel test.

## Validation

Passed:

- `style-engine-test` — including Sync Start standby toggle and Sync Stop pending-state regression.
- `yamaha-style-runtime-test` — including new Fill AB → Main B and Fill BA → Main A indicator mapping checks.
- `roland-stl-reader-test`.
- `panel_v20_arranger_hardware_buttons_test.py`.
- `panel_v21_hardware_button_smoothing_alignment_test.py`.
- `panel_v23_yamaha_psr_s_indicator_test.py` (new).

The wider legacy Python source-check collection also contains unrelated baseline failures in audio output, right-panel geometry, R3 support audit, registry memory, RtAudio settings, output deadline, voice picker, and VST2 routing checks. Those checks target other code paths and were not changed in this indicator patch.

## Reference

Yamaha PSR-S950/S750 Owner's Manual (Indonesian), "Tentang status lampu tombol-tombol bagian (INTRO/MAIN VARIATION/BREAK/ENDING)" and "Mengoperasikan Playback Gaya":
https://jp.yamaha.com/files/download/other_assets/3/332763/psrs950_id_om_a0.pdf

Yamaha PSR-SX900/SX700 Owner's Manual (section lamp palette distinction):
https://europe.yamaha.com/en/download/files/2090818/

Yamaha PSR-S operating guidance for the tempo/Sync Start beat indicator:
https://psrtutorial.com.psrstyles.com/lessons/start/s45_stylecontrol.html

## MSVC build correction — 2026-11-05

The first Windows/MSVC build exposed two same-scope redeclarations in `EnsemblesWindow::buildUi()`:

- The Settings-page helper and the arranger-panel helper both used the local name `addSection`, although they have different signatures and are declared in the same function scope.
- The Settings Tempo group and the compact panel Tempo widget both used the local name `tempoGroup`.

The follow-up patch fixes the naming collisions without changing the widgets' behavior:

- The Settings helper is now `addSettingsSection`; the arranger helper retains `addSection` so existing panel source contracts remain compatible.
- The compact panel Tempo widget is now `panelTempoGroup`; the Settings group retains `tempoGroup`.
- `panel_v23_yamaha_psr_s_indicator_test.py` now guards against these UI helper/tempo redeclarations.

Validation after the correction:

- Yamaha PSR-S indicator source tests: 6/6 passed.
- Arranger hardware button tests: 5/5 passed.
- Hardware-button smoothing/alignment tests: 4/4 passed.
- Registry/memory hardware-button tests: 6/6 passed.
- StyleEngine runtime regression script passed, including arranger transitions, sync start/stop and live-style replacement.
- Native style renderer routing source tests: 7/7 passed.
- Roland STL UI source tests: 23/23 passed.

The full Qt/MSVC executable has not been built in this environment. Re-run `V19.0-Apply-Build-Run.bat` on the Windows Qt 6.11.2/MSVC x64 setup to confirm the compiler proceeds beyond the reported redeclarations. This patch does not claim a completed Windows build.
