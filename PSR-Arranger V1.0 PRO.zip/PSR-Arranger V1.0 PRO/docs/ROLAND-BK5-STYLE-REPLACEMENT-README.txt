ENSEMBLES 6.8.7 - ROLAND BK-5 STYLE FILES
========================================

TUJUAN
------
Mengganti isi folder:
  data\StyleFiles

Dengan koleksi Roland BK-5 .STL pada repositori:
  https://github.com/minialbi00-dev/YW/blob/main/STYLE%20ROLLAND%20BK-5.zip

LANGKAH
-------
1. Ekstrak overlay kompatibilitas Roland V18.3 Timing Fix ini ke root proyek
   ensembles-cpp (folder yang berisi CMakeLists.txt dan src\).
2. Jalankan Install-Roland-BK5-Styles.bat.
3. Skrip mengunduh ZIP dari URL di atas, memeriksa isinya, menyiapkan semua
   file .STL, lalu mencadangkan isi data\StyleFiles lama ke folder saudara
   bernama data\StyleFiles_Backup_YYYYMMDD-HHMMSS.
4. Setelah staging berhasil, isi data\StyleFiles diganti dengan file .STL.
   Jika ada nama duplikat di arsip, skrip memberi akhiran _2, _3, dan seterusnya.
5. Bangun ulang proyek menggunakan perintah CMake pada README.md di root source.

KEAMANAN DATA
-------------
Skrip tidak menghapus isi style lama secara permanen; seluruh isi folder lama
perlu tetap dipertahankan sebagai cadangan. Jika unduhan atau validasi gagal,
folder StyleFiles lama tidak disentuh.

CATATAN
-------
Build dan pemutaran seluruh style harus diuji setelah penggantian. Menyalin
file .STL saja tidak membuktikan kompatibilitas semua style dengan arranger.
