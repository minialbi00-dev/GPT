# Yamaha Genos2 CASM / Ctb2 — Corpus Revalidation

Date: 2026-11-06  
Project: Ensembles 6.8.7 V20  
Status: **parser corpus validated; Genos2 behavioral equivalence remains partial**

## Corrected corpus baseline

The active `data/StyleFiles/Yamaha PSR-S` directory contains 642 files:

| Extension | Files |
|---|---:|
| `.prs` | 582 |
| `.sst` | 47 |
| `.scp` | 10 |
| `.fps` | 3 |

The Yamaha runtime successfully loaded all 642 files. Raw FourCC scanning found 26,384 `Ctb2` chunks, all with a 47-byte payload:

| Extension | Raw Ctb2 chunks |
|---|---:|
| `.prs` | 23,042 |
| `.sst` | 2,917 |
| `.scp` | 214 |
| `.fps` | 211 |
| **Total** | **26,384** |

After the runtime expands each CSEG table over the sections listed in its Sdec field, the loaded map contains 92,234 Ctb2 section/channel rules. This is why raw Ctb2 tag count and runtime rule count differ. All 92,234 decoded rules currently have a 47-byte raw payload, three six-byte transform slots, and a retained seven-byte tail.

The earlier 2026-11-05 audit's statement that this PSR-S corpus had zero Ctb2 records was based on a different, 92-file `.sty` subset. It does not describe the current 642-file PSR-S corpus and must not be used as its baseline.

## Representative real record

`data/StyleFiles/Yamaha PSR-S/Pop&Rock/Unplugged.T160.prs` contains a 47-byte Ctb2 record for `SteelGtr`:

- Source channel: 2
- Destination channel: 11
- Bytes 20–21: `0x30, 0x5F` (48 and 95)
- Three six-byte transform blocks begin at offsets 22, 28 and 34
- Bytes 40–46 are retained verbatim

The record is consistent with the current interpretation of bytes 20–21 as Middle-range boundaries and the three transform blocks as Low/Middle/High settings. The interpretation is supported by the real payload and broad corpus distributions, but is not yet independently confirmed by a Yamaha-published binary-layout specification.

## Observed field distributions

Across 92,234 section/channel Ctb2 rules (276,702 transform slots):

- NTR values observed: 0, 1, 2.
- NTT values observed: 0 through 10, with highly uneven use.
- RTR values observed: 0 through 4.
- 45,423 slots have the per-slot Bass On bit set; 231,279 do not.
- RTR Pitch Shift (1) and Pitch Shift to Root (2) are common, not edge cases.

These observations matter for prioritization: RTR 1/2 affect most melodic slots in this corpus. The runtime now recalculates their target pitch when a chord changes and emits a same-tick Note-Off/Note-On revoice for that held voice. This prevents sustained accompaniment from remaining stuck on the previous chord. It is an explicit MIDI 1.0 compatibility fallback, **not** Genos2's continuous no-new-attack pitch bend. Do not replace it with channel-wide MIDI pitch bend: that would detune unrelated simultaneous notes sharing the destination channel.

## Current verification

- `tests/yamaha_casm_corpus_test.cpp`: all 642 files load; all 92,234 expanded Ctb2 rules decode to 47 bytes, three slots, and seven preserved tail bytes.
- `tests/yamaha_style_runtime_test.cpp`: direct C++17 build and runtime tests pass, including Ctb2 slot boundaries, per-slot Bass On, mute masks, Cancel, Root Fixed/Root Trans examples, selected NTT behavior, RTR 0–4 held-note updates, repeated chord changes, final Note-Off pairing, and the public `StyleEngine::changeChord()` → MIDI sink route.
- `tests/yamaha_sty_playback_corpus_test.cpp`: recursively exercises all 642 PSR-S files through `StyleEngine`; 642/642 load and produce note-on plus bank/program/controller setup events.
- `tests/run_style_engine_test.sh`: passes when the legacy `.enstl` fixture directory is made available from `legacy-reference/data/Styles/StyleFiles`; the source package's test's expected `data/Styles/StyleFiles` path is otherwise absent.
- Yamaha style picker, native renderer routing, style MIDI queue, and LCD viewport geometry source tests pass.

## Remaining gaps before any 1:1 claim

1. **Ctb2 field-map certification:** the 47-byte shape and offsets are consistent across the real corpus, but the meaning of all fields—especially bytes 20–21 and the seven-byte tail—needs an independent Yamaha reference or byte-for-byte device-generated fixture. Keep raw payload preservation.
2. **RTR 1/2:** the current same-tick revoice fallback updates held pitches and preserves Note-Off pairing. True Genos2 behavior still requires per-note continuous pitch evolution without a new attack or disturbance to other notes on a shared MIDI channel. Standard channel-wide pitch bend is not a correct substitute.
3. **NTT completeness:** current Melody/Chord and minor-family behavior remains an approximation for several chord families. The full Yamaha conversion tables, especially Guitar-specific tables, are not available in the public manual.
4. **NTR Guitar:** current note-by-note mapping cannot reconstruct Yamaha guitar voicing/fingering context or the All Purpose / Stroke / Arpeggio tables.
5. **Slash-bass Guitar:** Yamaha specifies that only the bottom note inside Guitar voicings follows slash-bass; the current event model does not identify that note from a complete voicing.
6. **Real Genos2 A/B:** exact MIDI event and audio comparison is still required for each NTR/NTT/RTR combination, chord ID, slash chord, Note Limit, and section transition.
7. **Windows Qt build and playback:** the current environment cannot certify the target Windows/MSVC/Qt runtime.

Passing parser tests and successfully loading the complete style corpus establish parser robustness for this corpus. They do not establish 1:1 Genos2 sound or protocol equivalence.
