# Yamaha PSR-S Style List — reference layout iteration (6.8.7 V20)

This iteration replaces the generic one-column Style picker presentation with the visual composition in the supplied `STYLE LIST.png` reference. The reference image is used for visual proportions only; it does not define or change the application's LCD dimensions, resolution, window geometry, or surrounding panel geometry.

The Style page fills the existing `lcdContentStack_` viewport. Header, row, category-button, and footer dimensions respond to that viewport so the composition is retained at the LCD's existing size:

- Orange command header with Style title, Preset/User/Favorites, Search, File, Menu and Close controls (56 px at the reference's native scale, proportionally adapted to the existing LCD viewport).
- Left category column at approximately 25.5% of the page width, with the reference's nine two-column category tiles.
- Right Style browser at approximately 74.5% of the page width, arranged as two columns with five rows per page. In `Pop&Rock`, Pop styles fill the left column and Rock styles fill the right column, matching the sample rather than simply continuing one sorted list across both columns.
- Dark row surfaces, black type/category badge, right-aligned tempo, highlighted selected row, P1–P5 page strip, navigation arrows and bottom path/status strip.

The Preset browser reads `data/StyleFiles/Yamaha PSR-S` recursively, including category subfolders. Windows paths are normalized before deriving category names. Current category mapping:

- `Ballad` is included under `Pop&Rock`.
- `Country` is included under `World`.
- `Latin&Ballroom` is separated into `Latin` and `Ballroom` using style-name tokens.
- Other Yamaha folders map directly to the matching reference category.

The `Pop&Rock` paginator advances five entries within each badge column at a time; other categories advance in ten-entry pages. The application retains the existing `styleCombo_` selection and `loadSelectedStyle()` pipeline as the authoritative style-loading route. Tempo encoded in `.Txxx` filenames is read without eagerly parsing every style file at startup; Yamaha runtime tempo parsing is used only when a filename does not provide tempo. User-loaded files remain available under User mode.

The supplied package contains 642 Yamaha PSR-S style files across the ten source folders. Static source/regression checks verify the layout contract and selection route. The reference bitmap itself is 800×480 pixels; that bitmap size is not an instruction to change the application's LCD. Pixel-level visual verification must be made from a screenshot at the application's existing LCD size, with no resizing of the LCD or main window.


## Geometry preservation

- No `resize()`, `setFixedSize()`, or resolution change is applied to the main window, LCD stack, center panel, or surrounding hardware panels by the Style List implementation.
- The main window's existing `resize(1344, 708)` and `setMinimumSize(1040, 680)` values are inherited unchanged from the supplied `Ensembles_V20_LCD_update.zip` base.
- Only child controls within the Style page are scaled to the available `lcdContentStack_` viewport.


## Left/right edge precision correction

The left and right rails are now explicit and symmetric within the existing viewport. At an 800 px viewport width, the category rail is exactly 204 px (25.5%) and the Style list receives the remaining 596 px. The category grid uses equal 6 px outer insets; the list content uses equal 6 px left/right insets, leaving 584 px for two equal 292 px columns. The page footer uses the same 6 px left/right rails as the list rows.

The previous `- 6` width adjustment was removed because it left an unused strip only on the right edge. Column width now uses half the actual list viewport, so both columns reach the same right and left inset rails. The five-row height similarly divides the actual list viewport into five rows without the previous hard-coded 4 px remainder.
