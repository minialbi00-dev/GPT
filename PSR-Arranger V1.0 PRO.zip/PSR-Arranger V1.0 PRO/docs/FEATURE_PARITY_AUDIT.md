# Ensembles original-to-Windows port feature audit

Date: 2026-10-23. This audit records source-level implementation coverage and is intentionally conservative. “Partial” means some associated UI/state or a related path exists, but behavior is not equivalent to the original. It does not claim successful runtime tests where none were run.

| Original subsystem / feature | Current Qt/C++ port status | Gap before 1:1 |
|---|---|---|
| Original `.enstl` style marker analysis and marker-to-tick mapping | **Ported core + tested** | Complete application lifecycle, import/analysis UI and exact cross-component signals still need integration. |
| Original arranger sections: intro, variations, fills, ending, break, sync start/stop | **Core state transitions ported + tested** | Rewire all original `ArrangerCore` / `CentralBus` side effects, UI event ordering, record/playback hooks and measure state. |
| Original chord finder and style transposition rules | **Ported, with bounds-safety repair** | Compare edge cases and integration against original runtime; source undefined out-of-range cases are normalized rather than reproduced. |
| Built-in/user style discovery | **Partial** | Ten original `.enstl` files and user `Documents/ensembles/styles` scanning work in the port; full original preferences and style lifecycle are not complete. |
| Internal SoundFont synthesis | **Partial** | FluidSynth + SF2 loader works in source/runtime smoke test on authoring Linux, but original `EnsemblesGM.sf2` is unavailable as a full binary here; bundled TimGM6mb is only a fallback, not the original sound bank. |
| RtAudio stereo output | **Implemented in source; Windows runtime unverified** | Compile and test host API/device selection, switching, sample rates, buffer changes and continuous playback on real Windows hardware. |
| RtAudio output configuration | **Iteration 6 source implementation** | API/device/rate/buffer selectors, refresh, status and test tone are added; no supported claim of Windows GUI compile or successful hardware enumeration yet. |
| Master gain, FluidSynth Reverb/Chorus | **Partial** | Basic FluidSynth parameters and controls are wired; compare effect algorithms, presets, routing and audible results with original. |
| Original voice catalog (>200 voices in upstream description) and registration of voice state | **Partial** | Ten persistent registration slots now memorize/recall the currently ported voice/style/tempo/transpose/octave/accompaniment/layer/split/FX/volume state. Current UI still exposes mainly 128 GM programs; custom banks, exact SoundFont voice list, all original state and original slot/bank semantics remain incomplete. |
| R1/R2/L voices, Layer and Split | **Partial** | Current core routing uses internal channels 17/18/19 and basic layer/split; exact original voice lifecycle, keyboard semantics, bank/program handling and UI are incomplete. |
| R3 as a separate right-hand voice slot | **Not implemented end-to-end** | FluidSynth accepts channels 0–63, but the Qt port only exposes/maps R1, L and R2 (channels 17/19/18). Channel 23 has no R3 program-selection, keyboard-note, settings, or registration-memory route; the legacy `synthesizer_voice_program_r3` declaration is unused. See `docs/R3_AUDIO_SUPPORT_AUDIT_6_5.md`. |
| Assignable 4 knobs / 10 sliders | **Partial** | CC mapping and persistence are wired; verify original default mappings, MIDI/synth routing, controller semantics and master knob behavior end-to-end. |
| Joystick assignment/control | **Not ported** | Current labels are not a functional joystick surface; implement axis input, target mapping, persistence, pickup/scaling and MIDI/parameter routing. |
| 12 sampling pads | **Not ported as sample playback** | Current pads issue percussion MIDI notes. Original pads play user-selected audio samples with volume/stop behavior; arbitrary audio file loading and player lifecycle are required. |
| Sample recorder | **Not ported** | Original source includes sample recording from microphone/system/mixed sources; current Qt UI does not duplicate that workflow. |
| 10-track recorder/sequencer | **Not ported** | Current recorder is principally MIDI-file open/playback, not the original multi-track record/edit/project workflow or style-control capture. |
| MIDI file playback | **Partial** | SMF parser/writer and basic playback exist; full original arrangement integration, editing, recording, tempo/timing edge cases and project lifecycle remain. |
| Physical MIDI input/controllers | **Partial (iteration 6.7)** | WinMM device enumeration/selection, input open/start/stop/close, queued note-on/note-off handling, zero-velocity note-off normalization, original channel-to-layer mapping, Split By Channel preference, transpose/octave and internal-only routing are now present. Remaining: original note-learn/control-map persistence and assignment UI, CC-to-style/registry/mixer/slider actions, input event interception, raw-MIDI mode, automated device hot-plug, exact PortMidi timing, and Windows hardware/runtime verification. |
| Windows MIDI output | **Partial** | WinMM MIDI Mapper output and selectable routing exist; device behavior and exact original mapping still need hardware test. |
| Arpeggiator | **Not ported** | Control is disabled until original algorithm and timing/voice routing are implemented. |
| Harmonizer | **Not ported** | Control is disabled until original algorithm and voice assignment are implemented. |
| Auto-accompaniment style catalog | **Partial** | Ten `.enstl` assets are included; this is not the full upstream style collection, and the original project describes portions as WIP. |
| LV2 instrument/effect plugins and racks | **Not ported** | Need a plugin host, plugin discovery/UI, audio/MIDI routing, state save/load, and compatibility testing. |
| Original Settings/preferences and exact theme/widgets | **Partial (iteration 6.2 visual pass)** | The home-panel Qt skin now has custom silver socket dials, squared slider caps, tighter LCD tab geometry, darker photo-overlay treatment and adjusted control sizes. This reduces the largest screenshot mismatches, but still needs a Windows screenshot overlay against the original at the same client size; exact GTK theme, icons, dynamic widgets and responsive layout are not yet pixel-identical. |
| Desktop integration / packaging | **Partial** | Windows build/deploy script exists; exact original elementary OS integration is platform-specific and not a 1:1 Windows feature. |

## Release gate

A feature is **not** “complete” merely because a control is visible or its source compiles. For each subsystem, compare the relevant original source and user-visible workflow, add behavior tests, build with Qt 6 + MSVC 2022 + vcpkg on Windows, and run `docs/WINDOWS_HARDWARE_TEST.md`. This audit is meant to prevent missing features from being mistaken for completed porting work.
