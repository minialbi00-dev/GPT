# Ensembles 6.8.7 — Yamaha destination Fill / Roland-style transition fix

Date: 2026-11-05

## Corrected transition rule

The previous Yamaha panel routing incorrectly selected `FILL XY` from the source and destination Main letters and sent a different-Main request through `queue_fill_next_bar()`. That meant MAIN A -> MAIN B selected FILL AB and could defer the Fill to the next bar. This was not the target-based Fill behavior requested for Ensembles.

The corrected behavior mirrors the already implemented Roland variation-transition policy:

- When Auto Fill is ON and a different destination Main is selected, choose the destination Main's own Fill section: MAIN A -> FILL AA -> MAIN A; MAIN B -> FILL BB -> MAIN B; MAIN C -> FILL CC -> MAIN C; MAIN D -> FILL DD -> MAIN D.
- The button press queues that Fill immediately through `CppArrangerEngine::queue_fill()`. The scheduler enters at the next beat boundary, preserving the current global beat/bar phase. If the request is during the last beat, the next beat boundary is the next bar downbeat.
- The Fill's destination mapping returns to the selected Main. A later Main selection while a Fill is already playing updates the post-Fill destination rather than stacking/restarting a second Fill.
- With Auto Fill OFF, a different Main still changes directly. Re-pressing the active Main remains a direct/self Fill command.

This is deliberately NOT the previous `FILL AB` source-to-target mapping for A -> B. In the requested example, pressing MAIN B while MAIN A is playing must audibly play `FILL BB`, then enter `MAIN B`.

## Source changes

- `src/style_engine.cpp`: transition selection now forms `FILL <target><target>` and uses the immediate next-beat Fill scheduler.
- `tests/yamaha_style_runtime_test.cpp`: synthetic style now includes distinct `FILL BB` and `FILL AA` patterns; transition MIDI regression checks that A -> B emits the unique BB note, and the indicator regression checks the target Main lamp.
- `tests/genos2_button_press_source_test.py`: source guard now enforces destination-based Fill selection.
- `tests/style_stop_midi_queue_source_test.py`: source guard enforces immediate Fill scheduling for destination changes.

## Verification performed

PASS: `yamaha-style-runtime-test` compiled directly with GCC C++17 and ran successfully.
PASS: `tests/run_style_engine_test.sh`.
PASS: `tests/style_stop_midi_queue_source_test.py` (17/17).
PASS: `tests/genos2_button_press_source_test.py` (11/11).
PASS: `tests/panel_v23_yamaha_psr_s_indicator_test.py` (6/6).
PASS: `tests/roland_stl_ui_source_test.py` (23/23).
PASS: `tests/yamaha_style_picker_source_test.py`.
PASS: `tests/native_style_renderer_routing_source_test.py` (7/7).

## Verification limits

The full Qt GUI target was not built here because Qt6 development files are unavailable in this Linux environment. No Windows/MSVC build, live MIDI controller test, or physical Genos 2 audio comparison was performed. The C++ arranger runtime test verifies that A -> B selects and emits the unique FILL BB pattern; it does not establish acoustic 1:1 equivalence to physical Genos 2 hardware.

## Build

On Windows, extract the project and run `V19.0-Apply-Build-Run.bat`.
