Ensembles Native SCVA Validation Suite
======================================

Tujuan
------
Tes tanpa perangkat keras untuk resource SCVA yang tertanam, profil NativeTS,
coverage/readback table dan wave ROM, audio non-senyap, routing MIDI/controller,
FX, dan kebijakan startup native-only. Tes ini bukan pengganti validasi audio di
mesin Windows dan tidak membuktikan build/runtime lulus hanya dari static test.

Build/run (Windows, dari root proyek)
------------------------------------
Prasyarat: Qt 6 Desktop MSVC x64, Visual Studio C++ x64, CMake, vcpkg, dan
koneksi jaringan pada konfigurasi pertama kecuali source NativeTS tersedia lokal.
Set `QT_ROOT_DIR` ke kit Qt dan `VCPKG_ROOT` ke checkout vcpkg, lalu jalankan
perintah PowerShell berikut (konfigurasi/build utama dijelaskan juga di README.md):

  cmake -S . -B build -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$env:QT_ROOT_DIR" -DCMAKE_TOOLCHAIN_FILE="$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" -DVCPKG_TARGET_TRIPLET=x64-windows -DVCPKG_MANIFEST_MODE=ON -DVCPKG_INSTALLED_DIR="$PWD/build/vcpkg_installed" -DBUILD_TESTING=ON
  cmake --build build --parallel
  ctest --test-dir build -R "scva-native-" --output-on-failure

Laporan dan WAV dibuat di bawah `build/tests/` saat test renderer berjalan.
Lihat keluaran CTest dan pastikan test `scva-native-profile-midi-audio-effects`
berstatus PASS serta delta audio EFX tidak nol. Jangan anggap pemeriksaan source
atau ROM statis sebagai bukti bahwa EFX benar-benar terdengar.

Mode native-only
----------------
Jalankan aplikasi dengan `--scva-native-required`, atau atur
`ENSEMBLES_SCVA_NATIVE_REQUIRED=1`. Dalam mode ini kegagalan inisialisasi native
tidak boleh diam-diam beralih ke VST2 atau FluidSynth.

Cakupan tes
-----------
- Identitas/hash SCCore.dll, coverage/readback tabel, dan signature wave ROM.
- Audio piano non-senyap, program change, drum channel 10, port-4, CC7/CC10,
  pitch bend, modulation/sustain.
- Perbandingan output reverb, chorus, delay, dan insertion EFX.
- Renderer test terhubung langsung ke NativeTS tanpa link VST2/FluidSynth.

Batasan
-------
Jalankan CTest pada Windows/MSVC dan dengarkan WAV sebelum menyatakan validasi
Native SCVA/EFX selesai. Checklist hardware terpisah ada di WINDOWS_HARDWARE_TEST.md.
