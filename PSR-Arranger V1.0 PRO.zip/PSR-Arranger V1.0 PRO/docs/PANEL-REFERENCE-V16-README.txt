ENSEMBLES 6.8.7 — PANEL REFERENCE V16
====================================

Scope
-----
This revision changes only the left/right control panels in src/main_qt.cpp and
carries forward src/audio_engine.cpp from the previous audio-output work. The
central LCD, keyboard, 16-channel mixer below the LCD, transport and other UI
areas are not redesigned in this revision.

Left panel
----------
- Knob Assign and Master Knob Assign buttons.
- Four knobs default to Cutoff, Resonance, Reverb Send and Chorus Send.
- Master Vol remains the application output/master-volume control.
- Six function faders: STYLE, SONG, AUDIO, PADS, DRUM/PERC, CHORD.
- The former ACC label is now CHORD.
- AUDIO is a temporary output-layer fader until an audio-file player exists.
- SONG scales MIDI-file playback note-on velocity and CC7 values.
- PADS scales drum-pad note velocity.
- CHORD scales melodic accompaniment note-on velocity (not drum channel 10).

Right panel
-----------
- Large knob is a Data Entry / Scroll encoder, not a volume knob.
- Turning the encoder navigates the active Voice or Style list in the central LCD.
  The arrow button opens/closes the relevant picker; -/+ step through entries.
- Chords toggles style accompaniment, Layer toggles the existing layered-voice
  behavior, and Split toggles the existing split-key behavior.
- Four independent part-volume faders: L, R1, R2, R3; each sends MIDI CC7 and
  stores its current value in QSettings. R3 is an independent extra MIDI part;
  the present voice browser exposes named presets for L/R1/R2 only.
- Reverb and Chorus buttons toggle the existing effects. EFX Setup opens the
  existing native-EFX settings dialog.
- Transpose, Octave, Tempo and Arpeggiator use the existing application state
  and handlers; their +/- buttons adjust the current values.

Settings/migration
------------------
The control-map default version is incremented to 16. Existing known V14/V15
factory defaults are migrated to the reference layout. Explicit non-default
custom mappings remain intact, except that the first six faders are now fixed
function faders by design. Slider values use the existing QSettings keys.

Validation performed here
-------------------------
The Python source-level tests were run successfully (21 tests total). The build
could not be compiled or launched in this Linux execution environment because
Qt 6 Widgets and the Windows MSVC/vcpkg build toolchain are not installed here.
Use Rebuild-And-Run-Panel-Reference-V16.bat on a Windows machine with Qt 6 MSVC,
Visual Studio C++ tools and vcpkg to configure, compile and launch the GUI.
The batch file will stop on missing prerequisites and write a build log rather
than claiming a successful build.
