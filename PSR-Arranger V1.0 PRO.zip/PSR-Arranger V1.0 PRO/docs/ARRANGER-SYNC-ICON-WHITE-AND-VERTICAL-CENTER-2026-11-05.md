# Arranger Sync / Start-Stop icon correction

- Removed cyan edge strokes from the STOP block in Sync Stop and Start/Stop; both blocks now use the same solid white foreground as the other icon elements.
- Set the icon vertical reference to the exact button midpoint (`height() * 0.5`).
- Rebalanced Sync Stop and Sync Start glyph bounds around that midpoint so their complete painted symbols are vertically centered.
- Start/Stop symbol is centered on the same vertical midpoint.
- Button dimensions, captions, LED placement, and engine connections are unchanged.

Validation: `panel_v20_arranger_hardware_buttons_test.py` (7/7) and `panel_v21_hardware_button_smoothing_alignment_test.py` (4/4) pass. No Windows Qt/MSVC build or runtime screenshot was performed; confirm final rendering in Windows.
