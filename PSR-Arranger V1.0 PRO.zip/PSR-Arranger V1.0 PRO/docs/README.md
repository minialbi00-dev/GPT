# Ensembles C++ — Qt 6 / Windows port

> **Status:** migration work in progress. Iteration 5 adds a real **FluidSynth + SoundFont + RtAudio** internal audio path alongside Windows Multimedia MIDI output (WinMM). This remains a **partial migration**, not a complete 1:1 port of the entire application.

The Windows frontend uses **Qt 6 Widgets**, **FluidSynth** for instrument synthesis and built-in effects, **RtAudio** for stereo playback, and **WinMM** as a selectable external MIDI Mapper route. CMake uses the project `vcpkg.json` manifest to resolve FluidSynth and RtAudio for the `x64-windows` triplet. Qt and Visual Studio/MSVC must already be installed; vcpkg must be available.

## What was ported in this revision

- **Iteration 6.7 — physical MIDI input foundation:** WinMM input devices can be refreshed, selected, opened, and closed; queued callback delivery keeps WinMM driver-thread callbacks away from Qt/audio objects. MIDI note-on/note-off (including note-on velocity zero) now follows the original input layer routing and the “Split By Channel” setting. The original fallback accompaniment voicing and its style-loop/sync-start gates are used when no style is actively looping. External CC-to-control assignment, note-learn maps, raw MIDI mode, automatic hot-plug and full controller UI actions are still pending; this is not yet complete MIDI-input parity. See [`docs/MIDI_INPUT_PORTING_ITERATION_6_7.md`](docs/MIDI_INPUT_PORTING_ITERATION_6_7.md).

- Original `.enstl` style analysis contract: Config marker, tempo/chord mode, time signature, and the fixed 15-marker section map.
- Original `chord_finder.c/.h` scoring algorithm carried into C++; pitch-class lookups are normalized modulo 12 to fix out-of-bounds accesses present in the source snapshot, with tests for all twelve major/minor triads.
- The original style engine chord-transposition cases, CC82 alternate-channel switching/filter rules, channel note tracking, chord-change note resend, and the section state transitions represented by `style_player.c`.
- Ten original `.enstl` style examples included in `data/Styles/StyleFiles`; the Qt frontend also scans `Documents/ensembles/styles` for user styles using the original `genre@name.enstl` filename contract.
- The section controls follow the original selection semantics: Intro, Variation / Fill-in A–D, and Ending queue/select a part, while the separate play button starts/stops playback. Fill-in remains part of the source section state machine.
- Tests cover style metadata/marker ticks, all packaged styles, all 12 roots of major/minor triads, transposition vectors, a source-`.enstl` MIDI event trace at the Variation A start, CentralBus clock latch, split-vs-long elapsed-time equivalence (including updates beyond 60 seconds), stop-measure reset, variation-to-fill transitions, intros, endings, sync start/stop, and active style replacement.

This is real reuse/porting of the original logic, not a replacement accompaniment generator. The current UI is still a harness around this part of the engine, and the whole program has not reached parity.

## Main-panel controls — Iteration 4

The Chords/Accompaniment, Layer, and Split switches now change keyboard/style routing and persist in QSettings; the keyboard split point can be changed by right-clicking a key. Transpose/octave, FX levels/state, main output volume, and metronome state also persist. Reverb/Chorus defaults match the original post-load GSettings values (enabled, levels 7/2). Arpeggiator and Harmonizer are deliberately disabled until their original algorithms are ported. Panel routing now uses the internal FluidSynth voice channels when that output is selected. See [`docs/PANEL_CONTROL_PARITY_ITERATION_4.md`](docs/PANEL_CONTROL_PARITY_ITERATION_4.md).

## Audio backend — Iteration 5

The Qt port now creates a 64-channel FluidSynth instance, loads a real `.sf2` SoundFont, renders interleaved 44.1 kHz stereo float samples through an RtAudio callback, and routes queued MIDI events into the same synth. Master Reverb/Chorus use FluidSynth's group-effect APIs with the original Ensembles 0–10 preset arrays. Internal voices follow the source `synthesizer.c` channel assignments: R1=17, R2/layer=18, L/split=19, metronome=16, and chord voices=20–22. WinMM stays available as `Windows MIDI Mapper only` or alongside the internal synth.

**SoundFont caveat:** this package includes `LS-GM.sf2` under `data/SoundFont/` for the native LS-GM Yamaha `.STY` route. The separate original `EnsemblesGM.sf2` payload for the general FluidSynth fallback is not present (an LFS pointer remains only under `legacy-reference/`), and the application detects/rejects pointer or invalid files. For the FluidSynth fallback, supply a SoundFont you are licensed to use via Settings → `Pilih SoundFont (.sf2)…`. If the private SCVA runtime loads successfully, its audio path does not require this FluidSynth fallback bank. The third-party notice/license files under `data/SoundFonts/` are retained as documentation for the separate general GM bank.

Still not fully migrated: original `ArrangerCore`/`CentralBus` signal and recorder integration; physical MIDI input CC/note-learn mapping and automatic hotplug; multitrack recorder/sequencer/project format; original harmonizer/arpeggiator algorithms; LV2 plugin/rack/effects; arbitrary sample pads; original SoundFont voice catalog and complete original UI/preferences. FluidSynth audio output is now available, but it does not by itself establish 1:1 sound or behavior. See [`docs/AUDIO_BACKEND_PORTING_ITERATION_5.md`](docs/AUDIO_BACKEND_PORTING_ITERATION_5.md) and [`docs/PORTING_STATUS.md`](docs/PORTING_STATUS.md).

### Yamaha `.STY` playback correction — 2026-11-05 (Step 5)

The Yamaha `.STY` runtime received a dedicated playback correction pass. The parser now reads SFF1 Ctab NTR/NTT from bytes 20/21 (not editable/note-mute bytes 10/11), ignores `SFF1`/`SInt` metadata markers as arranger sections, sorts format-1 MIDI events chronologically, and replays pre-section bank/program/controller setup before the first note. Root Transpose and Root Fixed are handled differently; Root Fixed chord mapping chooses the closest legal octave. Yamaha RHY1/RHY2 (MIDI channels 9/10, zero-based 8/9) are isolated on private SF2 channels 40/41 for both the bundled Native LS-GM sampler and external FluidSynth SoundFonts. Bank Select CC0/MSB and CC32/LSB are staged independently per rhythm part; Program Change commits the exact matching percussion preset from the active SF2 preset catalog. If the requested drum PC is unavailable, resolution stays within the percussion-bank family and never substitutes a melodic preset. The chord fader does not attenuate these two rhythm channels. These part/channel transformation changes are explicitly gated to Yamaha `.STY` while LS-GM is active; Roland `.STL` arranger transformations remain unchanged. Native sound-engine selection by file extension is handled separately by the Step 6 routing layer below.

Step 5 regression checks passed for the expanded Yamaha runtime test, existing StyleEngine test, all 92 supplied `.sty` files through the actual StyleEngine MIDI sink (92/92 produced notes and setup events), and dual LS-GM rhythm channels 40/41. Exact Yamaha firmware equivalence for Guitar NTR and all NTT variants is not claimed; physical Windows audio and a full Qt/MSVC build remain to be verified. See `LS-GM-REALTIME-ENSEMBLES-INTEGRATION-2026-11-05.md` for test detail.

### LS-GM Windows build note — 2026-11-05

The complete source package includes the `src/` include directory on the `ensembles-cpp` target. This is required by the native LS-GM translation units (`#include "SoundFont/...hpp"`) and fixes the missing-header C1083 errors from the earlier package. Use this full ZIP rather than applying a separate CMake patch. For the cleanest retry, extract the package into a fresh `ensembles-cpp` folder and run `V19.0-Apply-Build-Run.bat`. A complete Windows/MSVC build and physical audio playback are still pending verification.

## Build on Windows with the included batch files

This package includes `Build-And-Run-Windows.bat`. On a Windows PC where Qt Desktop MSVC x64, Visual Studio C++ tools, CMake, Ninja, and vcpkg are already installed:

1. Extract the ZIP.
2. Double-click `Build-And-Run-Windows.bat` from this folder. It looks for the existing Qt/vcpkg paths (and reuses a matching `build-qt-audio-ninja` cache when present), initializes the Visual Studio x64 compiler environment, configures CMake, builds `ensembles-cpp.exe`, deploys Qt DLLs, stages app data and the SCVA folder, then starts the program.
3. Build output is placed in `build-qt-audio-ninja\`. If the included CMake cache points to a different source folder, the script uses `build-qt-audio-ninja-current\` instead of overwriting that cache.
4. To launch the last successful build without rebuilding, run `Run-Ensembles.bat`.

The script prefers the kit stored in an existing cache; otherwise it checks `C:\Qt\6.11.2\msvc2022_64` and other `C:\Qt\6.*\msvc2022_64` kits. It detects vcpkg from `VCPKG_ROOT`, `VCPKG_INSTALLATION_ROOT`, or `%LOCALAPPDATA%\Ensembles\tools\vcpkg`. The first configure may still need Internet access if the vcpkg manifest packages or NativeTS source are not already cached. Build logs and errors remain visible in the console. The `V19.0-Apply-Build-Run.bat` file is the canonical script; `Build-And-Run-Windows.bat` and the legacy `#V19.0-Apply-Build-Run.BAT` both delegate to it. The ACMP source fix is already integrated, so no overlay patch is applied.

## Build/tests without Qt (engine and parser tests)

On a C++17 toolchain with `g++`:

```sh
./tests/run_midi_parser_test.sh
./tests/run_midi_input_router_test.sh
./tests/run_style_engine_test.sh
python tests/audio_backend_source_smoke_test.py
python tests/soundfont_runtime_smoke_test.py
```

The SoundFont runtime test reports `SKIP` when no valid bundled SF2 is present; if you supply the expected `TimGM6mb.sf2`, it also checks the header and exercises FluidSynth when its shared library is installed. In CMake/CTest on a Windows toolchain, the MIDI/style tests are registered when `BUILD_TESTING=ON`. The Qt GUI itself was not build-tested in this authoring environment because Qt 6/MSVC is not installed here.

## Project map

- `src/main_qt.cpp` — Qt frontend, SoundFont selection/settings, audio-routing UI, and WinMM MIDI output adapter.
- `src/audio_engine.cpp/.hpp` — FluidSynth synth, SoundFont loading, RtAudio output callback, queued MIDI events and built-in effect API.
- `src/style_engine.cpp/.hpp` — ported original style analysis, playback event filtering, chord transpose and ARR section state logic.
- `src/chord_finder.cpp/.h` — original chord finder code carried into C++.
- `src/midi_file.cpp/.hpp` — Standard MIDI File parser/writer with absolute tick and marker retention.
- `src/midi_input_router.hpp` — tested, platform-independent WinMM short-message decoding and original channel-to-layer mapping.
- `data/StyleFiles/` — Roland `.STL` styles used by ACMP regression tests.
- `data/Styles/StyleFiles/` — original `.enstl` examples used by the style engine tests.
- `legacy-reference/` — original source tree retained for reference and continuing parity work.
- `CMakeLists.txt` + `vcpkg.json` — primary CMake/vcpkg build. `ensembles-qt.pro` is a best-effort Qt Creator/qmake alternative requiring prepared vcpkg libraries and separate runtime deployment.
- `docs/PORTING_STATUS.md` — current migration boundaries and validation record.
- `docs/ARR_LOGIC_1TO1_AUDIT.md` — source-to-port map, tests, known differences, and remaining parity gates.
- `docs/WINDOWS_HARDWARE_TEST.md` — Windows hardware validation checklist.

The original source is GPL-3.0-or-later. Keep required license/attribution notices when distributing derived code.

## Original GUI reference and parity status

The Qt front end's home layout is being matched against the original Ensembles screenshot and Vala/GTK widget sources. See [`docs/GUI_MIGRATION_1TO1_AUDIT.md`](docs/GUI_MIGRATION_1TO1_AUDIT.md) for the mapping and remaining parity checklist. This is a visual-parity iteration, **not** a completed 1:1 migration. It does not claim that FluidSynth/SoundFont voices, the original full arranger/synth routing, arbitrary sample pads, 10-track recorder, registration memory, or LV2 rack are already equivalent on Windows.

## Iteration 6.8 — internal VST2 instrument host

The app includes an internal VST2 host path for 64-bit instrument DLLs. The plugin editor is not opened; MIDI from the Voice and Style paths is sent to the plugin and audio is rendered through the existing RtAudio stream. The plugin path is saved in QSettings. FluidSynth remains available as a fallback. See `Ensembles-Qt-Iteration-6.8-VST2-Host-Notes.txt` and `tests/vst2_host_source_test.py`.

### Iteration 6.8.7 — SCVA automatic internal loading

Startup now searches `plugins/SCVA/` beside the executable for the embedded SCVA core and initializes Native SCVA as the default engine when available. When an external style is loaded, the format-specific renderer takes precedence: Yamaha `.STY` switches to LS-GM Native C++, while Roland `.STL` switches to Native SCVA C++. Native renderer selection and MIDI delivery are enforced by the Step 6 style-routing layer described below. CMake stages the plugin folder beside the executable. This private package includes SCVA DLL/data copied into it; use only files you are licensed to use and do not redistribute them without permission. `tools/Install-SCVA-Portable.ps1` remains available for replacing the local plugin folder. See `plugins/SCVA/README.txt` for the licensing caveat.

### VST2 MIDI dispatch correction (Iteration 6.8.5)

The VST2 host now dispatches MIDI using the VST2 `effProcessEvents` opcode **25**. Earlier iterations mistakenly used opcode 8 (`effGetParamName`), and the previous mock plugin copied that same error. The mock now only handles opcode 25, so the host integration test fails if MIDI is sent with the wrong opcode. See `Ensembles-Qt-Iteration-6.8.5-VST2-MIDI-Opcode-Fix-Notes.txt`.

## Yamaha PSR-S arranger styles (.STY)

Yamaha PSR-S styles are supported alongside native `.enstl` and legacy Roland `.STL` files.
Place `.STY` files in `Documents/ensembles/styles` on Windows (or the existing built-in
`data/StyleFiles` directory); the style picker lists them under **Yamaha PSR-S**. The new
portable runtime reads the SMF tracks and Yamaha CASM section metadata, and routes Main,
Intro, Fill In, Break, Ending, chord/CASM transformation, and tempo through the existing
Ensembles MIDI sink. Only the style parser and arranger scheduler are ported from the supplied
`cpp.zip`; the Android-only native audio/voice code is not built into the Qt/Windows target.



## Ensembles 6.8.7 realtime native style sound routing

The native sound engine is selected automatically from the loaded style file extension; the user does **not** manually choose the renderer for each style:

- Yamaha `.STY` → **LS-GM Native C++** using the bundled `data/SoundFont/LS-GM.sf2`. SCVA, VST2, FluidSynth and Windows MIDI are not allowed to receive that style's events.
- Roland `.STL` → **Native SCVA C++** using the embedded `:/SCVA/SCCore.dll` resource. LS-GM, VST2, FluidSynth and Windows MIDI are not allowed to receive that style's events.
- Native Ensembles `.enstl` → retains the currently selected general audio route.

Loading a new `.STY` or `.STL` stops and unloads the previous renderer safely, activates the required native renderer on the existing RtAudio output, persists the matching route, and updates the audio status. The Settings route selector displays **Auto by style: Yamaha .STY → LS-GM; Roland .STL → SCVA**. While a Yamaha or Roland external style is loaded, manual route changes are reverted to the renderer required by that style. A mismatch blocks style MIDI instead of silently playing it through the wrong sound engine.

The 92 `.sty` files supplied with Live-Styler 14 are installed into `data/StyleFiles/` and grouped as **LS-GM** in the style picker. The LS-GM sampler supports 64 MIDI channels to retain Ensembles' internal keyboard layers on channels 16–22. See `NATIVE-STYLE-SOUND-ROUTING-2026-11-05.md` and `LS-GM-REALTIME-ENSEMBLES-INTEGRATION-2026-11-05.md`.

## Settings dialog redesign (2026-11-05)

The Settings window is organized into DAW-style Audio, MIDI, Performance, Instruments, and Effects tabs. Each category uses grouped controls and scrollable content, with a resizable dialog and automatic-save note. Existing QSettings keys and control callbacks are preserved. The Instruments tab clarifies that its optional FluidSynth SoundFont selection does not replace the bundled LS-GM bank used by Yamaha `.STY`. See `SETTINGS-UI-REDESIGN-2026-11-05.md`.
