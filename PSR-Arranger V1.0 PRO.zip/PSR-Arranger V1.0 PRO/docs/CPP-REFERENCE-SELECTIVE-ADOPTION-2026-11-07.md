# Selective Adoption from `cpp.zip` — 2026-11-07

## Scope

This change intentionally does **not** import or replace the Yamaha CASM parser,
Ctb2 handling, chord transform, NTR/NTT, RTR, or any Yamaha style playback logic
from `cpp.zip`. The existing Ensembles V20 CASM and arranger implementation is
left as the source of truth.

## Adopted idea: read-only memory-mapped SF2 input

The reference Android implementation uses a read-only OS file mapping for its
SoundFont source. V20 now applies that file-access pattern inside its existing
`lsgm::Sf2Synth::load()` implementation:

- Windows: `CreateFileW` + `CreateFileMappingW` + `MapViewOfFile`.
- POSIX: `open` + `fstat` + `mmap(MAP_PRIVATE)`.
- Parser helpers consume `std::span<const std::uint8_t>` over the mapped file.
- UTF-8 paths are converted to native filesystem paths, including Windows wide paths.
- Mapping and OS handles are released by RAII when `load()` returns.
- The V20 sampler's PCM sample store remains resident in its own memory. This is
  deliberate: the realtime audio callback does not have to fetch sample pages
  from the file mapping while rendering.
- The full source file is no longer duplicated into a whole-file
  `std::vector<std::uint8_t>` before sample decoding.

Loading is transactional: newly decoded samples, presets and lookup tables are
committed only after the bank has parsed successfully. A malformed replacement
bank therefore does not overwrite the last successfully loaded synth state.

This is a parser/startup memory improvement; it does not claim zero-copy sample
playback or a lower total resident-set size under every OS memory policy.

## Deliberately not adopted: alternate arranger scheduler / MIDI queue

V20 already has a dedicated audio command queue and sample-offset scheduler in
`AudioEngine`:

- bounded GUI-to-audio command ring (`kQueueCapacity = 8192`),
- absolute `targetTimeUs` deadlines,
- callback-side conversion from event timestamps to frame offsets,
- sorted dispatch within an audio block,
- a style generation counter that invalidates stale style events on Stop without
  cancelling live keyboard MIDI.

The reference's alternate arranger scheduler would create a second timing path
and duplicate responsibilities. It was therefore not copied. No second MIDI
queue was introduced.

## CASM preservation

No CASM parser or transform source was modified for this selective adoption.
In particular, these remain untouched by this patch:

- `src/yamaha_style_runtime.cpp`
- `src/yamaha_arranger_engine.cpp`
- `src/yamaha_arranger_engine.hpp`
- `src/style_engine.cpp`

## Validation added

`tests/soundfont_external_bank_test.cpp` now verifies:

1. External SF2 loading from a Unicode directory and filename.
2. The mapped file can be renamed immediately after `load()` returns, proving
   that the file mapping/handles are no longer held open.
3. The selected preset renders finite, non-silent audio.
4. Loading a malformed replacement fails without damaging the already loaded bank.

`tests/soundfont_mmap_source_test.py` checks platform-specific mapping lifecycle,
non-owning parser input, transactional commit, and preservation of V20's existing
sample-accurate style event queue.
