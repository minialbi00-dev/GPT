# Main-panel parity pass — Iteration 4

Date: 2026-10-23

This iteration compares the Qt panel with the original `ControlPanel.vala`, `CentralBus.vala`, `Synthesizer.vala`/`synthesizer.c`, and `KeyBed.vala`. It is a step toward parity, not a declaration that the application is already 1:1.

## Implemented

- **Chords / Accompaniment** is a real persistent checkable state. It controls lower-key chord routing when a style is loaded and filters melodic style note-ons when accompaniment is off (preserving drum-channel note-ons), following `synthesizer.c::handle_events_for_midi_players`. Disabling accompaniment also sends all-notes-off/all-sounds-off to avoid hanging voices.
- **Layer** routes a right-hand note to the primary voice and the second voice (GM MIDI channels 1 and 3 in the Windows adapter). It is persistent.
- **Split** routes keys at or below the split point to the left voice channel and keys above the point to the primary right voice. It is persistent. Because the original GTK KeyBed exposes a small split-point button on every key, this Qt port currently uses a right-click on a key as the equivalent interaction; the split point is stored in QSettings.
- Transpose and octave enable/value state persists. Reverb/Chorus enabled state and level persist. The level-to-CC scale is consistent between button and level changes.
- Effective default panel state follows the original GSettings schema after settings load: Reverb enabled at level 7 and Chorus enabled at level 2. The `ControlPanel.vala` constructor briefly seeds 5/1 before `load_settings()` loads schema-backed values, so treating 5/1 as the final effective defaults was incorrect.
- Output volume persists. Metronome state is shared between its top-panel button and settings-dialog checkbox.
- Added static Qt panel source smoke checks. These check source invariants only and do not compile or run the GUI.
- Arpeggiator and Harmonizer are intentionally disabled until their actual algorithms are ported. They are not left as apparently-working toggles with no note-generation effect.

## Compatibility limits

- Layer/Split use external Windows MIDI channels. These channels are not equivalent to the original app's separate FluidSynth realtime channel group, and can conflict with channels used by style files on some output devices.
- Reverb/Chorus are sent as MIDI CC 91/93. This cannot reproduce the original FluidSynth master-effects API on every Windows synth.
- With accompaniment enabled, lower keys update the chord only when a style is loaded; the full original chord-preview voicing when the style is stopped is not yet ported.
- Split-key selection is right-click rather than the original per-key split button.
- Arpeggiator, Harmonizer, full original synth routing, voice management, physical MIDI input, and original FX DSP are still incomplete. Iteration 6 replaces placeholder Registration Memory buttons with ten persistent snapshots of the currently ported state, but original bank/snapshot semantics still need parity work.

## Validation

- `tests/run_midi_parser_test.sh` — PASS.
- `tests/run_style_engine_test.sh` — PASS; includes all ten shipped styles and original ARR-state regressions.
- `python3 tests/qt_panel_source_smoke_test.py` — PASS (9 static source invariants).
- CMake configure for the GUI — BLOCKED in the authoring environment: `Qt6Config.cmake`/Qt 6 development package is not installed.
- Qt 6/MSVC compilation and real Windows MIDI/audio behavior — NOT TESTED here. Run `Build-And-Run-Windows.bat` on a Windows machine with Qt 6 Desktop MSVC x64 and Visual Studio C++ Build Tools. Do not treat this iteration as build-verified until that succeeds.
