# Yamaha Genos chord detection and external SF2 loading

Date: 2026-11-06

## Scope

This iteration addresses two concrete gaps reported during Yamaha ACMP testing:

1. chord recognition was reduced to a small set of legacy chord families and discarded MIDI octave/bass information;
2. the native SF2 sampler used the bundled LS-GM bank in several startup/route-change paths even after an external SF2 had been selected.

No LCD geometry, LS-GM bank assets, Native SCVA resources, or output-route exclusivity rules were changed.

## Chord detection changes

- The Genos-aware detector now stores held MIDI notes (0..127), rather than relying exclusively on a 12-bit pitch-class bitmap.
- The classifier recognizes the 33 pitch-class chord-control templates (IDs 0..33) and handles ID 30 (1+8 octave fingering) from the actual note numbers.
- When no notes remain held, the detector reports chord ID 34 (Cancel) and no bass note. The UI deliberately retains the last style chord on ordinary keyboard release, matching its existing hold-last-chord policy; this is not treated as a new chord event.
- The lowest held MIDI note is returned independently as `bass_pc`. Both the on-screen keyboard and split-MIDI chord paths pass the exact Genos ID and bass pitch class to `StyleEngine::changeChord()`.
- `StyleEngine` already forwards the values to the Yamaha arranger; Ctb2 Bass-On rules can now see slash bass rather than always receiving `bass_valid=false`.
- The classifier uses a root hint to break pitch-class ambiguities such as relative-minor / relative-sixth voicings. This is still a deterministic keyboard-input heuristic, not a full reproduction of every Genos chord-fingering mode. Inversions and unusual voicings need A/B verification against a Genos.

## External SF2 loading changes

- The Settings > Instruments picker stores the absolute external bank path in `audio/externalSoundFontPath`.
- Startup and Yamaha style route changes call `discoverStyleSoundFont()`: a valid selected external SF2 takes priority; otherwise the bundled `data/SoundFont/LS-GM.sf2` is used.
- The Native SF2 route uses the generic `AudioEngine::loadNativeSoundFont()` API, which loads the selected path with the in-process `lsgm::Sf2Synth` on the existing RtAudio output stream. File paths are passed as UTF-8 and opened through `std::filesystem::path`, including paths containing non-ASCII characters.
- Changing to a Yamaha style no longer silently reloads the bundled bank over a selected external SF2.
- The FluidSynth route also continues to use the selected file path.

The SF2 renderer has been proven to load and render the external `TimGM6mb.sf2` bank in this environment (136 advertised presets; first preset 0:73 `Flute TB` rendered non-zero audio). This verifies external path access (including a non-ASCII directory path) and basic preset/sample rendering. It does **not** certify complete SoundFont 2.04 modulator, controller, effect, or edge-case compatibility for every third-party bank.

## Regression tests

- `chord-finder-genos-test`: all 33 documented pitch-class templates; transposed major; octave-only ID 30; final-note release/Cancel; C-major-over-G slash bass.
- `genos-chord-id-slash-bass-integration-source-guard`: both keyboard and split-MIDI paths pass Genos ID and slash bass to StyleEngine.
- `soundfont-external-bank-test <path.sf2>`: loads a caller-supplied external file, selects an advertised preset, renders MIDI note 60, checks finite samples and non-zero energy.
- `external-sf2-selection-persistence-source-guard`: verifies remembered external path, startup resolver, style route resolver, and native loading API.
- Existing Yamaha runtime test passed, including CASM and held-ACMP chord-change routing.
- Full PSR-S playback corpus passed: 642 files, zero load failures; all 642 generated Note-On and setup events.
- Existing bundled LS-GM native renderer test passed: 308 presets and non-zero rendered output.

To run the external-bank CTest on a Windows/Qt build, set `ENSEMBLES_EXTERNAL_SF2_TEST_PATH` to the full path of a real `.sf2` file before configuring/running CTest. The standalone target can also be run as `soundfont-external-bank-test <path.sf2>`.

## Remaining Genos compatibility gaps

This iteration does not make the arranger 1:1 with Genos. In particular:

- RTR 1/2 still use the current revoice/re-articulation fallback in the MIDI output path. True per-note pitch movement without a new attack is not yet implemented.
- NTT remains incomplete for some extension chord qualities and special scale/chord modes.
- NTR Guitar still cannot reliably identify the lowest note of a multi-note guitar voicing from isolated note events.
- Bass-On and slash-bass routing has better source information now, but needs note-range / multi-track hardware comparison.
- Chord inference templates and inversion selection need controlled A/B capture against the same Genos fingering mode, split point, and exact MIDI event sequence.
- Windows MSVC/Qt build and GUI selection/restart were not executed in this Linux environment because Qt 6 development packages are unavailable. They require validation on the user's Windows build machine.

The implementation should therefore be described as improved Genos-aware behavior with regression coverage, not as verified 1:1 compatibility.
