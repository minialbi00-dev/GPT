# External SF2 renderer restoration — 2026-11-07

## Scope

Restore FluidSynth as the renderer for user-selected external `.sf2` files. Keep the existing V20 CASM parser, Yamaha StyleEngine, arranger scheduler, timestamped MIDI queue, LCD geometry, bundled Native LS-GM fallback and Native SCVA route unchanged.

## What changed

- `chooseSoundFont()` sends the selected external bank to `AudioEngine::loadFluidSynthSoundFont()` when an audio stream already exists. It does not send the chosen external bank to the TinySoundFont/native LS-GM loader.
- If there is no existing engine, the selection initializes one FluidSynth + RtAudio engine.
- `loadFluidSynthSoundFont()` creates and loads a candidate FluidSynth synth before touching the active callback. It then pauses and reuses the existing RtAudio stream, swaps the synth, resumes the same stream, and retains the previous synth until restart succeeds.
- The RtAudio callback continues to render `synth_` through `fluid_synth_write_float()`. TinySoundFont remains a separate native bundled LS-GM fallback, not the renderer for user-selected external SF2 banks.
- FluidSynth preset metadata is enumerated from the loaded SoundFont using FluidSynth's SoundFont/preset iteration API. The existing MSB/LSB/PC browser is preserved and now consumes this FluidSynth catalog for external banks.
- FluidSynth uses `synth.midi-bank-select=mma`, so bank selection is computed as `CC0 * 128 + CC32`. PC remains a separate MIDI Program Change event.
- `masterGain_` remembers the UI output gain across external-bank replacement. The chooser and route-switch path also reapply the current gain, Reverb, Chorus and voice programs.
- A saved explicit `fluid` route is now handled before automatic SCVA/VST2 startup. This prevents an external bank that was selected and saved as FluidSynth from remaining only a fallback while another renderer takes the output stream.
- A legacy saved `lsgm` route with a remembered external SF2 is migrated to FluidSynth. If no external bank is selected, the bundled Native LS-GM fallback remains available.
- Explicit FluidSynth route selection does not also attach a stale VST2 path.

## Files changed

- `src/main_qt.cpp`
- `src/audio_engine.cpp`
- `src/audio_engine.hpp`
- `tests/soundfont_external_path_source_test.py`
- `tests/sf2_bank_select_source_test.py`
- `tests/soundfont_mmap_source_test.py`
- `tests/native_style_renderer_routing_source_test.py`

No CASM, Yamaha arranger, StyleEngine, scheduler, LCD, LS-GM bank data or Native SCVA source file was changed.

## Regression checks run

Passed source-level checks:

- `soundfont_external_path_source_test.py`
- `sf2_bank_select_source_test.py`
- `soundfont_mmap_source_test.py` (verifies that TinySoundFont is retained only for the native LS-GM fallback)
- `native_style_renderer_routing_source_test.py`
- `audio_output_diagnostic_source_test.py`
- `style_stop_midi_queue_source_test.py`
- `yamaha_style_picker_source_test.py`
- `yamaha_style_grid_source_test.py`
- `yamaha_style_grid_borders_test.py`
- `yamaha_style_edge_alignment_test.py`
- `yamaha_style_viewport_geometry_test.py`
- `chord_finder_genos_integration_source_test.py`

## Build/runtime limitation

A full CMake configure/build was attempted but cannot run in this Linux environment because Qt 6 development files (`Qt6Config.cmake`) are not installed. Therefore this package has source-level regression verification only; Windows/MSVC/Qt build and actual audio-device playback must still be verified on the target Windows machine.

## FluidSynth bank mode reference

FluidSynth documents the `mma` bank-select mode as `bank = CC0 * 128 + CC32`:
https://www.fluidsynth.org/api/settings_synth.html
