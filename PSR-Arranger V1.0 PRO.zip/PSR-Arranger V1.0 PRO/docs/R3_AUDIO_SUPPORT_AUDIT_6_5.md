# Iteration 6.5 — LCD Controls and R3 Audio Support Audit

Date: 2026-10-23
Base: Iteration 6.4 LCD Controls

## LCD and hardware controls

- Removed the 14 px blank inset before the LCD tabs. The two-line tab strip now occupies 47 px at the actual top of the display, with explicit title/subtitle labels and vertical centering.
- Increased the cover image viewport to 116 px to keep the photo/metrics boundary close to the supplied reference proportions.
- Restored the reference-style blue top indicator for checked hardware controls; the control face remains charcoal instead of turning teal/blue.
- Persisted Octave active state now refreshes the same style property on load and toggle, so its indicator does not desynchronize from the saved state.
- Style/Voice click routes and their in-LCD stacked picker pages are unchanged.

## R3 audit result: not end-to-end supported

The current low-level FluidSynth instance is configured with `synth.midi-channels = 64`, and the MIDI command handler accepts an explicit channel override from 0 through 63. Channel 23 can therefore be addressed by the low-level engine if a caller sends an event to it.

That is **not** the same as an implemented R3 voice slot. The Qt application currently has only three selectable voice slots (`R1`, `L`, `R2`), maps them to FluidSynth channels `17`, `19`, and `18`, and routes keyboard notes/program changes/registration memory for those slots only. No R3 program selection or R3 keyboard layer is wired to channel 23. The legacy reference contains a declaration named `synthesizer_voice_program_r3`, but no usage of that variable; the original voice menu and synthesizer routing likewise actively describe/use R1, R2 and L rather than a complete fourth R3 slot.

**Conclusion:** audio-channel capacity is sufficient for a future R3 implementation, but R3 is not a selectable/playable feature in this Qt port today. This iteration deliberately does not invent a new R3 UI or alter the established R1/L/R2, Style, or RtAudio routes. A proper R3 implementation needs an explicit product decision for its controls/layer semantics, program persistence, registration memory, and hardware MIDI behavior.

## Validation status

Source-level regression tests cover the LCD geometry, checked-button styling, Style/Voice picker contract, and the R3 capability boundary. Existing audio, style, MIDI parser, registration, RtAudio settings, and ASIO manifest checks remain in the package.

This package was not compiled with Qt 6 + MSVC and was not launched on Windows in this authoring environment. ASIO4ALL enumeration and live RtAudio playback remain hardware/runtime checks for the Windows build.
