# Ensembles 6.8.7 — Settings UI redesign

## Overview

The Settings dialog has been reorganized into a conventional DAW-style preferences window. The change is limited to presentation and widget organization; the existing settings keys, callbacks, audio routing logic, MIDI device connection logic, and effect parameter handlers are retained.

## Tabs

- **Audio** — style sound-engine routing, RtAudio host API, output device, sample rate, buffer/latency, audio status, and test tone.
- **MIDI** — external MIDI input device list, refresh, connection status, and split-by-channel routing.
- **Performance** — tempo, master output level, metronome, and modulation/LFO helper.
- **Instruments** — optional FluidSynth SoundFont and VST2 instrument selection. The explanatory note clarifies that Yamaha `.STY` uses bundled `LS-GM.sf2` and is not controlled by the optional FluidSynth SoundFont field.
- **Effects** — master reverb/chorus and Native SCVA EFX parameter controls.

## Layout and usability

- Wider, resizable dialog with a minimum usable size.
- Scrollable tab pages so long option groups do not overflow smaller displays.
- Consistent group-box sections, form alignment, control sizing, and spacing.
- Header, short descriptions, and automatic-save indication.
- Audio/MIDI/performance/effects settings are separated instead of being stacked into one long form.

## Compatibility

- Existing `QSettings` key names are unchanged.
- Existing widget pointers and signal handlers are retained.
- No changes were made to Yamaha `.STY` → LS-GM or Roland `.STL` → SCVA renderer routing.
- The optional FluidSynth SoundFont UI explicitly identifies itself as separate from the bundled LS-GM bank.

## Validation

Source-level structural checks passed, and existing non-Qt regression binaries remain available in the package. A complete Qt/MSVC application build and visual verification on Windows must still be performed in the target Windows environment; this Linux build environment does not have Qt 6 development headers installed.
