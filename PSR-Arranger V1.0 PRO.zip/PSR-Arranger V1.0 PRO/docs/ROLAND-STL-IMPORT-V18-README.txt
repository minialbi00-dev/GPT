ENSEMBLES 6.8.7 — ROLAND STL COMPATIBILITY V18.3 (TIMING FIX)
================================================

SCOPE
-----
This overlay adds loading of legacy Roland arranger .STL files with the G8 or
EV two-arrangement header format. The existing native Ensembles .enstl MIDI
path is retained. The user's V17.9 LCD/Voice header and Style-button changes
are included in src/main_qt.cpp.

INSTALL
-------
1. Close Ensembles.
2. Extract this ZIP directly into the project root containing CMakeLists.txt
   and src/. Allow the included files to overwrite their matching files.
3. Put Roland .STL files in either:
       data/StyleFiles/
   or (recommended for user files):
       Documents/ensembles/styles/
4. Run Rebuild-And-Run-Roland-STL-Compatibility-V18.bat from that project root.
   The V18.3 launcher verifies src/roland_stl.cpp and CMakeLists.txt before
   building. CMake regenerates the Ninja graph to compile the new source file.
5. Open Style and choose the entry under the "Roland" genre.

SUPPORTED IMPORT MAPPING
------------------------
The importer translates the Roland binary pattern records to the in-memory
MidiFile/StyleEngine contract. It creates the 15 section markers required by
Ensembles and converts compact note lengths into explicit MIDI Note Off events.

  Intro A       Roland Basic Intro
  Intro B       Roland Advanced Intro
  Variation A   Basic Original
  Fill A        Basic Fill To Original
  Variation B   Basic Variation
  Fill B        Basic Fill To Variation
  Variation C   Advanced Original
  Fill C        Advanced Fill To Original
  Variation D   Advanced Variation
  Fill D        Advanced Fill To Variation
  Ending A      Basic Ending
  Ending B      Advanced Ending

Bank Select, Program Change, regular Control Change and Pitch Wheel events are
translated where present. The four Variation/Fills slots are a compatibility
mapping to the current Ensembles UI; this is not a complete emulation of every
Roland arranger model's panel behavior.

KNOWN LIMITS — PLEASE READ
-------------------------
* This importer targets the legacy G8/EV two-arrangement STL structure. It does
  not claim support for every newer Roland/BK/E-A file revision.
* The current StyleEngine uses its existing chord transposition model. The
  importer chooses the Major chord stream when available, falling back to Minor
  or 7th only when the earlier stream is absent. Live switching among the three
  stored Roland chord-family streams and Adaptive Chord Voicing (ACV) is not
  implemented in this patch; ACV/Data Entry records are skipped.
* Roland's Variation2 and Fill-To-Variation2 parts are not exposed separately
  in the current UI mapping.
* In the supplied 1 6-8SlowRock.STL, header data says 4/4 and approximately
  73 BPM, even though the filename contains "6-8". The importer trusts the
  binary header; it does not infer time signature from the filename.
* That sample references address 0x4958 183 times. The referenced sequence is
  not a valid 62-bar arrangement for all those parts, so the importer treats
  extremely over-aliased addresses (more than 32 references) as empty/unused
  placeholders and falls back to another available chord-family address. This
  protects this supplied sample but is a heuristic that should be checked on
  additional Roland models/files.
* The supplied Roland control-panel photo is treated as a reference for a
  later transport UI pass. This V18 patch adds file import and selection; it
  does not redesign the transport row into the exact pictured hardware layout.
* Yamaha .STY import is not included in V18.

TESTS
-----
The source adds these tests when CMake BUILD_TESTING is enabled:
  roland-stl-header-events-and-style-markers
  roland-stl-ui-source-guard

In this authoring environment, the new Roland reader C++ regression test,
source-guard test, existing StyleEngine test, and MIDI parser/writer test pass.
A Windows/MSVC + Qt application build and an actual listening test have not
been run here. The launcher builds the application on the user's machine.

FORMAT REFERENCE
----------------
The parser is an independent C++ implementation based on the publicly
documented legacy Roland STL structure and the provided binary sample, with
TomiSoft RolandStyleReader used as a format reference:
https://github.com/std66/RolandStyleReader


WHY V18.2 CHANGES THE CODE LAYOUT
---------------------------------
The first V18 build log showed LNK2019 for ensembles::load_style_source_file().
V18.1 attempted to force-rebuild the existing style_engine.cpp object. That was
only a build workaround and did not make the symbol live in a newly-added object.

V18.2 moves the exported dispatcher and Roland STL parser into src/roland_stl.cpp,
a dedicated translation unit listed in the GUI target and both style-related test
targets. The updated launcher explicitly reruns CMake against the existing cache
before building, so Ninja regenerates its graph and compiles the new source file.
This resolves the structural reason the dispatcher symbol can be absent from the
link; the user's MSVC/Qt build still needs to confirm the full application starts.


V18.3 TIMING CORRECTION
-----------------------
The Roland STL records store each event's delta as the time AFTER that event
until the next record. V18.3 timestamps the event at the accumulated tick and
adds its delta only after decoding it. This matches the reference RolandStyleReader
iteration order and fixes the one-delta shift that disturbed note spacing and
made instruments start out of alignment. Stream-end timing now uses accumulated
deltas up to 0x8F, and generated Note Offs are prevented from spilling into the
following section. The regression fixture uses non-zero deltas and asserts
exact event timestamps.

The regression was compiled and run in a local C++ test harness and passed; this
is not a replacement for rebuilding the Qt/MSVC application and auditioning the
actual BK-5 styles on the target Windows setup.
