# Ensembles 6.8.7 — S-YXG2006LE native renderer, step 3

## Changes in this step

- WAV importer now accepts mono/stereo RIFF/WAVE PCM 8/16/24/32-bit and IEEE float32 (8–192 kHz). Stereo sources are downmixed to the mono voice buffer used by the sampler.
- Existing `XGPCM1` key/velocity-zone model remains the sample mapping layer. Multiple velocity zones may target a single bank/program/note range.
- Per-voice state-variable low-pass filter uses XG CC74 cutoff and CC71 resonance state.
- CC91 reverb send and CC93 chorus send now feed preallocated stereo delay networks. Delay memory is allocated in `open()`, not in the audio render callback.
- XG channel 10 percussion treats notes as one-shot triggers and ignores NoteOff truncation.
- Unit tests now exercise PCM16 mono, PCM24 stereo, multiple velocity layers, stereo output, sustain, independent parts, reverb/chorus tail, and percussion one-shot behavior.

## Validation

Standalone native renderer test:

`S-YXG2006LE native PCM renderer tests passed`

AddressSanitizer + UndefinedBehaviorSanitizer + leak detection:

`S-YXG2006LE native PCM renderer tests passed`

`audio_engine.cpp` compiled as a C++20 object against the previously used RtAudio/FluidSynth compatibility stubs. The only compiler messages were existing `std::filesystem::u8path` deprecation warnings.

## Important boundary

This step improves the native PCM playback engine; it does not decode `sxgdat6l.tbl`, and it does not contain original Yamaha factory samples. The example manifest references `piano_C4.wav`, which is intentionally not bundled, so the example alone cannot make sound. To play audio through this renderer, the manifest must reference actual PCM/WAV assets.

Publicly available material found in this research cycle describes the 2006LE waveform table as a separate non-WAV data payload; the detailed community format notes are explicitly marked as potentially inaccurate. The currently public Madaha project README also says its S-YXG2006LE `.tbl` files are not yet read by that project, even though its older S-YXG50 pipeline and XG audio stages are functional. No speculative parser was added on the basis of those unverified notes.

## Remaining work for factory S-YXG2006LE sounds

A usable PCM export/sample set plus its voice-element metadata (key/velocity zones, root keys, loop points, envelope and drum mappings) is still required to populate `XGPCM1` with the actual timbres. The current reverb/chorus are basic send effects, not full Yamaha XG effect-DSP parity or complete XG SysEx effect configuration.
