# Left Mixer Scale Tick Placement Correction — V19.4

The yellow/amber scale marks on the six left-panel faders are now painted at the far-left and far-right edges of each slider widget. They occupy the outer side gutters and no longer intrude into the recessed dark fader track. The groove remains the dark centered track; the silver/white handle and slider value/input behavior are unchanged.

No PNG image is added as a runtime asset. The marks and fader face continue to be drawn/styled by Qt code. The six existing mappings (STYLE, SONG, AUDIO, PADS, DRUM/PERC, CHORD) are retained.
