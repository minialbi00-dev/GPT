Ensembles 6.8.7 — Assignable Controls V11
========================================

Purpose
-------
Activate the ten sliders, four assignable knobs and master knob using named default targets. Assignments persist in QSettings and the assignment dialog can select a named function or a custom MIDI CC.

Default slider mapping
----------------------
1. Voice L Volume: CC7 to the dedicated L internal part and external MIDI channel 2.
2. Voice R1 Volume: CC7 to the dedicated R1 internal part and external MIDI channel 1.
3. Voice R2 Volume: CC7 to the dedicated R2 internal part and external MIDI channel 3.
4. Style Volume: CC7 to internal style channels 1–16 except channel 10 so Drum Volume remains independent; external style note-on velocities are scaled separately so the three dedicated external voice channels are not changed by this control.
5. Reverb Send: CC91 on the currently selected voice part.
6. Chorus Send: CC93 on the currently selected voice part.
7. Filter Cutoff: CC74 on the currently selected voice part.
8. Filter Resonance: CC71 on the currently selected voice part.
9. Expression: CC11 on the currently selected voice part.
10. Drum Volume: CC7 on MIDI channel 10 / internal channel 9.

Default four knob mapping
-------------------------
1. Pan: CC10 on selected voice part.
2. Modulation: CC1 on selected voice part.
3. Reverb Send: CC91 on selected voice part.
4. Chorus Send: CC93 on selected voice part.

Master knob
-----------
Always controls app output gain and Windows MIDI output volume, if that route is active. When Master Knob Assign is enabled, other sliders/knobs can additionally be toggled as linked targets.

Assignment workflow
-------------------
Click Slider Assign then release a slider, or click Knob Assign then release a knob. Choose a named function in the dialog. Choose “Custom MIDI CC” to use the manually selected MIDI channel and controller. Changes are stored under QSettings uiControlMaps; old unassigned placeholders migrate to these defaults while preexisting custom mappings are preserved.

Validation limits
-----------------
The included Python test checks that the expected source mappings and output routes are present. It does not replace a Windows/MSVC rebuild, audio-device initialization, hardware MIDI test, or listening test. The V11 launcher forces recompilation of src/main_qt.cpp, builds the existing Ninja GUI target, and launches normal audio mode (never --safe-ui).
