# LS-GM / SCVA silent-audio diagnostic update

- The SoundFont renderer is named LS-GM throughout user-facing labels, code symbols and tests.
- The Audio Settings button `Test output (440 Hz)` now injects a 1.2-second sine directly into the RtAudio callback.
- The test signal bypasses MIDI routing, LS-GM, SCVA, FluidSynth and style playback.
- If this tone is audible, the selected RtAudio device/stream is delivering samples and the remaining problem is in renderer/MIDI activation.
- If this tone is not audible, investigate RtAudio API/device selection, Windows output routing, endpoint mute/volume or stream callback delivery before changing either instrument engine.
- This change adds a diagnostic; it does not claim to have verified playback on the user's physical Windows device.

- The Windows launcher builds the LS-GM renderer test and the Native SCVA validation executable before CTest.
- The Native SCVA validator writes `build-qt-audio-ninja/tests/SCVA-Native-Validation-Report.txt` and `SCVA-Native-Validation.wav`; the launcher prints the text report for troubleshooting.
- The physical output tone must be tested from Settings → Audio after the application starts; the offline renderer tests do not touch the Windows speaker device.
