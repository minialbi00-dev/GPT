ENSEMBLES C++ / QT — CATATAN PAKET SOURCE
========================================

Paket ini adalah pohon source, bukan patch overlay dan bukan binary portable.
File CMake utama berada di root proyek (`CMakeLists.txt`), bersama `src/`,
`tests/`, `regression/`, `data/`, `tools/`, dan `vcpkg.json`.

UJI ACMP TANPA QT
-----------------
Jalankan dari root source dengan CMake dan compiler C++20:

  cmake -S regression -B build-acmp-regression
  cmake --build build-acmp-regression --parallel
  ctest --test-dir build-acmp-regression --output-on-failure

Regresi ini memakai STYLE nyata `data/StyleFiles/8B Pop7 G1000.STL` dan memeriksa
Variasi A, Fill A di lebih dari satu kanal ACMP, Fill C, timing clock StyleEngine,
dan reader STL.

BUILD APLIKASI WINDOWS
----------------------
Gunakan Qt 6 Desktop MSVC x64, Visual Studio x64 toolchain, CMake, Ninja, serta
vcpkg. Lihat bagian build Windows pada `../README.md`. Folder build/cache tidak
ikut ZIP karena menyimpan absolute path mesin asal dan dapat membuat konfigurasi
CMake gagal ketika paket dipindahkan.

CATATAN SCVA
------------
Folder `plugins/SCVA/` berisi berkas plugin proprietary yang disediakan untuk
build privat ini. Pertahankan lisensi/aktivasi yang berlaku; jangan
mendistribusikan ulang berkas tersebut tanpa izin. Build SCVA native juga dapat
memerlukan akses jaringan untuk mengambil source NativeTS, kecuali source lokal
atau arsip yang valid telah disediakan.
