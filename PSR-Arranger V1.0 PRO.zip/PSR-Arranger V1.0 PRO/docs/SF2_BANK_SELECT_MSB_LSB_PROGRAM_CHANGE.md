# Native SF2 Bank Select (MSB/LSB) and Program Change

This note describes the Native C++ SF2 path only. The SCVA voice-bank/map UI remains on its existing path.

## MIDI mapping

- CC 0 is Bank Select MSB (7-bit, 0..127).
- CC 32 is Bank Select LSB (7-bit, 0..127).
- The SoundFont preset bank is the combined 14-bit value `(MSB << 7) | LSB`.
- Program Change is a 7-bit value (0..127). The Settings UI displays PC 1..128 for musicians and subtracts one before sending MIDI.
- The expected event sequence is CC 0, CC 32, then Program Change. CC 0 and CC 32 stage the requested bank; only Program Change selects the new preset. The synth stores both bytes independently, so arrival order does not affect the combined bank.
- CC 121 resets the staged Bank Select bytes to zero but does not reset the active Program Change.

## UI

Open **Settings → Instruments → SF2 Bank Select / Program Change**.

1. Load an external `.sf2` with **Choose SoundFont (.sf2)…**.
2. Choose a part: R1, L, or R2.
3. Select a preset from the actual preset list, or enter MSB, LSB, and PC manually.
4. Press **Apply Bank + PC**.

The list is built from the loaded SF2 preset headers. Entries that do not exist in the loaded file are not sent. The status line displays the selected preset, 14-bit bank, and both the human PC value and actual MIDI byte.

R3 continues to mirror R2's bank/program selection, matching the existing voice-routing model; it does not yet have an independent SF2 selector.

## Runtime routing

The Native SF2 MIDI path forwards CC 0, CC 32, and Program Change on the same internal channel override used by note events. The SF2 synth uses the combined bank with TinySoundFont's channel bank/preset APIs. Drum-designated internal channels (MIDI channel 10 and the application's private rhythm channels) retain TinySoundFont's percussion-bank fallback behavior.

SCVA map/variation semantics are not reused for SF2. When the Native SF2 route is inactive, the existing SCVA/FluidSynth voice-bank behavior remains unchanged.

## Regression coverage

`tests/soundfont_external_bank_test.cpp` checks real LS-GM presets in multiple banks, including LSB bank 1, LSB bank 8, and MSB 1 / LSB 0 (SF2 bank 128). It verifies controller order independence, staged Bank Select behavior, Program Change commit, CC 121 behavior, and percussion-bank selection. The same loader test is also run against a second external SF2 when available.

`tests/sf2_bank_select_source_test.py` guards the UI ranges, PC conversion, MIDI event order, and AudioEngine forwarding path.
