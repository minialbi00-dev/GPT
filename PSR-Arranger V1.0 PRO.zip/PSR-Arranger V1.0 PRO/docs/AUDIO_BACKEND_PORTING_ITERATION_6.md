# Audio backend porting — Iteration 6 (2026-10-23)

## Implemented in this iteration

- **RtAudio host API picker.** The Settings dialog lists APIs compiled into the current RtAudio build, with an automatic/default API option.
- **Output device picker.** Enumerates RtAudio's actual device IDs (it does not assume IDs are sequential), filters to devices with at least two output channels, labels the system-default device, and lets the user return to default routing.
- **Sample-rate picker.** Uses the selected device's reported sample-rate list where available; provides conservative fallback values when the host API returns no list. The selected rate is also passed to FluidSynth.
- **Buffer-size picker.** Lets the user choose 64, 128, 256, 512, 1024, or 2048 frames. The engine bounds requests and records the frame count returned by RtAudio after opening the stream.
- **Active output status.** Displays the active device, API, sample rate, buffer size, and approximate per-buffer duration. The duration is an estimate, not a measurement of total end-to-end latency.
- **Refresh and test.** Refresh re-enumerates output devices. Test sound sends an A4 note to internal voice channel 17, and then sends note-off after 350 ms.
- **Persistent settings.** Host API, device ID (or system default), sample rate, and buffer frames are stored in `QSettings`.
- **Failure handling.** Both `openStream()` and `startStream()` return codes are checked. A candidate engine is initialized before replacing the active engine, so a failed device change does not discard the old stream.

## Important behavior notes

1. These controls configure the **internal FluidSynth + RtAudio route**. They do not change the Windows MIDI Mapper's hardware destination.
2. A device must expose at least stereo output. Mono-only destinations are intentionally omitted because the current render callback is stereo.
3. The sample-rate list is based on host-reported capabilities, but the actual open call remains the definitive compatibility check. A device or API can disappear after enumeration; in that case the error is shown and the previous active stream is preserved when one exists.
4. An SF2 SoundFont must be selected/available before the internal stream can start. Changing output controls without an available SoundFont stores the settings for the next successful initialization.
5. An RtAudio API may open successfully but still behave differently across WASAPI, DirectSound, ASIO, and other compiled host APIs. Buffer duration shown in the UI is only frames/sample-rate arithmetic and does not include device/driver buffering.

## Verification in this environment

- `python tests/audio_backend_source_smoke_test.py` — PASS (static source checks).
- `python tests/rtaudio_settings_source_test.py` — PASS (12 static source-contract checks).
- `python tests/qt_panel_source_smoke_test.py` — PASS (9 static checks).
- MIDI parser/writer and style-engine native tests — run separately; see `docs/PORTING_STATUS.md`.
- **Windows MSVC/Qt compilation: NOT RUN here.**
- **Physical device enumeration, device switching, audible test tone, and latency/glitch behavior on Windows: NOT TESTED here.**

This is an actual source implementation, not a claim of verified runtime behavior. Do not mark the RtAudio feature complete until the Windows build and test procedure in `docs/WINDOWS_HARDWARE_TEST.md` passes on the target machine.


## ASIO / ASIO4ALL detection fix (Iteration 6.1)

The prior manifest depended on plain `rtaudio`, which does not enable any optional vcpkg features by default. Consequently, `RtAudio::getCompiledApi()` did not list Windows ASIO and the Settings API selector could not show ASIO4ALL as an output device. The manifest now requests the vcpkg feature `rtaudio[asio]`. CMake's manifest mode will build/install this configured RtAudio variant on the next configure pass.

After rebuilding on Windows, Settings should list the compiled `Windows ASIO` host API when the feature built successfully. Select that API and refresh devices; the output device should be named by the installed ASIO driver (often `ASIO4ALL v2`). ASIO4ALL is an ASIO driver, not a separate RtAudio host API. The driver must be installed in matching x64 architecture for this x64 build. If `Windows ASIO` is still absent, inspect the vcpkg manifest install log for an ASIO feature/build failure; do not infer successful ASIO support only from the presence of ASIO4ALL in Windows.

This source/configuration change has been checked by a manifest contract test, but the ASIO backend has not been compiled or exercised on the user's Windows machine in this environment.
