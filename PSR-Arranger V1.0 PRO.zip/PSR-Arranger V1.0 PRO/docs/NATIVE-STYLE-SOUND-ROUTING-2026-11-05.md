# Native Style Sound Routing Fix — 2026-11-05

## Required routing contract

Ensembles 6.8.7 selects the native sound engine from the loaded external style extension:

| Style file | Required renderer | Forbidden renderers for style MIDI |
|---|---|---|
| Yamaha `.STY` / `.sty` | LS-GM Native C++ (`data/SoundFont/LS-GM.sf2`) | Native SCVA, VST2, FluidSynth, WinMM |
| Roland `.STL` / `.stl` | Native SCVA C++ (embedded `:/SCVA/SCCore.dll`) | LS-GM, VST2, FluidSynth, WinMM |
| Ensembles `.enstl` | Existing general audio route | No extension-specific override |

The renderer is chosen automatically when a style loads successfully. The style type is authoritative over the previous audio route selection.

## Root cause

The preceding integration provided an LS-GM option in Settings, but `applyStyleFile()` did not activate it based on the file being loaded. Normal startup initialized Native SCVA by default; consequently, a Yamaha `.STY` loaded while SCVA was active continued to send its arranger MIDI to SCVA. The MIDI sink's RHY1/RHY2 remapping only occurred when LS-GM was already active, so that remap could not fix the renderer-selection error.

## Changes

1. Added `activateNativeRendererForStyle()` to `main_qt.cpp`; it is called after a style has parsed successfully and before the loaded style is exposed as ready for playback.
2. `.STY` unloads active Native SCVA, VST2, or the experimental S-YXG renderer as applicable, then activates `LS-GM.sf2` in the existing RtAudio engine. It sets and persists the LS-GM route.
3. `.STL` unloads LS-GM and other exclusive renderers, reads the embedded SCVA core resource, and activates Native SCVA. It sets and persists the auto/SCVA route.
4. Added `AudioEngine::unloadNativeScva()` so SCVA can be safely removed before a Yamaha style is activated.
5. `loadNativeScvaFromMemory()` can now replace an active FluidSynth instance: it initializes the SCVA candidate first, stops RtAudio, disposes FluidSynth/settings while the callback is stopped, then activates SCVA and restarts the stream.
6. The Settings route selector now explains the automatic mapping. While a `.STY` or `.STL` is loaded, attempts to manually select another renderer are reverted.
7. `sendStyleMidi()` has a final route guard. Yamaha style events are dropped unless LS-GM is the active native renderer; Roland STL events are dropped unless Native SCVA is active. This prevents silent cross-routing.
8. Added `native_style_renderer_routing_source_test.py` and registered it with CTest.

## Validation performed

- AudioEngine compiled with `ENSEMBLES_HAS_NATIVE_SCVA=0` against local RtAudio/FluidSynth compatibility headers.
- AudioEngine compiled with `ENSEMBLES_HAS_NATIVE_SCVA=1` against the bundled NativeTS headers. Both builds produced only the pre-existing `std::filesystem::u8path` deprecation warnings.
- Seven new source routing checks passed.
- Yamaha runtime regression passed, including CASM Ctab-27 offsets, Root Fixed/Transpose bypass, preamble setup replay, channel 9–16 routing, RHY1/RHY2 isolation, Note-Off pairing, and StyleEngine routing.
- All 92 supplied Yamaha `.STY` files passed the StyleEngine real-time corpus test: 92 files produced notes, 92 files produced bank/program/controller setup; 1,844 note-ons and 10,837 setup events were observed.
- Roland `.STL` reader checks passed.
- The previous Step 5 parser/corpus fixes remain in the source package.

## Validation not performed

The complete Qt GUI was not compiled in this Linux authoring environment because Qt 6/MSVC Windows is unavailable. Physical Windows audio output and actual listening tests must still be performed on the target Windows PC. The routing contract is source-guarded and AudioEngine translation units compile in both native-SCVA feature configurations, but this report does not claim a complete Windows application build or speaker-level verification.

## Windows build

Extract this full package into a clean folder, then run `V19.0-Apply-Build-Run.bat`. Do not layer this source over an older extracted project tree; old CMake caches or source files can preserve the previous manual-only routing behavior.
