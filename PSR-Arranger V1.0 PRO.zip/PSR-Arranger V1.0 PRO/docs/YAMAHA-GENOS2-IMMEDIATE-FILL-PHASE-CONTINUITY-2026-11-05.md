# Ensembles 6.8.7 — Genos 2 Immediate Fill / Beat-Phase Continuity Fix

Date: 2026-11-05

## User-visible issue

The previous Fill scheduler treated every Fill request as a barline transition. A request issued in the middle of a Main measure was held until a later barline, and when the Fill finally started it always loaded source-pattern event zero. That made the Fill feel late and could restart the rhythmic phrase instead of preserving the beat grid.

## New behavior

### 1. Immediate / Self Fill

`CppArrangerEngine::queue_fill()` is now the Immediate Fill path:

- It stores an absolute `pending_fill_start_tick_` at the next beat boundary after the button request.
- The outgoing Main continues through the beat already in progress.
- At the next beat boundary, new Main Note-On/controller events are suppressed; pending Main Note-Offs are flushed.
- The Fill source pattern is anchored to the current measure downbeat and loaded at the matching in-bar phase (`load_state(requested, bar_start, phase)`).
- The Fill runs through the remainder of the existing measure; it does not reset the shared global tick, beat count, tempo clock, or barline.
- At the original next downbeat, the Fill ends and its destination Main starts at phase zero.

This implements the Genos 2 Reference Manual's Immediate concept: a section change takes effect on the next beat and the destination section receives the beat number at the change, then continues from that same beat. The implementation applies this to direct/self Fill, so a mid-bar trigger cuts over on the next beat without moving the bar grid.

### 2. Auto Fill In when changing to another Main

`queue_fill_next_bar()` is a separate policy used by Auto Fill In when selecting a different Main variation. It keeps Yamaha Genos 2's documented Next Bar behavior: a change after beat one waits for the next barline even when the general section-change timing is Immediate.

Re-pressing the currently active Main is treated as direct/self Fill and uses the Immediate path. Selecting a different Main while Auto Fill In is enabled uses the Next Bar path.

### 3. Section and note handling

- Fill XY destination mapping remains based on the second letter (for example, FILL AB returns to MAIN B).
- New notes from the outgoing Main are not layered over Fill.
- Existing Main Note-Offs at the transition point are still emitted.
- A further Main selection while a Fill is already playing changes the destination after the current Fill; it does not stack or restart another Fill.

## Regression tests added/updated

The synthetic Yamaha 4/4 fixture now has distinct notes on each beat of Main and Fill patterns. Tests verify:

| Request | Expected result |
|---|---|
| Immediate Fill requested at tick 700 | Enter at tick 960 (next beat), using Fill's beat-3 events |
| Same request | Remain on the original global bar grid; return to destination Main at tick 1920 |
| Immediate Fill requested at tick 1500 | Enter at tick 1920 (next downbeat), using Fill phase zero |
| Auto Fill requested at tick 700 | Next Bar path enters at tick 1920 |
| Press active Main again with Auto Fill off | Immediate/self Fill is heard |
| Press active Main again with Auto Fill on | Immediate/self Fill remains responsive |
| Change from Main A to Main B with Auto Fill on | FILL AB path is selected and uses Next Bar timing |

## Verification performed

- `yamaha-style-runtime-test`: passed (GCC C++17 build and run).
- `style_engine_test`: passed.
- `yamaha-sty-playback-corpus-test`: 92 Yamaha `.sty` files, zero failures; 92 files produced Note-On events and setup events; 1,844 Note-On events and 13,965 setup events total.
- `roland-stl-reader-test`: passed.
- `style_stop_midi_queue_source_test.py`: 17/17 source guards passed.
- `yamaha_style_picker_source_test.py`: all Yamaha picker/parser/panel checks passed.

The test fixture validates scheduler tick placement and emitted MIDI events, not acoustic equivalence against a physical Genos 2. A full Windows Qt/MSVC build and a live test with a Genos 2 remain necessary.

## Yamaha reference

- Genos2 Reference Manual, “Style Playback Related Settings,” printed page 11. It defines Immediate as changing at the next beat while carrying the beat number into the new section; Next Bar otherwise waits for the next measure, and Auto Fill In forces Next Bar behavior. Official PDF: https://data.yamaha.com/files/download/other_assets/1/2318561/Genos2_reference_manual_En_C0.pdf
- Genos2 Owner's Manual, “Playing with Styles—Operations While Performing,” printed page 67. It describes pressing the selected Main Variation again to play its Fill In and enabling Auto Fill In to play fills when selecting Main variations. Official PDF: https://usa.yamaha.com/files/download/other_assets/4/2318564/Genos2_owners_manual_En_D0.pdf
