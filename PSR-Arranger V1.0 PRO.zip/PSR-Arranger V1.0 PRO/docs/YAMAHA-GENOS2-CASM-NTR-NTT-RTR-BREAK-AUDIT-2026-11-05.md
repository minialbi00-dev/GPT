# Yamaha Genos2 BREAK / CASM / NTR / NTT / RTR — Audit & Partial Fix

Date: 2026-11-05  
Project: Ensembles 6.8.7  
Status: **partial compatibility work; not 1:1 certified**

## Important correction

Earlier patches and status notes described the BREAK behavior and CASM path too confidently. Passing local tests proves only the tested scheduler/parser cases; it does **not** establish acoustic or protocol equivalence with a physical Genos2. This audit deliberately separates verified implementation behavior from unresolved Genos2 behavior.

## Changes included in this partial patch

1. Yamaha SFF `Fill In BA` is normalized to the dedicated `BREAK` section. BREAK uses the same Immediate Fill policy: it is queued for the next beat, inherits the matching bar phase, and finishes at the current barline before returning to the active Main. A press in the final beat naturally activates at the next downbeat. If a normal Fill is already running, that Fill reaches its boundary first, then BREAK starts using the same phase rule.
2. The engine reacts to chord changes for held CASM notes for RTR modes it can represent directly:
   - `0 Stop`: sends Note-Off and consumes the later source Note-Off without sending a duplicate.
   - `3 Retrigger`: sends Note-Off then a newly transformed Note-On.
   - `4 Retrigger to Root`: sends Note-Off then a root-pitch Note-On in the existing octave; bass-role slash-bass handling is used only when the parsed flag is present.
3. Ctab NTR `Root Trans` now uses the Genos2 `High Key` octave crossover when the value is a valid pitch class: target roots at/below High Key transpose upward, roots above it transpose downward. If the high-key field is not a usable pitch class, the old nearest-interval fallback is retained.
4. Ctab byte 21 is treated as NTT selector, not as an NTT Bass flag. SFF GE `Cntt` records remain the source for NTT Bass state and override NTT by destination channel.

## Verified by the current tests

- C++17 direct build of the Yamaha runtime + arranger + StyleEngine test executable.
- BREAK tests built around the real Yamaha marker spelling `Fill In BA`: recognition, next-beat activation, mid-measure phase carry, final-beat/downbeat activation, current-barline return to Main, and queued BREAK after a running Fill.
- RTR tests for Stop, Retrigger, and Retrigger to Root.
- Ctab High Key crossover test (F boundary: D moves up; G moves down from source C).
- Existing StyleEngine, MIDI queue, Genos2 button/indicator, Roland UI, Yamaha Style picker, and native renderer routing source tests.

The full test commands and counts are in `YAMAHA-GENOS2-CASM-NTR-NTT-RTR-BREAK-VERIFICATION-2026-11-05.txt`.

## Known gaps — why this is not 1:1 yet

### CASM / source pattern

- `source_type` is parsed from Ctab but not used to reconstruct the original source-chord voicing. The current input chord type is also reduced from the app's 12 labels to seven transform families; sus2, sus4, sixth and add9 fall back to the major family, and ninth falls back to dominant seventh.
- Ctab note-mute and chord-mute masks (the bytes before Source Root/Source Chord) are not applied to note/chord selection.
- The current Yamaha UI path calls `set_chord(root, type)` without a slash-bass note. Therefore it cannot fully implement Genos2 NTT Bass/on-bass behavior from the actual detected slash chord.
- NTR Guitar is still an approximation. Real guitar fingering/voicing and its All Purpose / Stroke / Arpeggio tables are not implemented.
- Note Limit is applied as a generic octave-fit operation; it has not been compared against Yamaha's per-part Voice/range behavior.

### NTT

Genos2 documents Bypass, Melody, Chord, Melodic Minor, Melodic Minor 5th, Harmonic Minor, Harmonic Minor 5th, Natural Minor, Natural Minor 5th, Dorian and Dorian 5th, plus Guitar-specific tables. The current runtime does not implement these as separate Yamaha tables. Most non-bypass values still share a simplified seven-family map; the special handling of NTT value 2 is only a heuristic, not Yamaha's complete Chord or Guitar table behavior.

### Ctb2 / SFF2

The bundled `data/StyleFiles` corpus contains 92 Yamaha style files and was rescanned after correcting the Yamaha `Fill In BA` alias on 2026-11-05:

- `CASM`: 92 occurrences
- `Ctab`: 6,261 occurrences
- `Cntt`: 660 occurrences
- `Ctb2`: 0 occurrences
- `Fill In BA` / dedicated BREAK sections: 84 of 92 Yamaha files are recognized by the runtime after normalization; the previous parser recognized 0 as BREAK.

Consequently, local tests exercise Ctab/Cntt but provide no real Ctb2 fixture. The current Ctb2 multi-slot interpretation and slot selection are not validated against a Genos2 melodic Ctb2 table. Do not treat Ctb2 playback as 1:1.

### RTR

- RTR 0, 3 and 4 now have direct event-level handling and synthetic regression tests.
- Historical status at the time of this 2026-11-05 audit: RTR 1 Pitch Shift and RTR 2 Pitch Shift to Root were not implemented; held-note routing only handled RTR 0, 3 and 4.
- **Superseded by `YAMAHA-CASM-RTR-HELD-NOTE-CHORD-UPDATE-2026-11-06.md`:** RTR 1/2 now recalculate the held voice target on chord changes and use a same-tick Note-Off/Note-On fallback, with current note-off remapping. This is not Genos2's continuous no-new-attack pitch bend.
- Held-note Ctb2 slot selection is now based on the original source note's Low/Middle/High range; direct Genos2 behavior still needs A/B validation.

### BREAK

The Genos2 Owner's Manual confirms the Break pattern and automatic return to Main, but does not specify the exact button-press quantization threshold. The implementation follows the user's explicit correction and the existing Immediate Fill scheduler: next beat, phase carry, and return on the current barline. A physical Genos2 MIDI OUT capture/A-B test is still required to prove exact hardware identity. The current corrected timing is detailed in `GENOS2-BREAK-IMMEDIATE-FILL-TIMING-CORRECTION-2026-11-05.md`.

## Official reference basis

- Yamaha Genos2 Owner's Manual, BREAK: one-measure pattern then return to Main.
- Yamaha Genos2 Reference Manual, Styles / SFF Edit, pages 28–31: Source Root/Chord, NTR, NTT, NTT Bass, High Key, Note Limit and RTR descriptions.

The manuals describe the intended instrument behavior, but do not publish all internal per-note conversion tables or the complete SFF GE Ctb2 binary layout. This patch therefore does not claim that the undocumented portions have been reverse-engineered completely.

## Required evidence to complete 1:1 validation

- Real Genos2 `.sty` fixtures containing varied Ctab/Ctb2 records (including melodic Ctb2 with all low/middle/high ranges), across multiple sections.
- A Genos2 MIDI OUT capture or controlled audio recording for chord changes covering each NTR/NTT/RTR mode, slash chords, source chord variants, and note limits.
- A/B event comparison at multiple BREAK press positions across the measure, including during Main and Fill playback.
- A Windows/MSVC Qt build and playback test with the intended sound renderer.

Until those checks are completed, the implementation status remains **partial**, not “1:1 Genos2”.
