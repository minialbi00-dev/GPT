# LS-GM Native Realtime Integration — Ensembles 6.8.7

## What changed

- Vendored the native C++20 `lsgm::Sf2Synth` into `src/SoundFont/`.
- Bundled `data/SoundFont/LS-GM.sf2`; CMake copies it beside the executable under `data/SoundFont/`.
- Copied the 92 supplied `.sty` files into the flat built-in `data/StyleFiles/` folder under an `LS-GM -` prefix so Ensembles discovers them in the existing style picker and groups them as **LS-GM**.
- Added `AudioEngine::loadLsGmNativeSoundFont()` / `unloadLsGmNativeSoundFont()` and an exclusive LS-GM callback route.
- Timed MIDI commands are rendered in sample-offset segments. This means the existing Ensembles `StyleEngine` can drive the native sampler through its existing `sendMidiAt()` sink.
- Expanded sampler MIDI channel state from 16 to 64 channels so Ensembles keyboard layers on internal channels 16–22 continue to work while style parts occupy channels 0–15.
- Added `LS-GM Native C++ (LS-GM.sf2) + RtAudio` to the Audio Output Routing selector. Selecting it loads the bundled bank; the existing arranger Start/Stop, Intro, Main, Fill, Break, Ending, chord recognition, tempo and section-transition logic continue to be supplied by Ensembles' existing `StyleEngine`.
- In this route, MIDI is not duplicated to Windows MIDI, FluidSynth, VST2, or the previous Yamaha renderer.

## Runtime flow

`Ensembles StyleEngine` → timestamped MIDI queue (`AudioEngine::sendMidiAt`) → RtAudio callback → native `lsgm::Sf2Synth` → stereo output.

Keyboard/live part MIDI with internal channel overrides 16–22 is also accepted by the 64-channel sampler.

## Verification performed

- GCC C++20 compiled `audio_engine.cpp` against RtAudio/FluidSynth compatibility stubs with `ENSEMBLES_HAS_NATIVE_SCVA=0`; only the pre-existing `std::filesystem::u8path` deprecation warnings remained.
- Native SF2 sampler test passed: 308 presets loaded, MIDI channel 17 rendered non-zero audio, and audio remained silent before the simulated sample-offset note-on deadline.
- End-to-end `AudioEngine` callback harness passed with a device stub: initialized an audio-only RtAudio stream, loaded the SF2 native route, queued MIDI on internal channel 17, invoked the production audio callback, and measured non-zero output. The same callback harness passed ASan/UBSan with leak detection. This validates the callback path, not a physical speaker/device in this container.
- The original LS-GM regression suite passed: 308 presets, 15 sections, 18 CASM parts, 92 `.sty` files scanned, and 284 style events dispatched in the render test.
- Ensembles `StyleEngine` loaded all 92 copied `.sty` files with zero failures.
- Existing `style-engine-test` passed its arranger, chord finder, transposition, long-duration timing, intro/variation/fill/ending, sync-start/stop and live style replacement checks.
- Existing `yamaha-style-runtime-test` passed PSR-S parser, CASM, channel 9–16 routing, RHY1/RHY2 isolation, note-off pairing and StyleEngine routing checks.
- AddressSanitizer + UndefinedBehaviorSanitizer test passed with leak detection enabled.

## Windows CMake build correction (2026-11-05)

A Windows/MSVC build log exposed a packaging issue: the three LS-GM translation units include headers as `SoundFont/<name>.hpp`, but the application target did not have `src/` on its private include search path. The full source package now includes this correction directly in `CMakeLists.txt` immediately after the `AUTORCC` target property:

```cmake
target_include_directories(ensembles-cpp PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
```

This correction is part of the complete project ZIP; no separate hotfix script is required. The user's configure stage completed, and the log showed `audio_engine.cpp` and `main_qt.cpp` compiling before Ninja stopped at the three missing LS-GM headers. The corrected package has not yet been validated by a complete Windows/MSVC application build, so a successful executable build and physical audio test are not claimed.

## Build limitation

The full Ensembles Qt application was not built in this Linux environment because Qt6 development files (`Qt6Config.cmake`) are not installed. The CMake configuration fails at `find_package(Qt6 6.0 REQUIRED COMPONENTS Widgets)`. Therefore the Qt UI and Windows/MSVC executable still require a full build on the user's Windows development environment.

## Scope boundary

This integration reuses Ensembles' existing real-time arranger and chord/section logic, including its `YamahaStyleRuntime` / `CppArrangerEngine` CASM path; it does not replace that logic. The LS-GM sampler renders the MIDI produced by the existing `StyleEngine`. The SF2 playback implementation is a supported subset for the supplied LS-GM bank, not a claim of full SF2 2.04 conformance.

## Yamaha `.STY` playback corrections — 2026-11-05 (Step 5)

The first integration proved that the native LS-GM sampler could render MIDI and that the supplied style files could be loaded. It did **not** prove that Yamaha arranger setup and CASM transformations were being applied correctly. The following corrections now sit in the actual `YamahaStyleRuntime` / `CppArrangerEngine` → `StyleEngine` playback path:

- **SFF1 `Ctab` parsing:** `NTR` and `NTT` are read from byte offsets 20 and 21. The previous parser mistakenly read the editable and note-mute bytes at offsets 10 and 11 as `NTR`/`NTT`, corrupting chord-follow behavior across many parts. The 27-byte table fields for High Key, Note Limit Low/High and RTR are also retained.
- **Metadata marker filtering:** `SFF1` and `SInt` are no longer exposed as playable arranger sections. Only recognized Yamaha section markers are used to build the arranger timeline. Events are globally sorted by tick and track after parsing format-1 MIDI files.
- **Startup preamble replay:** Bank Select (CC0/CC32), Program Change, setup controllers, channel pressure and pitch bend that occur before the first real arranger marker are replayed at start, before the first section's note events. Notes from the preamble are intentionally not replayed.
- **NTR handling:** Root Transpose (NTR 0) applies the root interval; Root Fixed (NTR 1) no longer receives the same root shift. NTT Bypass leaves the incoming pitch unchanged for Root Fixed and applies only the root interval for Root Transpose. For Root Fixed with a chord table, octave selection now chooses the closest legal chord pitch to the original register instead of always flooring to the lower octave. Guitar NTR and other Yamaha NTT modes remain a practical subset rather than a claim of exact keyboard-firmware equivalence.
- **Percussion isolation:** `CC_Crash` and other named percussion roles are identified as rhythm parts. Yamaha RHY1/RHY2 output channels 8/9 are routed to private LS-GM synth channels 40/41, each forced to the bundled Live-Styler percussion preset (bank 128, program 0). This preserves independent note/controller state for both drum parts without consuming Ensembles' keyboard-layer channels 16–22. The chord fader no longer attenuates either Yamaha rhythm channel. This private-channel remap is guarded by both Yamaha-style-active and LS-GM-native-active checks; Roland `.STL` / SCVA routing is not altered.

### Step 5 verification performed

- `yamaha_style_runtime_test` was expanded and passed: SFF1/SInt marker filtering, exact Ctab-27 NTR/NTT offsets, Root Transpose + Bypass, Root Fixed + Bypass, Root Fixed chord voicing register, preamble bank/program/controller order, prior Ctb2 fixture, arranger transitions, part/channel routing and Note-Off pairing.
- Existing `style-engine-test` passed unchanged.
- Full supplied `.sty` corpus passed the actual `YamahaStyleRuntime` + `CppArrangerEngine` path: **92 files, 0 failures, 1,293 real sections; all 92 emitted setup data, and all produced note events in the initial playback window.**
- Full supplied `.sty` corpus passed the actual `StyleEngine::play()` / `advanceMicroseconds()` MIDI sink path: **92 files, 0 failures; all 92 produced notes and channel setup events (1,844 note-ons and 10,837 setup events during the test window).** This is now preserved as the `yamaha-sty-real-time-playback-corpus` CTest target.
- Native SF2 dual-rhythm check passed: both private LS-GM channels 40/41 rendered non-zero output from the bundled `LS-GM.sf2` (308 presets).
- Physical Windows output, the full MSVC/Qt application build, and listening tests are still required. The container has no Qt6 development package and cannot run a Windows audio device; no such verification is claimed.

## Current Yamaha `.STY` runtime path

`Yamaha .STY` → SMF/marker + SFF1 CASM parser → startup setup replay → Yamaha arranger section scheduler → corrected CASM NTR/NTT transformation and destination-channel mapping → `StyleEngine` MIDI sink → private RHY1/RHY2 sampler channels 40/41 plus melodic channels → exclusive native `lsgm::Sf2Synth` → RtAudio.

Step 5 originally required manually selecting LS-GM in Audio Output Routing. That manual requirement was removed in Step 6: loading a Yamaha `.STY` now automatically activates LS-GM Native C++, while loading Roland `.STL` automatically activates Native SCVA. Load a Yamaha `.STY`, enable Chords/Accompaniment, and press Start. See `NATIVE-STYLE-SOUND-ROUTING-2026-11-05.md` for the format-locked renderer policy.
