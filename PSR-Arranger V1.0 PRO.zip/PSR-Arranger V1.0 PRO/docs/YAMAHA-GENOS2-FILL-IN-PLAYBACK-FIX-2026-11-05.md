# Yamaha Genos 2 Fill-In and Style Stop Safety Fix — 2026-11-05

## Corrected defects

1. **Fill bar timing:** `CppArrangerEngine::queue_fill()` now applies Genos 2 Next Bar policy: a request during beat one can take effect immediately; a request after beat one is deferred to the next measure downbeat. Deferred fills start at event zero and receive a complete measure.
2. **Immediate Yamaha Style Stop:** Yamaha Stop emits CC120 (All Sounds Off), CC64=0 (Sustain Off), and CC123 (All Notes Off) on all 16 Style channels with target time zero. Stop no longer relies only on release-style Note-Off/All Notes Off behavior.
3. **Timed Style MIDI cancellation:** all Style-origin MIDI commands are tagged with a generation in RtAudio. Stop increments that generation, so stale commands are discarded in the GUI-to-audio queue, pending deadline queue, and already-extracted callback events. Live keyboard MIDI is not tagged and is not cancelled.
4. **Windows WinMM deadline cancellation:** scheduled Style events carry a separate generation. Stop removes queued Style events and the worker drops a stale Style event even if it was already dequeued; non-Style MIDI messages remain intact.
5. **Hard-stop deadline:** panic messages are emitted at deadline zero, not at a beat timestamp inherited from the last transport tick.

## Regression coverage

- Yamaha arranger fixture: first-beat Fill can start immediately; beat-two and late-beat Fill wait for the next barline.
- Deferred Fill plays its first event at the new barline, is not layered with Main notes, and returns to its destination Main after one complete measure.
- Style Stop fixture: all 16 channels receive immediate CC120, CC64=0, and CC123=0.
- Source guards verify stale scheduled Style MIDI is invalidated in both RtAudio and WinMM paths without tagging live keyboard MIDI.

## Yamaha behavior reference

The Yamaha Genos 2 Reference Manual (Style Playback Related Settings, printed page 12) says Next Bar changes immediately if the operation is done within the first subsequent beat; otherwise it changes at the beginning of the next bar. Auto Fill In forces Next Bar even when Immediate is selected. The implementation follows that first-beat threshold.

## Verification boundary

The C++ Yamaha runtime and StyleEngine tests are intended to be built/run with the project's CMake test targets. The full Qt/MSVC GUI and physical WinMM/RtAudio device behavior still need to be confirmed on the target Windows machine.
