# Ensembles 6.8.7 V19.0 — Reference Icon + Chord/Auto Fill Size Correction

## Corrections from the user's reference screenshot

- Chord and Auto Fill caps changed from 36 x 42 px to **34 x 32 px**. Their captions remain above the cap; the LED remains the only state indicator.
- Intro, Variation, Break, Ending, Sync Stop, Sync Start, and Start/Stop dimensions are unchanged from the previously accepted dimensions.
- Sync Stop icon changed from horizontal stripes to the Yamaha-style upright-bar motif.
- Sync Start icon uses the same upright-bar motif plus a downward trigger triangle.
- Start/Stop icon is a compact stop block / diagonal separator / right-facing play triangle composition.
- Icon geometry is vector-painted and antialiased. No glyph-font dependency is introduced.
- Button interaction wiring and LED state logic are unchanged.

## Verification

Passed:
- `tests/panel_v20_arranger_hardware_buttons_test.py` (7 tests)
- `tests/panel_v21_hardware_button_smoothing_alignment_test.py` (4 tests)

`tests/qt_panel_source_smoke_test.py` still reports two unrelated existing failures concerning Layer MIDI channel routing and unported automators. They are not caused by this visual patch and were not changed.

A Windows Qt/MSVC render/build was not available in this environment, so final pixel-level confirmation must be done in the user's Windows build.
