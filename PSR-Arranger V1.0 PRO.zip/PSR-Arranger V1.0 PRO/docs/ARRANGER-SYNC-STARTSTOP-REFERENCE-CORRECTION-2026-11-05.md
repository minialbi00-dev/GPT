# Arranger Sync / Start-Stop Reference Correction

Date: 2026-11-05

## Changes

- `Sync Stop`, `Sync Start`, and `Start/Stop` groups are fixed at 54 px high and top-aligned in the transport row, matching the `Ending` section rail (10 px caption + 2 px gap + 42 px cap).
- `Sync Stop` icon follows the supplied close-up: three compact horizontal bars above a compact stop block, with a narrow cyan edge accent.
- `Sync Start` icon follows the supplied close-up: three compact horizontal bars above a filled downward triangle.
- `Start/Stop` uses the compact stop-square / rising diagonal / play-triangle composition, with a cyan edge accent on the stop square.
- Button dimensions and engine signal wiring are unchanged: section buttons 38x42 px, Sync buttons 45x42 px, Start/Stop 60x42 px. Chord and Auto Fill sizing is unchanged by this correction.

## Verification

Passed:

- `python tests/panel_v20_arranger_hardware_buttons_test.py` — 7/7
- `python tests/panel_v21_hardware_button_smoothing_alignment_test.py` — 4/4

`python tests/qt_panel_source_smoke_test.py` reports two source invariants outside this visual correction:

- Layer routes a second right-hand note on MIDI channel 3
- unported automators are disabled rather than pretending to work

No Windows Qt/MSVC build or running GUI screenshot was produced in this environment. The patch is source-verified; final pixel-level placement should be confirmed in the Windows build.
