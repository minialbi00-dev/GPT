Ensembles 6.8.7 — Simplified Mixer Panel V15
==========================================

Purpose
-------
Reduce redundant default volume/effect assignments in the left control panel so users can understand each control without opening the Assign dialog.

Simplified faders 1–10
----------------------
1. Voice Vol — changes CC7 for Voice L, Voice R1, and Voice R2 together.
2. Style — changes accompaniment volume independently from keyboard voices.
3. Drum — changes MIDI channel 10 drum volume independently from other style channels.
4. Expr. — CC11 for the selected Voice part.
5. Rev Send — CC91 send for the selected Voice part.
6. Ch Send — CC93 send for the selected Voice part.
7. Cutoff — CC74 for the selected Voice part.
8. Reso — CC71 for the selected Voice part.
9. Pan — CC10 for the selected Voice part.
10. Mod — CC1 for the selected Voice part.

Knobs 1–4
----------
Attack (CC73), Release (CC72), Vib Rate (CC76), Vib Depth (CC77), all directed to the selected Voice part. These avoid duplicating the Pan/Mod/Reverb/Chorus fader targets.

Master knob
-----------
Master Vol only controls application output level. It is not duplicated by any fader.

Effects terminology
------------------
The right-side Reverb FX and Chorus FX controls enable/set the internal global effect processor. Rev Send and Ch Send faders send MIDI CC91/CC93 to the selected voice part. These are different controls with clearly differentiated labels.

Migration
---------
On first launch, unchanged V14 default assignments are converted once to the simplified V15 map. Settings that differ from the prior default-map signature are treated as custom user assignments and retained. The migration version is then stored, so later launches do not reset settings.

Build and launch
----------------
Run Rebuild-And-Run-Simplified-Mixer-V15.bat from this overlay. It uses the existing build-qt-audio-ninja folder, validates source tests, touches main_qt.cpp/audio_engine.cpp to force recompilation, builds ensembles-cpp and launches normal mode (audio is not intentionally skipped).

Validation performed here
-------------------------
The source checks for simplified defaults/labels/migration and the V14 output-gain checks pass in the authoring environment. This is not a substitute for compiling the Qt/MSVC target and listening to the actual Windows output.
