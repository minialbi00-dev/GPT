# Ensembles 6.8.7 — S-YXG2006LE Native C++ Integration

## Current implementation

### Bank/program index

- `Xg2006LeBankTable` reads the uncompressed `UTG VPRM` index section of `sxgbnw6l.tbl`.
- The supplied file was tested from disk (not only against a synthetic fixture).
- Result: header valid; 950 bank/program entries are marked present; bank 0/0 program 0 is present with compact voice index 402.
- The parser does not touch waveform payload bytes and does not treat the bank index as PCM.

### Native PCM renderer

- `Syxg2006LeNativeRenderer` is a C++ renderer for PCM zones supplied by an `XGPCM1` manifest. WAV import accepts mono/stereo PCM 8/16/24/32-bit and IEEE float32 at 8–192 kHz; stereo assets are downmixed to the current mono voice representation.
- It supports 16 MIDI parts, bank/program mapping through the parsed table, key and velocity layers, 256-voice allocation, looping and natural one-shots, linear interpolation, pitch bend, volume, expression, equal-power pan, per-zone ADSR, sustain pedal, all-notes-off and all-sounds-off.
- Per-voice state-variable low-pass filtering responds to CC74/CC71. CC91/CC93 feed preallocated stereo reverb/chorus delay lines. Channel 10 percussion ignores NoteOff so drum samples play through their one-shot duration.
- The basic delay effects are functional native C++ sends, not verified parity with Yamaha's full XG DSP/effect-type engine.
- Wave files and manifests are loaded before the callback is resumed. The audio render path performs no file I/O and creates no per-block dynamic allocations.
- `XGPCM1` is an interchange manifest. It is not the native format of `sxgdat6l.tbl`.

### Ensembles audio integration

- `AudioEngine` loads the renderer on the existing stereo RtAudio stream.
- The renderer is selected exclusively in the callback. Timed MIDI is applied at its scheduled frame offset, and renderer output is written into the same stereo output buffer before the existing master output stage.
- While selected, MIDI is not forwarded to Native SCVA, VST2, or FluidSynth. Enabling this startup mode also uses device-only RtAudio initialization; FluidSynth is not instantiated as a fallback.
- To select this mode at startup, set both environment variables:

```bat
set ENSEMBLES_SYXG2006LE_BANK=C:\Ensembles\Yamaha2006LE\sxgbnw6l.tbl
set ENSEMBLES_SYXG2006LE_PCM_MANIFEST=C:\Ensembles\Yamaha2006LE\xgpcm-bank.csv
Ensembles.exe
```

- If either variable is absent or renderer loading fails, startup reports an error and does not silently switch to another synthesizer.

## Validation performed

- Standalone native renderer tests pass: bank parser fixture, multiple velocity zones, PCM16 mono and PCM24 stereo WAV import, non-zero stereo PCM, sustain/pedal release, independent parts, reverb/chorus wet tail, and XG channel-10 one-shot behavior.
- The same standalone tests pass with AddressSanitizer and UndefinedBehaviorSanitizer, including leak detection.
- `audio_engine.cpp` compiles as a C++20 object against interface-compatible RtAudio/FluidSynth stubs. Only pre-existing `std::filesystem::u8path` deprecation warnings were emitted.
- The real supplied `sxgbnw6l.tbl` was parsed successfully: `valid=1 voices=950 bank00=1 piano=1 pianoIndex=402`.
- The complete Qt application build was not verified in this container because the Qt6 development package/config was unavailable.

## Important current limitation

The implementation does **not** yet parse or render the original waveform payload in `sxgdat6l.tbl`. The renderer currently consumes `XGPCM1` plus external WAV zones. Therefore the C++ renderer, 16-part MIDI handling, sample-zone mapping, basic native filter/effect processing and exclusive RtAudio mixer route are implemented and tested, but the original factory S-YXG2006LE instrument sound is **not yet playable from the two Yamaha `.tbl` files alone**. The generated sine fixture in the test proves that the native PCM pipeline produces sound; it is not a Yamaha sound-bank test.

No result in this report should be interpreted as a verified full S-YXG2006LE waveform parser or a successful full Qt/Windows application build.
