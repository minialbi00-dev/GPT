# External SF2 loader repair — 2026-11-07

## Root causes addressed

1. The previous native SF2 implementation used a narrower custom parser. It has been replaced by TinySoundFont (the parser/sampler included in the supplied `cpp.zip` reference) while preserving the V20 `Sf2Synth` API.
2. The previous UI selection path constructed a second `AudioEngine` while the existing RtAudio stream could still own the selected output device. On exclusive/shared-mode-sensitive Windows drivers, this can prevent the new stream from opening. The active UI path now reuses the existing `AudioEngine` and calls `loadNativeSoundFont()` directly. The sampler loads a candidate first, pauses the existing RtAudio stream, swaps the sampler, then restarts the same stream.
3. Choosing an SF2 explicitly switches the active instrument route to Native SF2. If VST2, native SCVA, or the Yamaha native PCM renderer currently owns the route, the chooser attempts to unload that renderer before loading the selected SF2. Roland `.STL` keeps its SCVA route and only remembers the selected SF2 for the next non-STL session.

## Loader implementation

- `src/SoundFont/tsf.h` is TinySoundFont v0.9 from the supplied reference source.
- `src/SoundFont/sf2_synth.cpp` compiles the TinySoundFont implementation and loads with `tsf_load_memory_mapped()`.
- Windows uses `CreateFileW` / `CreateFileMappingW` / `MapViewOfFile`; POSIX uses `open` / `mmap`. The UTF-8 path is converted to `std::filesystem::path`.
- The mapping remains alive for the entire lifetime of the TSF sampler because the sample data is referenced from the mapped SF2 file. Destruction order closes TSF before unmapping the file.
- The sampler allocates a bounded 1024-voice pool before it is installed on the audio callback.
- Candidate bank loading is transactional: a parsing/voice-allocation failure leaves the previously active bank intact.
- CMake explicitly lists `tsf.h` for the application and native sampler tests.

## UI workflow

1. Open **Settings → Plugins → Choose SoundFont (.sf2)**.
2. Choose a complete RIFF/SFBK `.sf2` file. Git-LFS pointer text and non-SF2 files are rejected.
3. On success, the status reports the filename and preset count; output routing is set to Native C++ SF2 and the absolute path is saved in QSettings.
4. The selected external bank is preferred for Yamaha `.STY/.PRS/.SST/...` playback on startup. If no external selection exists, bundled `LS-GM.sf2` remains the default.

## Verification performed

- `soundfont_external_bank_test.cpp` compiled and passed with the bundled LS-GM bank (308 presets).
- The same external-bank test passed with the independent third-party `/usr/share/sounds/sf2/TimGM6mb.sf2` bank (136 presets; program 0:73, Flute TB). This exercises a bank that is not the bundled LS-GM. The test verifies UTF-8 temporary path, mapped-sample lifetime after the original path is renamed, audible render energy, and rollback after a deliberately malformed Hydra table.
- `soundfont_native_engine_test.cpp` compiled and passed with LS-GM: 308 presets and non-zero render energy after the note-on deadline.
- `soundfont_external_path_source_test.py` and `soundfont_mmap_source_test.py` passed.
- Audio backend, scheduler/Stop queue, Yamaha renderer routing, Style List and LCD geometry source tests passed.

## Remaining validation limits

- The current Linux environment does not have Qt 6 Development files, so the full GUI target could not be configured or compiled here. The Windows/MSVC build and the actual Settings dialog still need validation on the target Windows machine.
- TinySoundFont v0.9 does not implement every SF2 feature (notably full modulator/effect-send behavior). The tested banks load and render, but this is not a claim of complete SoundFont 2.04 feature coverage for every vendor bank.
- No CASM, Yamaha StyleEngine, scheduler, LCD geometry, LS-GM terminology, or Native SCVA source was changed by this repair.
