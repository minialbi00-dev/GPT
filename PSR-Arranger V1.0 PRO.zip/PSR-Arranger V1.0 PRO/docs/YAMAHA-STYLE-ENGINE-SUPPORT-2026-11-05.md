# Ensembles 6.8.7 — Yamaha PSR-S / PSR-SX / Genos 2 Style Engine

Date: 2026-11-05

## Direction

This milestone focuses the arranger playback path on Yamaha Style files used by PSR-S, PSR-SX and Genos-family keyboards. The arranger panel now follows the Yamaha section count: Intro 1–3, Main Variation A–D, Fill A–D, Break, and Ending 1–3. Intro 4 and Ending 4 have been removed. Yamaha Intro C and Ending C use their own section slots; they are not aliases of Intro A or Ending A.

## Recognized single-style extensions

| Extension | Yamaha category | Current playback path |
|---|---|---|
| `.STY` | Standard | Yamaha SMF/CASM runtime |
| `.BCS` | Basic | Yamaha SMF/CASM runtime |
| `.PRS` | Pro / Professional | Yamaha SMF/CASM runtime |
| `.SST` | Session | Yamaha SMF/CASM runtime |
| `.FPS` | Free Play | Yamaha SMF/CASM runtime |
| `.PST` | Pianist | Yamaha SMF/CASM runtime |
| `.PCS` | Piano Combo | Yamaha SMF/CASM runtime |
| `.SCP` | DJ | Yamaha SMF/CASM runtime |
| `.AUS` | Audio Style / Audio Phraser source | Container and Audio Part metadata recognized; audio playback is not yet implemented |

The extension identifies a Yamaha Style category. It is not used as the SFF version detector. SFF1 / SFF GE classification is based on markers and internal Yamaha metadata (for example Ctb2, Cntt and Audio Style chunks).

Expansion-package/container extensions such as `.YEP` and `.PPI` are intentionally not classified as individual Style files. An expansion-package importer is a separate feature.

## Parser / runtime work in this milestone

- Case-insensitive recognition of all nine single-style suffixes in the picker and StyleEngine dispatch.
- SMF format 0 and 1 parsing, tempo/time-signature metadata, marker sections, setup preamble and track role routing.
- Yamaha appended chunk scanning for CASM, OTSc, FNRc, AASM and AFil.
- CASM parsing across multiple CSEG groups, including Sdec, 27-byte Ctab, the recognized 47-byte Ctb2 shape, and multiple Cntt channel records.
- Cntt is matched by destination channel; its NTT selector overrides the corresponding Ctab/Ctb2 slot values and its high bit carries the bass-on flag.
- The final MTrk boundary can be recovered from an EOT event immediately followed by a valid Yamaha extension chunk. This handles real SFF GE files whose declared final MTrk length overlaps CASM.
- Audio-only .AUS is identified and refused by the MIDI-only playback path with an explicit diagnostic instead of silently producing empty or misleading playback.
- A MIDI-based Live Audio .STY may continue through its MIDI lanes; its Audio Part is surfaced in the UI as detected but not rendered.

## Playback sections

- Intro A / B / C
- Main A / B / C / D
- Fill AA / AB / AC / AD, BA / BB / BC / BD, CA / CB / CC / CD, DA / DB / DC / DD (according to the section markers supplied by a style)
- Break
- Ending A / B / C

The UI exposes four Main Variations and three Intro / three Ending controls. Not every file contains every section; the runtime must use section markers actually found in the loaded style.

## Verification performed in this workspace

- Yamaha Style runtime C++ regression passed, including Ctab byte offsets, Cntt NTT override / bass-on, multiple CSEG groups, the final-MTrk/CASM-overlap case, setup preamble replay, channels 9–16, RHY1/RHY2 isolation and Note-Off pairing.
- StyleEngine C++ regression passed, including arranger transitions, Fill scheduling, Sync Start / Stop and live Style replacement.
- Roland STL reader regression passed; the separate Roland path remains intact.
- Shipped Yamaha `.sty` corpus: 92 files scanned, 0 failures, all 92 produced note-ons and setup events (1,844 note-ons; 10,837 setup events).
- Source tests passed for Yamaha picker / routing, Roland UI compatibility and PSR-S panel indicators.

## Important limitations — not yet full Yamaha hardware emulation

1. `.AUS` AASM/AFil metadata is detected, but the Audio Part decoder, beat-grid (AInf/BPnt) scheduling, pitch-preserving time stretch and live audio mixing are not implemented. Audio-only `.AUS` playback is therefore not claimed as supported.
2. OTSc and FNRc are detected as chunks but their full One Touch Setting / function-record payloads are not yet decoded into UI state.
3. The Ctb2 rhythm-table layout is recognized, but all Ctb2 melodic-part layouts have not been independently verified against a broad device corpus.
4. NTR/NTT conversion is an implemented subset, not a bit-perfect copy of every Yamaha chord family, Guitar voicing, retrigger rule, note-limit edge case or model-specific behavior.
5. The regression corpus available in this source package contains 92 `.sty` files. Real `.prs`, `.sst`, `.bcs`, `.fps`, `.pst`, `.pcs`, `.scp` and `.aus` files from multiple generations are still needed for extension-by-extension hardware validation. The eight MIDI suffixes use the same SMF/CASM parser path and were also tested using a representative MIDI Style fixture with each suffix.
6. A full Qt/MSVC Windows application build and playback on physical PSR-S / PSR-SX / Genos 2 hardware were not executed in this Linux build environment. Run the supplied Windows build script and perform instrument-level A/B testing before treating the result as release-certified.

## Next engineering order

1. Collect real SFF1 and SFF GE fixtures from PSR-S, PSR-SX and Genos 2, including all supported file categories.
2. Validate all Ctab/Ctb2/Cntt layouts and complete NTR/NTT/RTR rules against Yamaha reference behavior.
3. Decode AASM/AFil, the embedded WAVE blocks and AInf/BPnt beat grid; implement pitch-preserving time stretch and audio part scheduling.
4. Decode OTSc / OTS voice and effect assignments, then verify bank/program/voice behavior with the selected sound engine.
5. Compare known chord progressions, fills, tempo changes and ending transitions against the physical Yamaha instruments.
