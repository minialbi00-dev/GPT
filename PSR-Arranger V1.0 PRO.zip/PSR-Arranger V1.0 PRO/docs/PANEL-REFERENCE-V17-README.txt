ENSEMBLES 6.8.7 — PANEL FUNCTIONAL FIX V17.2 — TARGET LAYOUT
=========================================

Scope
-----
This overlay updates only the left/right control panel and the MIDI/audio note path required to make those controls work. The central LCD and other screen areas are not redesigned.

Changes in V17.2
--------------
1. Vertical fader direction is corrected: moving the handle up increases the MIDI/audio level; moving it down reduces the level. Both the six fixed left-panel faders and four right-part faders use Qt's normal vertical orientation, and the right faders explicitly document the up/down behavior in their tooltips.
2. L, R1, R2, and R3 each have an actual ON/OFF button below the fader label, matching the supplied target image. OFF sends sustain-off, All Sound Off, All Notes Off, and CC7=0 to the matching internal part and its external MIDI channel. ON restores its bank/program, CC7 fader value, and expression. Switch states and fader values persist in QSettings.
3. Keyboard note routing respects enabled parts. In Split mode, the lower side routes to L if L is ON. The right side independently routes to each enabled R1/R2/R3 part. If Chords and Split are enabled together, the low notes still update chord recognition and also play the enabled L Voice.
4. R3 has its own internal MIDI channel 4 (zero-based channel 3) and receives note-on/note-off, program, bank, volume, and mute messages. Until a separate R3 voice picker exists, R3 follows the current R2 Voice so it cannot be left with an uninitialized instrument.
5. The arpeggiator note path now supports slot 3 and its note-off uses channel 4 correctly. External channel-split keyboard input also obeys the L/R1/R2 enable state.
6. An active internal Native SCVA engine always receives MIDI even when an old saved routing preference is "Windows MIDI Mapper only". In that stale setting, the application will not accidentally route notes only to a missing external synth or double-trigger an external synth while native SCVA is active.
7. The Layer button acts as a shortcut for toggling R2. The dedicated R2 ON/OFF button remains independently usable after that.

Default state and controls
--------------------------
- L and R1 default ON.
- R2 defaults to the saved Layer state (or OFF for a clean configuration).
- R3 defaults OFF until enabled by its own ON button.
- R3 initially mirrors R2's selected Voice program/bank/map.
- Right faders control part volume; the separate Master Volume control remains the master output control.

Install and build
-----------------
1. Extract this ZIP directly into the same existing project root that contains CMakeLists.txt and the previously working build-qt-audio-ninja folder. Allow src/main_qt.cpp and the test/launcher files to overwrite their older versions.
2. Close Ensembles before running Rebuild-And-Run-Panel-Reference-V17.2-Target-Layout.bat.
3. The launcher reuses the existing build tree and does not configure a new Qt kit or build folder. It first runs all source checks, then compiles and launches the application.

Validation and limits
---------------------
The V17.2 source-regression checks and the 21 existing V14/V15/V16 source checks pass in the authoring environment (34 tests total). This does not substitute for a Windows/MSVC build or listening test on the user's PC; this environment cannot run the user's Windows audio device. The launcher checks compiler/build success, not perceived audio. After launch, check: move each fader up and down; turn each part ON/OFF; with Split ON, test L below the split point; test R1 above split; enable R2 and R3 and test layering; try Chords+Split together; confirm the master volume is independent of part faders.

Previous compile regression resolved in V17.1: the local array was renamed from "slots" to "voiceSlots" to avoid Qt keyword-macro expansion. The source guard remains included; run the included V17.2 BAT on Windows to confirm a native MSVC build.

V17.2 target-layout correction
------------------------------
The right panel is now composed like the supplied GitHub screenshot: a 100-pixel Data Entry knob with its three navigation buttons below it; Chords/Layer/Split in a middle column; Reverb/EFX Setup/Chorus directly under the encoder/toggle block; four tall L/R1/R2/R3 faders at the right; and each part's visible ON/OFF switch below its label. Transpose, Octave, Tempo and Arpeggiator are arranged in the compact bottom row. The left panel is unchanged by this layout-only revision.
