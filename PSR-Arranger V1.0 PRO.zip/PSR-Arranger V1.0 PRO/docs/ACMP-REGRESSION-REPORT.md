# ACMP beat-grid repair — verification report (generalized saturated-delta pass)

## Source change

The previous reader only corrected one exact shape: four chord hits in a two-bar Variation, or two chord hits in a one-bar Fill. That was too narrow for the reported symptom across most STYLE files.

The current pass records the source-record index and raw delta for each Roland STL event, then detects a run of multi-note ACMP chord groups with confirmed `255`-source-tick intervals and a bar-aligned stream. Consecutive chord groups are allowed to have different pitch sets/voicings; the previous identical-pitch-signature condition rejected real harmonic changes and was too strict. Confirmed saturated intervals are corrected from 255 to the intended 240-source-tick grid. The detector requires at least three consecutive qualifying groups for a Variation run, or a two-group run starting at tick zero in a one-bar Fill. It does not quantize isolated 255 deltas, offbeat notes that do not belong to a qualifying chord run, drum/bass streams, non-bar-aligned streams, Intro/Ending sections, or unrelated timing.

Unlike the previous narrow patch, the correction is applied through source-record provenance: events after a confirmed saturated delta move with the corrected interval, including controller events and other material later in that same ACMP part. This avoids aligning just the chord attack while leaving nearby events behind. Note Offs that would overlap the next corrected chord are clamped to that retrigger; the final chord release is preserved when it already sits near the loop boundary. Fill sections remain one-shot and the section/loop marker duration remains anchored to its original bar boundary.

## Regression results

Build/tested locally on Linux with GNU C++ and CMake:

- `acmp_timing_regression`: **PASS** — Variation A, Fill A on two ACMP parts, advanced Fill C, and drum timing unchanged.
- `style_engine_clock_regression`: **PASS** — varied callback cadence and event-deadline checks.
- `roland_stl_reader_regression`: **PASS** — parser, synthetic saturated ACMP groups, changing chord voicings between retriggers, controller events between chord groups, final-release handling, Auto Fill, and loop tests.
- Standalone CTest: **3/3 passed**.

Command:

```sh
cmake -S regression -B build-acmp-regression
cmake --build build-acmp-regression --parallel
ctest --test-dir build-acmp-regression --output-on-failure
```

## STYLE corpus audit and limitations

The included corpus audit loads 401 files and reports 29 files with an existing “part too long or invalid pointer” error. These 29 are not counted as passes. The audit reports 6,124,235 parsed events and 1,555,764 off-beat Note On events preserved, which is why broad global quantization is not an acceptable fix.

The full Qt/MSVC Windows build and live MIDI/audio playback on a Roland BK-5/G1000 were not run in this environment. Passing source-level regressions does not prove hardware audio timing. After building on Windows, verify an affected Variation and Fill against the drum beat; if a mismatch persists, capture the current output MIDI stream or timing trace before adding broader quantization. The updated regression covers a synthetic pattern with different voicings, but it is still a source-level test and cannot prove the audible sync issue is resolved on the user PC. Do not quantize all offbeat events: many are valid syncopations.

## Launcher

`V19.0-Apply-Build-Run.bat` is provided in the project root as the full build/test/deploy/run entrypoint, and `#V19.0-Apply-Build-Run.BAT` is retained as an identical legacy-name copy. Both use the same source already included in this package; no overlay patch is applied at runtime.


## V19 FIX3 — output-deadline regression (cross-route)

A second, shared playback-path problem was found after the ACMP parser-only passes did not change the audible result: `StyleEngine` produced absolute event deadlines, but the WinMM output branch discarded them and called `midiOutShortMsg` directly from the 3 ms Qt timer callback. In dual-output mode, the same `wantsWindowsMidiOutput()` condition also disabled timestamped delivery to RtAudio. That made output timing depend on GUI callback cadence rather than the event deadline on those routes.

The current fix sends WinMM STYLE messages through a dedicated steady-clock deadline worker and retains timestamped delivery for RtAudio even when WinMM is enabled. Look-ahead is enabled for either active output route, and the scheduler is stopped before the WinMM handle closes. Non-STYLE UI/keyboard MIDI keeps its immediate path. A source guard now protects these invariants.

Validation limitation: the scheduler is Windows-only and cannot be auditioned on the Linux preparation host. The C++ parser/tick regressions and Python source guard can pass here, but the definitive check is rebuilding the Windows Qt app and listening to Variation plus Fill with the user's actual output route. This correction targets the common output-timing path, not another speculative 255-tick parser quantization.


## Forensic runtime trace (diagnostic build)

Set `ENSEMBLES_ACMP_TRACE=1` before launching `ensembles-cpp.exe`, or use the bundled `V19.0-Apply-Build-Run.bat`, which enables it for the launched app. The trace is written to `%TEMP%\Ensembles_ACMP_RuntimeTrace.csv`. Play a problematic Roland STYLE for 10–20 seconds, then close the app so the trace writer can flush.

The trace records STYLE engine tick/deadline, output route handoff, estimated sample position within the RtAudio callback, and actual WinMM API return time. `AUDIO_APPLY_ESTIMATE` is not a microphone/DAC loopback measurement. Run `powershell -ExecutionPolicy Bypass -File .\Analyze-ACMP-Trace.ps1` to summarize queue drops, fallbacks and output lateness by channel. The trace is opt-in in the executable and is designed to enqueue fixed-size records; file I/O runs on a separate writer thread.

The STYLE event callback no longer calls `QSettings::sync()` for incoming CC7 values: these are playback events, not user settings, and synchronous persistence could block the transport thread. This is a confirmed source-level fix, not yet proof that it alone resolves the perceived ACMP/drum mismatch.
