# PSR-Arranger V20 — ACMP Chord Recognition / CASM Stage 7

Date: 2026-11-16

## User reproduction

The reported reproduction style is `6-8Rock.T162.prs`. Its SFF2/Ctb2 CASM contains 116 rules. Main A-D use Source Chord Type `0x02` for several melodic/chordal parts, which means Yamaha Chord Control ID 2 (`Maj7`).

## Root cause corrected

The runtime incorrectly reversed the byte-valued Ctab/Ctb2 `Source Chord Type` field as `0x21 - raw`. Yamaha's source-type numbering is direct: `0x00=Maj`, `0x02=Maj7`, `0x08=min`, `0x13=7th`, through `0x21=1+2+5`; `0x22` is Cancel. The reverse ordering is relevant to the packed Chord Mute bitfield layout, not this source-type byte.

For `6-8Rock.T162.prs`, raw `0x02` was previously interpreted as ID 31 (`1+5`), so a source B-natural from the Cmaj7 recording context was not recognized as a source-chord tone in Melody processing and could survive over a requested C-major chord. The direct mapping now correctly identifies it as the seventh of the source Cmaj7 context and fits it to a C-major chord tone. A requested Cmaj7 still retains B-natural.

## Regression added

`yamaha-sty-playback-corpus-test` now loads the actual `Pop&Rock/6-8Rock.T162.prs` file and runs its `MAIN A:13` Pad rule in the real arranger engine:

- C major (Genos chord ID 0): no B-natural output in the tested Main A playback window.
- Cmaj7 (Genos chord ID 2): B-natural remains present.
- The source CASM rule must decode as Ctb2, Source Chord Type `0x02`, Root Transpose, Chord NTT.

## Validation

- Yamaha style runtime test passes.
- Genos chord detector test passes (33 chord IDs plus input tracking cases).
- PSR-S CASM corpus passes: 642/642 styles loaded; 92,234 Ctb2 rules; 0 malformed.
- Targeted playback regression on `6-8Rock.T162.prs` passes with C major and Cmaj7.

A full GUI/Qt build and a direct hardware test on a Yamaha PSR-S/SX or Genos 1/2 remain outside this validation environment.
