# Windows 11 hardware validation checklist

This checklist is for a real Windows 11 machine. A green CI build does **not** prove that audio devices, MIDI devices, or audio latency work correctly.

## Record the test environment

- Windows 11 edition/build:
- CPU / RAM:
- Audio output device and driver (WASAPI/shared, ASIO, USB interface, etc.):
- MIDI input device (if any):
- SoundFont file and size:
- Application package / commit SHA:
- Test date:

## Build and launch

1. Download and extract the `ensembles-cpp-windows` CI artifact.
2. Launch `ensembles-cpp.exe` from the extracted CI package, or run `build-qt-audio-ninja\ensembles-cpp.exe` after a local build following README.md.
3. Confirm the window opens without missing-DLL, GTK theme, or GLib schema errors.
4. Note any startup warnings and whether the application remains responsive.

## Audio and SoundFont

This source ZIP does not contain a valid SF2 payload. For FluidSynth/RtAudio playback, load a known-good SoundFont that you are licensed to use. A real original `EnsemblesGM.sf2` gives closer parity if you have a licensed copy. SCVA output is a separate runtime path. In Settings, test all four output routes: Auto, internal FluidSynth/RtAudio, Windows MIDI Mapper, and Both.

1. Connect/select the intended Windows audio output before launching.
2. Open Settings, choose **Pilih SoundFont (.sf2)…**, and load a known-good `.sf2` SoundFont.
3. Play several virtual keyboard notes across the displayed range.
4. Check for audible output, clipping, stuck notes, dropouts, crackling, and excessive latency.
5. Toggle reverb and chorus; verify an audible difference where the SoundFont makes it apparent.
6. Press **Panic** while notes are sounding; confirm all notes stop.
7. Repeat after changing the default Windows output device and after reconnecting the audio interface.

## MIDI file playback and recording

1. Open a known-good format-0 MIDI file and play, pause/stop as available.
2. Open a known-good format-1 multi-track file and verify tempo/event timing is plausible.
3. Record a short phrase on the virtual keyboard, stop recording, and export a `.mid` file.
4. Reopen the exported file in this application and in a second MIDI player/editor; compare note timing and note-off behavior.
5. Repeat with drum pads, metronome, and LFO controls.
6. Test long files, malformed files, canceling file dialogs, and repeated start/stop cycles.

## MIDI hardware and known scope limits

Iteration 6.7 adds a WinMM physical MIDI input adapter, device selection, and note-on/note-off routing, but this subsystem is **not hardware-validated yet** and CC/note-learn maps are still incomplete. Do not mark hardware MIDI input as passed until a real Windows device passes the checks below. The Qt port also retains known gaps in the original accompaniment signal graph and recorder integration; current drum pads are GM-note triggers rather than arbitrary sample pads.

### Physical MIDI input — Iteration 6.7

1. Open Settings and press **Refresh input**. Confirm each Windows MIDI input device appears once.
2. Check a device and verify the status shows one connected input. Send a note-on and note-off; verify the internal SoundFont responds and notes do not hang.
3. Test notes at different velocities, including a controller sending note-on with velocity zero for release.
4. Repeat with **Split By Channel** off and on. When on, test source MIDI channels 1, 2, 3 and 4+ and compare layer routing with the original Ensembles behavior.
5. Check two connected devices, disconnect one, disconnect all, and close the application while notes are held. Record any stuck notes, stuck connection state, callbacks/crashes, or missing devices.
6. Send CC messages and verify they are **not yet expected** to operate the original style/registry/mixer controls in Iteration 6.7; that mapping remains unfinished.

## Result template

For each test, record **PASS / FAIL / NOT TESTED**, steps to reproduce, expected result, actual result, and attach logs/screenshots where possible. A release candidate should not be marked hardware-validated while any required test is `NOT TESTED`.
