# Yamaha XG native PCM route in Ensembles

This change adds a C++ bank/program-index reader, a 16-part PCM voice renderer, and an exclusive RtAudio route.

## Implemented

- `Xg2006LeBankTable` validates the `UTG VPRM` header and reads the bank map and compact program map from `sxgbnw6l.tbl`.
- The supplied `sxgbnw6l.tbl` was parsed successfully: 950 program entries are marked present; bank 0/0 program 0 resolves to compact voice index 402.
- `Syxg2006LeNativeRenderer` imports mono/stereo WAV zones (PCM 8/16/24/32-bit or IEEE float32, 8–192 kHz) and downmixes stereo assets for the current mono-zone playback core.
- Key ranges, velocity layers, root-note tuning, loop points, gain and per-zone ADSR are mapped from the manifest. The renderer supports 16 parts, 256 voices, interpolation, pitch bend, volume, expression, pan and sustain.
- Per-voice state-variable low-pass filtering responds to XG cutoff/resonance controllers (CC74/CC71). XG reverb/chorus sends (CC91/CC93) feed preallocated stereo delay networks. Channel 10 percussion is triggered as a one-shot sample and is not truncated by NoteOff.
- `AudioEngine` can select the renderer on the existing RtAudio stream. Scheduled MIDI is dispatched at its frame offset. Rendered stereo PCM enters the normal callback output/master stage.
- The Yamaha route is exclusive: SCVA, VST2 and FluidSynth receive neither the same MIDI nor rendered output while it is active. Startup mode uses an RtAudio-only initialization path, without constructing FluidSynth.

## PCM zone manifest

The `XGPCM1` manifest is a sample interchange format; it is **not** the format of `sxgdat6l.tbl`. It starts with the exact header `XGPCM1`, followed by rows with 16 comma-separated fields:

`bank_msb,bank_lsb,program,key_low,key_high,velocity_low,velocity_high,root_key,loop_start,loop_end,wave_file,attack_ms,decay_ms,sustain_level,release_ms,gain`

`wave_file` is a relative path to RIFF/WAVE: mono or stereo PCM 8/16/24/32-bit, or IEEE float32, at 8–192 kHz. Stereo imports are downmixed to mono. Loop positions are in frames; both positions set to zero means sample-end one-shot. Key and velocity ranges allow multiple elements/layers for a single program. A row is accepted only when its bank/program is marked present by `sxgbnw6l.tbl`. See `data/yamaha2006le/xgpcm-bank.example.csv`.

## Startup

```bat
set ENSEMBLES_SYXG2006LE_BANK=C:\Ensembles\Yamaha2006LE\sxgbnw6l.tbl
set ENSEMBLES_SYXG2006LE_PCM_MANIFEST=C:\Ensembles\Yamaha2006LE\xgpcm-bank.csv
Ensembles.exe
```

Both variables are required. When Yamaha startup is explicitly requested but loading fails, Ensembles shows the failure and does not silently select SCVA, VST2 or FluidSynth.

## Current limitation

The C++ path currently reads the uncompressed bank/program index in `sxgbnw6l.tbl` and PCM zones supplied through `XGPCM1`. It does **not** yet parse the original waveform payload in `sxgdat6l.tbl`. Consequently, the native PCM pipeline and mixer route are implemented and tested, but original factory S-YXG2006LE timbres are not yet playable from the two Yamaha `.tbl` files alone. The sine-wave fixture in the unit test proves PCM output only, not Yamaha timbre reproduction.
