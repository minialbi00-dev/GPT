# Ensembles 6.8.7 — Yamaha Style Engine Build Fix 2

Date: 2026-11-05

## User build failure

The Windows MSVC 19.51 / Qt 6.11.2 build completed 72 of 75 compile steps, then stopped in `src/main_qt.cpp`:

```text
main_qt.cpp(6223): error C2065: 'secondary': undeclared identifier
```

## Root cause

Inside the style-list population loop, the Yamaha branch assigned a Yamaha section/BPM summary to `secondary` before the local `QString secondary;` declaration. The declaration was below the Yamaha branch, next to the generic MIDI parser. C++ correctly rejected that use-before-declaration.

## Fix

- Moved `QString secondary;` to the beginning of the per-style list-item scope, before either Yamaha or generic MIDI summary code.
- Removed the later duplicate declaration.
- Left Yamaha runtime loading, generic MIDI metadata parsing, and final LCD list-item metadata behavior unchanged.
- Extended `tests/yamaha_style_picker_source_test.py` with a regression guard requiring exactly one declaration before all subsequent `secondary` references in that scope.

## Validation performed here

Command:

```sh
python tests/yamaha_style_picker_source_test.py
```

Result: all 15 Yamaha style family / arranger panel source checks passed, including the new declaration-order guard.

## Build status

The reported fatal C++ diagnostic is addressed in source. This Linux workspace does not have the user's MSVC 19.51 + Qt 6.11.2 Windows toolchain, so a complete Windows GUI rebuild is not claimed. Run `V19.0-Apply-Build-Run.bat` again on Windows to verify the full application link and launch.
