Ensembles 6.8.7 - Assignable Controls V13: Visible Fader Names
==============================================================

Purpose
-------
V13 keeps the V12 audio/control mapping and adds a visible name under each of
10 sliders and 4 assignable knobs, plus a Master Vol label. Names refresh when
an assignment changes. Hovering any control shows the full mapped function,
including MIDI CC/channel details for custom mappings. The assignment dialog
also identifies the physical control and its current short name.

Default slider captions
-----------------------
1 L Vol       Voice L Volume
2 R1 Vol      Voice R1 Volume
3 R2 Vol      Voice R2 Volume
4 Style       Style Volume
5 Reverb      Reverb Send (selected Voice)
6 Chorus      Chorus Send (selected Voice)
7 Cutoff      Filter Cutoff (CC 74)
8 Reso        Filter Resonance (CC 71)
9 Expr.       Expression (CC 11)
10 Drum       Drum Volume (MIDI channel 10)

Default knob captions
---------------------
1 Pan, 2 Mod, 3 Reverb, 4 Chorus. Master dial is labelled Master Vol.

Install
-------
Extract this overlay into the project root containing the ensembles-cpp
folder and overwrite matching files. Run:
  ensembles-cpp\Rebuild-And-Run-Assignable-Controls-V13.bat

The launcher checks the mapping and label tests, forces main_qt.cpp rebuild,
builds the normal GUI target and starts the application in normal audio mode.
Log files:
  ensembles-cpp\ensembles-assignable-controls-v13-build.log
  ensembles-cpp\ensembles-assignable-controls-v13-run.log

Validation and limitations
--------------------------
12 existing mapping/source checks and 7 V13 label checks passed in the
available authoring environment. A Windows/Qt compile and live audio audition
were not performed here. Confirm RtAudio startup and control response on the
Windows machine; a source test pass alone does not prove sound output.
