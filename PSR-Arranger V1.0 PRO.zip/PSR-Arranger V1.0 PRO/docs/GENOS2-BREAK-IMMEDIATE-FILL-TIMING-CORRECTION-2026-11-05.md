# Genos2 BREAK / Fill In BA — Immediate Fill Timing Correction

The previous BREAK patch incorrectly waited for the next full downbeat/bar and reset the BA stream to phase zero. That does not match the requested behavior.

BREAK now uses the same scheduler rule as Immediate Fill In:

1. On button press, queue the BA section for the next beat.
2. Start the BA stream at the matching phase within the current bar.
3. Finish at the original barline and return to the active Main.
4. A press during the final beat naturally activates at the next downbeat, where phase is zero.
5. If another Fill is already sounding, let it finish at its existing boundary before BREAK takes over.

This applies equally to the dedicated `queue_break()` entry point and the `FILL BA` alias. The button/LED identity remains BREAK.

Verification: see `GENOS2-BREAK-IMMEDIATE-FILL-TIMING-VERIFICATION-2026-11-05.txt`. A real bundled Yamaha Style test (`LS-GM - Swing-Jazz - middel.sty`) confirms next-beat activation, BA MIDI events, and return to Main at the original barline. Physical Genos2 hardware comparison and Windows/MSVC GUI build remain outstanding.
