# Ensembles GUI migration — original-reference audit

**State:** visual parity iteration, not a claim of complete 1:1 migration.

## Reference used

- Original AppCenter listing: <https://appcenter.elementary.io/com.github.subhadeepjasu.ensembles/>
- Original source project: <https://github.com/ensemblesaw/ensembles-app>
- Screenshot captured from the original project's `screenshots/Screenshot.png`, copied unchanged to [`reference/original-ensembles-gui.png`](reference/original-ensembles-gui.png).
- The reference capture is a 1440×744 image with the application window approximately 1344×708. The Qt front end uses that inner-window size as its initial size.
- Original UI sources reviewed include `src/Shell/MainWindow.vala`, `src/Shell/Layouts/ControlPanel.vala`, `src/Shell/Layouts/SliderBoardView.vala`, `src/Shell/Layouts/VoiceCategoryView.vala`, `src/Shell/Layouts/MixerBoardView.vala`, `src/Shell/Layouts/SamplerPadView.vala`, `src/Shell/Layouts/StyleControllerView.vala`, `src/Shell/Layouts/RegistryView.vala`, `src/Shell/Layouts/KeyBed.vala`, `src/Shell/Widgets/OctaveKeyboard.vala`, `src/Shell/Widgets/Key.vala`, and the original theme CSS.

## Mapped to the Qt home screen

| Original region | Qt migration implementation | Parity status |
|---|---|---|
| Custom header: close, 4 navigation arrows, Tempo, centered app title, folder/settings/fullscreen | Frameless Qt header with drag and edge resize | Layout mapped; the arrows' original navigation semantics are not yet migrated |
| Left control board: knob assignments, master knob, slider assignment, ten vertical faders | Same five dials and ten faders, original dark gradient treatment | Visual structure mapped; controller-assignment editor and DSP mapping remain unported |
| Center display: Style / Voice L / Voice R1 / Voice R2 tabs, piano photo, Tempo/Measure/Beat/Transpose/Octave/Chord, 16 style lanes + L/R1/R2 meters | Qt tabs, original photo staged from source asset, six metric cells, 19 lane meters | Layout mapped. Meters are deliberately zero until a real audio peak source exists; measure is not fabricated |
| Right control panel: large dial, +/activate/−, Recorder, Chords/Layer/Split/Metronome, Transpose/Octave/Arpeggiator/Reverb/Chorus/Harmonizer controls | Corresponding controls and parameter cards | Layout mapped; unsupported functions report their current migration boundary instead of simulating a success |
| Voice types: 12 categories | Same 12 category labels in original 4-column grid | Visual map; program choices still use 128 GM patches, not the original FluidSynth SoundFont voice bank |
| Mixer: 16 style lanes + L/R1/R2/SP | 20 faders, numbers, lock buttons | 16 lanes send MIDI CC7; the separate voice/sampler lanes await original synth routing |
| Sampling pads: 12 pads plus record/folder/stop | 12 GM percussion note pads, record/folder actions and stop | Shape/count mapped; these are note triggers, not arbitrary-sample playback or recording |
| Style controller / registry: Intro, Variation A–D, Break, Ending, Sync Start/Stop, Start/Stop, Bank, 10 registration slots and Memorize | Same visible control group | Basic section controls route to the current style engine; ten slots now persist and recall the currently ported voice/style/tempo/control state, while original bank semantics and full snapshot parity remain incomplete |
| Bottom keyboard: 60 keys, X/Y assignment well, HOLD/ZOOM, SUST/STOP | Custom-painted live 60-note keyboard, left assignment well, zoom/scroll, sustain, stop | Keyboard layout and Zoom mapped; joystick/X-Y assignments and HOLD semantics are incomplete |

## Deliberate correctness constraints

- Do not use an image of the original screenshot as the live application UI. The controls above are native Qt widgets and the keys are a live painter widget connected to the current MIDI handler.
- Do not synthesize fake activity in the center meters. They remain zero until the project has real per-channel audio peak data.
- A GM patch chooser and Windows MIDI Mapper are not equivalent to the original FluidSynth synth with its SoundFont bank. Reverb/chorus CC messages may be ignored by a destination device.
- A 12-pad MIDI percussion trigger panel is not equivalent to the original 12 assignable audio sample pads.
- An approximate style UI is not proof that the full original style engine, chord routing, recorder, complete original registration memory, sample audio paths, and plugin rack are equivalent.
- The original app advertised 200+ voices, built-in auto-accompaniment, 12 sampling pads, a 10-track recorder, and external MIDI controllers. The current Qt UI still has gaps in those behaviours; don't advertise them as migrated yet.

## Validation record for this iteration

- `bash tests/run_midi_parser_test.sh` — passed.
- `bash tests/run_style_engine_test.sh` — passed; includes the ten shipped style assets, marker map, chord finder/transposition, CentralBus latch, Intro/Variation/Fill/Ending, Sync Start/Stop, and live style replacement tests.
- Static source checks — passed for five-octave keyboard, zoom/scroll, 12 GM pads, original photo staging, no octave-range selector, and non-fabricated meter values.
- Qt GUI build and Windows runtime were **not** validated in this environment because the Qt 6 Widgets/MSVC toolchain is unavailable here. The next validation step is building with the already-installed Qt 6 MSVC x64 kit and comparing the resulting screenshot at 1344×708 against the reference capture.

## Acceptance checklist for claiming 1:1

- [ ] Build the Qt GUI with the user's existing Qt 6/MSVC x64 kit.
- [ ] Capture a clean idle screenshot at 1344×708 and compare side-by-side with the reference.
- [ ] Verify all five-octave key geometry, split-key placement, and active-note visual types.
- [ ] Match program/category selection and the original left/right voice routing.
- [ ] Compare the event sequence for every ARR transition and chord type against the original engine.
- [ ] Complete the remaining gaps in FluidSynth/SoundFont voice parity, MIDI input, audio metering, arbitrary sample pads, 10-track recorder, original registration/bank semantics, controller assignments and plugin routing.
- [ ] Only call the migration 1:1 after both visible behavior and event/audio outputs meet those checks.
