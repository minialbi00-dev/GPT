# Migration status — original ARR core port in progress

> **Truthful status:** this is not yet a complete 1:1 migration of the entire Ensembles application. This revision ports a real subset of the original style-arranger implementation; it is not a newly invented accompaniment generator. Platform audio, app-wide integration, and multiple original subsystems are still incomplete and must not be described as equivalent.

## Original logic now represented in the C++ port

- `src/style_engine.cpp` ports the original style MIDI analyser contract: the fixed 15-marker table, Config tempo/chord mode, signature, marker-to-tick formula, and original `.enstl` marker ordering.
- `src/chord_finder.cpp` and `src/chord_finder.h` carry over the original `chord_finder.c/.h` scoring formulas rather than replacing the algorithm. The source snapshot accesses pitch classes outside the 0–11 array bounds; the C++ port normalizes those lookups modulo 12 to eliminate undefined behavior while retaining the chromatic scoring intent. This is a documented safety/correctness repair, not byte-for-byte behavior for the original undefined cases.
- `StyleEngine::transformKey()` carries the original `get_chord_modified_key()` chord/type transposition cases, including original style major/minor mode, alt-channel state, and random branches.
- MIDI style-event handling retains the original control-120 filter, CC82 alt-channel switch and channel filters, melodic-note transposition exceptions for channels 10/11 in the original 1-based notation (C++ channels 9/10), note tracking and chord-change resend behavior.
- The original section marker mapping and state transitions are represented: Intro A/B, Variation A–D, Fill A–D, Ending A/B, fill queueing, sync start/stop, break, looping, section changes, and note-halt points.
- The original ten `.enstl` assets are shipped at `data/StyleFiles`. CMake copies them next to the build output. The Qt frontend scans both built-in assets and user files under `Documents/ensembles/styles` using the source `genre@name.enstl` contract.
- Qt section-button actions now mirror the original queue-only behavior; playback is controlled by the separate Start/Stop button, and the four Variation / Fill-in selectors use the original paired marker map.
- The 10 assignable sliders and 4 assignable knobs are active. Mapping dialogs select MIDI channel 1–16 and CC; assignments and Master Knob targets persist in QSettings. With the FluidSynth route selected these CCs are sent directly into the internal synth; with WinMM selected they are sent as MIDI CC to the Windows MIDI Mapper.
- Iteration 5 adds a real FluidSynth instance, valid SF2 loader, RtAudio stereo callback, a bounded event queue, master gain, and the original Reverb/Chorus parameter/effect APIs. Iteration 6 adds RtAudio host API/device selection, reported sample rates, configurable buffer size, live output status, and a test tone. Iteration 6.1 enables vcpkg feature `rtaudio[asio]`, so the compiled RtAudio API list should include Windows ASIO when dependency configuration/build succeeds. The internal voice channels follow source `synthesizer.c` (R1=17, R2/layer=18, L/split=19; metronome=16; chord voices=20–22).
- The clock latch's 300 ms release interval is represented from `Core/ChoppingBlock/CentralBus.vala`; this port does not yet recreate every cross-subsystem signal and recorder side effect from `CentralBus`.

## Main-panel behavior added in Iteration 4 and Iteration 5

- Chords/Accompaniment has a real state; lower-key chord routing can detect chords even when no style is loaded, and the source-based fallback chord voicing uses internal channels 20–22 when style looping/sync-start gates allow it. Style melodic note-ons are gated while accompaniment is off, except on the drum channel. Disabling it also stops hanging notes.
- Layer/Split modes persist and route keyboard notes across Windows GM MIDI channels; the split point is user-adjustable via right-click on a key. This is a Qt interaction substitute for the original small split button on each key.
- Transpose/octave toggles and values, FX state/levels, output volume, and metronome checkbox/button state persist. Ten registration slots can now save/recall the current ported voice, style, tempo, transpose/octave, accompaniment/layer/split, metronome, Reverb/Chorus and volume state; this is not yet full original registration/bank parity.
- Arpeggiator/Harmonizer are disabled in the Qt frontend pending port of the original algorithms, rather than pretending a visual toggle produces notes.
- Iteration 6.7 adds physical WinMM MIDI input device selection and note routing, including normal keyboard split/accompaniment routing and channel-split mode. It is a partial port; see `docs/MIDI_INPUT_PORTING_ITERATION_6_7.md` for unsupported original input-mapping behavior.
- Audio routing now offers Auto (internal FluidSynth if a valid SoundFont/output opens, else WinMM), internal-only, WinMM-only and both. The original Ensembles SF2 path is a Git-LFS pointer in this checkout; a generic TimGM6mb GPL-2 GM fallback is now bundled so the internal route can attempt playback without external setup.
- `tests/rtaudio_asio_manifest_test.py` verifies the vcpkg manifest requests the ASIO feature. `tests/qt_panel_source_smoke_test.py` checks nine panel source invariants; `tests/audio_backend_source_smoke_test.py` checks the audio integration wiring. Neither is a GUI runtime/build test.

## Not yet 1:1 / known compatibility boundaries

- **Audio parity:** FluidSynth/RtAudio and internal channels/effects are now connected, but the real original SoundFont file is not bundled (only the licensed TimGM6mb fallback is), the full original voice catalog/state is not ported, and actual Windows playback/latency/effect parity has not been tested. Iteration 6 adds a configurable RtAudio device/API/rate/buffer picker. Iteration 6.1 now asks vcpkg to build its optional ASIO backend; actual ASIO4ALL discovery, stream opening, and playback still require validation on the user’s Windows x64 system. WinMM remains an external MIDI Mapper output path.
- **Arranger/UI integration:** the state engine is not yet wired to all original `ArrangerCore`, `StylePlayer`/`CentralBus` signals, style controller UI events, recorder style-control events, measure display, harmonizer and voice/synthesizer chord-detection path. The current GUI is a migration harness for exercising the ported style engine, not full visual/behavioral parity.
- **Style discovery/configuration:** built-in styles are discovered from `data/StyleFiles` (with the legacy-reference fallback), and user `.enstl` styles are discovered from the original `Documents/ensembles/styles` folder. Filenames follow the source contract `genre@name.enstl` and are sorted by genre case-insensitively. Original preferences, import/analysis lifecycle, and remaining settings/configuration behavior are not yet ported.
- **MIDI devices:** iteration 6.7 ports WinMM device enumeration/open/close and note events only. MIDI learn maps, Note-to-control assignments, CC-to-style/registration/mixer/slider dispatch, raw MIDI mode, automatic hot-plug and exact PortMidi polling timing are still not ported. Windows build and real device tests remain mandatory.
- **Recording/sequencing:** the complete multitrack recorder/sequencer, project format, style-control recording and playback are not ported.
- **Plugins/audio/sample systems:** LV2 host, plugin UI/rack routing/state, arbitrary audio sampling pads, and full audio routing are not ported.
- **Entire application:** original settings/preferences, desktop integration, complete theme/controller-widget styling, harmonizer and full keyboard/synthesizer voice management are not yet equivalent.

## Validation performed in the authoring environment

- `tests/audio_backend_source_smoke_test.py` — PASS (static audio linkage, SF2 selection checks, RtAudio callback/effect APIs and WinMM route checks; not compile/runtime verification).
- `tests/soundfont_runtime_smoke_test.py` — PASS using the authoring environment's `libfluidsynth.so.3`; bundled TimGM6mb loaded and produced nonzero audio for internal channels 17/18/19. This is not Windows/RtAudio verification.
- `tests/run_midi_parser_test.sh` — PASS (SMF parser/writer round-trip).
- `tests/run_style_engine_test.sh` — PASS (the ten packaged `.enstl` assets, marker positions for the reference style, original chord-finder vectors for all 12 major/minor triads, deterministic transposition cases, CentralBus 300 ms clock latch, intro/variation/fill/ending transitions, sync start/stop, and live-style replacement).
- AddressSanitizer/UndefinedBehaviorSanitizer run of the style-engine test — PASS after normalizing pitch-class lookups in the source chord finder; the original C source indexed outside its 13-element array for some chord-score formulas.
- Controller UI static smoke checks — PASS (4 knobs and 10 sliders are wired; map persistence and master targets are present; code brace-balance check passed). These are source checks, not a substitute for running the GUI.
- Qt 6 + vcpkg/FluidSynth/RtAudio GUI CMake configure — **blocked** because this authoring environment has no Qt6Config.cmake and no Windows MSVC/vcpkg audio dependency toolchain; no GUI compile was possible here. Windows MSVC build and real Windows audio — **not tested**.
- Windows MIDI output, physical MIDI input and audible parity — **not tested on real Windows hardware**.
- `tests/run_midi_input_router_test.sh` — PASS (packed WinMM short messages, note-on velocity-zero normalization, explicit note-off, CC classification and original channel-to-layer clamp). `tests/midi_input_source_test.py` — PASS (static wiring only). These tests do not validate WinMM callbacks or a physical MIDI device.

Passing native core tests verifies only the tested core behaviors. It does not establish whole-application 1:1 parity or confirm the GUI compiles and plays on Windows. Keep `docs/WINDOWS_HARDWARE_TEST.md` as a release gate.


See [`PANEL_CONTROL_PARITY_ITERATION_4.md`](PANEL_CONTROL_PARITY_ITERATION_4.md), [`AUDIO_BACKEND_PORTING_ITERATION_5.md`](AUDIO_BACKEND_PORTING_ITERATION_5.md), [`AUDIO_BACKEND_PORTING_ITERATION_6.md`](AUDIO_BACKEND_PORTING_ITERATION_6.md), and [`FEATURE_PARITY_AUDIT.md`](FEATURE_PARITY_AUDIT.md) for exact behavior, build prerequisites, feature gaps, and validation limits.
