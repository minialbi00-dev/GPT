# Audio backend port — Iteration 5

Date: 2026-10-23

## What is connected

This iteration adds a Windows-ready C++ backend around the same FluidSynth APIs used by the original Ensembles synthesizer:

- **FluidSynth** creates the local synthesizer, loads an SF2 bank, handles MIDI messages and renders audio.
- **SoundFont selector** accepts only readable RIFF/SFBK files before attempting to initialize FluidSynth. The selected path is persisted in `QSettings`.
- **RtAudio** opens the default stereo output device at 44,100 Hz. Its callback asks FluidSynth to write interleaved float stereo samples.
- **MIDI command queue** transfers UI/MIDI events to the audio callback thread, so FluidSynth event mutation and audio rendering stay on the same thread. The bounded queue contains 8,192 commands; if it is full the current event is rejected rather than blocking the audio callback.
- **Effects APIs** call FluidSynth's master Reverb/Chorus controls using the exact 0–10 parameter arrays in `legacy-reference/src/Core/Synthesizer/providers/synthesizer_settings.c`.
- **WinMM** remains available as the Windows MIDI Mapper route. Settings can select Auto, FluidSynth + RtAudio, Windows MIDI Mapper only, or both at once. This port currently covers MIDI output, not physical MIDI input.

## Internal synth channel mapping

Matching `legacy-reference/src/Core/Synthesizer/synthesizer.c`:

| Purpose | FluidSynth channel (zero-based) |
|---|---:|
| Main right-hand voice (R1) | 17 |
| Layer / second right-hand voice (R2) | 18 |
| Left/split voice (L) | 19 |
| Metronome | 16 |
| Chord / harmony voices | 20–22 |
| Style MIDI parts | 0–15 |

Ordinary MIDI status bytes encode channel nibbles only for channels 0–15. `AudioEngine::sendMidi` therefore carries an explicit internal-channel override instead of trying to encode internal channels 16–63 into the status byte. External WinMM output receives ordinary MIDI channels 1–16.

## Dependencies and Windows build

`vcpkg.json` declares `fluidsynth` and `rtaudio`. Current Windows build instructions and CMake commands are maintained in the root `README.md`. They expect:

- Qt 6 Desktop MSVC x64 and `windeployqt.exe`.
- Visual Studio C++ Build Tools/MSVC x64 and Windows SDK.
- CMake/NMake. The build script searches common vcpkg locations. If no valid install is found, it clones the official vcpkg repository when Git is available; without Git, it downloads and extracts the official GitHub ZIP using Windows PowerShell, then runs `bootstrap-vcpkg.bat`. The source tree is cached under `%LOCALAPPDATA%\Ensembles\tools\vcpkg`. An existing install can still be selected through `VCPKG_ROOT`.
- Network access when vcpkg needs to build or fetch dependencies on first configure.

The CMake toolchain activates vcpkg manifest mode and installs into `build-qt-audio-msvc/vcpkg_installed/x64-windows`. Runtime dependency DLLs are copied beside the application; `windeployqt` deploys Qt libraries/plugins. The workflow `.github/workflows/windows-qt-msvc.yml` uses the same configuration.

## SoundFont caveat and included fallback

`data/SoundFonts/EnsemblesGM.sf2` in this source snapshot is a 134-byte Git LFS pointer whose declared asset size is 156,197,504 bytes. It is not the actual original bank, and the app detects and rejects the pointer.

To allow internal playback without extra downloads, this iteration packages `TimGM6mb.sf2` as a generic GM fallback. Its source provenance and GPL-2 terms are included as `data/SoundFonts/COPYRIGHT.txt`, `GPL-2.txt`, and `THIRD_PARTY_NOTICE.txt`. The fallback is not the original Ensembles bank; it enables audio testing, but exact instrument timbres and balance will differ. If the real `EnsemblesGM.sf2` file is provisioned later, the app prefers it over TimGM6mb.

## Not yet 1:1

- The original 156 MB Ensembles SoundFont data is still missing from this repository snapshot; bundled TimGM6mb is only a fallback bank and does not create original-sound parity.
- No physical MIDI input enumeration/event ingestion or hot-plug support has been added; WinMM here is output-only.
- The source project's separate FX rack/LV2 plugins, voice catalog, audio callback metering/visualization, full MIDI recorder, and all `ArrangerCore`/`CentralBus` signal semantics remain incomplete.
- Device selection is currently RtAudio's default output device, not a full output-device selector. ASIO and all Windows driver modes require validation on the target PC.
- `python tests/soundfont_runtime_smoke_test.py` — PASS on the authoring Linux host using `libfluidsynth.so.3`: TimGM6mb loaded successfully, programs selected on internal channels 17/18/19, and a nonzero stereo buffer was rendered. This test validates the bank and local FluidSynth runtime only; it does not exercise RtAudio or Windows binaries.
- This authoring environment cannot run the Qt/MSVC/vcpkg Windows build. Passing static source checks, a FluidSynth runtime smoke test, and core parser/style tests is not a Windows build or audible-parity test. Use `docs/WINDOWS_HARDWARE_TEST.md` to validate the built executable and record the Windows/audio stack used.
