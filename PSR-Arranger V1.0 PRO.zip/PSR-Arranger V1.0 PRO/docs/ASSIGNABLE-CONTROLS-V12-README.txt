Ensembles 6.8.7 - Assignable Controls Functional V12
===================================================

This is a corrected Windows overlay for the previous V11 assignable-control source.
The earlier batch launcher was saved with LF-only line endings and UTF-8 special characters; on some Windows CMD setups that can be parsed as separate malformed commands. Both launcher filenames in this overlay use CRLF and ASCII-only command syntax.

Install
-------
Extract this overlay into the project root that contains the ensembles-cpp folder, and overwrite matching files. Then run:
  ensembles-cpp\Rebuild-And-Run-Assignable-Controls-V12.bat

The launcher verifies the existing Ninja build directory is for this same source tree, checks the source mapping, forces recompilation of src/main_qt.cpp, builds the normal GUI target, and launches normal mode (not --safe-ui).

Log files
---------
ensembles-cpp\ensembles-assignable-controls-v12-build.log
ensembles-cpp\ensembles-assignable-controls-v12-run.log

Important
---------
A successful build does not by itself prove that RtAudio opened a device or that the controls were heard. Confirm startup output and test audio in the running app.
