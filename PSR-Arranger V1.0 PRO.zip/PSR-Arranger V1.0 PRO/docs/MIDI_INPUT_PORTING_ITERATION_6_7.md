# Physical MIDI input — Iteration 6.7

Date: 2026-10-23. This revision begins the source-faithful port of `legacy-reference/src/Core/MidiInput/MidiInputHost.vala` and its WinMM-facing Qt adapter. It does **not** claim complete MIDI controller parity.

## Implemented in this revision

- Settings contains a list of physical MIDI input devices from `midiInGetNumDevs` / `midiInGetDevCapsW`, with explicit refresh and checkable connect/disconnect state.
- Selected inputs use `midiInOpen` with `CALLBACK_FUNCTION`, `midiInStart`, and controlled stop/reset/close lifecycle. The callback only forwards packed short messages to the Qt event queue; widget and audio state are touched on the Qt thread.
- `src/midi_input_router.hpp` decodes WinMM packed short-message bytes and identifies note-on, note-off, and control-change. A note-on with velocity zero is normalized to note-off, as expected by MIDI note semantics.
- Input note-on/off goes through the internal synth only, avoiding an accidental MIDI-through loop into the selected WinMM output. Without Split By Channel it shares the main keyboard routing path. With Split By Channel, input MIDI channels 1/2/3 map to internal layers R1/R2/L (synth channels 17/18/19), and higher channels clamp to L as the original `MidiInputHost.process_note_signal()` does.
- Keyboard accompaniment routing now allows chord detection without requiring a style file to be loaded. The internal fallback chord voicing uses original channels 20–22 and retains the original gates: attack only when style looping is inactive and sync-start is not pending; release clears the fallback notes.
- The portable decoder / layer mapping has a C++ test, registered in CTest as `winmm-midi-input-routing` and callable using `tests/run_midi_input_router_test.sh`.

## Source mapping

| Original source | Port location / status |
|---|---|
| `Core/MidiInput/MidiInputHost.vala::refresh/connect_device/disconnect_device` | `EnsemblesWindow::refreshMidiInputDevices`, `connectMidiInputDevice`, `disconnectMidiInputDevice`; WinMM APIs replace the original PortMidi C wrapper for Windows. |
| `Core/MidiInput/MidiInputHost.vala::monitor_device_stream` | WinMM `MIM_DATA` callback queues packed messages to the Qt thread; driver callbacks do not touch audio objects/widgets. Timing and polling are therefore not byte-for-byte PortMidi equivalent. |
| `Core/MidiInput/MidiInputHost.vala::process_note_signal` | `decodeMidiShortMessage`, `originalMidiInputLayerForChannel`, and `handleMidiInputMessage`. |
| `Core/Synthesizer/synthesizer.c::synthesizer_send_notes` | Main keyboard routing and fallback channel 20–22 voicing. The original is the behavioral reference; Windows device-specific behavior still needs testing. |
| `Shell/Layouts/AppMenuView.vala::Split By Channel` | QSettings key `midi/splitByChannel`. |

## Still not ported

- Original `note_map`, `control_map`, and reverse assignment labels, their serialized settings format, and the control-learn interaction.
- Original `midi_event_received` interception, note-to-control mapping, and CC dispatch to style buttons, registration memory, mixer, slider/knob, and master-knob targets.
- Original raw MIDI input mode, exact PortMidi polling behavior, device-added/removed hot-plug monitoring, and all relevant error/status workflows.
- Full original keyboard/synthesizer integration for arpeggiator and harmonizer, chord event recorder hooks, and state propagation across `ArrangerCore` / `CentralBus`.
- Windows Qt/MSVC build and tests on an actual MIDI device. This authoring environment cannot verify the GUI compilation or Windows hardware stack.

## Windows validation checklist

1. Build with the project's `Build-And-Run-Windows.bat`.
2. Open Settings, refresh MIDI input, select a physical device, and verify connected status.
3. Test note-on/note-off and velocity while the internal SoundFont output is active; confirm note releases do not hang.
4. Toggle Split By Channel and test messages on MIDI channels 1, 2, 3, then 4+; verify the routing against the original app with the same split/accompaniment/layer state.
5. Disconnect the device and close the app while a note is held; confirm voices are released and no callback crash occurs.
6. Check the remaining compatibility boundaries above before describing this feature as complete.
