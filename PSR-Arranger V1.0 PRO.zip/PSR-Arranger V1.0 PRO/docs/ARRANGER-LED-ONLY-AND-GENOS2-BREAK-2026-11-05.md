# Arranger LED-only feedback and Yamaha Genos2 BREAK fix

Date: 2026-11-05
Project: Ensembles 6.8.7

## Panel feedback

The Chord, Auto Fill, Intro, Variation, Break, and Ending arranger caps now use LED-only state feedback. Their face, label, outline, and surface colors no longer change when selected, hovered, or pressed. The separate indicator is the state cue:

- Available section: green LED.
- Active section/toggle: steady red LED.
- Queued section: blinking red LED.
- Inactive/unavailable: LED off/dark.

Chord and Auto Fill retain their toggle behavior and engine wiring; only the face-color feedback was removed. The Auto Fill caption no longer changes to red. The Auto Fill tooltip/status wording was aligned with the current destination-Fill behavior.

## BREAK behavior

Yamaha Genos2 Owner's Manual describes BREAK as a one-measure pattern and says Style playback automatically shifts to Main when that pattern finishes. The implementation now uses the Yamaha SFF `Fill In BA` marker as the dedicated `BREAK` section. This mapping is essential: the previous parser incorrectly exposed `Fill In BA` as a normal `FILL BA`, causing `hasBreakSection()` to reject the BREAK button on many genuine Yamaha Styles. After correcting the mapping, the bundled Yamaha corpus scan recognizes 84 of 92 files as containing BREAK (the previous parser recognized 0):

1. BREAK can be queued only while the Yamaha Style is playing and the loaded Style contains the Yamaha SFF BREAK pattern. In standard SFF files this is marked `Fill In BA`, which the parser now normalizes to `BREAK`.
2. A press during playback queues BREAK on the next beat, exactly like Immediate Fill In; it does not wait for the next full bar.
3. At activation, BREAK inherits the current bar phase, exactly like a normal Fill In. If pressed mid-bar, it plays the remaining BA phrase and ends at the original barline. If pressed in the final beat, the next beat is the next downbeat and the complete BA phrase plays from phase zero.
4. At that barline playback returns to the active Main variation. If a normal Fill was already in progress when BREAK was pressed, the current Fill reaches its boundary first, then BREAK takes over using the same phase rule.
5. If the Style has no BREAK section, the button reports that condition instead of playing a different pattern.

The UI now reports `Section: Break` while the dedicated BREAK pattern is active (rather than displaying the overlapping legacy marker label `Fill A`).

## Verification

Passed:

- Direct GCC C++17 build and run of `tests/yamaha_style_runtime_test.cpp` including the one-measure BREAK timing, BREAK-after-Fill case, and `StyleEngine::breakPlay()` integration/return-to-Main checks.
- `tests/genos2_break_and_indicator_only_test.py` (7 checks).
- `tests/style_stop_midi_queue_source_test.py` (17 checks).
- `tests/genos2_button_press_source_test.py` (11 checks).
- `tests/panel_v20_arranger_hardware_buttons_test.py` (5 tests).
- `tests/panel_v21_hardware_button_smoothing_alignment_test.py` (4 tests).
- `tests/panel_v22_registry_memory_hardware_buttons_test.py` (6 tests).
- `tests/panel_v23_yamaha_psr_s_indicator_test.py` (6 tests).
- `tests/panel_v24_arranger_roman_alpha_labels_test.py` (4 tests).
- `tests/roland_stl_ui_source_test.py` (23 checks).
- `tests/yamaha_style_picker_source_test.py` and `tests/native_style_renderer_routing_source_test.py`.
- `bash tests/run_style_engine_test.sh`.

## Verification limits

A complete Qt GUI configure/build could not be performed in this Linux environment because Qt 6 development package/configuration files (`Qt6Config.cmake`) are not installed. The Windows/MSVC build, live MIDI controller operation, and an audio comparison on a physical Genos2 have not been performed. The C++ arranger tests verify scheduled MIDI events and section transitions; they do not prove acoustic equivalence with Yamaha hardware.

Reference: [Yamaha Genos2 Owner's Manual](https://usa.yamaha.com/files/download/other_assets/4/2318564/Genos2_owners_manual_En_D0.pdf), section `[BREAK] button`.
