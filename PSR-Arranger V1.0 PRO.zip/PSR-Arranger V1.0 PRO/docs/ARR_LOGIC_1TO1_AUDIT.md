# ARR logic migration audit — checkpoint, not completion claim

This file maps the C++ ARR checkpoint to the original Ensembles implementation. It is deliberately not a claim that the whole application is 1:1 yet.

## Source-to-port map

| Original source / behavior | C++ destination | Current verification |
|---|---|---|
| `Core/MidiPlayers/StyleEngine/style_analyser.c`: Config, 15 markers, measure-to-tick formula, time signature, chord scale type | `src/style_engine.cpp::analyzeStyleFile`, plus metadata retention in `src/midi_file.*` | The reference Pop style's 15 marker ticks, Config tempo/type, time signature and TPQ are asserted by `tests/style_engine_test.cpp`; all 10 packaged `.enstl` files are opened in the core test. |
| `style_player.c::get_chord_modified_key` and major/minor chord-type cases | `StyleEngine::transformKey` | Deterministic major/minor transposition vectors are tested. Randomized original branches retain the source `srand(time)/rand` pattern; randomized audible outcomes are not exhaustively proven equal across different C runtimes. |
| `style_player.c::parse_midi_events`: CC120 filter, CC82 alternate-channel state, alt-channel channel filters, transpose exceptions for MIDI drum channels, tracked notes | `StyleEngine::processMidiEvent` | New event-trace test compares emitted events at the Variation A start to the source `.enstl` event stream, applying the source filters. This is a source-stream regression check, not yet a golden trace captured from a running original FluidSynth build. |
| `style_player.c::parse_ticks`: chord-change resend, fill queue, section change at clock edge, Intro return, sync-stop, ending stop, note-halt and alt-channel reset | `StyleEngine::processPlayerTick` | Tests exercise variation loops, each variation's paired fill range, Intro A return, both endings, sync-start/stop, and live-style replacement. Latest tests also verify elapsed-time partition invariance over 60 seconds and the manual-stop measure reset. Timing still uses a deterministic local model rather than FluidSynth callbacks. |
| `Core/ChoppingBlock/CentralBus.vala`: clock latch hold and measure increment | `StyleEngine::advanceMicroseconds` clock maintenance | Test verifies clock maintenance persists and clears after the 300 ms hold and increments measure. The wider original GObject signal graph is not ported. |
| `StyleDiscovery.vala`: built-in and user paths, `genre@name.enstl` naming and genre sort | Qt frontend `setupStyleEngine()` | Implemented paths are `data/StyleFiles` (legacy-reference fallback) and `Documents/ensembles/styles`; valid files are sorted genre case-insensitively. GUI compile/runtime has not been tested in this environment because Qt/MSVC is unavailable. |
| `StyleControllerView.vala`: section press queues a section; separate start button calls `play_style`; four combined `VARIATION / FILL-IN` controls | Qt ARR controls in `src/main_qt.cpp` | Section controls only queue/switch the source markers; separate Start/Stop toggles transport. The GUI does not yet implement the original complete UI styling/active-state feedback or recorder event emission. |
| `Core/Utils/chord_finder.c/.h` | `src/chord_finder.cpp/.h` | Original scoring formulas retained. Safety deviation: the source snapshot indexes outside its declared `key_track[13]` for some formulas; C++ normalizes pitch-class reads modulo 12. This removes undefined memory access, so those previously undefined cases cannot be described as byte-for-byte behavior. Major/minor triads over all 12 roots and an AddressSanitizer/UBSan run pass. |

## Verified commands in the authoring environment

```sh
./tests/run_midi_parser_test.sh
./tests/run_midi_input_router_test.sh
./tests/run_style_engine_test.sh
python3 tests/midi_input_source_test.py
g++ -std=c++17 -Wall -Wextra -Wpedantic -fsanitize=address,undefined \
  -fno-omit-frame-pointer src/midi_file.cpp src/style_engine.cpp \
  src/chord_finder.cpp tests/style_engine_test.cpp -o /tmp/ensembles-style-engine-asan
/tmp/ensembles-style-engine-asan
```

The standalone parser, MIDI-input-router, and ARR-engine scripts, the MIDI-input static wiring checks, and the sanitizer-built ARR core test passed at this checkpoint. These runs test C++ core routines and original style fixtures; they do not compile or launch the Qt frontend.

## Blocking gaps before calling the port 1:1 end-to-end

1. The original audio backend is FluidSynth with `EnsemblesGM.sf2`; the Qt port now has an internal FluidSynth/RtAudio path plus an optional Windows MIDI Mapper path, but the original sound bank is unavailable in this checkout and Windows audio behavior is unverified. Patch selection, sound, effects, note cleanup, routing and timing can differ even when section/transposition decisions agree.
2. Iteration 6.7 adds WinMM physical MIDI input enumeration and note routing, but `MidiInputHost` note/control learn maps, CC-to-control actions, raw mode, auto-hotplug, and full `Synthesizer.detected_chord`/recorder signal integration remain unported.
3. The wider `ArrangerCore`/`CentralBus` signal connections, recorder style-state/actual-part events, measure/beat display hooks, harmonizer, full keyboard/synth voice routing, MIDI recorder/sequencer project compatibility, plugins/rack and sampling subsystems are not fully ported.
4. The Qt 6/MSVC GUI build, Windows runtime behavior and MIDI/audio output have not been validated on the target Windows installation because this environment has no Qt 6/MSVC kit.

### Work completed in this iteration

- Removed the one-minute cap in `advanceMicroseconds()`. A single 60.5-second update now matches a 60-second update followed by a 0.5-second update.
- Restored the source `central_measure = 0` behavior on manual Stop/toggle-Stop and the section-end sync-stop branch. The modeled CentralBus hold can still increment after a clock edge, matching its separate asynchronous role.
- Added a start-of-Variation-A event-trace regression against the original `.enstl` event stream, including CC120 and CC82/alternate-channel filtering rules.
- Both standalone parser and ARR engine tests pass after these changes.

The next parity gate is a side-by-side golden trace from a running original Ensembles build and this C++ engine: feed the same `.enstl`, chord-change sequence, start/stop/variation/fill/intro/ending actions and tempo changes, then compare emitted MIDI events, section boundaries and timing. The current fixture-based event trace follows source MIDI order/filter contracts but is not a substitute for that live oracle. Do not mark 1:1 until the comparison and real Windows device tests pass.
