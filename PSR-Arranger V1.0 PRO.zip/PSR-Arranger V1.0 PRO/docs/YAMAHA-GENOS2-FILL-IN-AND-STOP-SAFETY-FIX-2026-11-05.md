# Yamaha Genos 2 Fill-In Bar Sync and ACMP Stop Safety Fix — 2026-11-05

## Defects corrected

### Fill In bar sync

`CppArrangerEngine::queue_fill()` previously deferred only requests made during the last beat. That allowed a Fill queued during beat 2 or 3 to start in the middle of a measure and be shortened. It now follows the Genos 2 **Next Bar** rule: a request within beat 1 can take effect immediately; a request after beat 1 waits for the next bar downbeat. Deferred fills start at their first event and are given a complete measure before the destination Main is resumed.

### ACMP voice and scheduled-event cleanup on Stop

Yamaha Stop now emits hard-stop MIDI on all 16 Style channels, at deadline zero:

- CC120 — All Sounds Off (kill voices immediately)
- CC64=0 — Sustain Off (release pedal-held state)
- CC123=0 — All Notes Off (clear any notes the renderer still tracks)

This replaces the prior reliance on All Notes Off alone for the Yamaha Stop path. The channels previously skipped by the generic `sendNotesOff()` path are covered by the hard Stop panic.

### Preventing queued ACMP notes from returning after Stop

All Style-origin MIDI sent to RtAudio is now marked as Style MIDI and carries a generation number. When the first Stop CC120 is dispatched, the current Style generation is invalidated. Old events are ignored in all three stages:

1. GUI-to-audio command ring, including messages that had not yet been dequeued.
2. Audio callback's future-deadline queue.
3. Events already extracted for the current callback but not yet applied.

Live keyboard MIDI sent through the normal `sendMidi` API is not tagged and is not cancelled.

On Windows, deadline-scheduled WinMM Style messages carry their own generation. Stop removes queued Style messages, and the worker rejects an old-generation event even if it was already popped from the priority queue. Non-Style WinMM messages are retained.

Stop panic events have an immediate deadline (`targetTimeUs == 0`) so they are not held behind the last musical beat.

## Regression coverage

- Beat-one Fill can take effect immediately.
- Beat-two and late-beat Fill waits for the next barline.
- Deferred Fill begins with its first MIDI event at the downbeat, does not layer Main notes during the Fill, and resumes its destination Main after one measure.
- Yamaha Style Stop emits CC120, CC64=0, and CC123=0 on all 16 channels, all with deadline zero.
- Source guards verify generation cancellation for internal RtAudio and Windows WinMM scheduling.

## Test results in this environment

- `yamaha-style-runtime-test`: passed, including the new beat-one/beat-two/late-beat Fill checks and all-16-channel immediate Stop panic.
- `style-engine-test`: passed.
- `yamaha-sty-playback-corpus-test`: 92 Yamaha `.sty` files, zero failures; all 92 emitted notes and bank/program/controller setup events (1,844 Note-On events; 13,965 setup events).
- `roland-stl-reader-test`: passed.
- Style Stop/fill source guards: 13/13 passed.
- STYLE output deadline source guards: 5/5 passed.
- Yamaha family picker, native renderer route, arranger hardware and PSR-S indicator checks passed.

One existing Registry Memory source guard still reports two assertions outside this patch (slot label/tool-tip state and unported automator-state recording); no Registry Memory files were changed in this fix.

## Yamaha reference

Yamaha Genos 2 Reference Manual, *Style Playback Related Settings*, printed page 12: Next Bar changes immediately when the operation is done within the first subsequent beat; otherwise it changes at the beginning of the next bar. The manual also states that Auto Fill In forces Next Bar behavior even when Immediate is selected. Official manual: https://data.yamaha.com/files/download/other_assets/1/2318561/Genos2_reference_manual_En_C0.pdf

## Build boundary

The C++ arranger/runtime tests were compiled and run in this environment. CMake configuration reached `find_package(Qt6)` but the Linux container does not have Qt6 development files installed, so the complete Qt GUI and WinMM/MSVC application build could not be run here. The final Windows build and physical audio-device Stop test must still be run on the target machine.
