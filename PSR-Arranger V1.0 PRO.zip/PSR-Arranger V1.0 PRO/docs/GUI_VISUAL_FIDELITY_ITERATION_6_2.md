# UI reference fidelity — iteration 6.2

This pass narrows the visible mismatch between the legacy GTK screenshot and the Qt port; it is not a declaration of full 1:1 parity.

## Focused adjustments

- `PanelDial` paints the recessed rim, silver gradient face and small value-position socket. `QDial` range/value handling remains intact, so the UI still drives its existing MIDI/controller callbacks.
- Knob diameters now follow the reference more closely: assignable 29 px, Master Knob 48 px, main output dial 74 px.
- The in-client header retains its 54 px reference height. The central LCD has a 14 px top inset followed by a 33 px tab strip, preserving the cover-image top edge while placing the labels more accurately.
- The LCD cover image uses a restrained charcoal/teal overlay to blend into the control surface.
- Button gradient bevels are lighter and subtler; vertical and horizontal slider handles are square and silver rather than rounded. The assignable-knob row now sizes to its contents, preventing the sliders from being pushed down by excess row height.

## Verification status

`tests/ui_reference_fidelity_source_test.py` verifies source-level invariants. This environment has no Qt 6 + Windows MSVC GUI toolchain, so the frontend was not compiled or launched here. A 1:1 claim requires a Windows screenshot captured at the same client dimensions as the original, followed by an image overlay/difference pass. Remaining feature/function gaps are tracked in `FEATURE_PARITY_AUDIT.md`.
