# Arranger Hardware Button Reference Match — 2026-11-05

## Requested visual target
The arranger strip follows the user's uploaded `contoh.png` reference: compact black hardware caps, larger/taller button faces, small independent status LEDs, individual Sync Stop / Sync Start captions, and Yamaha-style transport pictograms.

## UI changes
- Intro, Variation, Break, Ending section caps: 38 x 42 px (previously 38 x 32 px).
- Chord and Auto Fill caps: 36 x 42 px (previously 36 x 32 px).
- Sync Stop and Sync Start: separate caption cells and 45 x 42 px caps.
- Start/Stop: 60 x 42 px cap.
- Custom vector glyphs reproduce the reference: stacked Sync Stop bars, tapered Sync Start bars, and square/slash/play Start/Stop mark.
- Active/checked arranger state no longer changes the face to red; the independent LED remains the state indicator.
- Registration Memory caps were resized to 38 x 42 px to retain the same row baseline as the enlarged Variation caps.

## Behavior preserved
All button callbacks, section indices, Sync Start/Stop actions, Start/Stop toggle wiring, chord control, Auto Fill persistence, and indicator refresh bindings are unchanged. Only the presentation/geometry was changed.

## Verification
Passed source-level regression checks:
- `panel_v20_arranger_hardware_buttons_test.py` (7)
- `panel_v21_hardware_button_smoothing_alignment_test.py` (4)
- `panel_v22_registry_memory_hardware_buttons_test.py` (6)
- `panel_v24_arranger_roman_alpha_labels_test.py` (4)

Qt GUI build/render was not run in this Linux environment because the Qt 6 development toolchain used by the Windows project is not available here. Confirm final pixel-level appearance in the Windows build.
