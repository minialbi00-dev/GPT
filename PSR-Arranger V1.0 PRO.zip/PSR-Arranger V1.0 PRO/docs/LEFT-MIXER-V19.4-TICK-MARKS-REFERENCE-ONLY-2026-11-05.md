# Left mixer — reference tick placement

## V19.7 correction

The previous tick calculation assumed the groove was exactly 14 px wide and centered within the slider widget. That assumption was not reliable for the final Qt stylesheet geometry. V19.7 queries the actual groove rectangle with `QStyle::subControlRect(QStyle::CC_Slider, ..., QStyle::SC_SliderGroove)` and positions each amber mark wholly outside its left/right edge, leaving a one-pixel dark gap.

Only the tick-coordinate calculation changed from the V19.4 mixer baseline. The V19.4 groove skin, handle, cells, spacing, slider semantics, six assignments, and MIDI routing remain preserved.

The 21:02:44 GitHub reference is the visual target: amber ticks in the two gutters flanking the recessed dark groove, never over the groove.
