# Ensembles Qt — Iteration 6.3: Voice/Style lists in the LCD

## What changed

- Voice and Style selection now replace the central LCD home/photo page in-place; they no longer open separate desktop dialogs.
- Both pages use the original teal LCD header, left-side close control, compact charcoal rows, single-selection behavior, and amber selection treatment.
- The Voice list contains all 128 General MIDI program names and uses the original shipped instrument-family thumbnails when available. The active Voice L / Voice R1 / Voice R2 slot is respected, and changes are sent through the existing FluidSynth/RtAudio and optional Windows MIDI routing.
- The Style list presents the style name with a genre badge. Time signature and tempo are read from each `.enstl` MIDI file's time-signature metadata and `Config` marker; no BPM value is fabricated when the file cannot be parsed.
- The home/photo page is restored with the LCD header's × control.
- CMake now stages `data/Images/Instruments` beside the executable so thumbnail lookup works in deployed builds as well as a source checkout.
- Added `tests/lcd_picker_source_test.py` for static regressions.

## Validation limits

Run:

```bat
python tests\lcd_picker_source_test.py
python tests\ui_reference_fidelity_source_test.py
python tests\qt_panel_source_smoke_test.py
python tests\audio_backend_source_smoke_test.py
python tests\rtaudio_settings_source_test.py
python tests\registry_memory_source_test.py
```

This authoring environment does not include the project's Qt 6/MSVC Windows toolchain. These static checks do not constitute a Windows GUI build or pixel-difference/runtime verification. Build and compare the client area against `legacy-reference/screenshots/ScreenshotVoice.png` and `ScreenshotStyles.png` at the same window dimensions.
