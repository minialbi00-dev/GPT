# ACMP FIX6 forensic trace — status and evidence

Date: 2026-10-28

## Confirmed source-level defect removed

In `src/main_qt.cpp`, the `StyleEngine::setTimedMidiSink` callback updated the channel mixer slider for incoming STYLE CC7 and then synchronously wrote `panel/stylePartVolume/<channel>` through `QSettings::sync()` before forwarding the MIDI event into `sendStyleMidi`. `sync()` performs synchronous persistence from the GUI-thread STYLE dispatch callback. A slow settings backend can therefore delay queue handoff for events sharing that dispatch batch and make their deadlines late. The UI slider update remains, but incoming playback automation is no longer persisted as a user preference in that realtime callback.

This is a real source-level blocking path and has been removed. Runtime evidence is still needed to establish whether it accounts for the full ACMP-versus-drum symptom.

## Runtime trace

Set `ENSEMBLES_ACMP_TRACE=1` before application launch. `V19.0-Apply-Build-Run.bat` in this package sets it automatically for the launched application. Output file: `%TEMP%\Ensembles_ACMP_RuntimeTrace.csv`.

The trace contains:

- `PARSER_TICK_CORRECTION`: raw local-pattern tick and normalized local-pattern tick for every event shifted by the `255→240` STL normalization pass, with source instrument slot, chord family, part, and arrangement. The analyzer reports these edits separately from timing latency.
- `ENGINE_DISPATCH`: absolute STYLE tick, target deadline, and time the event left StyleEngine.
- `OUTPUT_QUEUE`: time the GUI hands the event to internal audio and/or WinMM.
- `AUDIO_APPLY_ESTIMATE`: target deadline and estimated sample position inside the RtAudio callback block.
- `WINMM_SEND`: target deadline and timestamp immediately after the Windows MIDI short-message API call returns.
- `QUEUE_DROP`, `AUDIO_FALLBACK`, `WINMM_FALLBACK`: evidence of dropped or no-longer-timed events.
- `SECTION` and `STYLE_LOAD`: selected STYLE path and section marker context.

`AUDIO_APPLY_ESTIMATE` is not an acoustic loopback or DAC measurement. It is an estimate of the event's sample offset inside the application audio block. If application scheduling is all on time but the audible mismatch remains, the remaining investigation needs a loopback capture or an independent hardware MIDI timestamp capture.

## Verification performed in this environment

- Linux CMake regression build: passed.
- CTest ACMP timing / StyleEngine clock / Roland STL reader: 3/3 passed.
- New forensic trace source guard: 7/7 passed.
- Existing STYLE output-deadline source guard: 5/5 passed.
- Audio sample scheduler source checks and audio backend source smoke checks: passed.
- Standalone trace-writer smoke test: emitted valid CSV with `ENGINE_DISPATCH` and `AUDIO_APPLY_ESTIMATE` rows.
- Parser normalization instrumentation now records the raw tick and the tick after the `255→240` pass, so the next run can quantify that parser transformation instead of assuming it is correct.
- Whole-library audit on the packaged STYLE corpus: 401 files loaded, 29 failed with the existing malformed-pointer/part-length error. Total emitted timeline events across families: 6,124,235.

## Verification not performed

The complete Qt/MSVC Windows application was not compiled or played on the user's PC in this environment. No physical MIDI output or speaker/DAC loopback was measured. This package is a diagnostic build plus one source-level blocking-path fix; it does not claim the ACMP audio symptom is solved.
