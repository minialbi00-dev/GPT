# Yamaha Genos2 BREAK — Root Cause and Functional Fix

Date: 2026-11-05  
Project: Ensembles 6.8.7

## Root cause of the non-working BREAK button

The Yamaha SFF marker for the BREAK pattern is `Fill In BA`. Yamaha's MIDI Song to Style Owner's Manual explicitly lists `Fill In BA` as the BREAK section. The previous Ensembles runtime normalized this marker to `FILL BA`, treating it as an ordinary XY fill. The UI's `hasBreakSection()` only looked for `BREAK`, so it rejected the BREAK command for real Yamaha styles using the standard `Fill In BA` marker.

A second scheduler defect compounded the problem. When an explicit BREAK section was present and the button was pressed mid-measure, the scheduler entered on the next beat but loaded BREAK at that same nonzero phase. That could skip the opening notes and cut the pattern off at the current measure's downbeat. A synthetic test had incorrectly described this shortened remainder as a full-measure BREAK.

## Fixes

1. Normalize Yamaha `Fill In BA` and `FILL BA` to the canonical `BREAK` section in both the Yamaha Style runtime and arranger engine.
2. Route `queue_fill("FILL BA")` and `queue_fill_next_bar("FILL BA")` through the dedicated BREAK scheduler; do not treat BA as a regular Main-to-Main fill.
3. Queue BREAK on the next beat, using the same Immediate Fill scheduler as other Fill In sections. Do not wait for the next measure unless the next beat itself is the downbeat.
4. Start the BA source pattern at the matching bar phase and finish it at the current barline. If a normal Fill is already playing, let it reach its scheduled boundary first, then start BREAK with the same phase-continuity rule and return to its active Main destination.
5. Updated regression fixtures to use the real Yamaha marker spelling `Fill In BA`, rather than a synthetic standalone `Break` marker.

## Verification

- Direct GCC C++17 build and run of `tests/yamaha_style_runtime_test.cpp`: PASS.
- `tests/genos2_break_and_indicator_only_test.py`: 8/8 PASS.
- `tests/style_stop_midi_queue_source_test.py`: 17/17 PASS.
- `tests/genos2_button_press_source_test.py`: 11/11 PASS.
- `tests/panel_v23_yamaha_psr_s_indicator_test.py`: 6/6 PASS.
- `tests/run_style_engine_test.sh`: PASS.
- `tests/roland_stl_ui_source_test.py`: 23/23 PASS.
- Real bundled Style integration: `LS-GM - Swing-Jazz - middel.sty` loaded through `StyleEngine`; `hasBreakSection()` returned true; after a mid-beat press, BREAK became active on the next beat (not the next bar), emitted 20 note-on events during the remaining BA phrase, and returned to Main at the original barline.
- Corpus scan: 84 of the 92 bundled Yamaha `.sty` files expose `Fill In BA`; all 84 are now recognized as having BREAK. The old parser recognized 0 of the 92 files as containing a dedicated BREAK section.

## Limits

The Genos2 Owner's Manual specifies a one-measure BREAK pattern followed by Main, but it does not document the exact quantization rule for every button-press position. The previous patch used next-downbeat scheduling and incorrectly waited a full bar. The corrected scheduler uses the same next-beat / phase-carry policy as Immediate Fill In; it returns at the current barline. Physical Genos2 MIDI OUT capture is still needed to confirm exact device behavior. A physical Genos2 MIDI OUT capture and Windows/MSVC GUI build are still required before claiming exact 1:1 behavior. The test confirms event generation and section state, not acoustic identity with the keyboard.

## References

- Yamaha MIDI Song to Style Owner's Manual: `Fill In BA` is mapped to Break.
- Yamaha Genos2 Owner's Manual: the one-measure Break pattern automatically returns to Main.
