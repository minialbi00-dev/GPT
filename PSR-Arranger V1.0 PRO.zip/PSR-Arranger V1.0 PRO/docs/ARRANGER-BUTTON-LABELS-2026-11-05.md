# Arranger Button Label Update — 2026-11-05

Updated only the visible face labels in the arranger strip:

- INTRO buttons: `1 / 2 / 3` → `I / II / III`
- VARIATION buttons: `1 / 2 / 3 / 4` → `A / B / C / D`
- ENDING buttons: `1 / 2 / 3` → `I / II / III`

The section captions remain INTRO, VARIATION, and ENDING. Button counts, click handlers, section marker mappings, queue behavior, LED wiring, and arranger engine logic are unchanged.

Verification:
- `python3 tests/panel_v24_arranger_roman_alpha_labels_test.py` — 4 tests passed.
- `python3 tests/panel_v23_yamaha_psr_s_indicator_test.py` — 6 tests passed.

This is a source/UI label patch. A full Qt desktop build and live keyboard validation were not performed in this environment.
