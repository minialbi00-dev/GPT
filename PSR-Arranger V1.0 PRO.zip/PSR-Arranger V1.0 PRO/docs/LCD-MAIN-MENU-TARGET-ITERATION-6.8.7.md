# LCD Main Menu Target Iteration — Ensembles 6.8.7 V20

## Visual refinements
- MIDI/Audio now uses an inset inner card with 2 px left/right spacing, matching the surrounding LCD card rows.
- LCD card surfaces remain borderless and use a consistent 6 px corner radius; navigation buttons follow the same treatment.
- Removed the horizontal separator under the LCD status/header strip.
- Removed the shared background behind the six bottom navigation buttons; only the individual buttons retain their own surfaces.
- Vertically centered the two-line Register and Vocal Harmony labels inside their cards to prevent edge clipping.
- Existing MIDI tempo metadata, picker transitions, and audio/MIDI routing callbacks are preserved.

## Verification
- `tests/lcd_home_target_layout_test.py`: static source checks passed, including transparent navigation-row background and vertically centered Register/Harmony text.
- `tests/lcd_picker_source_test.py`: 8/8 static source checks passed.
- `tests/panel_v17_4_reference_geometry_test.py`: 5/5 tests passed.
- GUI runtime/build validation still requires the Qt 6 SDK on the build machine.
