# PSR-Arranger V20 — ACMP Chord Recognition Correction Stage 6

Baseline: `PSR-Arranger_V20_CASM_SFF_Compatibility_Stage5.zip`

Date: 2026-11-16

## Reported problem

A user-reported example was that pressing C major could make ACMP behave as Cmaj7. The detector correctly classified a clean C-E-G input as Major, but an extra B still held in another input source made the combined pitch set C-E-G-B, which is legitimately classified as Cmaj7. This showed that the main fault was stale/incorrectly paired input-note state, not a need to force Cmaj7 back to Major after recognition.

A second stale-note path existed when transpose or octave settings changed between Note-On and Note-Off: the Note-Off was recalculated using the new setting, so it could fail to release the pitch recorded at Note-On.

## Changes

1. **Exact Yamaha chord-template recognition.** The Genos recognizer accepts complete mandatory/optional pitch sets from the shared Chord Control vocabulary instead of selecting the nearest-scoring chord for an incomplete fingering. Transitional C-E therefore does not become Caug; the previous valid ACMP chord remains until a supported fingering is present. A genuinely held C-E-G-B remains Cmaj7, as it should.
2. **Independent input-source ownership.** Held notes are tracked separately for the on-screen keyboard and each MIDI channel. A Note-Off from one source cannot erase another source's same pitch. Repeated Note-On events for the same source/key are reference-counted so one Note-Off does not prematurely release the key.
3. **Deterministic stale-note cleanup.** ACMP off/panic, MIDI CC120 (All Sounds Off), MIDI CC123 (All Notes Off), and MIDI-input disconnect clear the corresponding held-note state. MIDI-source cleanup also clears its paired input/output note mappings.
4. **Press-time transpose pairing.** `ChordInputNoteMap` remembers the transposed/octave-shifted output pitch on Note-On and returns that exact pitch for Note-Off. This remains correct when transpose, octave, split point, or the MIDI split-input path changes while the note is held. Repeated same-key events are kept as a stack, and UI/MIDI sources remain independent.
5. **Genos chord-mask corrections.** The shared vocabulary fixes the required/optional tone sets for ID 14 (minor 7(11)), ID 20 (7sus4), and ID 23 (7(#11)). The fifth is mandatory for 7sus4 and 7(#11), while the documented optional extensions remain optional. A pitch set that forms a different valid chord is not mislabeled: C-F-Bb can be Fsus4, while C-E-F#-Bb can be C7b5; neither is C7sus4 or C7(#11).
6. **Both input paths updated.** The ordinary keyboard/UI route and MIDI Split-By-Channel route both use the press-time mapped pitch for chord detection and note release, then forward the exact recognized Genos ID and bass pitch class to StyleEngine.

## Regression coverage

- All 33 implemented Genos Chord Control IDs are tested in all 12 chromatic transpositions.
- Strict fingering tests cover C-E versus C-E-G, Cmaj7, Chord Cancel, and mandatory/optional tones for the corrected Genos IDs.
- A stale B held on one MIDI source while another source plays C-E-G reproduces the Cmaj7 contamination; clearing the stale source restores C Major.
- Same pitch held by UI and MIDI sources is independently released.
- Repeated Note-On/Note-Off events are reference-counted.
- Press-time transpose mapping covers transpose changes between press/release, duplicate same-key events, source isolation, source reset, and panic reset.
- MIDI input routing/source guards cover CC120/CC123 and both keyboard/MIDI chord paths.

## Verification

- `chord-finder-genos-test`: PASS — 33 chord IDs, strict fingering, source-safe note tracking, stale-note reset, octave and slash-bass tests.
- `chord-input-note-map-test`: PASS — source isolation, overlapping same-key events, press-time pitch pairing, source reset and panic reset.
- `midi-input-router-test`: PASS — Note-On/Off, zero-velocity Note-On, CC120/CC123 and channel mapping.
- `chord_finder_genos_integration_source_test.py`: PASS.
- `midi_input_source_test.py`: PASS — 10/10 checks.
- `midi_input_router_test.sh`: PASS.
- `yamaha-style-runtime-test`: PASS — CASM, RTR, held ACMP chord-change, section and fill regressions.
- `style_engine_test`: PASS — original style analysis, 10 shipped legacy styles, MIDI trace, chord finder, timing and transition tests (run with `legacy-reference` as the fixture working directory).
- Yamaha PSR-S CASM corpus: PASS — 642/642 styles loaded; 92,234 Ctb2 rules; 0 malformed rules.
- Yamaha PSR-S playback corpus: PASS — 642/642 styles emitted note-ons and setup; 12,605 note-ons, 97,897 setup events; 0 failures.

## Fidelity boundary

This stage addresses chord-input state ownership, strict chord recognition and Note-On/Note-Off pitch pairing. It does **not** prove bit-for-bit or audio-identical behavior with PSR-S/SX or Genos 1/2 hardware. A complete C-E-G-B fingering is still correctly recognized as Cmaj7; the software cannot infer that a genuinely held B was an accidental playing choice. No physical Yamaha A/B capture, Windows/MSVC build, or live MIDI OUT verification was performed. Full Qt application build remains unavailable in this environment because Qt6 development files are not installed.
