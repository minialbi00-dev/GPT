# PSR-Arranger V20 — CASM/SFF Refinement Stage 5

Baseline: `PSR-Arranger_V20_ACMP_Chord_Conformity_Stage4.zip`

Date: 2026-11-16

## Focus

This stage strengthens the runtime interpretation of Yamaha CASM/SFF chord tables for legacy Ctab/SFF1 styles and Ctb2/SFF2 styles used across PSR-S, PSR-SX and Genos generations. It does not change the UI, style naming, mixer/effects, section scheduling or file data.

## Changes

1. **One authoritative NTT Bass resolver.** `casm_ntt_bass_enabled()` selects the active Ctb2 Low/Middle/High slot and applies precedence consistently:
   - Ctb2's Bass On/Off flag in the selected slot is authoritative.
   - For Ctab, an explicit SFF-GE Cntt Bass On/Off flag is authoritative, including Bass Off.
   - Only legacy Ctab without explicit Cntt metadata interprets NTT selector 3 as the Bass table. Ctb2 selector 3 remains Melodic Minor and never implicitly enables slash bass.
2. **RTR 2/4 uses the same Bass semantics.** Pitch Shift to Root and Retrigger to Root now resolve NTT Bass through the same helper as note transposition. The previous RTR path could incorrectly treat any legacy Ctab without Cntt as Bass On, or miss the legacy NTT=3 behavior.
3. **Guitar slash-bass is voice-aware.** The arranger identifies the lowest source pitch in a simultaneous Guitar-NTR voicing. Only that voice follows the slash-bass pitch class; upper guitar voices continue to fit the chord voicing. Track labels such as `BASS` or `CHORD1` no longer decide which guitar voice is the bass.
4. **Held phrases are re-fitted together.** During RTR 1/3 chord changes and when a held note becomes unmuted, notes from the same source event/part are passed through the phrase voicing solver as a group. This keeps Guitar and chordal NTT voicings from being independently mapped note-by-note. Guitar-table-suppressed notes remain tracked so their note-off and later chord-state handling stay paired.
5. **Ctb2 range consistency.** Phrase fitting now declines to merge notes when their selected Ctb2 slots use different High Key values, as well as when their NTR/NTT/note limits/Bass settings differ. Different octave-crossover settings are therefore handled by the per-note path instead of borrowing the first note's High Key.

## Regression coverage

`tests/yamaha_style_runtime_test.cpp` now checks:

- Ctb2 NTT=3 with Bass Off does not imply slash-bass.
- Legacy Ctab NTT=3 implies Bass only when Cntt is absent.
- Explicit Cntt Bass Off overrides the legacy Ctab NTT=3 selector.
- RTR 2 and RTR 4 preserve the above Ctab/Cntt precedence.
- Guitar NTT Bass distinguishes the bottom voice from upper voices without relying on the CASM role text.
- Guitar RTR-to-Root follows slash bass only for the bottom guitar voice.
- Held Guitar-NTR phrases for RTR 1/3 are re-fitted into distinct, valid destination chord tones.

## Verification

- `yamaha-style-runtime-test`: PASS (GCC C++17, `-Wall -Wextra -Wpedantic`).
- `yamaha-casm-corpus-test`: PASS — 642/642 Yamaha PSR-S styles loaded; 92,234 Ctb2 rules decoded; 0 malformed Ctb2 rules.
- `yamaha-sty-playback-corpus-test`: PASS — 642/642 styles loaded and emitted note-ons plus bank/program/controller setup; 12,605 note-ons and 97,897 setup events; 0 failures.
- `style_engine_test`: PASS — original-style analysis, all 10 shipped legacy styles, MIDI trace, chord finder, transposition, timing and transition tests (run with `legacy-reference` as the fixture working directory).
- `style_stop_midi_queue_source_test.py`: PASS — 17/17 guards.
- `panel_v23_yamaha_psr_s_indicator_test.py`: PASS — 6/6 checks.
- Corpus playback count matches a clean run of the Stage 4 baseline.

## Fidelity boundary

This stage improves deterministic CASM/SFF interpretation and held-phrase handling; it does **not** establish bit-for-bit or audio-identical behavior with PSR-S/SX or Genos 1/2 hardware. Yamaha's private Guitar fingering tables and some SFF2 extension fields are not fully published. RTR 1/2 still use a same-tick note revoice compatibility fallback because the current MIDI 1.0 output path cannot express independent per-note pitch bends on a shared channel. The full Qt application configure/build was unavailable because Qt6 development files are not installed in this environment. No physical Yamaha A/B capture, Windows/MSVC build, or live MIDI OUT verification was performed.

## Reference

Yamaha Genos2 Reference Manual, “Style Creator / SFF parameters” (NTR, NTT, Guitar, NTT Bass, High Key and RTR descriptions):

https://data.yamaha.com/files/download/other_assets/1/2318561/Genos2_reference_manual_En_C0.pdf
