# S-YXG2006LE Native Engine — Research Update

Date: 2026-11-04

## Executive result

The current C++ audio path is a generic PCM sample renderer, not yet a native implementation of the Yamaha S-YXG2006LE voice engine. It can render externally supplied mono PCM16 WAV zones from an `XGPCM1` manifest. It does not decode or synthesize the content of `sxgdat6l.tbl`.

No complete, publicly documented `sxgdat6l.tbl` decoder was found in the reviewed public projects. The public Madaha project currently reads the older S-YXG50 pair (`sxgbin41.tbl` + `sxgwave4.tbl`) and explicitly says the 2006LE files are not read. The `syxg2026-hybrid` project renders 2006LE by creating sixteen isolated S-YXG2006LE VST2 instances; that is not a native C++ renderer and is not a path used by this project.

## Local asset verification

The supplied local files were checked without attempting to decode the waveform payload:

| File | Size | SHA-256 | Observation |
|---|---:|---|---|
| `sxgbnw6l.tbl` | 716,608 bytes (`0xAEF40`) | `d63746f591ba0d4ed281211adf8824361231bf5c922d9e4b3c78ca084bc96be8` | Starts with `UTG VPRM`; header contains section offsets `0x4040`, `0x9740`, `0x32EE8`, `0x7B88C`, `0x7BA8C`, `0x9CE8C`, and `0xA69F0`. All declared non-sentinel offsets are within file bounds. |
| `sxgdat6l.tbl` | 11,723,868 bytes (`0xB2E45C`) | `94196d753b601453943d32cd29759fcb54e9f8bccd373c30548bb6935595a3b1` | Does not begin with a RIFF/WAVE header. It is not directly loadable by the existing WAV reader. No payload decoding was attempted. |

The current table parser validates `UTG VPRM` and reads the compact bank/program index area. The prior local regression test reports 950 present bank/program entries and resolves bank 0/0, program 0 to compact index 402. That is metadata validation, not proof that a sample was resolved or rendered.

## Why the current renderer is silent

The startup route requires both:

- `ENSEMBLES_SYXG2006LE_BANK`
- `ENSEMBLES_SYXG2006LE_PCM_MANIFEST`

The manifest must be `XGPCM1` and each row must name an existing mono PCM16 RIFF/WAVE file. The example manifest points to `piano_C4.wav`, but the package contains no such WAV. The renderer fails asset loading when the file is absent; it does not synthesize a Yamaha voice from the `.tbl` files.

Even with valid WAV files, the current renderer is a simplified sample-zone engine: it has 16 parts, 256 voices, key/velocity zone selection, interpolation, looping, basic envelopes, pitch bend, volume, expression, pan, sustain and note-off handling. It does not yet model the full 2006LE voice-element graph, native pitch/filter/amplitude modulation, drum articulation tables, or Yamaha XG effects behavior.

## Public-source review

1. Madaha README: https://github.com/madaha-dev/madaha — currently reads the S-YXG50 family files and explicitly lists S-YXG2006LE table support as not implemented.
2. syxg2026-hybrid README: https://github.com/OnjLouis/syxg2026-hybrid — its documented architecture uses sixteen isolated S-YXG2006LE VST instances as dry PCM sources. It is not a native C++ decoder.
3. Community thread: https://tat.midishow.com/t/topic/44439/40 — contains a user-posted, AI-generated format report that explicitly warns it may be inaccurate. Its claims are not treated here as a verified specification.

## Engineering conclusion and next input needed

There are two distinct missing pieces:

1. A verified specification or authorized, already-decoded PCM export for the S-YXG2006LE waveform data and its sample/loop metadata.
2. A full native voice engine that consumes those samples and reproduces the voice-element, envelope, filter, modulation, drum and effect behavior.

I will not reconstruct or copy an undocumented internal decoder from the proprietary Yamaha binary. The safe engineering path is to use a documented format or prepared PCM/WAV assets, then implement and test the complete native voice engine against that input. Until that source data exists, claiming that the original S-YXG2006LE factory timbres are playing would be false.

## Test status

- The native PCM renderer unit test passed in the previous validation run.
- The same test passed under AddressSanitizer and UndefinedBehaviorSanitizer.
- The full Qt application build remains unverified in this environment because Qt6 development files are unavailable.
- These tests validate the generic PCM pipeline, not S-YXG2006LE factory timbres.


## Update: native PCM renderer development

The native renderer has now been extended independently of the proprietary waveform table: WAV import accepts PCM 8/16/24/32-bit and IEEE float32, mono/stereo (stereo downmixed), and the engine adds per-voice low-pass filter control, reverb/chorus send processing, and channel-10 one-shot drum triggering. Velocity-layer and key-zone mapping remain driven by the explicit `XGPCM1` sample manifest. Tests include mono PCM16, stereo PCM24, wet-effect tail, and percussion note-off behavior.

This work makes the **native sample playback pipeline** more complete, but does not convert `sxgdat6l.tbl` into usable samples. Public search results describe the waveform file as a separate non-WAV payload processed by the original Yamaha program; the community format notes available in search explicitly mark parts of their layout as AI-generated and potentially inaccurate. No unverified waveform layout or proprietary decoding routine has been added. The factory timbres therefore remain unavailable to this renderer until a usable, documented PCM export / authorized sample set is supplied.
