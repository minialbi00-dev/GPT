/*
 * Ensembles C++ - Qt 6 Windows frontend
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Audio is rendered locally by FluidSynth from a user-supplied SoundFont and
 * streamed through the selected RtAudio output device/API. WinMM remains available
 * as a selectable alternative or parallel MIDI output.
 */
#include "audio_engine.hpp"
#include "scva_startup_policy.hpp"
#include "midi_file.hpp"
#include "style_engine.hpp"
#include "yamaha_style_mixer_routing.hpp"
#include "chord_finder.h"
#include "midi_input_router.hpp"
#include "acmp_timing_trace.hpp"
#include "acmp_level_compensation.hpp"
#include "genos2_beat_clock.hpp"

#include <QApplication>
#include <QAbstractButton>
#include <QButtonGroup>
#include <QGuiApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QElapsedTimer>
#include <QFileDialog>
#include <QFile>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QMainWindow>
#include <QPushButton>
#include <QScrollArea>
#include <QListWidget>
#include <QListView>
#include <QStackedWidget>
#include <QStyledItemDelegate>
#include <QStyleOptionViewItem>
#include <QAbstractItemView>
#include <QIcon>
#include <QSlider>
#include <QSplitter>
#include <QTabWidget>
#include <QStatusBar>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>
#include <QGridLayout>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QSettings>
#include <QStyle>
#include <QStyleOptionSlider>
#include <QDial>
#include <QSpinBox>
#include <QProgressBar>
#include <QToolButton>
#include <QFrame>
#include <QPainter>
#include <QPainterPath>
#include <QLinearGradient>
#include <QPolygon>
#include <QPen>
#include <QSizePolicy>
#include <QAbstractSpinBox>
#include <QMouseEvent>
#include <QPoint>
#include <QPointer>
#include <QRect>
#include <QRectF>
#include <QSizeF>
#include <QEvent>
#include <QScreen>
#include <QPaintEvent>
#include <QPixmap>
#include <QColor>
#include <QFontMetrics>
#include <QFileInfo>
#include <QStringList>
#include <QDir>
#include <QCoreApplication>
#include <QMetaObject>
#include <QListWidgetItem>
#include <QStandardPaths>
#include <QSignalBlocker>
#include <QDirIterator>
#include <QInputDialog>
#include <QLineEdit>
#include <QMenu>
#include <QAction>
#include <QDesktopServices>
#include <QUrl>
#include <QRegularExpression>
#include <QResizeEvent>
#include <algorithm>
#include <atomic>
#include <array>
#include <cmath>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <tuple>
#include <thread>
#include <utility>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
#include <map>
#include <limits>
#include <optional>
#include <set>
#include <vector>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

namespace {
// Minimal crash-stage trace that does not depend on Qt being initialized.
// The file is recreated at each launch in the user's temporary directory.
std::ofstream gStartupTraceFile;
void startupTrace(const char *stage) noexcept {
    try {
        if (!gStartupTraceFile.is_open()) {
            std::filesystem::path directory;
            try { directory = std::filesystem::temp_directory_path(); }
            catch (...) { directory = std::filesystem::current_path(); }
            gStartupTraceFile.open(directory / "ensembles-startup-trace.log",
                                   std::ios::out | std::ios::trunc);
        }
        if (gStartupTraceFile.is_open()) {
            gStartupTraceFile << stage << '\n';
            gStartupTraceFile.flush();
        }
    } catch (...) {
        // Diagnostics must never prevent the application from starting.
    }
}

bool isYamahaStyleExtension(const QString &extensionOrPath) {
    const QString extension = QFileInfo(extensionOrPath).suffix().isEmpty()
        ? extensionOrPath.toLower() : QFileInfo(extensionOrPath).suffix().toLower();
    const std::string filename = std::string("style.") + extension.toStdString();
    return arranger::is_yamaha_style_extension(std::filesystem::path(filename));
}

QString yamahaStyleKindLabel(const QString &extensionOrPath) {
    const QString extension = QFileInfo(extensionOrPath).suffix().isEmpty()
        ? extensionOrPath.toLower() : QFileInfo(extensionOrPath).suffix().toLower();
    const std::string filename = std::string("style.") + extension.toStdString();
    return QString::fromLatin1(arranger::yamaha_style_file_kind_name(
        arranger::yamaha_style_file_kind(std::filesystem::path(filename))));
}

constexpr std::array<const char *, 128> kPatchNames = {
    "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano",
    "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavinet",
    "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba", "Xylophone",
    "Tubular Bells", "Dulcimer", "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ",
    "Reed Organ", "Accordion", "Harmonica", "Tango Accordion", "Nylon Guitar", "Steel Guitar",
    "Jazz Electric Guitar", "Clean Electric Guitar", "Muted Electric Guitar", "Overdrive Guitar",
    "Distortion Guitar", "Guitar Harmonics", "Acoustic Bass", "Fingered Bass", "Picked Bass", "Fretless Bass",
    "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello", "Contrabass",
    "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani", "String Ensemble 1", "String Ensemble 2",
    "SynthStrings 1", "SynthStrings 2", "Choir Aahs", "Voice Oohs", "Synth Voice", "Orchestra Hit",
    "Trumpet", "Trombone", "Tuba", "Muted Trumpet", "French Horn", "Brass Section", "SynthBrass 1", "SynthBrass 2",
    "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon", "Clarinet",
    "Piccolo", "Flute", "Recorder", "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
    "Lead 1 (Square)", "Lead 2 (Sawtooth)", "Lead 3 (Calliope)", "Lead 4 (Chiff)", "Lead 5 (Charang)",
    "Lead 6 (Voice)", "Lead 7 (Fifths)", "Lead 8 (Bass + Lead)", "Pad 1 (New Age)", "Pad 2 (Warm)",
    "Pad 3 (Polysynth)", "Pad 4 (Choir)", "Pad 5 (Bowed)", "Pad 6 (Metallic)", "Pad 7 (Halo)", "Pad 8 (Sweep)",
    "FX 1 (Rain)", "FX 2 (Soundtrack)", "FX 3 (Crystal)", "FX 4 (Atmosphere)", "FX 5 (Brightness)",
    "FX 6 (Goblins)", "FX 7 (Echoes)", "FX 8 (Sci-fi)", "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba",
    "Bag Pipe", "Fiddle", "Shanai", "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock", "Taiko Drum",
    "Melodic Tom", "Synth Drum", "Reverse Cymbal", "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird Tweet",
    "Telephone Ring", "Helicopter", "Applause", "Gunshot"
};
constexpr std::array<const char *, 12> kNoteNames = {
    "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
constexpr std::array<const char *, 12> kChordNames = {
    "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"};
constexpr std::array<const char *, 12> kChordTypeNames = {
    "Major", "Minor", "Diminished", "Sus2", "Sus4", "Augmented",
    "Sixth", "Seventh", "Major 7th", "Minor 7th", "Add 9", "Ninth"};
constexpr int kOriginalSplitKey = 54; // Core/ChoppingBlock/central_bus.c default

QString nativePathMessage(const QString &path) { return QDir::toNativeSeparators(path); }

struct VoiceCatalogEntry {
    int program = 0; // zero-based MIDI Program Change
    int bank = 0;    // SCVSC.tnf variation bank, selected by CC0
    int map = 4;     // GS Tone Map: 1=SC-55, 2=SC-88, 3=SC-88Pro, 4=SC-8820
    QString name;
    QString category;
};

struct NativeEfxChoice { const char *name; int key; };
static const std::array<NativeEfxChoice, 65> kNativeEfxChoices = {{
    {"Thru / Bypass", 0x0000}, {"Equalizer", 0x0100}, {"Spectrum", 0x0101},
    {"Enhancer", 0x0102}, {"Humanizer", 0x0103}, {"Overdrive", 0x0110},
    {"Distortion", 0x0111}, {"Phaser", 0x0120}, {"Auto Wah", 0x0121},
    {"Rotary", 0x0122}, {"Stereo Flanger", 0x0123}, {"Step Flanger", 0x0124},
    {"Tremolo", 0x0125}, {"Auto Pan", 0x0126}, {"Compressor", 0x0130},
    {"Limiter", 0x0131}, {"Hexa Chorus", 0x0140}, {"Tremolo Chorus", 0x0141},
    {"Stereo Chorus", 0x0142}, {"Space-D", 0x0143}, {"3D Chorus", 0x0144},
    {"Stereo Delay", 0x0150}, {"Modulation Delay", 0x0151}, {"Triple Tap Delay", 0x0152},
    {"Quad Tap Delay", 0x0153}, {"Time Control Delay", 0x0154}, {"Reverb", 0x0155},
    {"Gate Reverb", 0x0156}, {"3D Delay", 0x0157}, {"2-Voice Pitch Shifter", 0x0160},
    {"Feedback Pitch Shifter", 0x0161}, {"3D Auto", 0x0170}, {"3D Manual", 0x0171},
    {"Lo-Fi", 0x0172}, {"Lo-Fi 2", 0x0173}, {"Overdrive + Chorus", 0x0200},
    {"Overdrive + Flanger", 0x0201}, {"Overdrive + Delay", 0x0202}, {"Distortion + Chorus", 0x0203},
    {"Distortion + Flanger", 0x0204}, {"Distortion + Delay", 0x0205}, {"Enhancer + Chorus", 0x0206},
    {"Enhancer → Flanger", 0x0207}, {"Enhancer → Delay", 0x0208}, {"Chorus + Delay", 0x0209},
    {"Flanger + Delay", 0x020A}, {"Chorus + Flanger", 0x020B}, {"Rotary Multi", 0x0300},
    {"Guitar Multi 1", 0x0400}, {"Guitar Multi 2", 0x0401}, {"Guitar Multi 3", 0x0402},
    {"Clean Guitar Multi 1", 0x0403}, {"Clean Guitar Multi 2", 0x0404}, {"Bass Multi", 0x0405},
    {"Rhodes Multi", 0x0406}, {"Keyboard Multi", 0x0500}, {"Chorus // Delay", 0x1100},
    {"Flanger // Delay", 0x1101}, {"Chorus // Flanger", 0x1102}, {"Overdrive // Overdrive 2", 0x1103},
    {"Overdrive // Rotary", 0x1104}, {"Overdrive // Phaser", 0x1105}, {"Overdrive // Auto Wah", 0x1106},
    {"Phaser // Rotary", 0x1107}, {"Phaser // Auto Wah", 0x1108}
}};

QString voiceCategoryForProgram(int p) {
    static const std::array<const char *, 16> names = {"Piano", "Chromatic Percussion", "Organ", "Guitar", "Bass", "Strings", "Ensemble", "Brass", "Reed", "Pipe", "Synth Lead", "Synth Pad", "Synth Effects", "Ethnic", "Percussion", "Sound Effects"};
    return QString::fromLatin1(names[static_cast<std::size_t>(std::clamp(p, 0, 127) / 8)]);
}

std::array<std::uint8_t, 11> makeGsDt1(std::uint8_t ah, std::uint8_t am, std::uint8_t al, std::uint8_t value) {
    const int sum = ah + am + al + value;
    const auto checksum = static_cast<std::uint8_t>((128 - (sum & 0x7f)) & 0x7f);
    return {0xF0, 0x41, 0x10, 0x42, 0x12, ah, am, al, value, checksum, 0xF7};
}


// A small painter-based piano keyboard. This follows the original KeyBed's
// five-octave C2..B6 range and sends real note-on/note-off events through the
// existing Windows MIDI path rather than rendering a screenshot as a fake UI.
class PianoKeyboardWidget final : public QWidget {
public:
    explicit PianoKeyboardWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumHeight(108);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        setMouseTracking(true);
        setFocusPolicy(Qt::StrongFocus);
        setToolTip(QStringLiteral("Keyboard 5 oktaf. Klik kiri untuk memainkan nada; klik kanan pada sebuah key untuk memindahkan split point, seperti tombol split pada KeyBed asli."));
    }

    void setNoteCallback(std::function<void(int, bool)> callback) { noteCallback_ = std::move(callback); }
    void setSplitKeyCallback(std::function<void(int)> callback) { splitKeyCallback_ = std::move(callback); }
    void setSplitKey(int note) { splitKey_ = std::clamp(note, baseNote_, baseNote_ + 59); update(); }
    int splitKey() const { return splitKey_; }
    void setBaseNote(int note) { baseNote_ = std::clamp(note, 0, 127 - 59); splitKey_ = std::clamp(splitKey_, baseNote_, baseNote_ + 59); update(); }
    void setActiveNote(int note, bool active, int noteType = 0) {
        if (active) activeNoteTypes_[note] = noteType;
        else activeNoteTypes_.erase(note);
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.fillRect(rect(), QColor("#101010"));
        int whiteCount = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) if (!isBlack(n)) ++whiteCount;
        if (whiteCount <= 0) return;
        const qreal ww = static_cast<qreal>(width()) / whiteCount;
        const qreal keyTop = 4.0; // In the original, the switch bar overlays the keyboard's top margin.
        const qreal keyHeight = std::max<qreal>(1.0, height() - keyTop);
        int wi = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (isBlack(n)) continue;
            QRectF r(wi * ww, keyTop, ww, keyHeight);
            const auto active = activeNoteTypes_.find(n);
            if (active != activeNoteTypes_.end()) {
                const QColor base = active->second == 1 ? QColor("#e3b22b")
                    : active->second == 2 ? QColor("#16a995") : QColor("#168de1");
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, base.lighter(175));
                g.setColorAt(0.25, base);
                g.setColorAt(1.0, base.darker(155));
                p.fillRect(r, g);
            } else {
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, QColor("#585858"));
                g.setColorAt(0.80, QColor("#2d3d3e"));
                g.setColorAt(1.0, QColor("#273537"));
                p.fillRect(r, g);
            }
            p.setPen(QPen(QColor("#090909"), 1.0));
            p.drawRect(r.adjusted(0, 0, -0.6, -0.6));
            ++wi;
        }
        // Black keys are painted over the white keys and receive priority in hit testing.
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (!isBlack(n)) continue;
            const QRectF r = blackRect(n, ww, keyTop, keyHeight);
            const auto active = activeNoteTypes_.find(n);
            if (active != activeNoteTypes_.end()) {
                const QColor base = active->second == 1 ? QColor("#b78512")
                    : active->second == 2 ? QColor("#087d71") : QColor("#0969b4");
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, base.lighter(165));
                g.setColorAt(1.0, base.darker(175));
                p.fillRect(r, g);
            } else {
                QLinearGradient g(r.topLeft(), r.bottomLeft());
                g.setColorAt(0.0, QColor("#444444"));
                g.setColorAt(0.12, QColor("#181818"));
                g.setColorAt(1.0, QColor("#020202"));
                p.fillRect(r, g);
            }
            p.setPen(QPen(QColor("#000000"), 1.1));
            p.drawRect(r.adjusted(0, 0, -0.6, -0.6));
            p.setPen(QPen(QColor(255, 255, 255, 24), 1.0));
            p.drawLine(r.left() + 2, r.top() + 2, r.right() - 2, r.top() + 2);
        }
        // Match KeyBed: the split marker follows the user-selectable split key.
        int splitWhiteIndex = 0;
        for (int n = baseNote_; n < std::min(splitKey_, baseNote_ + 60); ++n) if (!isBlack(n)) ++splitWhiteIndex;
        const qreal sx = splitWhiteIndex * ww;
        p.setPen(Qt::NoPen);
        p.setBrush(QColor("#606060"));
        QPolygon marker;
        marker << QPoint(static_cast<int>(sx - 5), 0) << QPoint(static_cast<int>(sx + 5), 0)
               << QPoint(static_cast<int>(sx), 7);
        p.drawPolygon(marker);
    }

    void mousePressEvent(QMouseEvent *e) override {
        const int note = noteAt(e->position().toPoint());
        if (e->button() == Qt::RightButton) {
            // The original KeyBed exposes a split-key button on each key.
            // Right-click is the compact Qt equivalent and does not trigger a note.
            if (note >= 0 && splitKeyCallback_) splitKeyCallback_(note);
            e->accept();
            return;
        }
        if (e->button() != Qt::LeftButton) return;
        if (note >= 0) {
            pressedNote_ = note;
            if (noteCallback_) noteCallback_(note, true);
        }
    }

    void mouseMoveEvent(QMouseEvent *e) override {
        if (!(e->buttons() & Qt::LeftButton)) return;
        const int next = noteAt(e->position().toPoint());
        if (next >= 0 && next != pressedNote_) {
            if (pressedNote_ >= 0) {
                if (noteCallback_) noteCallback_(pressedNote_, false);
            }
            pressedNote_ = next;
            if (noteCallback_) noteCallback_(next, true);
        }
    }

    void mouseReleaseEvent(QMouseEvent *e) override {
        if (e->button() == Qt::LeftButton && pressedNote_ >= 0) {
            if (noteCallback_) noteCallback_(pressedNote_, false);
            pressedNote_ = -1;
        }
    }

private:
    static bool isBlack(int note) {
        const int pc = note % 12;
        return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10;
    }
    QRectF blackRect(int note, qreal whiteWidth, qreal keyTop, qreal keyHeight) const {
        int whitesBefore = 0;
        for (int n = baseNote_; n < note; ++n) if (!isBlack(n)) ++whitesBefore;
        return QRectF((whitesBefore - 0.36) * whiteWidth, keyTop, whiteWidth * 0.72, keyHeight * 0.575);
    }
    int noteAt(const QPoint &point) const {
        constexpr qreal keyTop = 4.0;
        if (point.y() < static_cast<int>(keyTop)) return -1;
        int whiteCount = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) if (!isBlack(n)) ++whiteCount;
        if (!whiteCount) return -1;
        const qreal ww = static_cast<qreal>(width()) / whiteCount;
        const qreal keyHeight = std::max<qreal>(1.0, height() - keyTop);
        for (int n = baseNote_; n < baseNote_ + 60; ++n)
            if (isBlack(n) && blackRect(n, ww, keyTop, keyHeight).contains(point)) return n;
        int wi = 0;
        for (int n = baseNote_; n < baseNote_ + 60; ++n) {
            if (isBlack(n)) continue;
            if (QRectF(wi * ww, keyTop, ww, keyHeight).contains(point)) return n;
            ++wi;
        }
        return -1;
    }
    std::function<void(int, bool)> noteCallback_;
    std::function<void(int)> splitKeyCallback_;
    std::map<int, int> activeNoteTypes_;
    int baseNote_ = 36;
    int splitKey_ = kOriginalSplitKey;
    int pressedNote_ = -1;
};

// The original uses a client-side headerbar rather than a second native caption.
// Keep the same structure on Windows and allow dragging from its empty areas.
class DraggableHeaderWidget final : public QWidget {
public:
    explicit DraggableHeaderWidget(QMainWindow *window, QWidget *parent = nullptr)
        : QWidget(parent), window_(window) {}
protected:
    void mousePressEvent(QMouseEvent *event) override {
        if (event->button() == Qt::LeftButton && window_ && !window_->isMaximized() && !window_->isFullScreen()) {
            dragging_ = true;
            dragOffset_ = event->globalPosition().toPoint() - window_->frameGeometry().topLeft();
            event->accept();
            return;
        }
        QWidget::mousePressEvent(event);
    }
    void mouseMoveEvent(QMouseEvent *event) override {
        if (dragging_ && window_ && (event->buttons() & Qt::LeftButton) && !window_->isMaximized() && !window_->isFullScreen()) {
            window_->move(event->globalPosition().toPoint() - dragOffset_);
            event->accept();
            return;
        }
        QWidget::mouseMoveEvent(event);
    }
    void mouseReleaseEvent(QMouseEvent *event) override {
        dragging_ = false;
        QWidget::mouseReleaseEvent(event);
    }
private:
    QMainWindow *window_ = nullptr;
    QPoint dragOffset_;
    bool dragging_ = false;
};

// Reference-style vertical mixer fader. It keeps QSlider's value model,
// keyboard/wheel behavior and signals, while adding the small amber scale marks
// visible beside the recessed hardware track in the supplied Roland mixer crop.
class ReferenceMixerSlider final : public QSlider {
public:
    explicit ReferenceMixerSlider(QWidget *parent = nullptr)
        : QSlider(Qt::Vertical, parent) {
        setMouseTracking(true);
        setFocusPolicy(Qt::StrongFocus);
        setAttribute(Qt::WA_OpaquePaintEvent, false);
    }

protected:
    void paintEvent(QPaintEvent *event) override {
        const bool compact = property("compactMixer").toBool();
        const bool akaiStyle = property("akaiStyleFader").toBool();
        constexpr int trackContentWidth = 14;
        constexpr int trackBorder = 1;
        constexpr int trackWidth = trackContentWidth + 2 * trackBorder;
        constexpr int horizontalMargin = 9;
        const int actualTrackWidth = akaiStyle ? 5 : (compact ? 12 : trackWidth);
        const int topMargin = compact ? 7 : (akaiStyle ? 5 : 6);
        const int bottomMargin = compact ? 7 : (akaiStyle ? 5 : 6);
        const int trackLeft = (!akaiStyle && !compact)
            ? std::max(0, horizontalMargin)
            : std::max(1, (width() - actualTrackWidth) / 2);
        const QRect trackRect(trackLeft, topMargin, actualTrackWidth,
                              std::max(1, height() - topMargin - bottomMargin));

        {
            QPainter p(this);
            p.setRenderHint(QPainter::Antialiasing, false);
            QLinearGradient trackGradient(trackRect.left(), trackRect.top(),
                                          trackRect.right() + 1, trackRect.top());
            trackGradient.setColorAt(0.00, QColor(QStringLiteral("#080909")));
            trackGradient.setColorAt(0.18, QColor(QStringLiteral("#17191a")));
            trackGradient.setColorAt(0.50, QColor(QStringLiteral("#242728")));
            trackGradient.setColorAt(0.82, QColor(QStringLiteral("#141617")));
            trackGradient.setColorAt(1.00, QColor(QStringLiteral("#070808")));
            p.fillRect(trackRect, trackGradient);
            p.setPen(QColor(QStringLiteral("#080909")));
            p.drawRect(trackRect.adjusted(0, 0, -1, -1));
            p.setPen(QColor(QStringLiteral("#4a4c4d")));
            p.drawLine(trackRect.left(), trackRect.top() + 1,
                       trackRect.left(), trackRect.bottom() - 1);
            p.setPen(QColor(QStringLiteral("#050505")));
            p.drawLine(trackRect.right(), trackRect.top() + 1,
                       trackRect.right(), trackRect.bottom() - 1);

            // Legacy/standard reference mode retains its side ruler. The Akai
            // MIDImix skin intentionally omits these ticks like the hardware.
            if (!akaiStyle) {
                const int top = 8;
                const int bottom = std::max(top + 1, height() - 9);
                const int span = bottom - top;
                constexpr int tickCount = 17;
                constexpr int tickGap = 1;
                for (int i = 0; i < tickCount; ++i) {
                    const int y = top + qRound(static_cast<qreal>(i) * span / (tickCount - 1));
                    const bool major = (i % 4) == 0;
                    const int tickWidth = major ? 8 : 5;
                    const QColor tick = major ? QColor(QStringLiteral("#e0bd58"))
                                              : QColor(QStringLiteral("#b9963e"));
                    const int leftTickX = trackRect.left() - tickGap - tickWidth;
                    const int rightTickX = trackRect.right() + tickGap + 1;
                    if (leftTickX >= 0) p.fillRect(QRect(leftTickX, y, tickWidth, 2), tick);
                    if (rightTickX + tickWidth <= width()) p.fillRect(QRect(rightTickX, y, tickWidth, 2), tick);
                }
            }
        }
        QSlider::paintEvent(event);
        if (akaiStyle && orientation() == Qt::Vertical) {
            QStyleOptionSlider option;
            initStyleOption(&option);
            const QRect handle = style()->subControlRect(QStyle::CC_Slider, &option,
                                                          QStyle::SC_SliderHandle, this);
            QPainter detail(this);
            detail.setRenderHint(QPainter::Antialiasing, false);
            detail.setPen(QColor(QStringLiteral("#55595b")));
            for (int line = 0; line < 4; ++line) {
                const int y = handle.top() + 3 + line * 2;
                if (y < handle.bottom() - 1)
                    detail.drawLine(handle.left() + 3, y, handle.right() - 3, y);
            }
            detail.setPen(QColor(QStringLiteral("#f0f0f0")));
            detail.drawLine(handle.left() + 3, handle.top() + 2,
                            handle.right() - 3, handle.top() + 2);
        }
    }
};

// Akai MIDImix-style rotary control: black knurled body, dark inset face,
// and a short white position marker. QDial retains native mouse/keyboard input.
class AkaiMixerKnob final : public QDial {
public:
    explicit AkaiMixerKnob(QWidget *parent = nullptr) : QDial(parent) {
        setRange(0, 127);
        setNotchesVisible(false);
        setWrapping(false);
        setTracking(true);
        setFocusPolicy(Qt::StrongFocus);
        setAttribute(Qt::WA_OpaquePaintEvent, false);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        const qreal side = std::max<qreal>(10.0, std::min(width(), height()) - 2.0);
        const QRectF body((width() - side) / 2.0, (height() - side) / 2.0, side, side);
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(0, 0, 0, 150));
        p.drawEllipse(body.translated(0.3, 1.0));

        QLinearGradient rim(body.topLeft(), body.bottomLeft());
        rim.setColorAt(0.0, QColor(QStringLiteral("#55595b")));
        rim.setColorAt(0.22, QColor(QStringLiteral("#242729")));
        rim.setColorAt(1.0, QColor(QStringLiteral("#080909")));
        p.setBrush(rim);
        p.setPen(QPen(QColor(QStringLiteral("#080909")), 0.8));
        p.drawEllipse(body);

        const QRectF face = body.adjusted(side * 0.17, side * 0.17, -side * 0.17, -side * 0.17);
        QLinearGradient faceGradient(face.topLeft(), face.bottomLeft());
        faceGradient.setColorAt(0.0, QColor(QStringLiteral("#34383a")));
        faceGradient.setColorAt(0.48, QColor(QStringLiteral("#202426")));
        faceGradient.setColorAt(1.0, QColor(QStringLiteral("#111415")));
        p.setBrush(faceGradient);
        p.setPen(QPen(QColor(QStringLiteral("#090a0a")), 0.7));
        p.drawEllipse(face);

        const int range = maximum() - minimum();
        const qreal t = range > 0 ? std::clamp((value() - minimum()) / static_cast<qreal>(range), 0.0, 1.0) : 0.5;
        const qreal angle = (135.0 + t * 270.0) * 3.14159265358979323846 / 180.0;
        const qreal radius = face.width() * 0.28;
        const QPointF center = face.center();
        const QPointF marker(center.x() + std::cos(angle) * radius,
                             center.y() + std::sin(angle) * radius);
        p.setPen(QPen(QColor(QStringLiteral("#f2f2f2")), std::max<qreal>(1.1, side * 0.075), Qt::SolidLine, Qt::RoundCap));
        p.drawLine(center, marker);
    }
};

// The GTK reference uses a recessed silver knob with a small movable socket,
// not Qt's default dark QDial face. Keep QDial's input/value behavior but paint
// the same hardware-like face used by the original panel.
class PanelDial final : public QDial {
public:
    explicit PanelDial(QWidget *parent = nullptr) : QDial(parent) {
        setAttribute(Qt::WA_OpaquePaintEvent, false);
        setNotchesVisible(false);
        setWrapping(false);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);

        const qreal side = std::max<qreal>(12.0, std::min(width(), height()) - 3.0);
        const QRectF outer((width() - side) / 2.0, (height() - side) / 2.0, side, side);
        const bool masterTarget = property("masterTarget").toBool();
        const QColor rim = masterTarget ? QColor("#b89a45") : QColor("#111819");

        p.setPen(Qt::NoPen);
        p.setBrush(QColor(0, 0, 0, 135));
        p.drawEllipse(outer.translated(0.4, 1.3));

        QLinearGradient rimGradient(outer.topLeft(), outer.bottomLeft());
        rimGradient.setColorAt(0.0, masterTarget ? QColor("#d8bd69") : QColor("#879493"));
        rimGradient.setColorAt(0.22, QColor("#3d3d3d"));
        rimGradient.setColorAt(1.0, QColor("#101010"));
        p.setBrush(rimGradient);
        p.setPen(QPen(rim, masterTarget ? 1.2 : 1.0));
        p.drawEllipse(outer.adjusted(0.5, 0.5, -0.5, -0.5));

        const qreal inset = std::max<qreal>(2.2, side * 0.105);
        const QRectF face = outer.adjusted(inset, inset, -inset, -inset);
        QLinearGradient faceGradient(face.topLeft(), face.bottomLeft());
        faceGradient.setColorAt(0.0, QColor("#e6e6e6"));
        faceGradient.setColorAt(0.28, QColor("#c9c9c9"));
        faceGradient.setColorAt(0.72, QColor("#b0b0b0"));
        faceGradient.setColorAt(1.0, QColor("#929292"));
        p.setBrush(faceGradient);
        p.setPen(QPen(QColor("#d4d4d4"), 0.7));
        p.drawEllipse(face);

        // The original knob indicates its position with a small socket on the
        // perimeter. Mid-value is at 12 o'clock, matching the four assignable knobs.
        const int span = maximum() - minimum();
        const qreal t = span > 0 ? std::clamp((value() - minimum()) / static_cast<qreal>(span), 0.0, 1.0) : 0.5;
        const qreal angle = (135.0 + t * 270.0) * 3.14159265358979323846 / 180.0;
        const qreal radius = face.width() * 0.285;
        const QPointF center = face.center() + QPointF(std::cos(angle) * radius, std::sin(angle) * radius);
        const qreal socketSize = side < 37.0 ? 3.8 : (side < 57.0 ? 5.2 : 6.2);
        const QRectF socket(center.x() - socketSize / 2.0, center.y() - socketSize / 2.0, socketSize, socketSize);
        p.setBrush(QColor("#737373"));
        p.setPen(QPen(QColor("#e1eae8"), 0.65));
        p.drawEllipse(socket.adjusted(-0.7, -0.7, 0.7, 0.7));
        p.setBrush(QColor("#435658"));
        p.setPen(QPen(QColor("#3b4c4e"), 0.45));
        p.drawEllipse(socket);
        p.setPen(QPen(QColor(255, 255, 255, 70), 0.55));
        p.drawArc(face.adjusted(1.1, 1.1, -1.1, -1.1), 35 * 16, 110 * 16);
    }
};

// Mouse actions in the arranger should behave like hardware: the command is
// issued on the physical mouse-down, not after the user releases the button.
// This application-wide filter synthesizes one Qt click on press and consumes
// the matching physical release, so ordinary clicked/toggled handlers remain
// the single action path. Momentary controls (for example the Sustain pedal)
// opt out and retain their real pressed/released lifetime.
class ImmediateMouseButtonPressFilter final : public QObject {
public:
    using QObject::QObject;

protected:
    bool eventFilter(QObject *watched, QEvent *event) override {
        const auto type = event->type();
        if (type == QEvent::MouseButtonPress || type == QEvent::MouseButtonDblClick) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton) {
                // A fresh physical press means any previous release was lost
                // outside the app; clear it even when the new target is a
                // momentary pedal or the on-screen keyboard (not a button).
                if (releasePending_) {
                    if (activeButton_) activeButton_->setDown(false);
                    activeButton_.clear();
                    releasePending_ = false;
                }
                auto *button = qobject_cast<QAbstractButton *>(watched);
                if (button && button->isEnabled() &&
                    !button->property("deferMouseClickUntilRelease").toBool()) {
                    activeButton_ = button;
                    releasePending_ = true;
                    QPointer<QAbstractButton> guard(button);
                    button->click();
                    // A clicked handler may open a modal dialog; the release may
                    // arrive in that nested event loop. Only leave the cap visually
                    // depressed while the matching physical release is still due.
                    if (guard && releasePending_ && activeButton_.data() == guard.data())
                        guard->setDown(true);
                    mouse->accept();
                    return true;
                }
            }
        } else if (type == QEvent::MouseButtonRelease) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton && releasePending_) {
                if (activeButton_) activeButton_->setDown(false);
                activeButton_.clear();
                releasePending_ = false;
                mouse->accept();
                return true;
            }
        } else if (type == QEvent::ApplicationDeactivate || type == QEvent::WindowDeactivate) {
            if (activeButton_) activeButton_->setDown(false);
            activeButton_.clear();
            // Keep releasePending_ armed until a release arrives or a new press
            // replaces it; this prevents a late release from firing a second click.
        }
        return QObject::eventFilter(watched, event);
    }

private:
    QPointer<QAbstractButton> activeButton_;
    bool releasePending_ = false;
};

// Rounded, anti-aliased hardware cap for arranger and transport controls.
// QPushButton remains the source of click/toggle behavior; only its face is custom-painted.
class HardwareCapButton final : public QPushButton {
public:
    explicit HardwareCapButton(const QString &text = QString(), QWidget *parent = nullptr)
        : QPushButton(text, parent) {
        setAttribute(Qt::WA_Hover, true);
        setAttribute(Qt::WA_OpaquePaintEvent, false);
        setAutoDefault(false);
        setDefault(false);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);

        const QRectF bounds = QRectF(rect()).adjusted(1.0, 1.0, -1.0, -1.0);
        if (bounds.width() <= 1.0 || bounds.height() <= 1.0) return;

        const bool indicatorOnly = property("indicatorOnly").toBool();
        const bool active = isCheckable() && isChecked();
        const bool pressed = isDown();
        const bool hovered = underMouse();
        QColor top = QColor("#3d4d4f");
        QColor middle = QColor("#1f2b2d");
        QColor bottom = QColor("#101010");
        QColor edge = QColor("#080808");
        QColor highlight = QColor(255, 255, 255, 52);
        QColor foreground = indicatorOnly ? QColor("#ededed") : palette().color(QPalette::ButtonText);

        // These arranger caps use their separate LED as the only state cue.
        // Keep the button face, label and outline identical while selected,
        // hovered or pressed; no red selection/press color is painted here.
        if (!indicatorOnly && active) {
            top = QColor("#4a292b");
            middle = QColor("#241719");
            bottom = QColor("#0b0809");
            edge = QColor("#8a3037");
            highlight = QColor(255, 110, 118, 125);
            foreground = QColor("#ff858a");
        } else if (!indicatorOnly && hovered) {
            top = QColor("#435658");
            middle = QColor("#293638");
            bottom = QColor("#151515");
            edge = QColor("#82918f");
            highlight = QColor(255, 255, 255, 82);
        }
        if (!indicatorOnly && pressed) {
            if (active) {
                top = QColor("#623538");
                middle = QColor("#392326");
                bottom = QColor("#1a1012");
            } else {
                top = QColor("#435658");
                middle = QColor("#293638");
                bottom = QColor("#181818");
            }
        }
        if (!isEnabled()) {
            foreground = QColor("#82918f");
            top = top.darker(135);
            middle = middle.darker(125);
            bottom = bottom.darker(115);
            highlight.setAlpha(20);
        }

        // A soft shadow and rounded vector path avoid the stair-stepped corners
        // produced by tiny stylesheet borders at this control size.
        QPainterPath shadow;
        shadow.addRoundedRect(bounds.translated(0.0, 0.65), 5.5, 5.5);
        painter.fillPath(shadow, QColor(0, 0, 0, 145));

        const QRectF face = bounds.adjusted(0.25, 0.15, -0.25, -0.55);
        QPainterPath facePath;
        facePath.addRoundedRect(face, 5.2, 5.2);
        QLinearGradient gradient(face.topLeft(), face.bottomLeft());
        gradient.setColorAt(0.0, top);
        gradient.setColorAt(0.24, middle);
        gradient.setColorAt(1.0, bottom);
        painter.setBrush(gradient);
        painter.setPen(QPen(edge, 1.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawPath(facePath);

        QPainterPath topRim;
        topRim.moveTo(face.left() + 6.0, face.top() + 1.1);
        topRim.cubicTo(face.left() + 10.0, face.top() - 0.1,
                       face.right() - 10.0, face.top() - 0.1,
                       face.right() - 6.0, face.top() + 1.1);
        painter.setBrush(Qt::NoBrush);
        painter.setPen(QPen(highlight, 0.8, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawPath(topRim);

        QFont labelFont = font();
        labelFont.setBold(true);
        if (labelFont.pointSizeF() < 8.0) labelFont.setPointSizeF(8.0);
        painter.setFont(labelFont);
        painter.setPen(foreground);
        const QString hardwareGlyph = property("hardwareGlyph").toString();
        if (hardwareGlyph.isEmpty()) {
            painter.drawText(QRectF(rect()).adjusted(1.0, 2.0, -1.0, -1.0), Qt::AlignCenter, text());
        } else {
            // Yamaha-style transport pictograms from the supplied panel reference.
            painter.setPen(Qt::NoPen);
            painter.setBrush(foreground);
            const qreal cx = width() * 0.5;
            const qreal cy = height() * 0.5;
            if (hardwareGlyph == QStringLiteral("sync-stop")) {
                // Reference pictogram: three horizontal sync bars above a solid
                // stop block. The narrow cyan edge is part of the supplied icon.
                constexpr qreal barWidth = 12.0;
                constexpr qreal barHeight = 2.0;
                for (int i = 0; i < 3; ++i) {
                    const qreal y = cy - 8.75 + static_cast<qreal>(i) * 3.0;
                    painter.drawRoundedRect(QRectF(cx - barWidth / 2.0, y,
                                                   barWidth, barHeight), 0.45, 0.45);
                }
                const QRectF stopBlock(cx - 5.5, cy + 0.75, 11.0, 8.0);
                painter.setPen(Qt::NoPen);
                painter.setBrush(foreground);
                painter.drawRect(stopBlock);
            } else if (hardwareGlyph == QStringLiteral("sync-start")) {
                // Reference SYNC START: the same three horizontal bars with a
                // filled downward-pointing trigger triangle below them.
                constexpr qreal barWidth = 12.0;
                constexpr qreal barHeight = 2.0;
                for (int i = 0; i < 3; ++i) {
                    const qreal y = cy - 8.75 + static_cast<qreal>(i) * 3.0;
                    painter.drawRoundedRect(QRectF(cx - barWidth / 2.0, y,
                                                   barWidth, barHeight), 0.45, 0.45);
                }
                QPolygonF down;
                down << QPointF(cx - 6.0, cy + 0.75)
                     << QPointF(cx + 6.0, cy + 0.75)
                     << QPointF(cx, cy + 8.75);
                painter.drawPolygon(down);
            } else if (hardwareGlyph == QStringLiteral("start-stop")) {
                // Reference combined STOP / START pictogram: solid white stop
                // square, rising diagonal divider, and solid play triangle.
                const QRectF stopSquare(cx - 16.0, cy - 5.5, 11.0, 11.0);
                painter.setPen(Qt::NoPen);
                painter.setBrush(foreground);
                painter.drawRect(stopSquare);
                painter.setPen(Qt::NoPen);
                painter.setBrush(foreground);
                QPolygonF slash;
                slash << QPointF(cx - 2.5, cy + 6.0)
                      << QPointF(cx + 1.5, cy + 6.0)
                      << QPointF(cx + 6.0, cy - 6.0)
                      << QPointF(cx + 2.0, cy - 6.0);
                painter.drawPolygon(slash);
                QPolygonF play;
                play << QPointF(cx + 8.0, cy - 6.0)
                     << QPointF(cx + 8.0, cy + 6.0)
                     << QPointF(cx + 16.0, cy);
                painter.drawPolygon(play);
            }
        }

        // No dotted focus rectangle: it changes the hardware-cap silhouette.
        // Arranger selection state is shown by the separate indicator LED.
    }
};

class CoverPhotoWidget final : public QWidget {
public:
    explicit CoverPhotoWidget(const QString &path, QWidget *parent = nullptr) : QWidget(parent), pixmap_(path) {
        setMinimumHeight(80);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.fillRect(rect(), QColor("#111111"));
        if (pixmap_.isNull()) return;
        const QSizeF srcSize = pixmap_.size();
        const qreal scale = std::max(width() / srcSize.width(), height() / srcSize.height());
        const QSizeF scaled(srcSize.width() * scale, srcSize.height() * scale);
        const QRectF target((width() - scaled.width()) / 2.0, (height() - scaled.height()) / 2.0, scaled.width(), scaled.height());
        p.setRenderHint(QPainter::SmoothPixmapTransform, true);
        p.drawPixmap(target, pixmap_, QRectF(pixmap_.rect()));
        // The legacy LCD uses the photo underneath charcoal/teal overlays. Darken
        // the Qt crop slightly so the cover image sits inside the display rather
        // than looking like a bright, unframed desktop photograph.
        QLinearGradient shade(0.0, 0.0, 0.0, height());
        shade.setColorAt(0.0, QColor(28, 34, 35, 58));
        shade.setColorAt(0.58, QColor(22, 29, 32, 36));
        shade.setColorAt(1.0, QColor(13, 19, 22, 72));
        p.fillRect(rect(), shade);
    }
private:
    QPixmap pixmap_;
};

// Paints the Voice and Style chooser rows in the same compact, instrument-panel
// language as the original LCD: charcoal rows, thumbnail/category badge, and an
// amber selected row.  Item metadata lives in Qt::UserRole + 1 (secondary line)
// and Qt::UserRole + 2 (right-hand badge).
class JoystickPadWidget final : public QWidget {
public:
    explicit JoystickPadWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumSize(110, 76);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        setMouseTracking(true);
        setToolTip(QStringLiteral("Seret titik untuk mengirim dua MIDI CC; default X=Pan CC10, Y=Modulation CC1."));
    }
    void setAxisValues(int x, int y) {
        x_ = std::clamp(x, 0, 127); y_ = std::clamp(y, 0, 127); update();
    }
    void setChangedCallback(std::function<void(int, int)> callback) { changed_ = std::move(callback); }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this); p.setRenderHint(QPainter::Antialiasing, true);
        p.fillRect(rect(), QColor("#151515"));
        QRectF area = QRectF(rect()).adjusted(9, 7, -9, -7);
        p.setPen(QPen(QColor("#304244"), 1)); p.setBrush(QColor("#1c1c1c")); p.drawRoundedRect(area, 3, 3);
        p.setPen(QPen(QColor("#424242"), 1, Qt::DashLine));
        p.drawLine(QPointF(area.center().x(), area.top()+3), QPointF(area.center().x(), area.bottom()-3));
        p.drawLine(QPointF(area.left()+3, area.center().y()), QPointF(area.right()-3, area.center().y()));
        const qreal cx = area.left() + 6 + (area.width()-12) * (static_cast<qreal>(x_) / 127.0);
        const qreal cy = area.bottom()-6 - (area.height()-12) * (static_cast<qreal>(y_) / 127.0);
        p.setPen(QPen(QColor("#6d6d6d"), 2)); p.setBrush(QColor("#b7b7b7")); p.drawEllipse(QPointF(cx, cy), 7, 7);
        p.setPen(QColor("#c6dfde")); p.setFont(QFont(p.font().family(), 7));
        p.drawText(QRectF(area.left()+2, area.bottom()-14, area.width()-4, 11), Qt::AlignRight|Qt::AlignVCenter,
                   QStringLiteral("X %1  Y %2").arg(x_).arg(y_));
    }
    void mousePressEvent(QMouseEvent *event) override { updateFromPoint(event->position()); event->accept(); }
    void mouseMoveEvent(QMouseEvent *event) override { if (event->buttons() & Qt::LeftButton) updateFromPoint(event->position()); event->accept(); }
private:
    int x_ = 64, y_ = 64;
    std::function<void(int, int)> changed_;
    void updateFromPoint(const QPointF &point) {
        const QRectF area = QRectF(rect()).adjusted(15, 13, -15, -13);
        if (area.width() <= 0 || area.height() <= 0) return;
        const int nx = std::clamp(qRound((point.x()-area.left())/area.width()*127.0),0,127);
        const int ny = std::clamp(qRound((area.bottom()-point.y())/area.height()*127.0),0,127);
        if (nx == x_ && ny == y_) return;
        x_ = nx; y_ = ny; update(); if (changed_) changed_(x_, y_);
    }
};

// Recessed dark category key styled after the physical Yamaha PSR-SX top panel.
// Labels remain printed on the chassis above each cap; the small amber lamp shows
// which category key was most recently selected.
class StyleCategoryKeyButton final : public QPushButton {
public:
    explicit StyleCategoryKeyButton(QWidget *parent = nullptr) : QPushButton(parent) {
        setCheckable(true);
        setFocusPolicy(Qt::NoFocus);
        setCursor(Qt::PointingHandCursor);
        setAttribute(Qt::WA_Hover, true);
        setFlat(true);
    }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        const QRectF socket = QRectF(rect()).adjusted(0.8, 0.8, -0.8, -0.8);
        if (socket.width() <= 2.0 || socket.height() <= 2.0) return;

        // Dark inset well around the actual key cap.
        painter.setPen(QPen(QColor(QStringLiteral("#080b0c")), 1.0));
        painter.setBrush(QColor(QStringLiteral("#0c1011")));
        painter.drawRoundedRect(socket, 2.0, 2.0);

        QRectF face = socket.adjusted(2.0, 1.5, -2.0, -2.0);
        if (isDown()) face.translate(0.0, 1.0);

        QColor top(QStringLiteral("#515b5d"));
        QColor middle(QStringLiteral("#30383a"));
        QColor bottom(QStringLiteral("#171c1e"));
        QColor edge(QStringLiteral("#090d0e"));
        QColor highlight(QStringLiteral("#7b8586"));
        if (underMouse()) {
            top = QColor(QStringLiteral("#626d6f"));
            middle = QColor(QStringLiteral("#3a4446"));
            bottom = QColor(QStringLiteral("#1d2426"));
            highlight = QColor(QStringLiteral("#a0a9a9"));
        }
        if (isDown()) {
            top = QColor(QStringLiteral("#202729"));
            middle = QColor(QStringLiteral("#303a3c"));
            bottom = QColor(QStringLiteral("#495456"));
            highlight = QColor(QStringLiteral("#111718"));
        }

        QLinearGradient capGradient(face.topLeft(), face.bottomLeft());
        capGradient.setColorAt(0.0, top);
        capGradient.setColorAt(0.46, middle);
        capGradient.setColorAt(1.0, bottom);
        painter.setPen(QPen(edge, 1.0));
        painter.setBrush(capGradient);
        painter.drawRoundedRect(face, 2.0, 2.0);

        // Very shallow machined bevels, not a white outlined key.
        painter.setPen(QPen(highlight, 0.8));
        painter.drawLine(QPointF(face.left() + 2.0, face.top() + 1.0),
                         QPointF(face.right() - 2.0, face.top() + 1.0));
        painter.setPen(QPen(QColor(QStringLiteral("#080b0c")), 0.8));
        painter.drawLine(QPointF(face.left() + 2.0, face.bottom() - 1.0),
                         QPointF(face.right() - 2.0, face.bottom() - 1.0));

        // Small amber status lamp like the category indicators on the PSR-SX deck.
        const QRectF led(face.left() + 5.0, face.center().y() - 1.5, 5.0, 3.0);
        if (isChecked()) {
            painter.setPen(Qt::NoPen);
            painter.setBrush(QColor(255, 153, 28, 55));
            painter.drawEllipse(led.adjusted(-2.0, -1.5, 2.0, 1.5));
            painter.setBrush(QColor(QStringLiteral("#ffad32")));
            painter.drawRoundedRect(led, 1.0, 1.0);
            painter.setPen(QPen(QColor(QStringLiteral("#ffe0a3")), 0.6));
            painter.drawLine(QPointF(led.left() + 1.0, led.top() + 0.6),
                             QPointF(led.right() - 1.0, led.top() + 0.6));
        } else {
            painter.setPen(Qt::NoPen);
            painter.setBrush(QColor(QStringLiteral("#21180d")));
            painter.drawRoundedRect(led, 1.0, 1.0);
        }
    }
};

class LcdPickerItemDelegate final : public QStyledItemDelegate {
public:
    explicit LcdPickerItemDelegate(bool voiceMode, QObject *parent = nullptr)
        : QStyledItemDelegate(parent), voiceMode_(voiceMode) {}

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const override {
        QSize hint = QStyledItemDelegate::sizeHint(option, index);
        if (voiceMode_) {
            hint.setHeight(40);
            hint.setWidth(option.widget ? std::max(360, option.widget->width()) : 480);
        } else {
            hint.setHeight(45);
        }
        return hint;
    }

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const override {
        painter->save();
        const QRect row = option.rect;
        const bool selected = option.state.testFlag(QStyle::State_Selected);
        painter->fillRect(row, selected ? QColor(QStringLiteral("#665400"))
                                        : QColor(QStringLiteral("#273537")));
        painter->setPen(QColor(QStringLiteral("#414141")));
        painter->drawLine(row.bottomLeft(), row.bottomRight());

        int textLeft = row.left() + 9;
        const QIcon icon = qvariant_cast<QIcon>(index.data(Qt::DecorationRole));
        if (voiceMode_) {
            const QRect iconRect(row.left() + 7, row.top() + 2, 54, 36);
            if (!icon.isNull()) icon.paint(painter, iconRect, Qt::AlignCenter, QIcon::Normal, QIcon::Off);
            textLeft = row.left() + 70;
        }

        const QString badge = index.data(Qt::UserRole + 2).toString();
        const QString secondary = index.data(Qt::UserRole + 1).toString();
        const QFont originalFont = painter->font();
        QFont mainFont = originalFont;
        mainFont.setPointSize(9);
        painter->setFont(mainFont);
        painter->setPen(selected ? QColor(QStringLiteral("#ffffff"))
                                 : QColor(QStringLiteral("#bdbdbd")));
        const int rightReserve = voiceMode_ ? 152 : 102;
        QRect mainRect(textLeft, row.top() + (voiceMode_ ? 1 : 3),
                       std::max(0, row.right() - textLeft - rightReserve),
                       voiceMode_ ? 21 : 21);
        painter->drawText(mainRect, Qt::AlignVCenter | Qt::AlignLeft,
                          painter->fontMetrics().elidedText(index.data(Qt::DisplayRole).toString(),
                                                             Qt::ElideRight, mainRect.width()));

        if (!badge.isEmpty()) {
            QFont badgeFont = originalFont;
            badgeFont.setPointSize(7);
            painter->setFont(badgeFont);
            const int badgeWidth = std::min(122, std::max(48, painter->fontMetrics().horizontalAdvance(badge) + 14));
            const QRect badgeRect(row.right() - badgeWidth - 7, row.top() + (voiceMode_ ? 2 : 5),
                                  badgeWidth, 16);
            painter->setPen(Qt::NoPen);
            painter->setBrush(QColor(QStringLiteral("#c5c5c5")));
            painter->drawRoundedRect(badgeRect, 2, 2);
            painter->setPen(QColor(QStringLiteral("#333333")));
            painter->drawText(badgeRect.adjusted(3, 0, -3, 0), Qt::AlignCenter,
                              painter->fontMetrics().elidedText(badge, Qt::ElideRight, badgeRect.width() - 6));
        }

        if (!secondary.isEmpty()) {
            QFont detailFont = originalFont;
            detailFont.setPointSize(7);
            painter->setFont(detailFont);
            painter->setPen(selected ? QColor(QStringLiteral("#f4e8b4"))
                                     : QColor(QStringLiteral("#b5b5b5")));
            const int detailTop = voiceMode_ ? row.top() + 21 : row.top() + 23;
            painter->drawText(QRect(textLeft, detailTop, row.width() - (textLeft - row.left()) - 8, 16),
                              voiceMode_ ? (Qt::AlignLeft | Qt::AlignVCenter)
                                         : (Qt::AlignRight | Qt::AlignVCenter), secondary);
        }
        painter->restore();
    }

private:
    bool voiceMode_ = false;
};

// Two-column Yamaha Style browser.  The viewport is deliberately paged at ten
// entries (five rows per column) so it follows the supplied 800x480 reference
// instead of becoming a long desktop-style list.
class LcdStyleGridListWidget final : public QListWidget {
public:
    explicit LcdStyleGridListWidget(QWidget *parent = nullptr) : QListWidget(parent) {}

protected:
    void resizeEvent(QResizeEvent *event) override {
        QListWidget::resizeEvent(event);
        // Split the usable viewport exactly in half.  Do not leave a hard-coded
        // 6 px remainder on the right: that made the outer left/right insets
        // visibly different from the reference.
        const int cellWidth = std::max(1, viewport()->width() / 2);
        const int cellHeight = std::max(24, viewport()->height() / 5);
        setGridSize(QSize(cellWidth, cellHeight));
    }
};

class LcdStyleGridItemDelegate final : public QStyledItemDelegate {
public:
    explicit LcdStyleGridItemDelegate(QObject *parent = nullptr) : QStyledItemDelegate(parent) {}

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &) const override {
        const int width = option.widget ? std::max(1, option.widget->width() / 2) : 143;
        const int height = option.widget ? std::max(24, option.widget->height() / 5) : 42;
        return QSize(width, height);
    }

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const override {
        painter->save();
        const QRect cell = option.rect;
        const QRect face = cell.adjusted(1, 1, -1, -1);
        const bool selected = option.state.testFlag(QStyle::State_Selected);
        painter->fillRect(face, selected ? QColor(QStringLiteral("#f0f0f6"))
                                         : QColor(QStringLiteral("#262626")));
        painter->setPen(QColor(QStringLiteral("#414141")));
        // Keep the regular grid as bottom/right one-pixel rules. Add only the
        // two missing OUTER boundaries: the far-left edge of column one and
        // the top edge of the first row in each column. Never draw top/left
        // borders on every cell; that doubles shared strokes and looks thicker.
        if (index.row() < 5)
            painter->drawLine(cell.topLeft(), cell.bottomLeft());
        if (index.row() == 0 || index.row() == 5)
            painter->drawLine(cell.topLeft(), cell.topRight());
        painter->drawLine(cell.bottomLeft(), cell.bottomRight());
        painter->drawLine(cell.topRight(), cell.bottomRight());

        const qreal itemScale = std::clamp(static_cast<qreal>(cell.height()) / 62.0, 0.55, 1.0);
        const int sx = qRound(13 * itemScale);
        const int sy = qRound(14 * itemScale);
        const int badgeWidth = qRound(38 * itemScale);
        const int badgeHeight = qRound(36 * itemScale);
        const QRect badgeRect(cell.left() + sx, cell.top() + sy, badgeWidth, badgeHeight);
        painter->fillRect(badgeRect, QColor(QStringLiteral("#050505")));
        QFont badgeFont = painter->font();
        badgeFont.setPointSizeF(std::max(6.0, 8.0 * itemScale));
        badgeFont.setBold(true);
        badgeFont.setStretch(QFont::Condensed);
        painter->setFont(badgeFont);
        painter->setPen(QColor(QStringLiteral("#ffffff")));
        painter->drawText(badgeRect.adjusted(2, 1, -2, -1), Qt::AlignCenter,
                          index.data(Qt::UserRole + 2).toString());

        const QString name = index.data(Qt::DisplayRole).toString();
        QFont nameFont = painter->font();
        nameFont.setStretch(QFont::Unstretched);
        nameFont.setPointSizeF(std::max(7.0, 14.0 * itemScale));
        nameFont.setBold(false);
        painter->setFont(nameFont);
        painter->setPen(selected ? QColor(QStringLiteral("#111111"))
                                 : QColor(QStringLiteral("#e1eae8")));
        const int nameLeft = qRound(62 * itemScale);
        const int rightReserve = qRound(142 * itemScale);
        const QRect nameRect(cell.left() + nameLeft, cell.top() + qRound(13 * itemScale),
                             std::max(0, cell.width() - rightReserve),
                             std::max(1, cell.height() - qRound(18 * itemScale)));
        painter->drawText(nameRect, Qt::AlignVCenter | Qt::AlignLeft,
                          painter->fontMetrics().elidedText(name, Qt::ElideRight, nameRect.width()));

        const QString tempo = index.data(Qt::UserRole + 1).toString();
        if (!tempo.isEmpty()) {
            QFont tempoFont = painter->font();
            tempoFont.setPointSizeF(std::max(6.0, 9.0 * itemScale));
            tempoFont.setItalic(true);
            painter->setFont(tempoFont);
            painter->setPen(selected ? QColor(QStringLiteral("#626262"))
                                     : QColor(QStringLiteral("#a9a9a9")));
            painter->drawText(QRect(cell.right() - qRound(84 * itemScale), cell.top() + qRound(2 * itemScale),
                                    qRound(76 * itemScale), qRound(19 * itemScale)),
                              Qt::AlignRight | Qt::AlignVCenter, tempo);
        }
        painter->restore();
    }
};


class LcdStyleResponsivePage final : public QWidget {
public:
    explicit LcdStyleResponsivePage(QWidget *parent = nullptr) : QWidget(parent) {}

    void setResizeHandler(std::function<void(const QSize &)> handler) {
        resizeHandler_ = std::move(handler);
        if (resizeHandler_ && size().isValid()) resizeHandler_(size());
    }

protected:
    void resizeEvent(QResizeEvent *event) override {
        QWidget::resizeEvent(event);
        if (resizeHandler_) resizeHandler_(event->size());
    }

private:
    std::function<void(const QSize &)> resizeHandler_;
};

class LcdStyleLogoWidget final : public QWidget {
public:
    explicit LcdStyleLogoWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setAttribute(Qt::WA_TranslucentBackground);
    }

    QSize sizeHint() const override { return QSize(29, 36); }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        // The logo cell is the full header height. Preserve the 29:36 source
        // aspect ratio and center the painted mark in that cell; do not stretch
        // it to a separately scaled short child height.
        const qreal scale = std::min(static_cast<qreal>(width()) / 29.0,
                                     static_cast<qreal>(height()) / 36.0);
        if (scale <= 0.0) return;
        painter.translate((width() - 29.0 * scale) / 2.0,
                          (height() - 36.0 * scale) / 2.0);
        painter.scale(scale, scale);
        const QColor paper(QStringLiteral("#ffffff"));
        const QRectF body(3.5, 11.0, 22.0, 17.0);
        painter.setPen(Qt::NoPen);
        painter.setBrush(paper);
        painter.drawRoundedRect(body, 2.5, 2.5);
        painter.drawEllipse(QRectF(3.5, 6.5, 22.0, 9.0));
        painter.setPen(QPen(QColor(QStringLiteral("#11675f")), 1.3));
        painter.drawLine(QPointF(4.5, 14.3), QPointF(24.5, 14.3));
    }
};

// Crisp, resolution-independent icons for the Yamaha-style Style List command bar.
// Avoids Unicode glyphs whose apparent size and shape vary between Windows fonts.
class LcdStyleHeaderIconWidget final : public QWidget {
public:
    enum class Kind { Search, Folder, Menu, Close, HardDrive, Star };

    explicit LcdStyleHeaderIconWidget(Kind kind, QWidget *parent = nullptr)
        : QWidget(parent), kind_(kind) {
        setAttribute(Qt::WA_TranslucentBackground);
        setAttribute(Qt::WA_TransparentForMouseEvents);
        setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
    }

    QSize sizeHint() const override { return QSize(32, 32); }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        const qreal scale = std::min(static_cast<qreal>(width()) / 32.0,
                                     static_cast<qreal>(height()) / 32.0);
        if (scale <= 0.0) return;
        painter.translate((width() - 32.0 * scale) / 2.0,
                          (height() - 32.0 * scale) / 2.0);
        painter.scale(scale, scale);
        const QColor white(QStringLiteral("#ffffff"));
        const QPen pen(white, 2.7, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
        painter.setPen(pen);
        painter.setBrush(Qt::NoBrush);

        switch (kind_) {
        case Kind::Search:
            painter.drawEllipse(QRectF(5.5, 4.5, 17.5, 17.5));
            painter.drawLine(QPointF(19.5, 19.5), QPointF(27.0, 27.0));
            break;
        case Kind::Folder: {
            QPainterPath folder;
            folder.moveTo(3.5, 8.5);
            folder.lineTo(11.5, 8.5);
            folder.lineTo(14.5, 12.0);
            folder.lineTo(28.5, 12.0);
            folder.lineTo(26.5, 25.5);
            folder.quadTo(26.2, 27.0, 24.8, 27.0);
            folder.lineTo(5.0, 27.0);
            folder.quadTo(3.5, 27.0, 3.5, 25.5);
            folder.closeSubpath();
            painter.setPen(Qt::NoPen);
            painter.setBrush(white);
            painter.drawPath(folder);
            painter.setPen(QPen(QColor(QStringLiteral("#11675f")), 1.2,
                                Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.drawLine(QPointF(5.5, 14.4), QPointF(26.8, 14.4));
            break;
        }
        case Kind::Menu:
            painter.drawLine(QPointF(4.5, 7.0), QPointF(27.5, 7.0));
            painter.drawLine(QPointF(4.5, 16.0), QPointF(27.5, 16.0));
            painter.drawLine(QPointF(4.5, 25.0), QPointF(27.5, 25.0));
            break;
        case Kind::Close:
            painter.drawLine(QPointF(5.0, 5.0), QPointF(27.0, 27.0));
            painter.drawLine(QPointF(27.0, 5.0), QPointF(5.0, 27.0));
            break;
        case Kind::HardDrive: {
            // Compact hard-disk glyph: rounded chassis, access seam and status LED.
            painter.setPen(QPen(white, 2.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.setBrush(Qt::NoBrush);
            painter.drawRoundedRect(QRectF(3.5, 6.5, 25.0, 19.0), 2.8, 2.8);
            painter.drawLine(QPointF(5.5, 17.0), QPointF(26.5, 17.0));
            painter.setPen(Qt::NoPen);
            painter.setBrush(white);
            painter.drawEllipse(QRectF(22.5, 20.0, 2.6, 2.6));
            break;
        }
        case Kind::Star: {
            // Filled five-point star drawn as a path, not a font glyph, so it
            // stays smooth and consistent on every Windows font/DPI setting.
            QPainterPath star;
            star.moveTo(16.0, 2.5);
            star.lineTo(19.6, 11.1);
            star.lineTo(29.0, 11.8);
            star.lineTo(21.8, 17.8);
            star.lineTo(24.2, 27.0);
            star.lineTo(16.0, 22.0);
            star.lineTo(7.8, 27.0);
            star.lineTo(10.2, 17.8);
            star.lineTo(3.0, 11.8);
            star.lineTo(12.4, 11.1);
            star.closeSubpath();
            painter.setPen(Qt::NoPen);
            painter.setBrush(white);
            painter.drawPath(star);
            break;
        }
        }
    }

private:
    Kind kind_;
};

class EnsemblesWindow final : public QMainWindow {
#ifdef _WIN32
    struct ScheduledWinMidiMessage {
        std::uint64_t targetTimeUs = 0;
        std::uint64_t sequence = 0;
        std::uint8_t status = 0;
        std::uint8_t data1 = 0;
        std::uint8_t data2 = 0;
        bool styleMessage = false;
        std::uint64_t styleGeneration = 0;
    };
    struct ScheduledWinMidiLater {
        bool operator()(const ScheduledWinMidiMessage &a,
                        const ScheduledWinMidiMessage &b) const noexcept {
            if (a.targetTimeUs != b.targetTimeUs) return a.targetTimeUs > b.targetTimeUs;
            return a.sequence > b.sequence;
        }
    };
#endif
public:
    EnsemblesWindow() {
        ensembles::acmp_trace::Trace::instance().initialize();
        const bool safeUiMode = QCoreApplication::arguments().contains(QStringLiteral("--safe-ui"));
        startupTrace(safeUiMode ? "window: constructor begin (--safe-ui)" : "window: constructor begin");
        setWindowFlag(Qt::FramelessWindowHint, true); // Original application uses an in-client titlebar.
        setWindowTitle(QStringLiteral("Ensembles"));
        resize(1344, 708); // Original reference content canvas; controls retain its proportions.
        setMinimumSize(1040, 680);
        if (QScreen *screen = QGuiApplication::primaryScreen()) {
            const QRect area = screen->availableGeometry();
            move(area.center() - QPoint(width() / 2, height() / 2));
        }
        startupTrace("window: before application stylesheet");
        setStyleSheet(QString::fromLatin1(R"STYLE(
            /* Shared mixer palette: graphite chassis, deep channel wells, teal activity. */
            QMainWindow { background: #101213; color: #e5eceb; }
            QWidget { color: #d8e1e0; font-family: "Segoe UI"; font-size: 9pt; }
            QWidget#appSurface { background: #1b2021; }
            QFrame#panel { border: 1px solid #080a0a; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #303739, stop:1 #171d1f); }
            QWidget#headerBar { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #2b3335, stop:1 #171d1f); border: 1px solid #070b0c; }
            QLabel#appTitle { font-size: 10pt; font-weight: 700; color: #edf3f2; }
            QLabel#sectionLabel { color: #a0afad; font-size: 8pt; }
            QLabel#metricHeading { color: #aebbb9; font-size: 8pt; }
            QLabel#metricValue { color: #9deeea; font-size: 9pt; font-weight: 600; }
            QLabel#tempoMetricValue { color: #ffcc00; font-size: 9pt; font-weight: 600; }
            QPushButton, QToolButton { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4a585a, stop:0.45 #354244, stop:1 #252e30); border: 1px solid #151a1b; border-top-color: #687476; border-radius: 1px; padding: 1px 4px; color: #f0f4f3; }
            QPushButton:hover, QToolButton:hover { border-color: #718585; background: #465b5d; }
            QPushButton:pressed, QToolButton:pressed { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #354648, stop:1 #20292b); border-color: #287e75; }
            QPushButton:checked, QToolButton:checked, QToolButton[active="true"] { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #455759, stop:0.45 #344447, stop:1 #222c2e); border: 1px solid #151a1b; border-top: 4px solid #48b1a5; }
            /* Compact arranger strip: raised hardware-style caps with recessed faces. */
            QPushButton#arrangerSectionButton, QPushButton#arrangerToggleButton, QPushButton#arrangerTransportButton {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #30383a, stop:0.18 #20282a, stop:0.70 #121819, stop:1 #090d0e);
                color: #edf2f1; border: 1px solid #090c0d; border-top: 2px solid #647173;
                border-left-color: #3e4b4d; border-right-color: #111718; border-bottom-color: #050708;
                border-radius: 4px; padding: 0 2px; font-size: 10pt; font-weight: 700;
            }
            QPushButton#arrangerSectionButton:hover, QPushButton#arrangerToggleButton:hover, QPushButton#arrangerTransportButton:hover {
                border-top-color: #9aa9a8; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #3d484a, stop:0.22 #263133, stop:1 #12191a);
            }
            QPushButton#arrangerSectionButton:pressed, QPushButton#arrangerToggleButton:pressed, QPushButton#arrangerTransportButton:pressed {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #090d0e, stop:1 #263133); border-top-color: #1a2223; border-bottom-color: #697777;
            }
            /* Refined Genos2-style satin caps: smooth edge, shallow bevel, restrained press feedback. */
            QPushButton[genosPhysicalButton="true"], QToolButton[genosPhysicalButton="true"] {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #687778, stop:0.48 #4b5b5d, stop:1 #303b3d);
                color: #f1f4f5;
                border: 1px solid #1c2627;
                border-top-color: #879594;
                border-bottom-color: #202a2b;
                border-radius: 3px;
                padding: 1px 4px;
                font-weight: 600;
            }
            QPushButton[genosPhysicalButton="true"]:hover, QToolButton[genosPhysicalButton="true"]:hover {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #788887, stop:0.5 #58696a, stop:1 #354345);
                border-color: #607475;
                border-top-color: #a0b1ae;
            }
            QPushButton[genosPhysicalButton="true"]:pressed, QToolButton[genosPhysicalButton="true"]:pressed {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #263335, stop:1 #48595a);
                border: 1px solid #1c2627;
                border-top-color: #2e3d3f;
                border-bottom-color: #758483;
                padding: 1px 4px;
            }
            QPushButton[genosPhysicalButton="true"]:checked, QToolButton[genosPhysicalButton="true"]:checked {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #72b8af, stop:0.5 #3c827c, stop:1 #22534f);
                color: #f4fbff;
                border: 1px solid #1d4945;
                border-top-color: #a9d5ce;
                border-bottom-color: #1a4541;
            }
            QPushButton[genosPhysicalButton="true"]:checked:hover, QToolButton[genosPhysicalButton="true"]:checked:hover {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #91cbc3, stop:0.5 #529d94, stop:1 #2e706a);
                border-top-color: #c0e3dd;
            }
            QPushButton[genosPhysicalButton="true"]:checked:pressed, QToolButton[genosPhysicalButton="true"]:checked:pressed {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 #205b56, stop:1 #468c84);
                border: 1px solid #1d4945;
                border-top-color: #285d58;
                border-bottom-color: #8fbeb7;
                padding: 1px 4px;
            }
            QPushButton[genosPhysicalButton="true"]:disabled, QToolButton[genosPhysicalButton="true"]:disabled {
                color: #879291;
                background: #303a3c;
                border: 1px solid #20292a;
                border-top-color: #596667;
            }
            QPushButton#rightPanelStyleButton, QPushButton#rightPanelModeButton { font-size: 8pt; }
            QPushButton#dataEntryStepButton { font-size: 10pt; }
            QToolButton#rightPanelEffectButton { font-size: 7pt; }
            QLabel#arrangerButtonLed { background: #171e20; border: 1px solid #0c1112; border-radius: 1px; }
            QLabel#arrangerSectionCaption { color: #d7e1df; font-size: 7pt; font-weight: 700; background: transparent; }
            QLabel#arrangerSubCaption { color: #aebbb9; font-size: 6.5pt; font-weight: 600; background: transparent; }
            QPushButton#flatButton { padding: 1px 3px; }
            QPushButton#headerLoadStyle { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #326b65, stop:1 #1c403d); border: 1px solid #102b29; border-top-color: #6fa69f; border-radius: 2px; padding: 2px 7px; color: #edf6f5; font-weight: 600; }
            QPushButton#headerLoadStyle:hover { background: #3d7770; border-color: #8abbb4; }
            QPushButton#headerLoadStyle:pressed { background: #183330; border-top-color: #122725; }
            QPushButton#transportPlay { background: #cf202c; border: 1px solid #701016; color: white; font-size: 15pt; font-weight: 700; }
            QPushButton#transportPlay:hover { background: #e12b38; }
            QPushButton#blueAction { background: #246b63; border-color: #103b36; }
            QPushButton#redAction { background: #bb1e2b; border-color: #671017; }
            QPushButton#displayTab { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #00897b, stop:1 #006064); border: 1px solid #004d47; border-right: 2px solid #00695c; padding: 0; }
            QPushButton#displayTab:hover { background: #00a898; }
            QPushButton#displayTab QLabel:first-child { color: #ffffff; font-size: 10pt; }
            QPushButton#displayTab QLabel:last-child { color: #d3efea; font-size: 8pt; }
            QDial { background: transparent; border: 0; }
            QSlider::groove:vertical { width: 5px; background: #151c1d; border: 1px solid #090d0e; }
            QSlider::handle:vertical { width: 11px; height: 13px; margin: 0 -4px; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #c6c6c6, stop:1 #a5a5a5); border: 1px solid #4e4e4e; border-radius: 0; }
            QSlider[referenceMixerFader="true"] { background: transparent; }
            QSlider[referenceMixerFader="true"]::groove:vertical {
                /* Geometry only: 14 px content + 1 px border on each side. */
                width: 14px; margin: 6px 9px;
                background: transparent;
                border: 1px solid transparent; border-radius: 1px;
            }
            QSlider[referenceMixerFader="true"]::handle:vertical {
                width: 21px; height: 13px; margin: 0 -4px;
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #f0f0f0, stop:0.22 #d9d9d9, stop:0.55 #bdbdbd, stop:1 #858585);
                border: 1px solid #5c5c5c; border-top-color: #f7f7f7; border-bottom-color: #626262; border-radius: 1px;
            }
            QSlider[compactMixer="true"]::groove:vertical {
                width: 10px; margin: 7px 6px; background: transparent;
                border: 1px solid transparent; border-radius: 1px;
            }
            QSlider[compactMixer="true"]::handle:vertical {
                width: 19px; height: 12px; margin: 0 -5px;
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ededed, stop:0.25 #d5d5d5, stop:0.6 #b7b7b7, stop:1 #898989);
                border: 1px solid #55595b; border-top-color: #f3f3f3; border-bottom-color: #65696b; border-radius: 2px;
            }
            QSlider[akaiStyleFader="true"] { background: transparent; }
            QSlider[akaiStyleFader="true"]::groove:vertical {
                width: 16px; margin: 5px 8px; background: transparent;
                border: 1px solid transparent; border-radius: 1px;
            }
            QSlider[akaiStyleFader="true"]::handle:vertical {
                width: 22px; height: 12px; margin: 0 -3px;
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #e1eae8, stop:0.22 #cfd1d2, stop:0.55 #aeb1b3, stop:1 #777b7e);
                border: 1px solid #4b4f51; border-top-color: #f4f5f5; border-bottom-color: #55595b; border-radius: 1px;
            }
            QFrame#akaiLeftMixerPanel, QFrame#akaiMidiMixPanel {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #282b2d, stop:0.35 #1d2022, stop:1 #101213);
                border: 1px solid #080909; border-top-color: #55595b; border-radius: 3px;
            }
            QWidget[akaiStripCell="true"] {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #262a2c, stop:0.5 #1b1e20, stop:1 #111314);
                border-left: 1px solid #414547; border-right: 1px solid #090a0a;
            }
            QPushButton[akaiMuteButton="true"] {
                min-height: 12px; max-height: 12px; padding: 0 1px;
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ffbf72, stop:1 #ee8d35);
                color: #271707; border: 1px solid #7b4618; border-radius: 1px; font-size: 5.5pt; font-weight: 800;
            }
            QPushButton[akaiMuteButton="true"]:checked { background: #f3e0c9; border: 1px solid #fff0d8; }
            QPushButton[akaiBankButton="true"] {
                min-height: 17px; max-height: 19px; padding: 1px 5px;
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #484d50, stop:1 #202426);
                color: #f0f1f1; border: 1px solid #080909; border-top-color: #6b7072; border-radius: 2px; font-size: 6pt; font-weight: 700;
            }
            QPushButton[akaiBankButton="true"]:checked { background: #b86b2d; color: #fff3e7; border-color: #efac69; }
            QPushButton[akaiSoloButton="true"] { min-height: 12px; max-height: 12px; padding: 0 1px; background: #d9d9d9; color: #181818; border: 1px solid #777; border-radius: 1px; font-size: 5.5pt; font-weight: 800; }
            QPushButton[akaiSoloButton="true"]:checked { background: #f1a34f; border-color: #fff0d9; }
            QPushButton[akaiChannelSelect="true"] { min-height: 12px; max-height: 13px; padding: 0; background: transparent; color: #d8dcde; border: 1px solid transparent; font-size: 5.5pt; font-weight: 800; }
            QPushButton[akaiChannelSelect="true"]:checked { color: #ffbd76; border-bottom: 1px solid #f18f3c; }
            QLabel[akaiPrintedLabel="true"] { color: #d8dcde; background: transparent; font-size: 5.5pt; font-weight: 700; }
            QSlider[masterTarget="true"]::handle:vertical { background: #c7a43d; border-color: #f0d57a; }
            QWidget[referenceMixerCell="true"] {
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #262a2c, stop:0.5 #1b1e20, stop:1 #111314);
                border-left: 1px solid #414547; border-right: 1px solid #090a0a;
                border-top: 1px solid #373c3e; border-bottom: 1px solid #080909;
            }
            QSlider::groove:horizontal { height: 5px; background: #151c1d; border: 1px solid #090d0e; }
            QSlider::handle:horizontal { width: 13px; height: 11px; margin: -4px 0; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #c6c6c6, stop:1 #a5a5a5); border: 1px solid #4e4e4e; border-radius: 0; }
            QSpinBox, QComboBox { background: #293638; color: #e8f0ef; border: 1px solid #121a1b; padding: 1px 3px; min-height: 20px; }
            QProgressBar { background: #1b2526; border: 1px solid #0e1516; border-radius: 0; }
            QProgressBar::chunk { background: qlineargradient(x1:0,y1:1,x2:0,y2:0, stop:0 #0a756e, stop:0.6 #459f56, stop:1 #a8c936); }
            QCheckBox { spacing: 5px; }
            QDialog { background: #202a2c; }
        )STYLE"));
        startupTrace("window: application stylesheet complete");

        startupTrace("window: entering buildUi");
        buildUi();
        channelActivityTimer_.setInterval(55);
        connect(&channelActivityTimer_, &QTimer::timeout, this, [this] {
            for (std::size_t i = 0; i < channelActivityLevels_.size(); ++i) {
                channelActivityLevels_[i] = std::max(0, channelActivityLevels_[i] - 9);
                if (channelActivityMeters_[i] && channelActivityMeters_[i]->value() != channelActivityLevels_[i])
                    channelActivityMeters_[i]->setValue(channelActivityLevels_[i]);
            }
        });
        channelActivityTimer_.start();
        startupTrace("window: buildUi returned");
        if (safeUiMode) {
            // This mode deliberately skips QSettings, MIDI device enumeration,
            // NativeTS/SCVA, FluidSynth, VST2 and style-engine startup. It is a
            // diagnostic isolation mode, not the normal audio-enabled launch.
            setStatus(QStringLiteral("SAFE UI MODE — audio/MIDI startup intentionally skipped"));
            startupTrace("window: --safe-ui skipped runtime/audio initialization");
        } else {
            startupTrace("window: before refreshMidiInputDevices");
            refreshMidiInputDevices();
            startupTrace("window: after refreshMidiInputDevices");
            loadPanelSettings();
            startupTrace("window: after loadPanelSettings");
            audioSettingsReady_ = true;
            loadControllerMaps();
            refreshControllerTooltips();
            updateAssignmentButtonAvailability();
            startupTrace("window: before openMidiOutput");
            openMidiOutput();
            startupTrace("window: before initializeAudioEngine (Native SCVA / fallback)");
            initializeAudioEngine();
            startupTrace("window: initializeAudioEngine returned");
            applyInitialMixerLevels();
            for (int i = 0; i < static_cast<int>(rightVoiceFaders_.size()); ++i) {
                if (!rightVoiceFaders_[static_cast<std::size_t>(i)]) continue;
                static constexpr int extChannels[4] = {1, 0, 2, 3};
                static constexpr int intChannels[4] = {19, 17, 18, 3};
                sendMidi(static_cast<quint8>(0xB0 | extChannels[i]), 7,
                         static_cast<quint8>(rightVoiceFaders_[static_cast<std::size_t>(i)]->value()), intChannels[i]);
            }
            applyPanelMidiSettings();
            refreshSf2PresetBrowser();
            applyAllVoicePrograms();
            for (int part = 0; part < 4; ++part)
                applyRightVoicePartState(part, rightVoiceEnabled_[static_cast<std::size_t>(part)], false);
            for (int i = 0; i < 10; ++i) {
                if (assignableSliders_[static_cast<std::size_t>(i)])
                    handleAssignableControlValue(i, assignableSliders_[static_cast<std::size_t>(i)]->value());
            }
            for (int i = 0; i < 4; ++i) {
                if (assignableKnobs_[static_cast<std::size_t>(i)])
                    handleAssignableControlValue(10 + i, assignableKnobs_[static_cast<std::size_t>(i)]->value());
            }
            startupTrace("window: before setupStyleEngine");
            setupStyleEngine();
            startupTrace("window: setupStyleEngine returned");
        }
        styleTimer_.setInterval(3);
        connect(&styleTimer_, &QTimer::timeout, this, [this] { onStyleTick(); });
        // Section pending LEDs use their own stable blink cadence. START/STOP
        // is not driven by this timer: it reads the live arranger tick phase.
        arrangerIndicatorTimer_.setInterval(250);
        connect(&arrangerIndicatorTimer_, &QTimer::timeout, this, [this] {
            arrangerIndicatorBlinkPhase_ = !arrangerIndicatorBlinkPhase_;
            refreshArrangerIndicators();
        });
        arrangerIndicatorTimer_.start();
        arrangerBeatPulseTimer_.setInterval(8);
        connect(&arrangerBeatPulseTimer_, &QTimer::timeout, this, [this] {
            refreshStartStopBeatIndicator();
        });
        arrangerBeatPulseTimer_.start();
        refreshArrangerIndicators();
        modulationTimer_.setInterval(10);
        connect(&modulationTimer_, &QTimer::timeout, this, [this] { onModulationTick(); });
        playbackTimer_.setInterval(3);
        connect(&playbackTimer_, &QTimer::timeout, this, [this] { onPlaybackTick(); });
    }

    // Data Entry selects the active Voice or Style directly within the central LCD.
    void rotateDataEntryDial(int value) {
        int delta = value - dataEntryDialLastValue_;
        if (delta > 64) delta -= 128;
        else if (delta < -64) delta += 128;
        dataEntryDialLastValue_ = value;
        if (delta == 0) return;

        if (dataEntryStyleMode_) {
            if (!lcdStyleList_ || lcdStyleList_->count() == 0) {
                setStatus(QStringLiteral("Belum ada Style pada daftar LCD."));
                return;
            }
            int row = lcdStyleList_->currentRow();
            if (row < 0) row = 0;
            row = std::clamp(row + delta, 0, lcdStyleList_->count() - 1);
            lcdStyleList_->setCurrentRow(row); // The existing row handler loads the selected Style.
            if (lcdStyleList_->item(row)) setStatus(QStringLiteral("Style: %1").arg(lcdStyleList_->item(row)->text()));
            return;
        }

        if (voiceSelectFilteredEntries_.empty()) openVoiceSelectPage(selectedProgramChannel_);
        const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        int selectedIndex = -1;
        for (std::size_t i = 0; i < voiceSelectFilteredEntries_.size(); ++i) {
            const auto &entry = voiceSelectFilteredEntries_[i];
            if (entry.program == voicePrograms_[slot] && entry.bank == voiceBanks_[slot] && entry.map == voiceMaps_[slot]) {
                selectedIndex = static_cast<int>(i);
                break;
            }
        }
        if (voiceSelectFilteredEntries_.empty()) {
            setStatus(QStringLiteral("Tidak ada Voice di kategori/map yang aktif."));
            return;
        }
        if (selectedIndex < 0) selectedIndex = std::clamp(voiceSelectPage_ * 12, 0, static_cast<int>(voiceSelectFilteredEntries_.size()) - 1);
        selectedIndex = std::clamp(selectedIndex + delta, 0, static_cast<int>(voiceSelectFilteredEntries_.size()) - 1);
        voiceSelectPage_ = selectedIndex / 12;
        refreshVoiceSelectPage();
        applyVoiceCatalogEntry(voiceSelectFilteredEntries_[static_cast<std::size_t>(selectedIndex)]);
        setStatus(QStringLiteral("Voice %1: %2").arg(selectedProgramChannel_ == 0 ? QStringLiteral("R1") : selectedProgramChannel_ == 1 ? QStringLiteral("L") : QStringLiteral("R2"), voiceSelectFilteredEntries_[static_cast<std::size_t>(selectedIndex)].name));
    }

    void activateDataEntryContext() {
        if (!lcdContentStack_) return;
        const QWidget *current = lcdContentStack_->currentWidget();
        if (current == lcdVoicePickerPage_ || current == lcdStylePickerPage_) {
            if (lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
            return;
        }
        if (dataEntryStyleMode_) {
            if (lcdStylePickerPage_) lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
        } else {
            openVoiceSelectPage(selectedProgramChannel_);
        }
    }

    // Used by the launcher to switch the central LCD to Voice Select after show().
    void showVoiceSelectPreview() { dataEntryStyleMode_ = false; openVoiceSelectPage(0); }

    ~EnsemblesWindow() override {
        playbackTimer_.stop();
        modulationTimer_.stop();
        styleTimer_.stop();
        channelActivityTimer_.stop();
        arrangerIndicatorTimer_.stop();
        arrangerBeatPulseTimer_.stop();
        arpeggiatorTimer_.stop();
        styleEngine_.stop();
#ifdef _WIN32
        // Drop future scheduled events before sending All Notes Off and closing WinMM.
        stopScheduledWindowsMidiWorker();
#endif
        allSoundsOff();
#ifdef _WIN32
        closeAllMidiInputDevices();
        {
            std::lock_guard<std::mutex> outputLock(midiOutMutex_);
            if (midiOut_) {
                midiOutReset(midiOut_);
                midiOutClose(midiOut_);
                midiOut_ = nullptr;
            }
        }
#endif
    }

private:
    enum ControlTarget : int {
        GenericMidiCc = 0,
        VoiceLVolume = 1,
        VoiceR1Volume = 2,
        VoiceR2Volume = 3,
        StyleVolume = 4,
        ReverbSend = 5,
        ChorusSend = 6,
        FilterCutoff = 7,
        FilterResonance = 8,
        VoiceExpression = 9,
        DrumVolume = 10,
        VoicePan = 11,
        VoiceModulation = 12,
        MasterVolume = 13,
        VoiceVolumeAll = 14,
        VoiceAttack = 15,
        VoiceRelease = 16,
        VoiceVibratoRate = 17,
        VoiceVibratoDepth = 18,
        SongVolume = 19,
        AudioVolume = 20,
        PadsVolume = 21,
        ChordVolume = 22
    };
    struct ControllerMap {
        bool assigned = false;
        int channel = 0; // zero-based MIDI channel for Generic MIDI CC
        int controller = 74;
        int target = GenericMidiCc;
    };
    std::array<ControllerMap, 16> controllerMaps_{}; // sliders 1..10, knobs 1..4, joystick X/Y
    std::array<bool, 14> masterTargets_{}; // ten sliders and four physical knobs; joystick axes are direct mappings.
    int styleVolume_ = 127; // Style bus level (0..127).
    int songVolume_ = 127; // MIDI-file playback velocity/CC7 scale.
    int audioFaderVolume_ = 127; // Temporary audio-layer fader until a dedicated audio-file player exists.
    int padsVolume_ = 127; // GM pad velocity scale.
    int chordVolume_ = 127; // Style accompaniment note velocity scale, separate from drum channel.
    std::array<QSlider *, 10> assignableSliders_{}; // First six are the fixed function faders on the reference left panel.
    std::array<QLabel *, 10> assignableSliderNameLabels_{};
    std::array<QSlider *, 4> rightVoiceFaders_{}; // L, R1, R2, R3; R3 uses MIDI channel 4.
    std::array<QPushButton *, 4> rightVoiceOnButtons_{};
    std::array<bool, 4> rightVoiceEnabled_{{true, true, false, false}}; // UI order L, R1, R2, R3.
    QDial *dataEntryDial_ = nullptr;
    int dataEntryDialLastValue_ = 64;
    bool dataEntryStyleMode_ = false;
    std::array<QDial *, 4> assignableKnobs_{};
    std::array<QLabel *, 4> assignableKnobNameLabels_{};
    QDial *masterControlDial_ = nullptr;
    QLabel *masterControlNameLabel_ = nullptr;
    QPushButton *knobAssignButton_ = nullptr;
    QPushButton *masterAssignButton_ = nullptr;
    QPushButton *sliderAssignButton_ = nullptr;
    bool knobAssignMode_ = false;
    bool masterAssignMode_ = false;
    bool sliderAssignMode_ = false;
    std::array<QPushButton *, 10> registryButtons_{};
    QPushButton *registryMemorizeButton_ = nullptr;
    QLabel *registryBankLabel_ = nullptr;
    int currentRegistryBank_ = 0;
    bool registryMemorizeMode_ = false;
    std::array<QProgressBar *, 19> channelActivityMeters_{};
    std::array<int, 19> channelActivityLevels_{};
    std::array<int, 16> channelMixerLevels_{};
    std::array<int, 8> stylePartOutputChannels_{{8, 9, 10, 11, 12, 13, 14, 15}};
    // Each style channel has its own CC7 fader, PAN (CC10), MUTE and SOLO controls.
    std::array<ReferenceMixerSlider *, 16> channelMixerFaders_{};
    std::array<QDial *, 16> channelMixerPanKnobs_{};
    std::array<QPushButton *, 16> channelMixerSoloButtons_{};
    std::array<bool, 16> channelMixerMuted_{};
    bool styleMixerSoloActive_ = false;
    int styleMixerSelectedChannel_ = 0;
    std::array<int, 6> leftMixerRestoreVolume_{};
    std::array<bool, 6> leftMixerMuted_{};
    std::array<QPushButton *, 6> leftMixerMuteButtons_{};
    QTimer channelActivityTimer_;
    QTimer arpeggiatorTimer_;
    struct ArpeggiatorHeldNote { int note = 0; int voiceSlot = 0; int velocity = 90; bool internalOnly = false; };
    std::vector<ArpeggiatorHeldNote> arpeggiatorHeldNotes_;
    int arpeggiatorStep_ = 0;
    int arpeggiatorCurrentNote_ = -1;
    int arpeggiatorCurrentVoiceSlot_ = 0;
    bool arpeggiatorCurrentLayered_ = false;
    bool arpeggiatorCurrentInternalOnly_ = false;

    QLabel *statusLabel_ = nullptr;
    QLabel *midiFileLabel_ = nullptr;
    QLabel *recordLabel_ = nullptr;
    QLabel *outputLabel_ = nullptr;
    QPushButton *playButton_ = nullptr;
    QPushButton *recordButton_ = nullptr;
    QComboBox *programCombo_ = nullptr;
    QComboBox *styleCombo_ = nullptr;
    QLabel *styleInfo_ = nullptr;
    QLabel *chordLabel_ = nullptr;
    QSlider *tempoSlider_ = nullptr;
    QLabel *tempoValue_ = nullptr; // Central display tempo metric
    QLabel *tempoDialogValue_ = nullptr;
    QSlider *gainSlider_ = nullptr;
    QCheckBox *metronomeCheck_ = nullptr;
    QCheckBox *lfoCheck_ = nullptr;
    QCheckBox *reverbCheck_ = nullptr;
    QCheckBox *chorusCheck_ = nullptr;
    QCheckBox *delayCheck_ = nullptr;
    QDialog *styleDialog_ = nullptr;
    QDialog *voiceDialog_ = nullptr;
    QStackedWidget *lcdContentStack_ = nullptr;
    QWidget *lcdHomePage_ = nullptr;
    QWidget *lcdVoicePickerPage_ = nullptr;
    QWidget *lcdStylePickerPage_ = nullptr;
    QListWidget *lcdVoiceList_ = nullptr;
    QListWidget *lcdStyleList_ = nullptr;
    QPushButton *lcdStylePresetButton_ = nullptr;
    QPushButton *lcdStyleUserButton_ = nullptr;
    QPushButton *lcdStyleFavoritesButton_ = nullptr;
    QLabel *lcdStylePathLabel_ = nullptr;
    std::array<QPushButton *, 5> lcdStylePageButtons_{};
    QPushButton *lcdStylePreviousPageButton_ = nullptr;
    QPushButton *lcdStyleNextPageButton_ = nullptr;
    QPushButton *lcdStyleTopButton_ = nullptr;
    std::vector<QPushButton *> lcdStyleCategoryButtons_;
    QString lcdStyleCategory_ = QStringLiteral("Pop&Rock");
    // The lower-left hardware-style shortcut panel can select one or several
    // catalogue families without changing the existing LCD category controls.
    QStringList lcdStyleCategoryGroup_;
    QString lcdStyleBadgeFilter_;
    QString lcdStyleShortcutLabel_;
    QString lcdStyleSearchText_;
    QStringList lcdStyleFavoritePaths_;
    int lcdStylePage_ = 0;
    int lcdStylePageCount_ = 1;
    bool lcdStyleUserMode_ = false;
    bool lcdStyleFavoritesOnly_ = false;
    QLabel *lcdVoicePickerTitle_ = nullptr;
    QLabel *lcdVoicePickerSubtitle_ = nullptr;
    QComboBox *lcdVoiceMapCombo_ = nullptr;
    QComboBox *lcdVoiceCategoryCombo_ = nullptr;
    QComboBox *lcdVoiceBankCombo_ = nullptr;
    QPushButton *lcdVoicePrevPage_ = nullptr;
    QPushButton *lcdVoiceNextPage_ = nullptr;
    QLabel *lcdVoicePageLabel_ = nullptr;
    int lcdVoicePage_ = 0;
    std::vector<VoiceCatalogEntry> voiceCatalog_;
    std::vector<VoiceCatalogEntry> filteredVoiceCatalog_;
    // Screenshot-matched Voice Select page embedded in the central LCD stack.
    QWidget *voiceSelectPageWidget_ = nullptr;
    QLabel *voiceSelectTitleLabel_ = nullptr;
    QListWidget *voiceSelectCategoryList_ = nullptr;
    QWidget *voiceSelectGridHost_ = nullptr;
    QGridLayout *voiceSelectGridLayout_ = nullptr;
    QHBoxLayout *voiceSelectPageButtonsLayout_ = nullptr;
    QPushButton *voiceSelectPreviousPageButton_ = nullptr;
    QPushButton *voiceSelectNextPageButton_ = nullptr;
    QLabel *voiceSelectPageSummaryLabel_ = nullptr;
    std::vector<QPushButton *> voiceSelectModelButtons_;
    std::vector<VoiceCatalogEntry> voiceSelectFilteredEntries_;
    QString voiceSelectCategory_ = QStringLiteral("Piano");
    int voiceSelectMap_ = 4;
    int voiceSelectPage_ = 0;
    std::array<int, 3> voiceMaps_ = {4, 4, 4};
    std::array<int, 3> voiceBanks_ = {0, 0, 0};
    QCheckBox *nativeEfxCheck_ = nullptr;
    QComboBox *nativeEfxTypeCombo_ = nullptr;
    QToolButton *nativeEfxPanelButton_ = nullptr;
    QLabel *nativeEfxNameLabel_ = nullptr;
    std::array<QSpinBox *, 20> nativeEfxParams_{};
    QDialog *settingsDialog_ = nullptr;
    JoystickPadWidget *joystickPad_ = nullptr;
    QPushButton *joystickXAssignButton_ = nullptr;
    QPushButton *joystickYAssignButton_ = nullptr;
    QComboBox *audioRoutingCombo_ = nullptr;
    QComboBox *midiOutputDeviceCombo_ = nullptr;
    QPushButton *midiOutTestButton_ = nullptr;
    QComboBox *audioApiCombo_ = nullptr;
    QComboBox *audioDeviceCombo_ = nullptr;
    QPushButton *refreshAudioDevicesButton_ = nullptr;
    QPushButton *testAudioButton_ = nullptr;
    QComboBox *audioSampleRateCombo_ = nullptr;
    QComboBox *audioBufferCombo_ = nullptr;
    QLabel *audioOutputStatusLabel_ = nullptr;
    QListWidget *midiInputDeviceList_ = nullptr;
    QPushButton *refreshMidiInputDevicesButton_ = nullptr;
    QLabel *midiInputStatusLabel_ = nullptr;
    QCheckBox *midiSplitByChannelCheck_ = nullptr;
    std::vector<ensembles::AudioEngine::OutputDevice> audioOutputDevices_;
    bool audioSettingsReady_ = false;
    QLabel *soundFontStatusLabel_ = nullptr;
    QPushButton *chooseSoundFontButton_ = nullptr;
    QComboBox *sf2PartCombo_ = nullptr;
    QComboBox *sf2PresetCombo_ = nullptr;
    QSpinBox *sf2BankMsbSpin_ = nullptr;
    QSpinBox *sf2BankLsbSpin_ = nullptr;
    QSpinBox *sf2ProgramSpin_ = nullptr;
    QPushButton *sf2ApplyPresetButton_ = nullptr;
    QLabel *sf2PresetStatusLabel_ = nullptr;
    std::vector<lsgm::PresetInfo> sf2PresetCatalog_;
    std::array<int, 3> sf2BankMsb_ = {0, 0, 0};
    std::array<int, 3> sf2BankLsb_ = {0, 0, 0};
    std::array<int, 3> sf2ProgramNumbers_ = {0, 33, 49}; // MIDI PC is zero-based.
    QLabel *vst2PluginStatusLabel_ = nullptr;
    QPushButton *chooseVst2PluginButton_ = nullptr;
    QPushButton *disableVst2PluginButton_ = nullptr;
    QString soundFontPath_;
    QString vst2PluginPath_;
    std::unique_ptr<ensembles::AudioEngine> audioEngine_ = std::make_unique<ensembles::AudioEngine>();
    QDialog *recorderDialog_ = nullptr;
    PianoKeyboardWidget *pianoKeyboard_ = nullptr;
    QLabel *styleNameLabel_ = nullptr;
    QLabel *lcdStyleMetaLabel_ = nullptr;
    QLabel *lcdPositionLabel_ = nullptr;
    QLabel *lcdMidiMetaLabel_ = nullptr;
    QLabel *voiceLLabel_ = nullptr;
    QLabel *voiceR1Label_ = nullptr;
    QLabel *voiceR2Label_ = nullptr;
    QLabel *voiceR3Label_ = nullptr;
    QLabel *measureMetricLabel_ = nullptr;
    QLabel *beatMetricLabel_ = nullptr;
    QLabel *transposeMetricLabel_ = nullptr;
    QLabel *octaveMetricLabel_ = nullptr;
    QSpinBox *transposeSpin_ = nullptr;
    QSpinBox *octaveSpin_ = nullptr;
    QSpinBox *reverbLevelSpin_ = nullptr;
    QSpinBox *chorusLevelSpin_ = nullptr;
    QSpinBox *delayLevelSpin_ = nullptr;
    bool accompanimentEnabled_ = false; // Original ControlPanel "Chords" / accompaniment switch
    bool layerEnabled_ = false;
    bool splitEnabled_ = false;
    int transposeAmount_ = 0;
    int octaveShiftAmount_ = 0;
    int splitKey_ = kOriginalSplitKey;
    QPushButton *accompButton_ = nullptr;
    QPushButton *styleChordControlButton_ = nullptr;
    QPushButton *styleAutoFillButton_ = nullptr;
    QPushButton *styleStartStopButton_ = nullptr;
    std::array<QPushButton *, 3> rolandIntroButtons_{};
    std::array<QPushButton *, 4> rolandVariationButtons_{};
    std::array<QPushButton *, 3> rolandEndingButtons_{};
    std::array<QLabel *, 3> arrangerIntroLeds_{};
    std::array<QLabel *, 4> arrangerVariationLeds_{};
    std::array<QLabel *, 3> arrangerEndingLeds_{};
    QLabel *arrangerBreakLed_ = nullptr;
    QLabel *arrangerChordLed_ = nullptr;
    QLabel *arrangerAutoFillLed_ = nullptr;
    QLabel *arrangerSyncStopLed_ = nullptr;
    QLabel *arrangerSyncStartLed_ = nullptr;
    QLabel *arrangerStartStopLed_ = nullptr;
    int arrangerActiveGroup_ = -1;   // 0=Intro, 1=Main Variation, 2=Ending
    int arrangerActiveButton_ = -1;
    int arrangerPendingGroup_ = -1;
    int arrangerPendingButton_ = -1;
    int arrangerPendingMarker_ = -1;
    bool arrangerBreakPending_ = false;
    bool arrangerIndicatorBlinkPhase_ = true;
    QPushButton *rolandBreakButton_ = nullptr;
    QPushButton *layerButton_ = nullptr;
    QPushButton *splitButton_ = nullptr;
    QPushButton *metronomeButton_ = nullptr;
    QPushButton *loadStyleButton_ = nullptr;
    QToolButton *reverbButton_ = nullptr;
    QToolButton *chorusButton_ = nullptr;
    QToolButton *arpButton_ = nullptr;
    QToolButton *harmonizerButton_ = nullptr;
    QSpinBox *arpSpin_ = nullptr;
    QSpinBox *harmonizerSpin_ = nullptr;
    int selectedProgramChannel_ = 0; // GM output channels: R1=1, L=2, R2=3
    std::array<int, 3> voicePrograms_ = {0, 33, 49};
    QTimer playbackTimer_;
    QTimer modulationTimer_;
    QTimer styleTimer_;
    QTimer arrangerIndicatorTimer_;
    QTimer arrangerBeatPulseTimer_;
    QElapsedTimer syncStartPulseClock_;
    QElapsedTimer playbackClock_;
    QElapsedTimer recordClock_;
    QElapsedTimer modulationClock_;
    QElapsedTimer styleClock_;
    qint64 lastStyleElapsedUs_ = 0;
    bool styleMidiTimelinePrimed_ = false;
    ensembles::StyleEngine styleEngine_;
    bool styleMidiStopPurgeIssued_ = false;
    ensembles::MidiFile midiFile_;
    QString midiPath_;
    QString activeStyleExtension_;
    QString pendingStylePath_;
    std::size_t playbackIndex_ = 0;
    bool playbackActive_ = false;
    bool recording_ = false;
    std::vector<ensembles::MidiEvent> recordedEvents_;
    int baseNote_ = 36;
    int tempo_ = 120;
    int beatCount_ = 0;
    qint64 nextBeatUs_ = 0;
    qint64 lastLfoUs_ = 0;
    bool midiOutputReady_ = false;
#ifdef _WIN32
    HMIDIOUT midiOut_ = nullptr;
    std::mutex midiOutMutex_;
    std::mutex scheduledMidiMutex_;
    std::condition_variable scheduledMidiCv_;
    std::priority_queue<ScheduledWinMidiMessage, std::vector<ScheduledWinMidiMessage>,
                        ScheduledWinMidiLater> scheduledMidiQueue_;
    std::thread scheduledMidiThread_;
    bool scheduledMidiStopping_ = false; // guarded by scheduledMidiMutex_
    bool midiTimerPeriodActive_ = false;
    std::uint64_t scheduledMidiSequence_ = 0;
    std::atomic<std::uint64_t> scheduledStyleMidiGeneration_{1};
    std::map<UINT, HMIDIIN> midiInputHandles_;
#endif
    int resizingEdges_ = 0;
    QPoint resizeStartGlobal_;
    QRect resizeStartGeometry_;

    // Match the original FluidSynth synthesizer.c mapping: R1=17, R2/layer=18, L/split=19.
    // UI voice slots remain ordered [R1, L, R2] for backward-compatible settings.
    static int internalVoiceChannel(int voiceSlot) noexcept {
        // Native SCVA/FluidSynth ports: R1=17, L=19, R2=18, and R3=channel 4.
        // Slots stay ordered [R1, L, R2, R3] so the existing voice browser/settings remain compatible.
        static constexpr int channels[] = {17, 19, 18, 3};
        return voiceSlot >= 0 && voiceSlot < 4 ? channels[voiceSlot] : 17;
    }

    static int rightPartExternalChannel(int partIndex) noexcept {
        static constexpr int channels[] = {1, 0, 2, 3}; // UI order L, R1, R2, R3
        return partIndex >= 0 && partIndex < 4 ? channels[partIndex] : 0;
    }

    static int rightPartInternalChannel(int partIndex) noexcept {
        static constexpr int channels[] = {19, 17, 18, 3}; // L, R1, R2, R3
        return partIndex >= 0 && partIndex < 4 ? channels[partIndex] : 17;
    }

    static int rightPartVoiceSlot(int partIndex) noexcept {
        // Do not name this array "slots": Qt defines slots as a keyword macro.
        static constexpr int voiceSlots[] = {1, 0, 2, 3}; // UI order L, R1, R2, R3
        return partIndex >= 0 && partIndex < 4 ? voiceSlots[partIndex] : 0;
    }

    void applyRightVoicePartState(int partIndex, bool enabled, bool persist = true) {
        if (partIndex < 0 || partIndex >= 4) return;
        static constexpr const char *labels[] = {"L", "R1", "R2", "R3"};
        rightVoiceEnabled_[static_cast<std::size_t>(partIndex)] = enabled;
        if (rightVoiceOnButtons_[static_cast<std::size_t>(partIndex)]) {
            auto *button = rightVoiceOnButtons_[static_cast<std::size_t>(partIndex)];
            button->setText(enabled ? QStringLiteral("ON") : QStringLiteral("OFF"));
            button->setToolTip(QStringLiteral("Voice %1 %2. Klik untuk mengaktifkan atau membisukan part ini.")
                .arg(QString::fromLatin1(labels[partIndex]), enabled ? QStringLiteral("aktif") : QStringLiteral("mute")));
        }
        const int extChannel = rightPartExternalChannel(partIndex);
        const int internalChannel = rightPartInternalChannel(partIndex);
        const int voiceSlot = rightPartVoiceSlot(partIndex);
        const int programSlot = partIndex == 3 ? 2 : voiceSlot; // R3 initially mirrors R2's selected Voice.
        auto sendPart = [this, extChannel, internalChannel](quint8 controller, quint8 value) {
            sendMidi(static_cast<quint8>(0xB0 | extChannel), controller, value, internalChannel);
        };

        if (enabled) {
            const bool sf2BrowserActive = hasActiveSf2PresetBrowser();
            const int bankMsb = sf2BrowserActive ? sf2BankMsb_[static_cast<std::size_t>(programSlot)]
                                          : voiceBanks_[static_cast<std::size_t>(programSlot)];
            const int bankLsb = sf2BrowserActive ? sf2BankLsb_[static_cast<std::size_t>(programSlot)]
                                          : voiceMaps_[static_cast<std::size_t>(programSlot)];
            const int program = sf2BrowserActive ? sf2ProgramNumbers_[static_cast<std::size_t>(programSlot)]
                                          : voicePrograms_[static_cast<std::size_t>(programSlot)];
            sendPart(0, static_cast<quint8>(std::clamp(bankMsb, 0, 127)));
            sendPart(32, static_cast<quint8>(std::clamp(bankLsb, 0, 127)));
            sendMidi(static_cast<quint8>(0xC0 | extChannel), static_cast<quint8>(std::clamp(program, 0, 127)), 0, internalChannel);
            sendPart(7, static_cast<quint8>(rightVoiceFaders_[static_cast<std::size_t>(partIndex)]
                ? rightVoiceFaders_[static_cast<std::size_t>(partIndex)]->value() : 100));
            sendPart(11, 127);
        } else {
            // Stop held notes immediately before muting, for both internal and external MIDI routes.
            sendPart(64, 0);
            sendPart(120, 0);
            sendPart(123, 0);
            sendPart(7, 0);
            stopArpeggiator(true);
        }
        if (persist) {
            QSettings settings;
            settings.setValue(QStringLiteral("panel/rightPartOn/%1").arg(QString::fromLatin1(labels[partIndex])), enabled);
            settings.sync();
            setStatus(QStringLiteral("Voice %1 %2.")
                .arg(QString::fromLatin1(labels[partIndex]), enabled ? QStringLiteral("ON — aktif") : QStringLiteral("OFF — mute")));
        }
    }

    enum class ArrangerLampState { Off, Available, Active, Pending };

    static void paintArrangerLed(QLabel *led, ArrangerLampState state, bool blinkPhase) {
        if (!led) return;
        QString background = QStringLiteral("#202b2d");
        QString border = QStringLiteral("#111111");
        switch (state) {
        case ArrangerLampState::Available:
            background = QStringLiteral("#27b765");
            border = QStringLiteral("#126637");
            break;
        case ArrangerLampState::Active:
            background = QStringLiteral("#ed424b");
            border = QStringLiteral("#8e171e");
            break;
        case ArrangerLampState::Pending:
            if (blinkPhase) {
                background = QStringLiteral("#ed424b");
                border = QStringLiteral("#8e171e");
            }
            break;
        case ArrangerLampState::Off:
            break;
        }
        led->setStyleSheet(QStringLiteral("background:%1;border:1px solid %2;border-radius:1px;")
            .arg(background, border));
    }

    void queueArrangerIndicator(int group, int buttonIndex, int markerIndex) {
        if (styleEngine_.isPlaying()) {
            arrangerPendingGroup_ = group;
            arrangerPendingButton_ = buttonIndex;
            arrangerPendingMarker_ = markerIndex;
        } else {
            arrangerActiveGroup_ = group;
            arrangerActiveButton_ = buttonIndex;
            arrangerPendingGroup_ = -1;
            arrangerPendingButton_ = -1;
            arrangerPendingMarker_ = -1;
        }
        refreshArrangerIndicators();
    }

    void refreshArrangerIndicators() {
        const bool hasStyle = styleEngine_.hasStyle();
        const bool fillActive = styleEngine_.fillPlaybackActive();
        const bool breakActive = styleEngine_.breakPlaybackActive();
        if (breakActive) arrangerBreakPending_ = false;
        const std::array<int, 3> introMarkers{{1, 2, 15}};
        const std::array<int, 4> variationMarkers{{3, 5, 7, 9}};
        const std::array<int, 3> endingMarkers{{11, 13, 16}};
        const auto updateSectionLeds = [&](const auto &leds, const auto &markers, int group) {
            for (std::size_t i = 0; i < markers.size(); ++i) {
                ArrangerLampState state = ArrangerLampState::Off;
                if (hasStyle && styleEngine_.hasPanelSection(markers[i]))
                    state = ArrangerLampState::Available;
                const bool active = arrangerActiveGroup_ == group && arrangerActiveButton_ == i;
                const bool pending = arrangerPendingGroup_ == group && arrangerPendingButton_ == i;
                const bool fillTarget = group == 1 && fillActive &&
                    arrangerActiveGroup_ == group && arrangerActiveButton_ == i;
                if (active && !fillTarget) state = ArrangerLampState::Active;
                if (pending || fillTarget) state = ArrangerLampState::Pending;
                paintArrangerLed(leds[i], state, arrangerIndicatorBlinkPhase_);
            }
        };
        updateSectionLeds(arrangerIntroLeds_, introMarkers, 0);
        updateSectionLeds(arrangerVariationLeds_, variationMarkers, 1);
        updateSectionLeds(arrangerEndingLeds_, endingMarkers, 2);

        ArrangerLampState breakState = ArrangerLampState::Off;
        if (hasStyle && styleEngine_.hasBreakSection()) breakState = ArrangerLampState::Available;
        if (breakActive) breakState = ArrangerLampState::Active;
        else if (arrangerBreakPending_) breakState = ArrangerLampState::Pending;
        paintArrangerLed(arrangerBreakLed_, breakState, arrangerIndicatorBlinkPhase_);
        paintArrangerLed(arrangerChordLed_,
            styleChordControlButton_ && styleChordControlButton_->isChecked()
                ? ArrangerLampState::Active : ArrangerLampState::Off, true);
        paintArrangerLed(arrangerAutoFillLed_,
            styleAutoFillButton_ && styleAutoFillButton_->isChecked()
                ? ArrangerLampState::Active : ArrangerLampState::Off, true);

        const bool syncStartArmed = hasStyle && styleEngine_.syncStartPending();
        const bool syncStopArmed = hasStyle && styleEngine_.syncStopPending();
        // SYNC START/STOP are steady standby indicators. The START/STOP beat
        // lamp is updated separately from the actual Style tick phase below.
        paintArrangerLed(arrangerSyncStartLed_,
            syncStartArmed ? ArrangerLampState::Active : ArrangerLampState::Off, true);
        paintArrangerLed(arrangerSyncStopLed_,
            syncStopArmed ? ArrangerLampState::Active : ArrangerLampState::Off, true);
        refreshStartStopBeatIndicator();
    }

    void refreshStartStopBeatIndicator() {
        if (!arrangerStartStopLed_) return;
        const bool hasStyle = styleEngine_.hasStyle();
        const bool playing = hasStyle && styleEngine_.isPlaying();
        const bool syncStartArmed = hasStyle && styleEngine_.syncStartPending();
        bool pulse = false;
        if (playing) {
            syncStartPulseClock_.invalidate();
            const auto &analysis = styleEngine_.analysis();
            pulse = ensembles::genos2BeatPulseActive(
                styleEngine_.currentTick(), analysis.ticksPerQuarter,
                analysis.timeSignatureDenominator, styleEngine_.tempo(), 85);
        } else if (syncStartArmed) {
            if (!syncStartPulseClock_.isValid()) syncStartPulseClock_.start();
            const int beatMs = std::max(1, 60000 / std::max(1, styleEngine_.tempo()));
            pulse = (syncStartPulseClock_.elapsed() % beatMs) < 85;
        } else {
            syncStartPulseClock_.invalidate();
        }
        paintArrangerLed(arrangerStartStopLed_,
            pulse ? ArrangerLampState::Active : ArrangerLampState::Off, true);
    }

    void setStatus(const QString &message) {
        if (statusLabel_) {
            statusLabel_->setText(QFontMetrics(statusLabel_->font()).elidedText(message, Qt::ElideRight, statusLabel_->maximumWidth()));
            statusLabel_->setToolTip(message);
            statusLabel_->show();
        }
        statusBar()->showMessage(message, 6000);
    }

    static QString controllerLabel(int cc) {
        switch (cc) {
        case 1: return QStringLiteral("Modulation (CC 1)");
        case 3: return QStringLiteral("Controller 3 / Pitch (CC 3)");
        case 7: return QStringLiteral("Volume (CC 7)");
        case 10: return QStringLiteral("Pan (CC 10)");
        case 11: return QStringLiteral("Expression (CC 11)");
        case 71: return QStringLiteral("Resonance (CC 71)");
        case 72: return QStringLiteral("Release Time (CC 72)");
        case 73: return QStringLiteral("Attack Time (CC 73)");
        case 74: return QStringLiteral("Filter Cutoff (CC 74)");
        case 76: return QStringLiteral("Vibrato Rate (CC 76)");
        case 77: return QStringLiteral("Vibrato Depth (CC 77)");
        case 91: return QStringLiteral("Reverb Send (CC 91)");
        case 93: return QStringLiteral("Chorus Send (CC 93)");
        default: return QStringLiteral("MIDI CC %1").arg(cc);
        }
    }

    static QString controlTargetLabel(int target) {
        switch (target) {
        case VoiceLVolume: return QStringLiteral("Voice L Volume");
        case VoiceR1Volume: return QStringLiteral("Voice R1 Volume");
        case VoiceR2Volume: return QStringLiteral("Voice R2 Volume");
        case StyleVolume: return QStringLiteral("Style Volume");
        case ReverbSend: return QStringLiteral("Reverb Send (selected Voice)");
        case ChorusSend: return QStringLiteral("Chorus Send (selected Voice)");
        case FilterCutoff: return QStringLiteral("Filter Cutoff (CC 74, selected Voice)");
        case FilterResonance: return QStringLiteral("Filter Resonance (CC 71, selected Voice)");
        case VoiceExpression: return QStringLiteral("Expression (CC 11, selected Voice)");
        case DrumVolume: return QStringLiteral("Drum Volume (MIDI channel 10)");
        case VoicePan: return QStringLiteral("Pan (CC 10, selected Voice)");
        case VoiceModulation: return QStringLiteral("Modulation (CC 1, selected Voice)");
        case MasterVolume: return QStringLiteral("Master Volume");
        case VoiceVolumeAll: return QStringLiteral("Voice Volume — L + R1 + R2 bersama");
        case VoiceAttack: return QStringLiteral("Attack Time (CC 73, Voice terpilih)");
        case VoiceRelease: return QStringLiteral("Release Time (CC 72, Voice terpilih)");
        case VoiceVibratoRate: return QStringLiteral("Vibrato Rate (CC 76, Voice terpilih)");
        case VoiceVibratoDepth: return QStringLiteral("Vibrato Depth (CC 77, Voice terpilih)");
        case SongVolume: return QStringLiteral("Song playback volume");
        case AudioVolume: return QStringLiteral("Audio output layer (temporary, before Audio Player)");
        case PadsVolume: return QStringLiteral("Percussion pad velocity");
        case ChordVolume: return QStringLiteral("Accompaniment/chord level");
        default: return QStringLiteral("Custom MIDI CC");
        }
    }

    // Compact labels stay directly attached to each physical control; full names remain in tooltips.
    static QString controlShortLabel(int target, int controller, bool assigned = true) {
        if (!assigned) return QStringLiteral("Unmap");
        if (target == GenericMidiCc) {
            switch (controller) {
            case 1: return QStringLiteral("Mod");
            case 7: return QStringLiteral("Vol");
            case 10: return QStringLiteral("Pan");
            case 11: return QStringLiteral("Expr.");
            case 71: return QStringLiteral("Reso");
            case 72: return QStringLiteral("Release");
            case 73: return QStringLiteral("Attack");
            case 74: return QStringLiteral("Cutoff");
            case 76: return QStringLiteral("Vib Rate");
            case 77: return QStringLiteral("Vib Depth");
            case 91: return QStringLiteral("Reverb");
            case 93: return QStringLiteral("Chorus");
            default: return QStringLiteral("CC%1").arg(controller);
            }
        }
        switch (target) {
        case VoiceLVolume: return QStringLiteral("L Vol");
        case VoiceR1Volume: return QStringLiteral("R1 Vol");
        case VoiceR2Volume: return QStringLiteral("R2 Vol");
        case StyleVolume: return QStringLiteral("Style");
        case ReverbSend: return QStringLiteral("Rev Send");
        case ChorusSend: return QStringLiteral("Ch Send");
        case FilterCutoff: return QStringLiteral("Cutoff");
        case FilterResonance: return QStringLiteral("Reso");
        case VoiceExpression: return QStringLiteral("Expr.");
        case DrumVolume: return QStringLiteral("Drum");
        case VoicePan: return QStringLiteral("Pan");
        case VoiceModulation: return QStringLiteral("Mod");
        case MasterVolume: return QStringLiteral("Master");
        case VoiceVolumeAll: return QStringLiteral("Voice Vol");
        case VoiceAttack: return QStringLiteral("Attack");
        case VoiceRelease: return QStringLiteral("Release");
        case VoiceVibratoRate: return QStringLiteral("Vib Rate");
        case VoiceVibratoDepth: return QStringLiteral("Vib Depth");
        case SongVolume: return QStringLiteral("SONG");
        case AudioVolume: return QStringLiteral("AUDIO");
        case PadsVolume: return QStringLiteral("PADS");
        case ChordVolume: return QStringLiteral("CHORD");
        default: return QStringLiteral("CC%1").arg(controller);
        }
    }

    static int defaultControlTarget(int index) {
        // Slider 1..10, then assignable knob 1..4. Joystick X/Y remain generic CC mappings.
        // Simplified V15: avoid three confusing voice-volume faders and duplicate
        // Reverb/Chorus assignments across both faders and knobs.
        static constexpr int defaults[14] = {
            StyleVolume, SongVolume, AudioVolume, PadsVolume, DrumVolume, ChordVolume,
            VoicePan, VoiceModulation, ReverbSend, ChorusSend,
            FilterCutoff, FilterResonance, ReverbSend, ChorusSend
        };
        return index >= 0 && index < 14 ? defaults[index] : GenericMidiCc;
    }

    static int defaultControllerForTarget(int target) {
        switch (target) {
        case VoiceLVolume: case VoiceR1Volume: case VoiceR2Volume:
        case VoiceVolumeAll: case StyleVolume: case DrumVolume: return 7;
        case ReverbSend: return 91;
        case ChorusSend: return 93;
        case FilterCutoff: return 74;
        case FilterResonance: return 71;
        case VoiceExpression: return 11;
        case VoicePan: return 10;
        case VoiceModulation: return 1;
        case VoiceAttack: return 73;
        case VoiceRelease: return 72;
        case VoiceVibratoRate: return 76;
        case VoiceVibratoDepth: return 77;
        case SongVolume: case AudioVolume: case PadsVolume: case ChordVolume: return 7;
        case MasterVolume: return 7;
        default: return 74;
        }
    }

    QString registrySlotGroupName(int slot, int bank = -1) const {
        const int resolvedBank = bank < 0 ? currentRegistryBank_ : bank;
        // Preserve old first-bank snapshots; additional banks have independent slots.
        if (resolvedBank == 0) return QStringLiteral("registry/slots/%1").arg(slot + 1);
        return QStringLiteral("registry/banks/%1/slots/%2").arg(resolvedBank + 1).arg(slot + 1);
    }

    void setRegistryBank(int bank) {
        currentRegistryBank_ = std::clamp(bank, 0, 99);
        QSettings settings;
        settings.setValue(QStringLiteral("registry/currentBank"), currentRegistryBank_);
        settings.sync();
        if (registryBankLabel_) registryBankLabel_->setText(QStringLiteral("%1").arg(currentRegistryBank_ + 1));
        updateRegistryButtonLabels();
        setStatus(QStringLiteral("Registration bank %1 aktif.").arg(currentRegistryBank_ + 1));
    }

    void updateRegistryButtonLabels() {
        QSettings settings;
        for (int i = 0; i < static_cast<int>(registryButtons_.size()); ++i) {
            auto *button = registryButtons_[static_cast<std::size_t>(i)];
            if (!button) continue;
            settings.beginGroup(registrySlotGroupName(i));
            const bool saved = settings.value(QStringLiteral("valid"), false).toBool();
            const QString stylePath = settings.value(QStringLiteral("stylePath")).toString();
            settings.endGroup();
            button->setText(saved ? QStringLiteral("%1*").arg(i + 1) : QString::number(i + 1));
            const QString styleName = stylePath.isEmpty()
                ? QStringLiteral("tanpa style") : QFileInfo(stylePath).completeBaseName();
            button->setToolTip(saved
                ? QStringLiteral("Bank %1 / Registration %2 tersimpan · %3. Klik untuk recall; aktifkan Memorize untuk menimpa.").arg(currentRegistryBank_ + 1).arg(i + 1).arg(styleName)
                : QStringLiteral("Bank %1 / Registration %2 kosong. Aktifkan Memorize lalu klik untuk menyimpan.").arg(currentRegistryBank_ + 1).arg(i + 1));
        }
    }

    void activateRegistrySlot(int slot) {
        if (slot < 0 || slot >= static_cast<int>(registryButtons_.size())) return;
        if (registryMemorizeMode_) {
            QSettings settings;
            const QString group = registrySlotGroupName(slot);
            settings.beginGroup(group);
            settings.setValue(QStringLiteral("valid"), true);
            settings.setValue(QStringLiteral("stylePath"), styleCombo_ ? styleCombo_->currentData().toString() : QString());
            settings.setValue(QStringLiteral("tempo"), tempoSlider_ ? tempoSlider_->value() : tempo_);
            settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]);
            settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]);
            settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
            settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]); settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]); settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
            settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]); settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]); settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
            settings.setValue(QStringLiteral("sf2BankMsbR1"), sf2BankMsb_[0]); settings.setValue(QStringLiteral("sf2BankMsbL"), sf2BankMsb_[1]); settings.setValue(QStringLiteral("sf2BankMsbR2"), sf2BankMsb_[2]);
            settings.setValue(QStringLiteral("sf2BankLsbR1"), sf2BankLsb_[0]); settings.setValue(QStringLiteral("sf2BankLsbL"), sf2BankLsb_[1]); settings.setValue(QStringLiteral("sf2BankLsbR2"), sf2BankLsb_[2]);
            settings.setValue(QStringLiteral("sf2ProgramR1"), sf2ProgramNumbers_[0]); settings.setValue(QStringLiteral("sf2ProgramL"), sf2ProgramNumbers_[1]); settings.setValue(QStringLiteral("sf2ProgramR2"), sf2ProgramNumbers_[2]);
            settings.setValue(QStringLiteral("transpose"), transposeSpin_ ? transposeSpin_->value() : transposeAmount_);
            settings.setValue(QStringLiteral("transposeOn"), true);
            settings.setValue(QStringLiteral("octave"), octaveSpin_ ? octaveSpin_->value() : octaveShiftAmount_);
            settings.setValue(QStringLiteral("octaveOn"), true);
            settings.setValue(QStringLiteral("accompanimentOn"), accompButton_ && accompButton_->isChecked());
            settings.setValue(QStringLiteral("layerOn"), layerButton_ && layerButton_->isChecked());
            settings.setValue(QStringLiteral("splitOn"), splitButton_ && splitButton_->isChecked());
            settings.setValue(QStringLiteral("splitKey"), splitKey_);
            settings.setValue(QStringLiteral("metronomeOn"), metronomeCheck_ && metronomeCheck_->isChecked());
            settings.setValue(QStringLiteral("reverbOn"), reverbCheck_ && reverbCheck_->isChecked());
            settings.setValue(QStringLiteral("reverbLevel"), reverbLevelSpin_ ? reverbLevelSpin_->value() : 7);
            settings.setValue(QStringLiteral("chorusOn"), chorusCheck_ && chorusCheck_->isChecked());
            settings.setValue(QStringLiteral("chorusLevel"), chorusLevelSpin_ ? chorusLevelSpin_->value() : 2);
            settings.setValue(QStringLiteral("delayOn"), delayCheck_ && delayCheck_->isChecked());
            settings.setValue(QStringLiteral("delayLevel"), delayLevelSpin_ ? delayLevelSpin_->value() : 5);
            settings.setValue(QStringLiteral("outputVolume"), gainSlider_ ? gainSlider_->value() : 75);
            settings.setValue(QStringLiteral("arpeggiatorType"), arpSpin_ ? arpSpin_->value() : 1);
            settings.setValue(QStringLiteral("arpeggiatorOn"), arpButton_ && arpButton_->isChecked());
            settings.setValue(QStringLiteral("harmonizerType"), harmonizerSpin_ ? harmonizerSpin_->value() : 1);
            settings.endGroup();
            settings.sync();
            if (registryMemorizeButton_) registryMemorizeButton_->setChecked(false);
            updateRegistryButtonLabels();
            setStatus(QStringLiteral("Registration Memory Bank %1 / Slot %2 disimpan.").arg(currentRegistryBank_ + 1).arg(slot + 1));
            return;
        }

        QSettings settings;
        settings.beginGroup(registrySlotGroupName(slot));
        if (!settings.value(QStringLiteral("valid"), false).toBool()) {
            settings.endGroup();
            setStatus(QStringLiteral("Registration Memory Bank %1 / Slot %2 masih kosong. Aktifkan Memorize untuk menyimpan preset.").arg(currentRegistryBank_ + 1).arg(slot + 1));
            return;
        }
        const QString stylePath = settings.value(QStringLiteral("stylePath")).toString();
        const int savedTempo = std::clamp(settings.value(QStringLiteral("tempo"), 120).toInt(), 40, 240);
        const std::array<int, 3> savedVoices = {
            std::clamp(settings.value(QStringLiteral("voiceR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceL"), 33).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceR2"), 49).toInt(), 0, 127)
        };
        const std::array<int, 3> savedVoiceMaps = {
            std::clamp(settings.value(QStringLiteral("voiceMapR1"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapL"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapR2"), 4).toInt(), 1, 4)
        };
        const std::array<int, 3> savedVoiceBanks = {
            std::clamp(settings.value(QStringLiteral("voiceBankR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankR2"), 0).toInt(), 0, 127)
        };
        const std::array<int, 3> savedSf2BankMsb = {
            std::clamp(settings.value(QStringLiteral("sf2BankMsbR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankMsbL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankMsbR2"), 0).toInt(), 0, 127)
        };
        const std::array<int, 3> savedSf2BankLsb = {
            std::clamp(settings.value(QStringLiteral("sf2BankLsbR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankLsbL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankLsbR2"), 0).toInt(), 0, 127)
        };
        const std::array<int, 3> savedSf2Programs = {
            std::clamp(settings.value(QStringLiteral("sf2ProgramR1"), savedVoices[0]).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2ProgramL"), savedVoices[1]).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2ProgramR2"), savedVoices[2]).toInt(), 0, 127)
        };
        const int savedTranspose = std::clamp(settings.value(QStringLiteral("transpose"), 0).toInt(), -12, 12);
        const int savedOctave = std::clamp(settings.value(QStringLiteral("octave"), 0).toInt(), -2, 2);
        const bool savedAccompaniment = settings.value(QStringLiteral("accompanimentOn"), false).toBool();
        const bool savedLayer = settings.value(QStringLiteral("layerOn"), false).toBool();
        const bool savedSplit = settings.value(QStringLiteral("splitOn"), false).toBool();
        const int savedSplitKey = std::clamp(settings.value(QStringLiteral("splitKey"), kOriginalSplitKey).toInt(), 36, 95);
        const bool savedMetronome = settings.value(QStringLiteral("metronomeOn"), false).toBool();
        const bool savedReverb = settings.value(QStringLiteral("reverbOn"), true).toBool();
        const int savedReverbLevel = std::clamp(settings.value(QStringLiteral("reverbLevel"), 7).toInt(), 0, 10);
        const bool savedChorus = settings.value(QStringLiteral("chorusOn"), true).toBool();
        const int savedChorusLevel = std::clamp(settings.value(QStringLiteral("chorusLevel"), 2).toInt(), 0, 10);
        const int savedOutputVolume = std::clamp(settings.value(QStringLiteral("outputVolume"), 75).toInt(), 0, 100);
        const int savedArpeggiatorType = std::clamp(settings.value(QStringLiteral("arpeggiatorType"), 1).toInt(), 1, 12);
        const bool savedArpeggiatorOn = settings.value(QStringLiteral("arpeggiatorOn"), false).toBool();
        const int savedHarmonizerType = std::clamp(settings.value(QStringLiteral("harmonizerType"), 1).toInt(), 1, 6);
        settings.endGroup();

        allSoundsOff();
        if (styleEngine_.isPlaying()) styleEngine_.stop();
        styleTimer_.stop();
        bool styleRestored = stylePath.isEmpty();
        if (styleCombo_) {
            const int styleIndex = stylePath.isEmpty() ? -1 : styleCombo_->findData(stylePath);
            if (styleIndex >= 0) {
                const QSignalBlocker blocker(styleCombo_);
                styleCombo_->setCurrentIndex(styleIndex);
                styleRestored = applyStyleFile(stylePath, 0);
            } else if (stylePath.isEmpty()) {
                const QSignalBlocker blocker(styleCombo_);
                styleCombo_->setCurrentIndex(-1);
                styleEngine_.unloadStyle();
                if (audioEngine_ && audioEngine_->isReady())
                    (void)audioEngine_->clearYamahaStyleEffects();
                activeStyleExtension_.clear();
                if (styleNameLabel_) styleNameLabel_->setText(QStringLiteral("No Style"));
                if (lcdMidiMetaLabel_) lcdMidiMetaLabel_->setText(QStringLiteral("4/4     ♩=%1   001/001").arg(tempo_));
                if (lcdStyleMetaLabel_) lcdStyleMetaLabel_->setText(QStringLiteral("Style    4/4     ♩ %1     1/8").arg(tempo_));
                if (styleInfo_) styleInfo_->setText(QStringLiteral("Belum ada style dipilih."));
            }
        }
        // A recalled style owns its initial BPM. Keep the registration's free
        // tempo only when no style could be restored.
        if (stylePath.isEmpty() || !styleRestored) {
            tempo_ = savedTempo;
            styleEngine_.setTempo(savedTempo);
        }
        if (tempoSlider_) { const QSignalBlocker blocker(tempoSlider_); tempoSlider_->setValue(tempo_); }
        if (tempoValue_) tempoValue_->setText(QString::number(tempo_));
        if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(tempo_));
        if (lcdMidiMetaLabel_) lcdMidiMetaLabel_->setText(QStringLiteral("%1     ♩=%2   001/001")
            .arg(beatMetricLabel_ ? beatMetricLabel_->text() : QStringLiteral("4/4"))
            .arg(tempo_));
        if (lcdStyleMetaLabel_) lcdStyleMetaLabel_->setText(QStringLiteral("Style    %1     ♩ %2     1/8")
            .arg(beatMetricLabel_ ? beatMetricLabel_->text() : QStringLiteral("4/4"))
            .arg(tempo_));

        voicePrograms_ = savedVoices;
        sf2BankMsb_ = savedSf2BankMsb;
        sf2BankLsb_ = savedSf2BankLsb;
        sf2ProgramNumbers_ = savedSf2Programs;
        for (int i = 0; i < 3; ++i) {
            const auto partIndex = static_cast<std::size_t>(i);
            voiceMaps_[partIndex] = savedVoiceMaps[partIndex];
            voiceBanks_[partIndex] = savedVoiceBanks[partIndex];
        }
        applyAllVoicePrograms();
        updateSf2PresetControlsForSlot(sf2PartCombo_ ? sf2PartCombo_->currentIndex() : 0);
        auto voiceLabelForSlot = [this](int slot) {
            const auto program = voicePrograms_[static_cast<std::size_t>(slot)];
            const auto bank = voiceBanks_[static_cast<std::size_t>(slot)];
            const auto map = voiceMaps_[static_cast<std::size_t>(slot)];
            for (const auto &entry : voiceCatalog_)
                if (entry.program == program && entry.bank == bank && entry.map == map) return entry.name;
            return QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
        };
        if (voiceR1Label_) voiceR1Label_->setText(voiceLabelForSlot(0));
        if (voiceLLabel_) voiceLLabel_->setText(voiceLabelForSlot(1));
        if (voiceR2Label_) voiceR2Label_->setText(voiceLabelForSlot(2));
        if (voiceR3Label_) voiceR3Label_->setText(voiceLabelForSlot(2));
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(voicePrograms_[static_cast<std::size_t>(selectedProgramChannel_)]); }

        if (transposeSpin_) transposeSpin_->setValue(savedTranspose);
        if (octaveSpin_) octaveSpin_->setValue(savedOctave);
        if (splitKey_ != savedSplitKey) {
            splitKey_ = savedSplitKey;
            if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        }
        if (accompButton_) accompButton_->setChecked(savedAccompaniment);
        if (styleChordControlButton_) {
            const QSignalBlocker chordBlocker(styleChordControlButton_);
            styleChordControlButton_->setChecked(savedAccompaniment);
        }
        styleEngine_.setChordControlEnabled(savedAccompaniment);
        if (layerButton_) layerButton_->setChecked(savedLayer);
        if (splitButton_) splitButton_->setChecked(savedSplit);
        if (metronomeCheck_) metronomeCheck_->setChecked(savedMetronome);
        if (reverbLevelSpin_) reverbLevelSpin_->setValue(savedReverbLevel);
        if (reverbCheck_) reverbCheck_->setChecked(savedReverb);
        if (chorusLevelSpin_) chorusLevelSpin_->setValue(savedChorusLevel);
        if (chorusCheck_) chorusCheck_->setChecked(savedChorus);
        if (nativeEfxCheck_) nativeEfxCheck_->setChecked(settings.value(QStringLiteral("nativeEfxOn"), true).toBool());
        if (nativeEfxTypeCombo_) nativeEfxTypeCombo_->setCurrentIndex(std::clamp(settings.value(QStringLiteral("nativeEfxType"), 5).toInt(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1));
        if (gainSlider_) gainSlider_->setValue(savedOutputVolume);
        if (masterControlDial_) {
            const QSignalBlocker blocker(masterControlDial_);
            masterControlDial_->setValue(std::clamp((savedOutputVolume * 127 + 50) / 100, 0, 127));
        }
        if (arpSpin_) arpSpin_->setValue(savedArpeggiatorType);
        if (arpButton_) arpButton_->setChecked(savedArpeggiatorOn);
        if (harmonizerSpin_) harmonizerSpin_->setValue(savedHarmonizerType);
        if (metronomeButton_ && metronomeButton_->isChecked() != savedMetronome) metronomeButton_->setChecked(savedMetronome);
        if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        applyPanelMidiSettings();
        savePanelSettings();
        setStatus(styleRestored
            ? QStringLiteral("Registration Memory Bank %1 / Slot %2 dipanggil.").arg(currentRegistryBank_ + 1).arg(slot + 1)
            : QStringLiteral("Registration Memory Bank %1 / Slot %2 dipanggil, tetapi file style tersimpan tidak ditemukan; style aktif dipertahankan.").arg(currentRegistryBank_ + 1).arg(slot + 1));
    }

    void loadPanelSettings() {
        QSettings settings;
        currentRegistryBank_ = std::clamp(settings.value(QStringLiteral("registry/currentBank"), 0).toInt(), 0, 99);
        voicePrograms_ = {
            std::clamp(settings.value(QStringLiteral("voiceR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceL"), 33).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceR2"), 49).toInt(), 0, 127)
        };
        voiceMaps_ = {
            std::clamp(settings.value(QStringLiteral("voiceMapR1"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapL"), 4).toInt(), 1, 4),
            std::clamp(settings.value(QStringLiteral("voiceMapR2"), 4).toInt(), 1, 4)
        };
        voiceBanks_ = {
            std::clamp(settings.value(QStringLiteral("voiceBankR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("voiceBankR2"), 0).toInt(), 0, 127)
        };
        sf2BankMsb_ = {
            std::clamp(settings.value(QStringLiteral("sf2BankMsbR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankMsbL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankMsbR2"), 0).toInt(), 0, 127)
        };
        sf2BankLsb_ = {
            std::clamp(settings.value(QStringLiteral("sf2BankLsbR1"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankLsbL"), 0).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2BankLsbR2"), 0).toInt(), 0, 127)
        };
        sf2ProgramNumbers_ = {
            std::clamp(settings.value(QStringLiteral("sf2ProgramR1"), voicePrograms_[0]).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2ProgramL"), voicePrograms_[1]).toInt(), 0, 127),
            std::clamp(settings.value(QStringLiteral("sf2ProgramR2"), voicePrograms_[2]).toInt(), 0, 127)
        };
        updateSf2PresetControlsForSlot(sf2PartCombo_ ? sf2PartCombo_->currentIndex() : 0);
        auto voiceLabelForSlot = [this](int slot) {
            const auto program = voicePrograms_[static_cast<std::size_t>(slot)];
            const auto bank = voiceBanks_[static_cast<std::size_t>(slot)];
            const auto map = voiceMaps_[static_cast<std::size_t>(slot)];
            for (const auto &entry : voiceCatalog_)
                if (entry.program == program && entry.bank == bank && entry.map == map) return entry.name;
            return QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
        };
        if (voiceR1Label_) voiceR1Label_->setText(voiceLabelForSlot(0));
        if (voiceLLabel_) voiceLLabel_->setText(voiceLabelForSlot(1));
        if (voiceR2Label_) voiceR2Label_->setText(voiceLabelForSlot(2));
        if (voiceR3Label_) voiceR3Label_->setText(voiceLabelForSlot(2));
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(voicePrograms_[static_cast<std::size_t>(selectedProgramChannel_)]); }
        soundFontPath_ = settings.value(QStringLiteral("audio/soundFontPath"), QString()).toString();
        vst2PluginPath_ = settings.value(QStringLiteral("audio/vst2PluginPath"), QString()).toString();
        const QString routing = settings.value(QStringLiteral("audio/outputRouting"), QStringLiteral("auto")).toString();
        if (midiOutputDeviceCombo_) {
            const int midiId = settings.value(QStringLiteral("audio/midiOutputDeviceId"), -1).toInt();
            const int midiIndex = midiOutputDeviceCombo_->findData(midiId);
            if (midiIndex >= 0) midiOutputDeviceCombo_->setCurrentIndex(midiIndex);
        }
        if (audioRoutingCombo_) {
            const int routeIndex = audioRoutingCombo_->findData(routing);
            audioRoutingCombo_->setCurrentIndex(routeIndex >= 0 ? routeIndex : 0);
        }
        const int apiValue = settings.value(QStringLiteral("audio/rtaudioApi"),
            static_cast<int>(RtAudio::UNSPECIFIED)).toInt();
        if (audioApiCombo_) {
            const int apiIndex = audioApiCombo_->findData(apiValue);
            audioApiCombo_->setCurrentIndex(apiIndex >= 0 ? apiIndex : 0);
        }
        const qint64 deviceValue = settings.value(QStringLiteral("audio/outputDeviceId"), -1).toLongLong();
        refreshAudioOutputDevices(deviceValue);
        refreshAudioSampleRates(static_cast<unsigned int>(settings.value(QStringLiteral("audio/sampleRate"), 44100).toUInt()));
        if (audioBufferCombo_) {
            const int index = audioBufferCombo_->findData(settings.value(QStringLiteral("audio/bufferFrames"), 256).toInt());
            audioBufferCombo_->setCurrentIndex(index >= 0 ? index : audioBufferCombo_->findData(256));
        }
        accompanimentEnabled_ = settings.value(QStringLiteral("panel/accompanimentOn"), false).toBool();
        layerEnabled_ = settings.value(QStringLiteral("panel/layerOn"), false).toBool();
        static constexpr const char *rightPartNames[] = {"L", "R1", "R2", "R3"};
        for (int i = 0; i < 4; ++i) {
            const bool defaultEnabled = i < 2 || (i == 2 && layerEnabled_);
            const bool enabled = settings.value(QStringLiteral("panel/rightPartOn/%1").arg(QString::fromLatin1(rightPartNames[i])), defaultEnabled).toBool();
            rightVoiceEnabled_[static_cast<std::size_t>(i)] = enabled;
            if (rightVoiceOnButtons_[static_cast<std::size_t>(i)]) {
                const QSignalBlocker blocker(rightVoiceOnButtons_[static_cast<std::size_t>(i)]);
                rightVoiceOnButtons_[static_cast<std::size_t>(i)]->setChecked(enabled);
                rightVoiceOnButtons_[static_cast<std::size_t>(i)]->setText(enabled ? QStringLiteral("ON") : QStringLiteral("OFF"));
            }
        }
        splitEnabled_ = settings.value(QStringLiteral("panel/splitOn"), false).toBool();
        // Legacy transposeOn/octaveOn settings are intentionally ignored: these are +/- parameters.
        transposeAmount_ = std::clamp(settings.value(QStringLiteral("panel/transpose"), 0).toInt(), -12, 12);
        octaveShiftAmount_ = std::clamp(settings.value(QStringLiteral("panel/octave"), 0).toInt(), -2, 2);
        splitKey_ = std::clamp(settings.value(QStringLiteral("panel/splitKey"), kOriginalSplitKey).toInt(), 36, 95);
        const bool metronomeOn = settings.value(QStringLiteral("panel/metronomeOn"), false).toBool();
        // Match the original GSettings schema defaults: reverb and chorus start enabled.
        const bool reverbOn = settings.value(QStringLiteral("panel/reverbOn"), true).toBool();
        const bool chorusOn = settings.value(QStringLiteral("panel/chorusOn"), true).toBool();
        const bool delayOn = settings.value(QStringLiteral("panel/delayOn"), true).toBool();
        const QSignalBlocker b1(accompButton_), b2(layerButton_), b3(splitButton_), b4(metronomeButton_);
        const QSignalBlocker b7(arpButton_), b8(harmonizerButton_);
        const QSignalBlocker b9(reverbButton_), b10(chorusButton_);
        const QSignalBlocker b11(transposeSpin_), b12(octaveSpin_), b13(reverbLevelSpin_), b14(chorusLevelSpin_);
        const QSignalBlocker b15(reverbCheck_), b16(chorusCheck_), b17(metronomeCheck_);
        const QSignalBlocker b18(delayCheck_), b19(delayLevelSpin_);
        accompButton_->setChecked(accompanimentEnabled_);
        if (styleChordControlButton_) {
            const QSignalBlocker chordBlocker(styleChordControlButton_);
            styleChordControlButton_->setChecked(accompanimentEnabled_);
        }
        styleEngine_.setChordControlEnabled(accompanimentEnabled_);
        layerButton_->setChecked(layerEnabled_);
        splitButton_->setChecked(splitEnabled_);
        metronomeButton_->setChecked(metronomeOn);
        // Restore the implemented Arpeggiator state; no held notes exist until the user plays.
        arpButton_->setChecked(settings.value(QStringLiteral("panel/arpeggiatorOn"), false).toBool());
        if (harmonizerButton_) harmonizerButton_->setChecked(false);
        reverbButton_->setChecked(reverbOn);
        chorusButton_->setChecked(chorusOn);
        metronomeCheck_->setChecked(metronomeOn);
        reverbCheck_->setChecked(reverbOn);
        chorusCheck_->setChecked(chorusOn);
        if (delayCheck_) delayCheck_->setChecked(delayOn);
        if (nativeEfxCheck_) nativeEfxCheck_->setChecked(settings.value(QStringLiteral("nativeEfxOn"), true).toBool());
        if (nativeEfxTypeCombo_) nativeEfxTypeCombo_->setCurrentIndex(std::clamp(settings.value(QStringLiteral("nativeEfxType"), 5).toInt(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1));
        transposeSpin_->setValue(transposeAmount_);
        octaveSpin_->setValue(octaveShiftAmount_);
        reverbLevelSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/reverbLevel"), 7).toInt(), 0, 10));
        chorusLevelSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/chorusLevel"), 2).toInt(), 0, 10));
        if (delayLevelSpin_) delayLevelSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/delayLevel"), 5).toInt(), 0, 10));
        arpSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/arpeggiatorType"), 1).toInt(), 1, 12));
        if (harmonizerSpin_) harmonizerSpin_->setValue(std::clamp(settings.value(QStringLiteral("panel/harmonizerType"), 1).toInt(), 1, 6));
        if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
        if (transposeMetricLabel_) transposeMetricLabel_->setText(QString::number(transposeAmount_));
        if (octaveMetricLabel_) octaveMetricLabel_->setText(QString::number(octaveShiftAmount_));
        if (gainSlider_) {
            const int savedVolume = std::clamp(settings.value(QStringLiteral("panel/outputVolume"), 75).toInt(), 0, 100);
            gainSlider_->setValue(savedVolume);
            if (masterControlDial_) {
                const QSignalBlocker blocker(masterControlDial_);
                masterControlDial_->setValue(std::clamp((savedVolume * 127 + 50) / 100, 0, 127));
            }
        }
        if (registryBankLabel_) registryBankLabel_->setText(QString::number(currentRegistryBank_ + 1));
        updateRegistryButtonLabels();
    }

    void savePanelSettings() {
        QSettings settings;
        settings.setValue(QStringLiteral("panel/accompanimentOn"), accompanimentEnabled_);
        settings.setValue(QStringLiteral("panel/layerOn"), layerEnabled_);
        settings.setValue(QStringLiteral("panel/splitOn"), splitEnabled_);
        // Kept true only for backward compatibility with older builds; no UI toggle exists.
        settings.setValue(QStringLiteral("panel/transposeOn"), true);
        settings.setValue(QStringLiteral("panel/octaveOn"), true);
        settings.setValue(QStringLiteral("panel/transpose"), transposeAmount_);
        settings.setValue(QStringLiteral("panel/octave"), octaveShiftAmount_);
        settings.setValue(QStringLiteral("panel/splitKey"), splitKey_);
        settings.setValue(QStringLiteral("panel/metronomeOn"), metronomeCheck_ && metronomeCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/reverbOn"), reverbCheck_ && reverbCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/chorusOn"), chorusCheck_ && chorusCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/reverbLevel"), reverbLevelSpin_ ? reverbLevelSpin_->value() : 7);
        settings.setValue(QStringLiteral("panel/chorusLevel"), chorusLevelSpin_ ? chorusLevelSpin_->value() : 2);
        settings.setValue(QStringLiteral("panel/delayOn"), delayCheck_ && delayCheck_->isChecked());
        settings.setValue(QStringLiteral("panel/delayLevel"), delayLevelSpin_ ? delayLevelSpin_->value() : 5);
        settings.setValue(QStringLiteral("nativeEfxOn"), nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        settings.setValue(QStringLiteral("nativeEfxType"), nativeEfxTypeCombo_ ? nativeEfxTypeCombo_->currentIndex() : 5);
        settings.setValue(QStringLiteral("panel/arpeggiatorType"), arpSpin_ ? arpSpin_->value() : 1);
        settings.setValue(QStringLiteral("panel/arpeggiatorOn"), arpButton_ && arpButton_->isChecked());
        settings.setValue(QStringLiteral("panel/harmonizerType"), harmonizerSpin_ ? harmonizerSpin_->value() : 1);
        settings.setValue(QStringLiteral("panel/outputVolume"), gainSlider_ ? gainSlider_->value() : 75);
        static constexpr const char *rightPartNames[] = {"L", "R1", "R2", "R3"};
        for (int i = 0; i < 4; ++i)
            settings.setValue(QStringLiteral("panel/rightPartOn/%1").arg(QString::fromLatin1(rightPartNames[i])), rightVoiceEnabled_[static_cast<std::size_t>(i)]);
        settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]); settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]); settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
        settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]); settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]); settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
        settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]); settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]); settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
        settings.setValue(QStringLiteral("sf2BankMsbR1"), sf2BankMsb_[0]); settings.setValue(QStringLiteral("sf2BankMsbL"), sf2BankMsb_[1]); settings.setValue(QStringLiteral("sf2BankMsbR2"), sf2BankMsb_[2]);
        settings.setValue(QStringLiteral("sf2BankLsbR1"), sf2BankLsb_[0]); settings.setValue(QStringLiteral("sf2BankLsbL"), sf2BankLsb_[1]); settings.setValue(QStringLiteral("sf2BankLsbR2"), sf2BankLsb_[2]);
        settings.setValue(QStringLiteral("sf2ProgramR1"), sf2ProgramNumbers_[0]); settings.setValue(QStringLiteral("sf2ProgramL"), sf2ProgramNumbers_[1]); settings.setValue(QStringLiteral("sf2ProgramR2"), sf2ProgramNumbers_[2]);
        settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
        if (audioRoutingCombo_) settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_->currentData().toString());
        if (midiOutputDeviceCombo_) settings.setValue(QStringLiteral("audio/midiOutputDeviceId"), midiOutputDeviceCombo_->currentData().toInt());
        if (audioApiCombo_) settings.setValue(QStringLiteral("audio/rtaudioApi"), audioApiCombo_->currentData().toInt());
        if (audioDeviceCombo_) settings.setValue(QStringLiteral("audio/outputDeviceId"), selectedRtAudioDeviceId().has_value()
            ? static_cast<qint64>(*selectedRtAudioDeviceId()) : qint64(-1));
        if (audioSampleRateCombo_) settings.setValue(QStringLiteral("audio/sampleRate"), audioSampleRateCombo_->currentData().toUInt());
        if (audioBufferCombo_) settings.setValue(QStringLiteral("audio/bufferFrames"), audioBufferCombo_->currentData().toInt());
        settings.sync();
    }

    void applyPanelMidiSettings() {
        const bool reverbOn = reverbCheck_ && reverbCheck_->isChecked();
        const bool chorusOn = chorusCheck_ && chorusCheck_->isChecked();
        const int reverbLevel = reverbLevelSpin_ ? reverbLevelSpin_->value() : 7;
        const int chorusLevel = chorusLevelSpin_ ? chorusLevelSpin_->value() : 2;
        const bool delayOn = delayCheck_ && delayCheck_->isChecked();
        const int delayLevel = delayLevelSpin_ ? delayLevelSpin_->value() : 5;
        if (audioEngine_ && audioEngine_->isReady()) {
            audioEngine_->setMasterReverb(reverbOn, reverbLevel);
            audioEngine_->setMasterChorus(chorusOn, chorusLevel);
            audioEngine_->setMasterDelay(delayOn, delayLevel);
        }
        // Hardware MIDI output still receives the matching XG send controllers.
        if (wantsWindowsMidiOutput()) {
            sendWindowsMidi(0xB0, 91, reverbOn ? static_cast<quint8>(std::clamp(reverbLevel * 127 / 10, 0, 127)) : 0);
            sendWindowsMidi(0xB0, 93, chorusOn ? static_cast<quint8>(std::clamp(chorusLevel * 127 / 10, 0, 127)) : 0);
            sendWindowsMidi(0xB0, 94, delayOn ? static_cast<quint8>(std::clamp(delayLevel * 127 / 10, 0, 127)) : 0);
        }
        updateModulationTimer();
        updateOutputStatus();
    }

    void loadControllerMaps() {
        QSettings settings;
        styleVolume_ = std::clamp(settings.value(QStringLiteral("uiControls/styleVolume"), 100).toInt(), 0, 127);
        const bool simplifiedDefaultsMigration = settings.value(QStringLiteral("uiControls/defaultMappingVersion"), 0).toInt() < 16;
        // V15 defaults are migrated once to the reference-panel layout. The first six faders
        // now have fixed instrument-section roles; four obsolete generic fader slots are hidden.
        static constexpr int oldDefaults[14] = {
            VoiceVolumeAll, StyleVolume, DrumVolume, VoiceExpression,
            ReverbSend, ChorusSend, FilterCutoff, FilterResonance,
            VoicePan, VoiceModulation, VoiceAttack, VoiceRelease, VoiceVibratoRate, VoiceVibratoDepth
        };
        // V14 used a different target for the four physical knobs; recognize both generations
        // so factory defaults migrate but deliberate custom assignments remain intact.
        static constexpr int legacyV14Defaults[14] = {
            VoiceLVolume, VoiceR1Volume, VoiceR2Volume, StyleVolume,
            ReverbSend, ChorusSend, FilterCutoff, FilterResonance,
            VoiceExpression, DrumVolume, VoicePan, VoiceModulation, ReverbSend, ChorusSend
        };
        static constexpr int simpleDefaultValues[14] = {100, 100, 100, 100, 100, 100, 64, 64, 30, 30, 64, 64, 30, 30};
        for (int i = 0; i < static_cast<int>(controllerMaps_.size()); ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            const bool hasTarget = settings.contains(prefix + QStringLiteral("target"));
            const bool storedAssigned = settings.value(prefix + QStringLiteral("assigned"), false).toBool();
            bool remappedDefault = false;
            map.channel = std::clamp(settings.value(prefix + QStringLiteral("channel"), (i == 0 ? 1 : (i == 2 ? 2 : 0))).toInt(), 0, 15);
            const int savedTarget = std::clamp(settings.value(prefix + QStringLiteral("target"), static_cast<int>(GenericMidiCc)).toInt(), static_cast<int>(GenericMidiCc), static_cast<int>(ChordVolume));
            const bool matchesKnownDefault = !hasTarget || savedTarget == oldDefaults[i] || savedTarget == legacyV14Defaults[i];
            if (i < 14 && simplifiedDefaultsMigration && matchesKnownDefault) {
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
                remappedDefault = true;
            } else if (hasTarget) {
                map.target = std::clamp(settings.value(prefix + QStringLiteral("target"), static_cast<int>(GenericMidiCc)).toInt(), static_cast<int>(GenericMidiCc), static_cast<int>(ChordVolume));
                map.assigned = settings.value(prefix + QStringLiteral("assigned"), true).toBool();
                map.controller = std::clamp(settings.value(prefix + QStringLiteral("controller"), defaultControllerForTarget(map.target)).toInt(), 0, 127);
            } else if (i < 14 && !storedAssigned) {
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
                remappedDefault = true;
            } else {
                map.target = GenericMidiCc;
                map.assigned = storedAssigned;
                const int defaultController = i == 14 ? 10 : (i == 15 ? 1 : 74);
                map.controller = std::clamp(settings.value(prefix + QStringLiteral("controller"), defaultController).toInt(), 0, 127);
                if ((i == 14 || i == 15) && !settings.contains(prefix + QStringLiteral("assigned"))) map.assigned = true;
            }
            if (i >= 14) {
                // Joystick axes always remain direct configurable CC mappings.
                map.target = GenericMidiCc;
                if (!settings.contains(prefix + QStringLiteral("assigned"))) map.assigned = true;
            }
            if (i < 6) {
                // These six faders are fixed by the reference design rather than user-remappable CC strips.
                map.target = defaultControlTarget(i);
                map.assigned = true;
                map.controller = defaultControllerForTarget(map.target);
                map.channel = 0;
            }
            const QString valueKey = QStringLiteral("uiControls/value/%1").arg(i);
            if (i < 10 && assignableSliders_[static_cast<std::size_t>(i)]) {
                const int saved = settings.value(valueKey, simpleDefaultValues[i]).toInt();
                const QSignalBlocker blocker(assignableSliders_[static_cast<std::size_t>(i)]);
                // The six labeled left-panel section faders must start at 100 on every launch;
                // do not restore old random-looking positions from earlier versions.
                const int startupValue = (i < 6) ? 100 : (remappedDefault ? simpleDefaultValues[i] : std::clamp(saved, 0, 127));
                assignableSliders_[static_cast<std::size_t>(i)]->setValue(startupValue);
                if (i < 6) settings.setValue(valueKey, 100);
            } else if (i >= 10 && i < 14 && assignableKnobs_[static_cast<std::size_t>(i - 10)]) {
                const int saved = settings.value(valueKey, simpleDefaultValues[i]).toInt();
                const QSignalBlocker blocker(assignableKnobs_[static_cast<std::size_t>(i - 10)]);
                assignableKnobs_[static_cast<std::size_t>(i - 10)]->setValue(remappedDefault ? simpleDefaultValues[i] : std::clamp(saved, 0, 127));
            }
            if (i < static_cast<int>(masterTargets_.size()))
                masterTargets_[static_cast<std::size_t>(i)] = settings.value(QStringLiteral("masterTargets/%1").arg(i), false).toBool();
        }
        settings.setValue(QStringLiteral("uiControls/defaultMappingVersion"), 16);
        for (int i = 0; i < 14; ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            settings.setValue(prefix + QStringLiteral("assigned"), map.assigned);
            settings.setValue(prefix + QStringLiteral("channel"), map.channel);
            settings.setValue(prefix + QStringLiteral("controller"), map.controller);
            settings.setValue(prefix + QStringLiteral("target"), map.target);
            const int value = i < 10 ? (assignableSliders_[static_cast<std::size_t>(i)] ? assignableSliders_[static_cast<std::size_t>(i)]->value() : simpleDefaultValues[i])
                                     : (assignableKnobs_[static_cast<std::size_t>(i - 10)] ? assignableKnobs_[static_cast<std::size_t>(i - 10)]->value() : simpleDefaultValues[i]);
            settings.setValue(QStringLiteral("uiControls/value/%1").arg(i), value);
        }
        settings.sync();
    }

    void saveControllerMaps() {
        QSettings settings;
        for (int i = 0; i < static_cast<int>(controllerMaps_.size()); ++i) {
            const QString prefix = QStringLiteral("uiControlMaps/%1/").arg(i);
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            settings.setValue(prefix + QStringLiteral("assigned"), map.assigned);
            settings.setValue(prefix + QStringLiteral("channel"), map.channel);
            settings.setValue(prefix + QStringLiteral("controller"), map.controller);
            settings.setValue(prefix + QStringLiteral("target"), map.target);
            if (i < static_cast<int>(masterTargets_.size()))
                settings.setValue(QStringLiteral("masterTargets/%1").arg(i), masterTargets_[static_cast<std::size_t>(i)]);
        }
        settings.setValue(QStringLiteral("uiControls/styleVolume"), styleVolume_);
        settings.sync();
    }

    void refreshControllerTooltips() {
        for (int i = 0; i < 10; ++i) {
            const auto &map = controllerMaps_[static_cast<std::size_t>(i)];
            QString tip = QStringLiteral("Slider %1").arg(i + 1);
            tip += map.assigned
                ? (map.target == GenericMidiCc
                    ? QStringLiteral(" — Channel %1, %2").arg(map.channel + 1).arg(controllerLabel(map.controller))
                    : QStringLiteral(" — %1").arg(controlTargetLabel(map.target)))
                : QStringLiteral(" — belum dipetakan; aktifkan Slider Assign lalu klik slider");
            if (masterTargets_[static_cast<std::size_t>(i)]) tip += QStringLiteral(" — target Master Knob");
            if (assignableSliders_[static_cast<std::size_t>(i)]) {
                assignableSliders_[static_cast<std::size_t>(i)]->setToolTip(tip);
                assignableSliders_[static_cast<std::size_t>(i)]->setProperty("masterTarget", masterTargets_[static_cast<std::size_t>(i)]);
                if (assignableSliderNameLabels_[static_cast<std::size_t>(i)]) {
                    if (i >= 6) assignableSliderNameLabels_[static_cast<std::size_t>(i)]->setText(controlShortLabel(map.target, map.controller, map.assigned));
                    assignableSliderNameLabels_[static_cast<std::size_t>(i)]->setToolTip(tip);
                }
                assignableSliders_[static_cast<std::size_t>(i)]->style()->unpolish(assignableSliders_[static_cast<std::size_t>(i)]);
                assignableSliders_[static_cast<std::size_t>(i)]->style()->polish(assignableSliders_[static_cast<std::size_t>(i)]);
            }
        }
        for (int i = 0; i < 4; ++i) {
            const int idx = 10 + i;
            const auto &map = controllerMaps_[static_cast<std::size_t>(idx)];
            QString tip = QStringLiteral("Knob %1").arg(i + 1);
            tip += map.assigned
                ? (map.target == GenericMidiCc
                    ? QStringLiteral(" — Channel %1, %2").arg(map.channel + 1).arg(controllerLabel(map.controller))
                    : QStringLiteral(" — %1").arg(controlTargetLabel(map.target)))
                : QStringLiteral(" — belum dipetakan; aktifkan Knob Assign lalu klik knob");
            if (masterTargets_[static_cast<std::size_t>(idx)]) tip += QStringLiteral(" — target Master Knob");
            if (assignableKnobs_[static_cast<std::size_t>(i)]) {
                assignableKnobs_[static_cast<std::size_t>(i)]->setToolTip(tip);
                assignableKnobs_[static_cast<std::size_t>(i)]->setProperty("masterTarget", masterTargets_[static_cast<std::size_t>(idx)]);
                if (assignableKnobNameLabels_[static_cast<std::size_t>(i)]) {
                    assignableKnobNameLabels_[static_cast<std::size_t>(i)]->setText(controlShortLabel(map.target, map.controller, map.assigned));
                    assignableKnobNameLabels_[static_cast<std::size_t>(i)]->setToolTip(tip);
                }
                assignableKnobs_[static_cast<std::size_t>(i)]->style()->unpolish(assignableKnobs_[static_cast<std::size_t>(i)]);
                assignableKnobs_[static_cast<std::size_t>(i)]->style()->polish(assignableKnobs_[static_cast<std::size_t>(i)]);
            }
        }
        for (int axis = 0; axis < 2; ++axis) {
            const int idx = 14 + axis;
            const auto &map = controllerMaps_[static_cast<std::size_t>(idx)];
            const QString label = axis == 0 ? QStringLiteral("Joystick X") : QStringLiteral("Joystick Y");
            const QString tip = map.assigned
                ? QStringLiteral("%1 → Channel %2, %3; seret pad XY untuk mengirim nilai.").arg(label).arg(map.channel + 1).arg(controllerLabel(map.controller))
                : QStringLiteral("%1 belum dipetakan; klik tombol Assign untuk mengatur MIDI CC.").arg(label);
            if (axis == 0 && joystickXAssignButton_) joystickXAssignButton_->setToolTip(tip);
            if (axis == 1 && joystickYAssignButton_) joystickYAssignButton_->setToolTip(tip);
        }
    }

    void updateAssignmentButtonAvailability() {
        if (!knobAssignButton_ || !masterAssignButton_) return;
        knobAssignButton_->setEnabled(!masterAssignMode_ && !sliderAssignMode_);
        if (sliderAssignButton_) sliderAssignButton_->setEnabled(!masterAssignMode_ && !knobAssignMode_);
        masterAssignButton_->setEnabled(!knobAssignMode_ && !sliderAssignMode_);
    }

    void stopControlAssignmentModes() {
        knobAssignMode_ = false;
        masterAssignMode_ = false;
        sliderAssignMode_ = false;
        if (knobAssignButton_) knobAssignButton_->setChecked(false);
        if (masterAssignButton_) masterAssignButton_->setChecked(false);
        if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
        updateAssignmentButtonAvailability();
    }

    void configureControlMapping(int index, const QString &controlName) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        auto &current = controllerMaps_[static_cast<std::size_t>(index)];
        QDialog dialog(this);
        dialog.setWindowTitle(QStringLiteral("Pemetaan %1").arg(controlName));
        dialog.setMinimumWidth(340);
        auto *layout = new QVBoxLayout(&dialog);
        auto *form = new QFormLayout;
        auto *targetBox = new QComboBox(&dialog);
        for (int target = GenericMidiCc; target <= ChordVolume; ++target)
            targetBox->addItem(controlTargetLabel(target), target);
        targetBox->setCurrentIndex(std::max(0, targetBox->findData(current.target)));
        auto *channelBox = new QComboBox(&dialog);
        for (int ch = 0; ch < 16; ++ch)
            channelBox->addItem(QStringLiteral("Channel %1").arg(ch + 1), ch);
        channelBox->setCurrentIndex(std::clamp(current.channel, 0, 15));
        auto *controllerBox = new QComboBox(&dialog);
        for (int cc = 0; cc <= 127; ++cc) controllerBox->addItem(controllerLabel(cc), cc);
        int ccIndex = controllerBox->findData(current.controller);
        controllerBox->setCurrentIndex(ccIndex >= 0 ? ccIndex : controllerBox->findData(74));
        form->addRow(QStringLiteral("Fungsi kontrol"), targetBox);
        form->addRow(QStringLiteral("Kanal MIDI (untuk Custom CC)"), channelBox);
        form->addRow(QStringLiteral("Controller (untuk Custom CC)"), controllerBox);
        layout->addLayout(form);
        auto *note = new QLabel(QStringLiteral("Fungsi bernama mengontrol target internal yang ditentukan. Kanal dan CC manual hanya digunakan untuk Custom MIDI CC."), &dialog);
        note->setWordWrap(true);
        layout->addWidget(note);
        auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
        connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
        connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
        layout->addWidget(buttons);
        if (dialog.exec() != QDialog::Accepted) return;
        current.assigned = true;
        current.target = targetBox->currentData().toInt();
        current.channel = channelBox->currentData().toInt();
        current.controller = current.target == GenericMidiCc
            ? controllerBox->currentData().toInt() : defaultControllerForTarget(current.target);
        saveControllerMaps();
        refreshControllerTooltips();
        stopControlAssignmentModes();
        const QString mapping = current.target == GenericMidiCc
            ? QStringLiteral("Channel %1, %2").arg(current.channel + 1).arg(controllerLabel(current.controller))
            : controlTargetLabel(current.target);
        setStatus(QStringLiteral("%1 → %2.").arg(controlName, mapping));
    }

    void handleAssignableControlPressed(int index, const QString &controlName) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        if (masterAssignMode_) {
            if (index >= static_cast<int>(masterTargets_.size())) {
                setStatus(QStringLiteral("Joystick X/Y tidak menjadi target Master Knob; keduanya punya pemetaan MIDI CC langsung."));
                return;
            }
            masterTargets_[static_cast<std::size_t>(index)] = !masterTargets_[static_cast<std::size_t>(index)];
            saveControllerMaps();
            refreshControllerTooltips();
            setStatus(QStringLiteral("%1 %2 untuk Master Knob.").arg(controlName).arg(masterTargets_[static_cast<std::size_t>(index)] ? QStringLiteral("ditambahkan sebagai target") : QStringLiteral("dihapus dari target")));
            return;
        }
        if ((index < 10 && sliderAssignMode_) || (index >= 10 && index < 14 && knobAssignMode_)) {
            configureControlMapping(index, controlName);
            return;
        }
        if (index >= 0 && index < 14) {
            const int value = index < 10
                ? (assignableSliders_[static_cast<std::size_t>(index)] ? assignableSliders_[static_cast<std::size_t>(index)]->value() : 0)
                : (assignableKnobs_[static_cast<std::size_t>(index - 10)] ? assignableKnobs_[static_cast<std::size_t>(index - 10)]->value() : 0);
            QSettings settings;
            settings.setValue(QStringLiteral("uiControls/value/%1").arg(index), value);
            settings.sync();
        }
    }

    void sendSelectedVoiceController(int controller, int value) {
        const int slot = std::clamp(selectedProgramChannel_, 0, 2);
        sendMidi(static_cast<quint8>(0xB0 | slot), static_cast<quint8>(controller),
                 static_cast<quint8>(std::clamp(value, 0, 127)), internalVoiceChannel(slot));
    }

    void setAssignableMasterVolume(int value) {
        const int bounded = std::clamp(value, 0, 127);
        const int percent = std::clamp((bounded * 100 + 63) / 127, 0, 100);
        if (gainSlider_) {
            const QSignalBlocker blocker(gainSlider_);
            gainSlider_->setValue(percent);
        }
        setMidiOutputVolume(percent);
        QSettings settings;
        settings.setValue(QStringLiteral("panel/outputVolume"), percent);
        settings.sync();
        if (masterControlDial_ && masterControlDial_->value() != bounded) {
            const QSignalBlocker blocker(masterControlDial_);
            masterControlDial_->setValue(bounded);
        }
    }

    void applyControlTarget(int index, int target, int value) {
        const int bounded = std::clamp(value, 0, 127);
        switch (target) {
        case VoiceVolumeAll:
            for (int slot = 0; slot < 3; ++slot)
                sendMidi(static_cast<quint8>(0xB0 | slot), 7, static_cast<quint8>(bounded), internalVoiceChannel(slot));
            return;
        case VoiceAttack: sendSelectedVoiceController(73, bounded); return;
        case VoiceRelease: sendSelectedVoiceController(72, bounded); return;
        case VoiceVibratoRate: sendSelectedVoiceController(76, bounded); return;
        case VoiceVibratoDepth: sendSelectedVoiceController(77, bounded); return;
        case SongVolume:
            songVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/songVolume"), songVolume_); settings.sync(); }
            return;
        case AudioVolume:
            audioFaderVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/audioVolume"), audioFaderVolume_); settings.sync(); }
            setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
            return;
        case PadsVolume:
            padsVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/padsVolume"), padsVolume_); settings.sync(); }
            return;
        case ChordVolume:
            chordVolume_ = bounded;
            { QSettings settings; settings.setValue(QStringLiteral("uiControls/chordVolume"), chordVolume_); settings.sync(); }
            return;
        case VoiceLVolume:
            sendMidi(0xB1, 7, static_cast<quint8>(bounded), internalVoiceChannel(1));
            return;
        case VoiceR1Volume:
            sendMidi(0xB0, 7, static_cast<quint8>(bounded), internalVoiceChannel(0));
            return;
        case VoiceR2Volume:
            sendMidi(0xB2, 7, static_cast<quint8>(bounded), internalVoiceChannel(2));
            return;
        case StyleVolume: {
            // Native style tracks live on MIDI channels 1..16. Send channel volume to the internal
            // accompaniment channels. External output scales style note-on velocity separately so
            // the three dedicated external keyboard-voice channels are not unintentionally changed.
            styleVolume_ = bounded;
            for (int channel = 0; channel < 16; ++channel) {
                if (channel == 9) continue; // Keep the dedicated Drum Volume control independent.
                channelMixerLevels_[static_cast<std::size_t>(channel)] = bounded;
                if (auto *partFader = channelMixerFaders_[static_cast<std::size_t>(channel)]) {
                    const QSignalBlocker blocker(partFader);
                    partFader->setValue(bounded);
                }
                const int partLevel = channelMixerLevels_[static_cast<std::size_t>(channel)];
                const int outputLevel = styleMixerPartMuted(channel) ? 0 : partLevel;
                const int styleOverride = (channel >= 8 && channel <= 15)
                    ? styleMixerSynthChannelOverride(channel - 8, channel) : channel;
                sendInternalMidiOnly(static_cast<quint8>(0xB0 | channel), 7,
                    static_cast<quint8>(std::clamp(outputLevel, 0, 127)), styleOverride);
                QSettings partSettings;
                partSettings.setValue(QStringLiteral("panel/stylePartVolume/%1").arg(channel + 1), partLevel);
            }
            QSettings settings;
            settings.setValue(QStringLiteral("uiControls/styleVolume"), styleVolume_);
            settings.sync();
            return;
        }
        case ReverbSend: sendSelectedVoiceController(91, bounded); return;
        case ChorusSend: sendSelectedVoiceController(93, bounded); return;
        case FilterCutoff: sendSelectedVoiceController(74, bounded); return;
        case FilterResonance: sendSelectedVoiceController(71, bounded); return;
        case VoiceExpression: sendSelectedVoiceController(11, bounded); return;
        case DrumVolume:
            if (styleEngine_.isYamahaStyle()) sendStyleMixerController(1, 7, bounded);
            else sendMidi(0xB9, 7, static_cast<quint8>(bounded), 9);
            return;
        case VoicePan: sendSelectedVoiceController(10, bounded); return;
        case VoiceModulation: sendSelectedVoiceController(1, bounded); return;
        case MasterVolume: setAssignableMasterVolume(bounded); return;
        default: break;
        }
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
        const auto status = static_cast<quint8>(0xB0 | map.channel);
        const auto controller = static_cast<quint8>(map.controller);
        const auto midiData = static_cast<quint8>(bounded);
        // Joystick axes route to the active internal voice while retaining the configured external channel.
        if (index >= 14) sendMidi(status, controller, midiData, internalVoiceChannel(selectedProgramChannel_));
        else sendMidi(status, controller, midiData);
    }

    void handleAssignableControlValue(int index, int value) {
        if (index < 0 || index >= static_cast<int>(controllerMaps_.size())) return;
        // The six faders printed on the LEFT panel are fixed function controls, not generic
        // MIDI assignments: STYLE, SONG, AUDIO, PADS, DRUM/PERC, CHORD.  Keep the Assign
        // modes available, but outside those modes these six labels must always do what they say.
        if (masterAssignMode_ || (index < 10 && sliderAssignMode_) || (index >= 10 && index < 14 && knobAssignMode_)) return;
        if (index >= 0 && index < 6) {
            static constexpr int fixedLeftTargets[6] = {StyleVolume, SongVolume, AudioVolume, PadsVolume, DrumVolume, ChordVolume};
            applyControlTarget(index, fixedLeftTargets[index], value);
            return;
        }
        const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
        if (!map.assigned) return;
        applyControlTarget(index, map.target, value);
    }

    bool styleMixerPartMuted(int channel) const {
        if (channel < 0 || channel >= 16) return false;
        return channelMixerMuted_[static_cast<std::size_t>(channel)] ||
            (styleMixerSoloActive_ && channel >= 8 && channel <= 15 && channel != styleMixerSelectedChannel_);
    }

    void handleMasterControlValue(int value) {
        const int boundedValue = std::clamp(value, 0, 127);
        // The existing left master knob controls application output gain.
        const int percent = std::clamp((boundedValue * 100 + 63) / 127, 0, 100);
        if (gainSlider_) {
            const QSignalBlocker blocker(gainSlider_);
            gainSlider_->setValue(percent);
        }
        if (masterControlDial_ && masterControlDial_->value() != boundedValue) {
            const QSignalBlocker blocker(masterControlDial_);
            masterControlDial_->setValue(boundedValue);
        }
        setMidiOutputVolume(percent);
        QSettings settings;
        settings.setValue(QStringLiteral("panel/outputVolume"), percent);
        settings.sync();
    }

    enum ResizeEdge : int { NoResizeEdge = 0, ResizeLeft = 1, ResizeRight = 2, ResizeTop = 4, ResizeBottom = 8 };

    int hitTestResizeEdge(const QPoint &globalPos) const {
        if (isFullScreen() || isMaximized()) return NoResizeEdge;
        constexpr int margin = 6;
        const QRect r = frameGeometry();
        int edges = NoResizeEdge;
        if (globalPos.x() >= r.left() && globalPos.x() < r.left() + margin) edges |= ResizeLeft;
        else if (globalPos.x() <= r.right() && globalPos.x() > r.right() - margin) edges |= ResizeRight;
        if (globalPos.y() >= r.top() && globalPos.y() < r.top() + margin) edges |= ResizeTop;
        else if (globalPos.y() <= r.bottom() && globalPos.y() > r.bottom() - margin) edges |= ResizeBottom;
        return edges;
    }

    Qt::CursorShape cursorForResizeEdges(int edges) const {
        const bool left = (edges & ResizeLeft) != 0;
        const bool right = (edges & ResizeRight) != 0;
        const bool top = (edges & ResizeTop) != 0;
        const bool bottom = (edges & ResizeBottom) != 0;
        if ((left && top) || (right && bottom)) return Qt::SizeFDiagCursor;
        if ((right && top) || (left && bottom)) return Qt::SizeBDiagCursor;
        if (left || right) return Qt::SizeHorCursor;
        if (top || bottom) return Qt::SizeVerCursor;
        return Qt::ArrowCursor;
    }

    bool eventFilter(QObject *watched, QEvent *event) override {
        Q_UNUSED(watched);
        if (event->type() == QEvent::MouseButtonPress) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton) {
                const int edges = hitTestResizeEdge(mouse->globalPosition().toPoint());
                if (edges != NoResizeEdge) {
                    resizingEdges_ = edges;
                    resizeStartGlobal_ = mouse->globalPosition().toPoint();
                    resizeStartGeometry_ = geometry();
                    mouse->accept();
                    return true;
                }
            }
        } else if (event->type() == QEvent::MouseMove) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            const QPoint globalPos = mouse->globalPosition().toPoint();
            if (resizingEdges_ != NoResizeEdge && (mouse->buttons() & Qt::LeftButton)) {
                const QPoint delta = globalPos - resizeStartGlobal_;
                QRect next = resizeStartGeometry_;
                if (resizingEdges_ & ResizeLeft)
                    next.setLeft(std::min(resizeStartGeometry_.left() + delta.x(), resizeStartGeometry_.right() - minimumWidth() + 1));
                if (resizingEdges_ & ResizeRight)
                    next.setRight(std::max(resizeStartGeometry_.right() + delta.x(), resizeStartGeometry_.left() + minimumWidth() - 1));
                if (resizingEdges_ & ResizeTop)
                    next.setTop(std::min(resizeStartGeometry_.top() + delta.y(), resizeStartGeometry_.bottom() - minimumHeight() + 1));
                if (resizingEdges_ & ResizeBottom)
                    next.setBottom(std::max(resizeStartGeometry_.bottom() + delta.y(), resizeStartGeometry_.top() + minimumHeight() - 1));
                setGeometry(next);
                mouse->accept();
                return true;
            }
            if (resizingEdges_ == NoResizeEdge) {
                const int edges = hitTestResizeEdge(globalPos);
                if (edges != NoResizeEdge) setCursor(cursorForResizeEdges(edges));
                else unsetCursor();
            }
        } else if (event->type() == QEvent::MouseButtonRelease) {
            auto *mouse = static_cast<QMouseEvent *>(event);
            if (mouse->button() == Qt::LeftButton && resizingEdges_ != NoResizeEdge) {
                resizingEdges_ = NoResizeEdge;
                unsetCursor();
                mouse->accept();
                return true;
            }
        }
        return QMainWindow::eventFilter(watched, event);
    }

    void buildUi() {
        startupTrace("buildUi: begin");
        auto *central = new QWidget(this);
        central->setObjectName(QStringLiteral("appSurface"));
        auto *root = new QVBoxLayout(central);
        root->setContentsMargins(4, 4, 4, 4);
        root->setSpacing(3);

        auto makePanel = [](QWidget *parent) {
            auto *frame = new QFrame(parent);
            frame->setObjectName(QStringLiteral("panel"));
            frame->setFrameShape(QFrame::StyledPanel);
            return frame;
        };
        auto makeCaption = [](const QString &text, QWidget *parent = nullptr) {
            auto *label = new QLabel(text, parent);
            label->setObjectName(QStringLiteral("sectionLabel"));
            return label;
        };
        // Utility dialogs keep secondary workflows accessible without cluttering the original home surface.
        auto makeDialog = [&](const QString &title) {
            auto *dialog = new QDialog(this);
            dialog->setWindowTitle(title);
            dialog->setModal(false);
            dialog->setMinimumWidth(390);
            return dialog;
        };
        startupTrace("buildUi: before style dialog");
        styleDialog_ = makeDialog(QStringLiteral("Ensembles — Styles"));
        auto *styleLayout = new QVBoxLayout(styleDialog_);
        styleLayout->addWidget(new QLabel(QStringLiteral("Pilih style Ensembles (.enstl), Roland STL (.STL), atau Yamaha PSR/SX/Genos Style (.STY/.PRS/.SST/.BCS/.FPS/.PST/.PCS/.SCP/.AUS)."), styleDialog_));
        styleCombo_ = new QComboBox(styleDialog_);
        styleCombo_->setMinimumWidth(340);
        styleLayout->addWidget(styleCombo_);
        styleInfo_ = new QLabel(QStringLiteral("Mencari style asli Ensembles…"), styleDialog_);
        styleInfo_->setWordWrap(true);
        styleLayout->addWidget(styleInfo_);
        auto *styleHint = new QLabel(QStringLiteral("Style asli dipertahankan; preset GM Windows bukan pengganti bank SoundFont FluidSynth."), styleDialog_);
        styleHint->setWordWrap(true);
        styleHint->setStyleSheet(QStringLiteral("color:#d6b46c"));
        styleLayout->addWidget(styleHint);
        auto *styleClose = new QPushButton(QStringLiteral("Tutup"), styleDialog_);
        styleLayout->addWidget(styleClose);
        connect(styleClose, &QPushButton::clicked, styleDialog_, &QDialog::hide);

        voiceDialog_ = makeDialog(QStringLiteral("Ensembles — Voice / GM Program"));
        auto *voiceLayout = new QVBoxLayout(voiceDialog_);
        voiceLayout->addWidget(new QLabel(QStringLiteral("Pilih preset General MIDI untuk voice R1 / L / R2. Perubahan dikirim ke kanal FluidSynth internal yang sesuai dan, bila dipilih, ke Windows MIDI Mapper."), voiceDialog_));
        programCombo_ = new QComboBox(voiceDialog_);
        for (const char *name : kPatchNames) programCombo_->addItem(QString::fromUtf8(name));
        voiceLayout->addWidget(programCombo_);
        auto *voiceNote = new QLabel(QStringLiteral("Rute internal mengikuti mapping asli: R1=kanal 17, R2/layer=18, L/split=19. Rute eksternal memakai kanal MIDI standar 1–3."), voiceDialog_);
        voiceNote->setWordWrap(true);
        voiceLayout->addWidget(voiceNote);
        auto *voiceClose = new QPushButton(QStringLiteral("Tutup"), voiceDialog_);
        voiceLayout->addWidget(voiceClose);
        connect(voiceClose, &QPushButton::clicked, voiceDialog_, &QDialog::hide);

        startupTrace("buildUi: before settings dialog and audio controls");
        settingsDialog_ = makeDialog(QStringLiteral("Ensembles — Settings"));
        settingsDialog_->setMinimumSize(820, 650);
        settingsDialog_->resize(900, 720);
        settingsDialog_->setSizeGripEnabled(true);
        settingsDialog_->setStyleSheet(QStringLiteral(R"STYLE(
            QDialog { background: #1b2526; color: #e8f0ef; }
            QLabel { color: #d0dcda; }
            QLabel#settingsHeading { color: #f0f6f4; font-size: 17pt; font-weight: 700; }
            QLabel#settingsSubheading { color: #9eafac; font-size: 9pt; }
            QTabWidget::pane { border: 1px solid #39494a; background: #202c2e; top: -1px; }
            QTabBar::tab { background: #2a393b; color: #c0cecb; border: 1px solid #39494a;
                           padding: 9px 18px; min-width: 82px; margin-right: 3px; }
            QTabBar::tab:selected { background: #2e514e; color: #ffffff; border-bottom: 2px solid #48b1a5; }
            QTabBar::tab:hover:!selected { background: #344648; }
            QGroupBox { color: #e8f0ef; font-size: 9pt; font-weight: 700;
                        border: 1px solid #3b4b4c; border-radius: 6px; margin-top: 12px; padding: 12px 10px 10px 10px; }
            QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; color: #83c9c0; }
            QComboBox, QSpinBox { min-height: 27px; padding: 2px 7px; background: #2a393b; color: #eef3f7;
                                  border: 1px solid #465c5d; border-radius: 4px; }
            QComboBox:hover, QSpinBox:hover { border-color: #69bdb3; }
            QPushButton { min-height: 29px; padding: 3px 12px; background: #33484a; color: #f0f4f7;
                          border: 1px solid #526568; border-radius: 4px; }
            QPushButton:hover { background: #3e5c5b; border-color: #6eaaa6; }
            QPushButton:pressed { background: #253638; }
            QCheckBox { spacing: 8px; padding: 3px 2px; }
            QSlider::groove:horizontal { height: 6px; background: #111819; border: 1px solid #39494a; border-radius: 3px; }
            QSlider::handle:horizontal { width: 15px; margin: -5px 0; background: #72b8b0; border: 1px solid #b5e4de; border-radius: 7px; }
            QListWidget { background: #192426; alternate-background-color: #263537; color: #e3eaf0;
                          border: 1px solid #3b4d4e; border-radius: 4px; padding: 4px; }
            QScrollArea { border: 0; background: transparent; }
            QStatusBar, QFrame#settingsDivider { color: #9eafac; }
        )STYLE"));

        auto *settingsRoot = new QVBoxLayout(settingsDialog_);
        settingsRoot->setContentsMargins(18, 16, 18, 14);
        settingsRoot->setSpacing(12);
        auto *settingsHeading = new QLabel(QStringLiteral("Settings"), settingsDialog_);
        settingsHeading->setObjectName(QStringLiteral("settingsHeading"));
        auto *settingsSubheading = new QLabel(QStringLiteral("Configure audio devices, MIDI input, performance and sound engines."), settingsDialog_);
        settingsSubheading->setObjectName(QStringLiteral("settingsSubheading"));
        settingsRoot->addWidget(settingsHeading);
        settingsRoot->addWidget(settingsSubheading);

        auto *settingsTabs = new QTabWidget(settingsDialog_);
        settingsTabs->setDocumentMode(true);
        settingsTabs->setMovable(false);
        settingsRoot->addWidget(settingsTabs, 1);

        auto makeSettingsTab = [&](const QString &title, QVBoxLayout **pageLayoutOut) {
            auto *scroll = new QScrollArea(settingsTabs);
            scroll->setWidgetResizable(true);
            scroll->setFrameShape(QFrame::NoFrame);
            auto *page = new QWidget(scroll);
            auto *pageLayout = new QVBoxLayout(page);
            pageLayout->setContentsMargins(14, 12, 14, 14);
            pageLayout->setSpacing(12);
            pageLayout->addStretch(1);
            scroll->setWidget(page);
            settingsTabs->addTab(scroll, title);
            if (pageLayoutOut) *pageLayoutOut = pageLayout;
            return pageLayout;
        };
        auto addSettingsSection = [](QVBoxLayout *layout, QGroupBox *section) {
            if (!layout || !section) return;
            const int stretchIndex = layout->count() - 1;
            layout->insertWidget(std::max(0, stretchIndex), section);
        };
        auto *settingsFoot = new QWidget(settingsDialog_);
        auto *settingsFootLayout = new QHBoxLayout(settingsFoot);
        settingsFootLayout->setContentsMargins(0, 0, 0, 0);
        auto *settingsSavedLabel = new QLabel(QStringLiteral("Settings are saved automatically."), settingsFoot);
        settingsSavedLabel->setStyleSheet(QStringLiteral("color:#98aaa7;font-size:8pt;"));
        settingsFootLayout->addWidget(settingsSavedLabel);
        settingsFootLayout->addStretch(1);
        auto *settingsClose = new QPushButton(QStringLiteral("Close"), settingsFoot);
        settingsClose->setMinimumWidth(100);
        settingsFootLayout->addWidget(settingsClose);
        settingsRoot->addWidget(settingsFoot);
        connect(settingsClose, &QPushButton::clicked, settingsDialog_, &QDialog::hide);

        // AUDIO TAB — output engine and RtAudio device configuration.
        QVBoxLayout *audioTabLayout = nullptr;
        makeSettingsTab(QStringLiteral("Audio"), &audioTabLayout);
        auto *engineGroup = new QGroupBox(QStringLiteral("Style sound engine / output routing"), settingsDialog_);
        auto *engineLayout = new QVBoxLayout(engineGroup);
        audioRoutingCombo_ = new QComboBox(engineGroup);
        audioRoutingCombo_->addItem(QStringLiteral("Automatic by style — selected physical MIDI OUT also receives MIDI"), QStringLiteral("auto"));
        audioRoutingCombo_->addItem(QStringLiteral("Internal FluidSynth + RtAudio only"), QStringLiteral("fluid"));
        audioRoutingCombo_->addItem(QStringLiteral("Native LS-GM bundled fallback + RtAudio"), QStringLiteral("lsgm"));
        audioRoutingCombo_->addItem(QStringLiteral("Windows MIDI OUT only (selected device)"), QStringLiteral("winmm"));
        audioRoutingCombo_->addItem(QStringLiteral("Both: internal audio + Windows MIDI"), QStringLiteral("both"));
        engineLayout->addWidget(audioRoutingCombo_);
        auto *midiOutRow = new QWidget(engineGroup);
        auto *midiOutRowLayout = new QHBoxLayout(midiOutRow);
        midiOutRowLayout->setContentsMargins(0, 0, 0, 0);
        midiOutputDeviceCombo_ = new QComboBox(midiOutRow);
        midiOutputDeviceCombo_->setObjectName(QStringLiteral("midiOutputDeviceCombo"));
        midiOutputDeviceCombo_->addItem(QStringLiteral("MIDI OUT: Windows MIDI Mapper"), -1);
#ifdef _WIN32
        for (UINT device = 0; device < midiOutGetNumDevs(); ++device) {
            MIDIOUTCAPSW caps{};
            if (midiOutGetDevCapsW(static_cast<UINT_PTR>(device), &caps, sizeof(caps)) == MMSYSERR_NOERROR)
                midiOutputDeviceCombo_->addItem(QStringLiteral("MIDI OUT: %1").arg(QString::fromWCharArray(caps.szPname)), static_cast<int>(device));
        }
#else
        midiOutputDeviceCombo_->setEnabled(false);
        midiOutputDeviceCombo_->setToolTip(QStringLiteral("Windows MIDI OUT tersedia pada Windows."));
#endif
        midiOutTestButton_ = new QPushButton(QStringLiteral("Test MIDI OUT"), midiOutRow);
        midiOutTestButton_->setEnabled(false);
        midiOutTestButton_->setToolTip(QStringLiteral("Kirim satu nada C4 singkat ke perangkat MIDI OUT yang dipilih."));
        midiOutRowLayout->addWidget(midiOutputDeviceCombo_, 1);
        midiOutRowLayout->addWidget(midiOutTestButton_);
        engineLayout->addWidget(midiOutRow);
        connect(midiOutputDeviceCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
#ifdef _WIN32
            if (midiOut_) {
                std::lock_guard<std::mutex> lock(midiOutMutex_);
                midiOutReset(midiOut_);
                midiOutClose(midiOut_);
                midiOut_ = nullptr;
                midiOutputReady_ = false;
            }
            if (midiOutTestButton_) midiOutTestButton_->setEnabled(false);
            if (audioSettingsReady_) openMidiOutput();
#endif
        });
        connect(midiOutTestButton_, &QPushButton::clicked, this, [this] { testMidiOutput(); });
        auto *engineHint = new QLabel(QStringLiteral("When a Yamaha Style-family file or Roland .STL is loaded, its dedicated native sound engine is selected automatically."), engineGroup);
        engineHint->setWordWrap(true);
        engineHint->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;"));
        engineLayout->addWidget(engineHint);
        addSettingsSection(audioTabLayout, engineGroup);

        auto *deviceGroup = new QGroupBox(QStringLiteral("Audio device"), settingsDialog_);
        auto *audioForm = new QFormLayout(deviceGroup);
        audioForm->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        audioForm->setFormAlignment(Qt::AlignTop);
        audioForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        audioApiCombo_ = new QComboBox(deviceGroup);
        audioApiCombo_->addItem(QStringLiteral("Automatic (RtAudio default API)"), static_cast<int>(RtAudio::UNSPECIFIED));
        for (const RtAudio::Api api : ensembles::AudioEngine::availableApis()) {
            if (api == RtAudio::UNSPECIFIED || api == RtAudio::RTAUDIO_DUMMY) continue;
            const std::string display = RtAudio::getApiDisplayName(api);
            const QString label = display.empty()
                ? QString::fromUtf8(RtAudio::getApiName(api).c_str())
                : QString::fromUtf8(display.c_str());
            audioApiCombo_->addItem(label, static_cast<int>(api));
        }
        audioDeviceCombo_ = new QComboBox(deviceGroup);
        auto *audioDeviceRow = new QWidget(deviceGroup);
        auto *audioDeviceRowLayout = new QHBoxLayout(audioDeviceRow);
        audioDeviceRowLayout->setContentsMargins(0, 0, 0, 0);
        audioDeviceRowLayout->setSpacing(6);
        refreshAudioDevicesButton_ = new QPushButton(QStringLiteral("Refresh"), audioDeviceRow);
        testAudioButton_ = new QPushButton(QStringLiteral("Test output (440 Hz)"), audioDeviceRow);
        audioDeviceRowLayout->addWidget(audioDeviceCombo_, 1);
        audioDeviceRowLayout->addWidget(refreshAudioDevicesButton_);
        audioDeviceRowLayout->addWidget(testAudioButton_);
        audioSampleRateCombo_ = new QComboBox(deviceGroup);
        audioBufferCombo_ = new QComboBox(deviceGroup);
        for (const int frames : {64, 128, 256, 512, 1024, 2048})
            audioBufferCombo_->addItem(QStringLiteral("%1 frames").arg(frames), frames);
        audioForm->addRow(QStringLiteral("Host API"), audioApiCombo_);
        audioForm->addRow(QStringLiteral("Output device"), audioDeviceRow);
        audioForm->addRow(QStringLiteral("Sample rate"), audioSampleRateCombo_);
        audioForm->addRow(QStringLiteral("Buffer / latency"), audioBufferCombo_);
        addSettingsSection(audioTabLayout, deviceGroup);
        auto *audioStatusGroup = new QGroupBox(QStringLiteral("Audio status"), settingsDialog_);
        auto *audioStatusLayout = new QVBoxLayout(audioStatusGroup);
        audioOutputStatusLabel_ = new QLabel(QStringLiteral("RtAudio not initialized"), audioStatusGroup);
        audioOutputStatusLabel_->setWordWrap(true);
        audioStatusLayout->addWidget(audioOutputStatusLabel_);
        addSettingsSection(audioTabLayout, audioStatusGroup);
        auto *audioHint = new QLabel(QStringLiteral("Lower buffer sizes reduce latency but may cause dropouts. Higher values are more stable but add latency. Device changes reopen the audio stream."), settingsDialog_);
        audioHint->setWordWrap(true);
        audioHint->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;padding:2px 4px;"));
        audioTabLayout->insertWidget(std::max(0, audioTabLayout->count() - 1), audioHint);

        // MIDI TAB — external controller input and channel handling.
        QVBoxLayout *midiTabLayout = nullptr;
        makeSettingsTab(QStringLiteral("MIDI"), &midiTabLayout);
        auto *midiInputGroup = new QGroupBox(QStringLiteral("MIDI input devices"), settingsDialog_);
        auto *midiInputLayout = new QVBoxLayout(midiInputGroup);
        auto *midiInputRow = new QWidget(midiInputGroup);
        auto *midiInputRowLayout = new QHBoxLayout(midiInputRow);
        midiInputRowLayout->setContentsMargins(0, 0, 0, 0);
        midiInputRowLayout->setSpacing(8);
        midiInputDeviceList_ = new QListWidget(midiInputRow);
        midiInputDeviceList_->setMinimumHeight(150);
        midiInputDeviceList_->setMaximumHeight(230);
        midiInputDeviceList_->setToolTip(QStringLiteral("Enable one or more MIDI input devices. Incoming notes are routed to the internal sound engine."));
        refreshMidiInputDevicesButton_ = new QPushButton(QStringLiteral("Refresh devices"), midiInputRow);
        midiInputRowLayout->addWidget(midiInputDeviceList_, 1);
        midiInputRowLayout->addWidget(refreshMidiInputDevicesButton_);
        midiInputLayout->addWidget(midiInputRow);
        midiInputStatusLabel_ = new QLabel(QStringLiteral("MIDI input devices have not been scanned."), midiInputGroup);
        midiInputStatusLabel_->setWordWrap(true);
        midiInputLayout->addWidget(midiInputStatusLabel_);
        addSettingsSection(midiTabLayout, midiInputGroup);
        auto *midiRoutingGroup = new QGroupBox(QStringLiteral("Input channel routing"), settingsDialog_);
        auto *midiRoutingLayout = new QVBoxLayout(midiRoutingGroup);
        midiSplitByChannelCheck_ = new QCheckBox(QStringLiteral("Split by channel (follow original MIDI routing)"), midiRoutingGroup);
        {
            QSettings midiSettings;
            midiSplitByChannelCheck_->setChecked(midiSettings.value(QStringLiteral("midi/splitByChannel"), false).toBool());
        }
        midiSplitByChannelCheck_->setToolTip(QStringLiteral("When enabled, MIDI input channels 1/2/3 follow the original R1/R2/L internal slot mapping."));
        midiRoutingLayout->addWidget(midiSplitByChannelCheck_);
        addSettingsSection(midiTabLayout, midiRoutingGroup);
        auto *midiHint = new QLabel(QStringLiteral("Check the devices you want to receive MIDI from. Multiple input devices may be enabled at the same time."), settingsDialog_);
        midiHint->setWordWrap(true);
        midiHint->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;padding:2px 4px;"));
        midiTabLayout->insertWidget(std::max(0, midiTabLayout->count() - 1), midiHint);

        // PERFORMANCE TAB — tempo, master level and timing helpers.
        QVBoxLayout *performanceTabLayout = nullptr;
        makeSettingsTab(QStringLiteral("Performance"), &performanceTabLayout);
        auto *tempoGroup = new QGroupBox(QStringLiteral("Tempo"), settingsDialog_);
        auto *tempoForm = new QFormLayout(tempoGroup);
        auto *tempoRow = new QWidget(tempoGroup);
        auto *tempoRowLayout = new QHBoxLayout(tempoRow);
        tempoRowLayout->setContentsMargins(0, 0, 0, 0);
        tempoSlider_ = new QSlider(Qt::Horizontal, tempoRow);
        tempoSlider_->setRange(40, 240);
        tempoSlider_->setValue(120);
        tempoDialogValue_ = new QLabel(QStringLiteral("120"), tempoRow);
        tempoDialogValue_->setMinimumWidth(72);
        tempoDialogValue_->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        tempoRowLayout->addWidget(tempoSlider_, 1);
        tempoRowLayout->addWidget(tempoDialogValue_);
        tempoForm->addRow(QStringLiteral("Master tempo"), tempoRow);
        addSettingsSection(performanceTabLayout, tempoGroup);
        auto *levelGroup = new QGroupBox(QStringLiteral("Master level"), settingsDialog_);
        auto *levelLayout = new QVBoxLayout(levelGroup);
        gainSlider_ = new QSlider(Qt::Horizontal, levelGroup);
        gainSlider_->setRange(0, 100);
        gainSlider_->setValue(75);
        levelLayout->addWidget(gainSlider_);
        auto *levelScale = new QHBoxLayout;
        auto *levelMin = new QLabel(QStringLiteral("0%"), levelGroup);
        auto *levelMax = new QLabel(QStringLiteral("100%"), levelGroup);
        levelScale->addWidget(levelMin);
        levelScale->addStretch(1);
        levelScale->addWidget(levelMax);
        levelLayout->addLayout(levelScale);
        addSettingsSection(performanceTabLayout, levelGroup);
        auto *timingGroup = new QGroupBox(QStringLiteral("Timing tools"), settingsDialog_);
        auto *timingLayout = new QVBoxLayout(timingGroup);
        metronomeCheck_ = new QCheckBox(QStringLiteral("Enable metronome (4/4)"), timingGroup);
        lfoCheck_ = new QCheckBox(QStringLiteral("Send LFO to MIDI CC1 (modulation)"), timingGroup);
        timingLayout->addWidget(metronomeCheck_);
        timingLayout->addWidget(lfoCheck_);
        addSettingsSection(performanceTabLayout, timingGroup);

        // PLUGINS TAB — SoundFont and optional VST2 instrument.
        QVBoxLayout *pluginsTabLayout = nullptr;
        makeSettingsTab(QStringLiteral("Instruments"), &pluginsTabLayout);
        auto *soundFontGroup = new QGroupBox(QStringLiteral("SoundFont SF2 — External / Native"), settingsDialog_);
        auto *soundFontLayout = new QVBoxLayout(soundFontGroup);
        auto *soundFontRow = new QHBoxLayout;
        chooseSoundFontButton_ = new QPushButton(QStringLiteral("Choose SoundFont (.sf2)…"), soundFontGroup);
        soundFontStatusLabel_ = new QLabel(QStringLiteral("Checking SoundFont…"), soundFontGroup);
        soundFontStatusLabel_->setWordWrap(true);
        soundFontStatusLabel_->setMinimumWidth(170);
        soundFontRow->addWidget(chooseSoundFontButton_);
        soundFontRow->addWidget(soundFontStatusLabel_, 1);
        soundFontLayout->addLayout(soundFontRow);
        auto *soundFontHint = new QLabel(QStringLiteral("Choose an external .sf2 file here. It is remembered across launches and rendered by FluidSynth (including its SF2 modulators, filters, envelopes, reverb, and chorus). MSB/LSB/PC are read from the loaded bank. Yamaha Style playback also uses this selected FluidSynth bank. The separate Native LS-GM sampler remains the fallback when no external bank is selected."), soundFontGroup);
        soundFontHint->setWordWrap(true);
        soundFontHint->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;"));
        soundFontLayout->addWidget(soundFontHint);

        auto *sf2PatchGroup = new QGroupBox(QStringLiteral("SF2 Bank Select / Program Change"), soundFontGroup);
        auto *sf2PatchLayout = new QVBoxLayout(sf2PatchGroup);
        auto *sf2PresetRow = new QHBoxLayout;
        sf2PartCombo_ = new QComboBox(sf2PatchGroup);
        sf2PartCombo_->addItems({QStringLiteral("R1"), QStringLiteral("L"), QStringLiteral("R2")});
        sf2PresetCombo_ = new QComboBox(sf2PatchGroup);
        sf2PresetCombo_->setMinimumWidth(280);
        sf2PresetRow->addWidget(new QLabel(QStringLiteral("Part"), sf2PatchGroup));
        sf2PresetRow->addWidget(sf2PartCombo_);
        sf2PresetRow->addWidget(new QLabel(QStringLiteral("Preset"), sf2PatchGroup));
        sf2PresetRow->addWidget(sf2PresetCombo_, 1);
        sf2PatchLayout->addLayout(sf2PresetRow);

        auto *sf2BankRow = new QHBoxLayout;
        sf2BankMsbSpin_ = new QSpinBox(sf2PatchGroup);
        sf2BankMsbSpin_->setRange(0, 127);
        sf2BankMsbSpin_->setPrefix(QStringLiteral("MSB "));
        sf2BankLsbSpin_ = new QSpinBox(sf2PatchGroup);
        sf2BankLsbSpin_->setRange(0, 127);
        sf2BankLsbSpin_->setPrefix(QStringLiteral("LSB "));
        sf2ProgramSpin_ = new QSpinBox(sf2PatchGroup);
        sf2ProgramSpin_->setRange(1, 128);
        sf2ProgramSpin_->setPrefix(QStringLiteral("PC "));
        sf2ProgramSpin_->setToolTip(QStringLiteral("Tampilan PC 1–128; byte Program Change MIDI yang dikirim adalah 0–127."));
        sf2ApplyPresetButton_ = new QPushButton(QStringLiteral("Apply Bank + PC"), sf2PatchGroup);
        sf2BankRow->addWidget(sf2BankMsbSpin_);
        sf2BankRow->addWidget(sf2BankLsbSpin_);
        sf2BankRow->addWidget(sf2ProgramSpin_);
        sf2BankRow->addWidget(sf2ApplyPresetButton_);
        sf2PatchLayout->addLayout(sf2BankRow);
        sf2PresetStatusLabel_ = new QLabel(QStringLiteral("Load SF2 untuk melihat daftar bank dan preset."), sf2PatchGroup);
        sf2PresetStatusLabel_->setWordWrap(true);
        sf2PresetStatusLabel_->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;"));
        sf2PatchLayout->addWidget(sf2PresetStatusLabel_);
        soundFontLayout->addWidget(sf2PatchGroup);
        addSettingsSection(pluginsTabLayout, soundFontGroup);
        auto *vst2Group = new QGroupBox(QStringLiteral("VST2 instrument plugin"), settingsDialog_);
        auto *vst2Layout = new QVBoxLayout(vst2Group);
        auto *vst2Row = new QHBoxLayout;
        chooseVst2PluginButton_ = new QPushButton(QStringLiteral("Browse VST2 (.dll)…"), vst2Group);
        disableVst2PluginButton_ = new QPushButton(QStringLiteral("Use FluidSynth"), vst2Group);
        vst2Row->addWidget(chooseVst2PluginButton_);
        vst2Row->addWidget(disableVst2PluginButton_);
        vst2Layout->addLayout(vst2Row);
        vst2PluginStatusLabel_ = new QLabel(QStringLiteral("External instrument: inactive"), vst2Group);
        vst2PluginStatusLabel_->setWordWrap(true);
        vst2Layout->addWidget(vst2PluginStatusLabel_);
        addSettingsSection(pluginsTabLayout, vst2Group);

        // EFFECTS TAB — shared FX and Native SCVA insert effect controls.
        QVBoxLayout *effectsTabLayout = nullptr;
        makeSettingsTab(QStringLiteral("Effects"), &effectsTabLayout);
        auto *masterFxGroup = new QGroupBox(QStringLiteral("Master effects"), settingsDialog_);
        auto *masterFxLayout = new QVBoxLayout(masterFxGroup);
        reverbCheck_ = new QCheckBox(QStringLiteral("Reverb (SF2 DSP / Yamaha XG CC91)"), masterFxGroup);
        chorusCheck_ = new QCheckBox(QStringLiteral("Chorus (SF2 DSP / Yamaha XG CC93)"), masterFxGroup);
        delayCheck_ = new QCheckBox(QStringLiteral("Style Delay (SF2 DSP / Yamaha XG Variation CC94)"), masterFxGroup);
        delayLevelSpin_ = new QSpinBox(masterFxGroup);
        delayLevelSpin_->setRange(0, 10);
        delayLevelSpin_->setValue(5);
        delayLevelSpin_->setToolTip(QStringLiteral("Master return level for the Delay component of Yamaha XG Variation effects."));
        auto *delayReturnRow = new QHBoxLayout;
        delayReturnRow->addWidget(new QLabel(QStringLiteral("Delay return"), masterFxGroup));
        delayReturnRow->addWidget(delayLevelSpin_);
        delayReturnRow->addStretch(1);
        masterFxLayout->addWidget(reverbCheck_);
        masterFxLayout->addWidget(chorusCheck_);
        masterFxLayout->addWidget(delayCheck_);
        masterFxLayout->addLayout(delayReturnRow);
        addSettingsSection(effectsTabLayout, masterFxGroup);

        auto *nativeEfxGroup = new QGroupBox(QStringLiteral("Native SCVA · EFX insert effect"), settingsDialog_);
        auto *nativeEfxLayout = new QVBoxLayout(nativeEfxGroup);
        nativeEfxCheck_ = new QCheckBox(QStringLiteral("Enable EFX and route parts to EFX"), nativeEfxGroup);
        nativeEfxTypeCombo_ = new QComboBox(nativeEfxGroup);
        for (const auto &choice : kNativeEfxChoices)
            nativeEfxTypeCombo_->addItem(QString::fromUtf8(choice.name), choice.key);
        nativeEfxCheck_->setChecked(true);
        nativeEfxTypeCombo_->setCurrentIndex(5); // SCVA Overdrive, a verified native EFX key 0x0110.
        nativeEfxLayout->addWidget(nativeEfxCheck_);
        auto *nativeEfxForm = new QFormLayout;
        nativeEfxForm->addRow(QStringLiteral("Algorithm / type"), nativeEfxTypeCombo_);
        nativeEfxLayout->addLayout(nativeEfxForm);
        auto *efxParamGrid = new QGridLayout;
        efxParamGrid->setContentsMargins(0, 5, 0, 2);
        efxParamGrid->setHorizontalSpacing(12);
        efxParamGrid->setVerticalSpacing(7);
        for (int i = 0; i < 20; ++i) {
            auto *cell = new QWidget(nativeEfxGroup);
            auto *cellLayout = new QHBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(5);
            auto *label = new QLabel(QStringLiteral("P%1").arg(i + 1), cell);
            label->setMinimumWidth(24);
            label->setToolTip(QStringLiteral("GS EFX Parameter %1; meaning depends on selected effect algorithm").arg(i + 1));
            auto *spin = new QSpinBox(cell);
            spin->setRange(-1, 127);
            spin->setValue(-1);
            spin->setSpecialValueText(QStringLiteral("ROM"));
            spin->setToolTip(QStringLiteral("ROM = use selected SCVA effect's native default; 0–127 overrides parameter %1").arg(i + 1));
            spin->setFixedWidth(82);
            nativeEfxParams_[static_cast<std::size_t>(i)] = spin;
            cellLayout->addWidget(label);
            cellLayout->addWidget(spin, 1);
            efxParamGrid->addWidget(cell, i / 4, i % 4);
            connect(spin, qOverload<int>(&QSpinBox::valueChanged), this, [this, i](int value) {
                if (value >= 0) sendGsDt1(0x40, 0x03, static_cast<std::uint8_t>(0x03 + i), static_cast<std::uint8_t>(value));
            });
        }
        nativeEfxLayout->addLayout(efxParamGrid);
        auto *efxNote = new QLabel(QStringLiteral("EFX is available only when the Native SCVA sound engine is active. ROM restores the selected effect's native parameter value. Parameter meanings depend on the selected algorithm."), nativeEfxGroup);
        efxNote->setWordWrap(true);
        efxNote->setStyleSheet(QStringLiteral("color:#9eb1ad;font-size:8pt;"));
        nativeEfxLayout->addWidget(efxNote);
        addSettingsSection(effectsTabLayout, nativeEfxGroup);

        connect(nativeEfxCheck_, &QCheckBox::toggled, this, [this] { applyNativeEfxSettings(); });
        connect(nativeEfxTypeCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { applyNativeEfxSettings(true); });
        connect(refreshMidiInputDevicesButton_, &QPushButton::clicked, this, [this] { refreshMidiInputDevices(); });
        connect(midiInputDeviceList_, &QListWidget::itemChanged, this, [this](QListWidgetItem *item) {
#ifdef _WIN32
            if (!item) return;
            bool idOk = false;
            const UINT id = item->data(Qt::UserRole).toUInt(&idOk);
            if (!idOk) return;
            const bool shouldConnect = item->checkState() == Qt::Checked;
            if (shouldConnect) {
                if (!connectMidiInputDevice(id)) {
                    const QSignalBlocker blocker(midiInputDeviceList_);
                    item->setCheckState(Qt::Unchecked);
                }
            } else {
                disconnectMidiInputDevice(id);
            }
            updateMidiInputStatus();
#else
            Q_UNUSED(item);
#endif
        });
        connect(midiSplitByChannelCheck_, &QCheckBox::toggled, this, [this](bool checked) {
            QSettings settings;
            settings.setValue(QStringLiteral("midi/splitByChannel"), checked);
            settings.sync();
            setStatus(checked
                ? QStringLiteral("Split By Channel MIDI aktif; input eksternal mengikuti pemetaan kanal asli jika perangkat tersambung.")
                : QStringLiteral("Split By Channel MIDI nonaktif; input eksternal mengikuti routing keyboard utama."));
        });
        connect(chooseSoundFontButton_, &QPushButton::clicked, this, [this] { chooseSoundFont(); });
        connect(sf2PartCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this,
                [this](int slot) { updateSf2PresetControlsForSlot(slot); });
        connect(sf2PresetCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this,
                [this](int index) { selectSf2PresetEntry(index); });
        auto syncSf2Controls = [this](int) { syncSf2PresetComboToFields(); };
        connect(sf2BankMsbSpin_, qOverload<int>(&QSpinBox::valueChanged), this, syncSf2Controls);
        connect(sf2BankLsbSpin_, qOverload<int>(&QSpinBox::valueChanged), this, syncSf2Controls);
        connect(sf2ProgramSpin_, qOverload<int>(&QSpinBox::valueChanged), this, syncSf2Controls);
        connect(sf2ApplyPresetButton_, &QPushButton::clicked, this, [this] { applySf2PresetSelection(true); });
        connect(chooseVst2PluginButton_, &QPushButton::clicked, this, [this] { chooseVst2Plugin(); });
        connect(disableVst2PluginButton_, &QPushButton::clicked, this, [this] { disableVst2Plugin(); });
        connect(audioRoutingCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            const QString route = audioRoutingCombo_->currentData().toString();
            const QString requiredRoute = isYamahaStyleExtension(activeStyleExtension_)
                ? (selectedExternalSoundFont().isEmpty() ? QStringLiteral("lsgm") : QStringLiteral("fluid"))
                : (activeStyleExtension_ == QStringLiteral("stl") ? QStringLiteral("auto") : QString());
            const bool physicalMidiDeviceSelected = midiOutputDeviceCombo_ &&
                midiOutputDeviceCombo_->currentData().toInt() >= 0;
            const bool explicitExternalRoute = route == QStringLiteral("winmm") ||
                route == QStringLiteral("both") ||
                (route == QStringLiteral("auto") && physicalMidiDeviceSelected);
            if (!requiredRoute.isEmpty() && route != requiredRoute && !explicitExternalRoute) {
                const QSignalBlocker blocker(audioRoutingCombo_);
                const int requiredIndex = audioRoutingCombo_->findData(requiredRoute);
                if (requiredIndex >= 0) audioRoutingCombo_->setCurrentIndex(requiredIndex);
                QSettings settings;
                settings.setValue(QStringLiteral("audio/outputRouting"), requiredRoute);
                settings.sync();
                setStatus(isYamahaStyleExtension(activeStyleExtension_)
                    ? (requiredRoute == QStringLiteral("fluid")
                        ? QStringLiteral("Yamaha Style menggunakan FluidSynth karena bank SF2 eksternal dipilih.")
                        : QStringLiteral("Yamaha Style menggunakan Native LS-GM bawaan; SF2 eksternal dipakai melalui FluidSynth pada rute FluidSynth."))
                    : QStringLiteral("Roland .STL selalu menggunakan SCVA Native C++; rute LS-GM tidak dipakai untuk style ini."));
                return;
            }
            QSettings settings; settings.setValue(QStringLiteral("audio/outputRouting"), route); settings.sync();
            synchronizeOutputRoutes();
            applyPanelMidiSettings();
            if (!audioSettingsReady_) return;
            if (route == QStringLiteral("lsgm")) {
                const QString bank = discoverLsGmSoundFont();
                QString error;
                if (bank.isEmpty() || !loadSoundFont(bank, false, &error)) {
                    const QString detail = bank.isEmpty()
                        ? QStringLiteral("Native LS-GM tidak ditemukan. Pilih FluidSynth untuk menggunakan SF2 eksternal.") : error;
                    setStatus(QStringLiteral("Native LS-GM gagal diaktifkan: %1").arg(detail));
                    QMessageBox::warning(this, QStringLiteral("Native LS-GM"), detail);
                }
            } else if (route == QStringLiteral("fluid") && audioEngine_ && audioEngine_->isReady() &&
                       !audioEngine_->isFluidSynthSoundFontActive()) {
                const QString bank = selectedExternalSoundFont().isEmpty()
                    ? (isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont())
                    : selectedExternalSoundFont();
                std::string fluidError;
                const QByteArray bankPath = QDir::toNativeSeparators(bank).toUtf8();
                const bool loaded = !bank.isEmpty() && audioEngine_->loadFluidSynthSoundFont(bankPath.constData(), &fluidError);
                if (!loaded) {
                    const QString detail = bank.isEmpty()
                        ? QStringLiteral("SoundFont SF2 tidak ditemukan.")
                        : QString::fromUtf8(fluidError.data(), static_cast<qsizetype>(fluidError.size()));
                    setStatus(QStringLiteral("Peralihan ke FluidSynth gagal: %1").arg(detail));
                    QMessageBox::warning(this, QStringLiteral("Audio route"), detail);
                } else {
                    soundFontPath_ = bank;
                    setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                    applyPanelMidiSettings();
                    refreshSf2PresetBrowser();
                    applyAllVoicePrograms();
                    updateAudioOutputStatus();
                    updateOutputStatus();
                }
            }
            if (route == QStringLiteral("both") && styleEngine_.hasStyle() &&
                (isYamahaStyleExtension(activeStyleExtension_) || activeStyleExtension_ == QStringLiteral("stl")) &&
                styleCombo_ && !styleCombo_->currentData().toString().isEmpty()) {
                QString rendererError;
                if (!activateNativeRendererForStyle(styleCombo_->currentData().toString(), &rendererError))
                    setStatus(QStringLiteral("Rute MIDI OUT + internal gagal menyiapkan renderer style: %1").arg(rendererError));
            }
        });
        connect(audioApiCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (!audioSettingsReady_) return;
            refreshAudioOutputDevices(-1);
            refreshAudioSampleRates(44100);
            applyAudioOutputSettings();
        });
        connect(audioDeviceCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (!audioSettingsReady_) return;
            refreshAudioSampleRates(audioSampleRateCombo_ ? audioSampleRateCombo_->currentData().toUInt() : 44100u);
            applyAudioOutputSettings();
        });
        connect(audioSampleRateCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (audioSettingsReady_) applyAudioOutputSettings();
        });
        connect(audioBufferCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) {
            if (audioSettingsReady_) applyAudioOutputSettings();
        });
        connect(refreshAudioDevicesButton_, &QPushButton::clicked, this, [this] {
            const auto preferred = selectedRtAudioDeviceId();
            refreshAudioOutputDevices(preferred ? static_cast<qint64>(*preferred) : -1);
            refreshAudioSampleRates(audioSampleRateCombo_ ? audioSampleRateCombo_->currentData().toUInt() : 44100u);
            applyAudioOutputSettings();
            setStatus(QStringLiteral("Daftar output RtAudio diperbarui."));
        });
        connect(testAudioButton_, &QPushButton::clicked, this, [this] {
            if (!audioEngine_ || !audioEngine_->isReady()) {
                const QString detail = QStringLiteral("RtAudio belum aktif. Pilih output device dan pastikan stream sudah terbuka.");
                setStatus(detail);
                if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(detail);
                return;
            }
            std::string error;
            // This oscillator is mixed directly by the RtAudio callback after
            // all renderer branches. It bypasses LS-GM, SCVA, FluidSynth and MIDI.
            if (!audioEngine_->playTestTone(440.0, 0.18f, 1200, &error)) {
                const QString detail = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
                setStatus(QStringLiteral("Direct RtAudio test gagal: %1").arg(detail));
                if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(detail);
                return;
            }
            setStatus(QStringLiteral("Direct RtAudio test 440 Hz berjalan 1,2 detik; sinyal melewati LS-GM/SCVA dan MIDI."));
        });

        recorderDialog_ = makeDialog(QStringLiteral("Ensembles — MIDI Recorder"));
        auto *recorderLayout = new QVBoxLayout(recorderDialog_);
        midiFileLabel_ = new QLabel(QStringLiteral("Belum ada berkas MIDI"), recorderDialog_);
        midiFileLabel_->setWordWrap(true);
        recorderLayout->addWidget(midiFileLabel_);
        auto *midiButtons = new QHBoxLayout;
        auto *openMidiButton = new QPushButton(QStringLiteral("Buka MIDI…"), recorderDialog_);
        playButton_ = new QPushButton(QStringLiteral("▶ Putar MIDI"), recorderDialog_);
        auto *stopMidiButton = new QPushButton(QStringLiteral("■ Stop"), recorderDialog_);
        midiButtons->addWidget(openMidiButton);
        midiButtons->addWidget(playButton_);
        midiButtons->addWidget(stopMidiButton);
        recorderLayout->addLayout(midiButtons);
        recordLabel_ = new QLabel(QStringLiteral("Perekam MIDI siap"), recorderDialog_);
        recordLabel_->setWordWrap(true);
        recorderLayout->addWidget(recordLabel_);
        recordButton_ = new QPushButton(QStringLiteral("● Rekam MIDI"), recorderDialog_);
        recorderLayout->addWidget(recordButton_);
        outputLabel_ = new QLabel(QStringLiteral("Memeriksa output MIDI Windows…"), recorderDialog_);
        outputLabel_->setWordWrap(true);
        recorderLayout->addWidget(outputLabel_);
        auto *recorderNote = new QLabel(QStringLiteral("Ini adalah recorder MIDI untuk event keyboard/pad, bukan perekam sampel audio asli."), recorderDialog_);
        recorderNote->setWordWrap(true);
        recorderNote->setStyleSheet(QStringLiteral("color:#d6b46c"));
        recorderLayout->addWidget(recorderNote);
        auto *recorderClose = new QPushButton(QStringLiteral("Tutup"), recorderDialog_);
        recorderLayout->addWidget(recorderClose);
        connect(openMidiButton, &QPushButton::clicked, this, [this] { loadMidi(); });
        connect(playButton_, &QPushButton::clicked, this, [this] { togglePlayback(); });
        connect(stopMidiButton, &QPushButton::clicked, this, [this] { stopPlayback(); });
        connect(recordButton_, &QPushButton::clicked, this, [this] { toggleRecording(); });
        connect(recorderClose, &QPushButton::clicked, recorderDialog_, &QDialog::hide);

        connect(programCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int index) {
            if (index < 0) return;
            const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
            voicePrograms_[slot] = index;
            if (hasActiveSf2PresetBrowser())
                sf2ProgramNumbers_[slot] = index;
            sendVoiceProgramForSlot(selectedProgramChannel_);
            if (hasActiveSf2PresetBrowser() &&
                sf2PartCombo_ && sf2PartCombo_->currentIndex() == selectedProgramChannel_) {
                updateSf2PresetControlsForSlot(selectedProgramChannel_);
            }
            if (lcdVoiceList_) refreshVoicePickerPage();
            QString name = QString::fromUtf8(kPatchNames[static_cast<std::size_t>(index)]);
            if (hasActiveSf2PresetBrowser()) {
                const std::uint16_t bank = static_cast<std::uint16_t>(
                    (sf2BankMsb_[slot] << 7) | sf2BankLsb_[slot]);
                auto preset = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
                    [bank, index](const lsgm::PresetInfo &item) {
                        return item.bank == bank && item.program == static_cast<std::uint16_t>(index);
                    });
                if (preset != sf2PresetCatalog_.end()) name = QString::fromUtf8(preset->name.c_str());
            }
            if (selectedProgramChannel_ == 0 && voiceR1Label_) voiceR1Label_->setText(name);
            if (selectedProgramChannel_ == 1 && voiceLLabel_) voiceLLabel_->setText(name);
            if (selectedProgramChannel_ == 2 && voiceR2Label_) voiceR2Label_->setText(name);
            if (selectedProgramChannel_ == 2 && voiceR3Label_) voiceR3Label_->setText(name);
        });
        connect(tempoSlider_, &QSlider::valueChanged, this, [this](int value) {
            tempo_ = value;
            if (tempoValue_) tempoValue_->setText(QString::number(value));
            if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(value));
            styleEngine_.setTempo(value);
            if (audioEngine_ && audioEngine_->isReady() && styleEngine_.isYamahaStyle())
                (void)audioEngine_->setYamahaStyleTempo(value);
        });
        connect(gainSlider_, &QSlider::valueChanged, this, [this](int value) {
            setMidiOutputVolume(value);
            if (masterControlDial_) {
                const QSignalBlocker blocker(masterControlDial_);
                masterControlDial_->setValue(std::clamp((value * 127 + 50) / 100, 0, 127));
            }
            QSettings settings; settings.setValue(QStringLiteral("panel/outputVolume"), value); settings.sync();
        });
        connect(metronomeCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (metronomeButton_ && metronomeButton_->isChecked() != on) metronomeButton_->setChecked(on);
            updateModulationTimer();
            QSettings settings; settings.setValue(QStringLiteral("panel/metronomeOn"), on); settings.sync();
        });
        connect(lfoCheck_, &QCheckBox::toggled, this, [this] { updateModulationTimer(); });
        connect(reverbCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (reverbButton_ && reverbButton_->isChecked() != on) reverbButton_->setChecked(on);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        connect(chorusCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (chorusButton_ && chorusButton_->isChecked() != on) chorusButton_->setChecked(on);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        if (delayCheck_) connect(delayCheck_, &QCheckBox::toggled, this, [this](bool) {
            applyPanelMidiSettings();
            savePanelSettings();
        });
        if (delayLevelSpin_) connect(delayLevelSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int) {
            applyPanelMidiSettings();
            savePanelSettings();
        });

        startupTrace("buildUi: settings dialog and controller hookups complete; building main panel");
        // Top title bar mirrors the original custom GTK header.
        auto *header = new DraggableHeaderWidget(this, central);
        header->setObjectName(QStringLiteral("headerBar"));
        header->setFixedHeight(54);
        auto *headerLayout = new QHBoxLayout(header);
        headerLayout->setContentsMargins(5, 2, 5, 2);
        headerLayout->setSpacing(5);
        auto *closeButton = new QPushButton(QStringLiteral("×"), header);
        closeButton->setObjectName(QStringLiteral("flatButton"));
        closeButton->setFixedWidth(36);
        connect(closeButton, &QPushButton::clicked, this, &QWidget::close);
        headerLayout->addWidget(closeButton);
        for (int i = 0; i < 4; ++i) {
            auto *arrow = new QPushButton(QStringLiteral("❯"), header);
            arrow->setObjectName(QStringLiteral("flatButton"));
            arrow->setFixedWidth(24);
            arrow->setToolTip(QStringLiteral("Navigasi cepat arranger; fungsi navigasi lanjut belum dipindahkan."));
            arrow->setEnabled(false);
            headerLayout->addWidget(arrow);
        }
        // The reference header places Metronome beside the transport buttons.
        metronomeButton_ = new QPushButton(QStringLiteral("Metronome"), header);
        metronomeButton_->setFixedWidth(84);
        metronomeButton_->setCheckable(true);
        metronomeButton_->setToolTip(QStringLiteral("Toggle metronome click."));
        connect(metronomeButton_, &QPushButton::toggled, this, [this](bool on) {
            if (metronomeCheck_ && metronomeCheck_->isChecked() != on) metronomeCheck_->setChecked(on);
        });
        headerLayout->addWidget(metronomeButton_);

        // Direct file loader sits beside Metronome so users can open a style
        // from any PC folder without first copying it into the library folders.
        loadStyleButton_ = new QPushButton(QStringLiteral("Load Style"), header);
        loadStyleButton_->setObjectName(QStringLiteral("headerLoadStyle"));
        loadStyleButton_->setFixedSize(86, 30);
        loadStyleButton_->setToolTip(QStringLiteral("Load a Yamaha PSR/SX/Genos Style or Roland .STL directly from a PC folder."));
        connect(loadStyleButton_, &QPushButton::clicked, this, [this] {
            openStyleFileFromPc();
        });
        headerLayout->addWidget(loadStyleButton_);

        headerLayout->addStretch(1);
        auto *title = new QLabel(QStringLiteral("Ensembles"), header);
        title->setObjectName(QStringLiteral("appTitle"));
        title->setAlignment(Qt::AlignCenter);
        headerLayout->addWidget(title);
        headerLayout->addStretch(1);
        auto *headerBalance = new QWidget(header);
        headerBalance->setFixedWidth(185); // Rebalanced for the new 86 px Load Style button beside Metronome.
        headerLayout->addWidget(headerBalance);
        auto *folderButton = new QPushButton(QStringLiteral("▱"), header);
        folderButton->setFixedSize(33, 30);
        folderButton->setToolTip(QStringLiteral("Buka MIDI / Recorder"));
        connect(folderButton, &QPushButton::clicked, recorderDialog_, &QDialog::show);
        headerLayout->addWidget(folderButton);
        auto *settingsButton = new QPushButton(QStringLiteral("⚙"), header);
        settingsButton->setFixedSize(33, 30);
        connect(settingsButton, &QPushButton::clicked, settingsDialog_, &QDialog::show);
        headerLayout->addWidget(settingsButton);
        auto *fullscreenButton = new QPushButton(QStringLiteral("⛶"), header);
        fullscreenButton->setFixedSize(33, 30);
        fullscreenButton->setToolTip(QStringLiteral("Toggle fullscreen"));
        connect(fullscreenButton, &QPushButton::clicked, this, [this] {
            if (isFullScreen()) showNormal(); else showFullScreen();
        });
        headerLayout->addWidget(fullscreenButton);
        root->addWidget(header);

        // Upper three-column deck: assignable controls, original central display, and transport/effects.
        startupTrace("buildUi: before three-panel LCD surface");
        auto *topRow = new QWidget(central);
        auto *topLayout = new QHBoxLayout(topRow);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(4);

        auto *leftTop = makePanel(topRow);
        leftTop->setObjectName(QStringLiteral("akaiLeftMixerPanel"));
        auto *leftTopLayout = new QVBoxLayout(leftTop);
        leftTopLayout->setContentsMargins(4, 4, 4, 3);
        leftTopLayout->setSpacing(2);
        auto *assignBars = new QHBoxLayout;
        // Target panel: the two assign buttons begin immediately inside the panel bezel.
        // Default child-layout margins add an unwanted inset on some Qt styles, so pin them.
        assignBars->setContentsMargins(0, 0, 0, 0);
        assignBars->setSpacing(2);
        knobAssignButton_ = new QPushButton(QStringLiteral("Knob Assign"), leftTop);
        masterAssignButton_ = new QPushButton(QStringLiteral("Master Knob Assign"), leftTop);
        for (auto *b : {knobAssignButton_, masterAssignButton_}) {
            b->setObjectName(QStringLiteral("panelAssignButton"));
            b->setFixedHeight(20);
            b->setStyleSheet(QStringLiteral("QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #3d4d4f,stop:1 #1b2527);border:1px solid #111;border-top:1px solid #5a6b6d;border-radius:0;padding:0 3px;font-size:8pt;color:#ededed;} QPushButton:checked{border-top:3px solid #48b1a5;background:#2d3d3e;}"));
        }
        auto *knobAssign = knobAssignButton_;
        auto *masterAssign = masterAssignButton_;
        knobAssign->setCheckable(true);
        masterAssign->setCheckable(true);
        knobAssign->setToolTip(QStringLiteral("Aktifkan, lalu klik salah satu dari empat knob untuk memetakan MIDI CC."));
        masterAssign->setToolTip(QStringLiteral("Aktifkan, lalu klik kontrol mana pun untuk memasukkan/mengeluarkannya dari kendali Master Knob."));
        connect(knobAssign, &QPushButton::clicked, this, [this, knobAssign, masterAssign](bool checked) {
            knobAssignMode_ = checked;
            if (checked) {
                masterAssignMode_ = false; sliderAssignMode_ = false;
                masterAssign->setChecked(false); if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
                setStatus(QStringLiteral("Mode Knob Assign aktif — klik knob 1–4 untuk memilih pemetaan."));
            } else setStatus(QStringLiteral("Mode Knob Assign nonaktif."));
            updateAssignmentButtonAvailability();
        });
        connect(masterAssign, &QPushButton::clicked, this, [this, knobAssign, masterAssign](bool checked) {
            masterAssignMode_ = checked;
            if (checked) {
                knobAssignMode_ = false; sliderAssignMode_ = false;
                knobAssign->setChecked(false); if (sliderAssignButton_) sliderAssignButton_->setChecked(false);
                setStatus(QStringLiteral("Mode Master Knob aktif — klik kontrol untuk menambah/menghapus target."));
            } else setStatus(QStringLiteral("Mode Master Knob nonaktif."));
            updateAssignmentButtonAvailability();
        });
        assignBars->addWidget(knobAssign, 1);
        assignBars->addWidget(masterAssign, 1);
        leftTopLayout->addLayout(assignBars);
        auto *dialRow = new QWidget(leftTop);
        auto *dialLayout = new QHBoxLayout(dialRow);
        dialLayout->setContentsMargins(3, 0, 3, 0);
        dialLayout->setSpacing(8);
        for (int i = 0; i < 4; ++i) {
            auto *cell = new QWidget(dialRow);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(0);
            auto *dial = new AkaiMixerKnob(cell);
            dial->setRange(0, 127); dial->setValue(64); dial->setNotchesVisible(false);
            dial->setFixedSize(26, 26);
            dial->setEnabled(true);
            assignableKnobs_[static_cast<std::size_t>(i)] = dial;
            connect(dial, &QDial::valueChanged, this, [this, i](int value) { handleAssignableControlValue(10 + i, value); });
            connect(dial, &QDial::sliderReleased, this, [this, i] {
                const int index = 10 + i;
                const auto &map = controllerMaps_[static_cast<std::size_t>(index)];
                const QString shortName = controlShortLabel(map.target, map.controller, map.assigned);
                handleAssignableControlPressed(index, QStringLiteral("Knob %1 (%2)").arg(i + 1).arg(shortName));
            });
            cellLayout->addWidget(dial, 0, Qt::AlignHCenter);
            auto *number = new QLabel(QString::number(i + 1), cell);
            number->setAlignment(Qt::AlignCenter);
            cellLayout->addWidget(number);
            auto *nameLabel = new QLabel(controlShortLabel(defaultControlTarget(10 + i), defaultControllerForTarget(defaultControlTarget(10 + i))), cell);
            nameLabel->setAlignment(Qt::AlignCenter);
            nameLabel->setMinimumWidth(0); nameLabel->setMaximumWidth(52);
            QFont nameFont = nameLabel->font(); nameFont.setPointSize(7); nameLabel->setFont(nameFont);
            nameLabel->setToolTip(controlTargetLabel(defaultControlTarget(10 + i)));
            assignableKnobNameLabels_[static_cast<std::size_t>(i)] = nameLabel;
            cellLayout->addWidget(nameLabel);
            dialLayout->addWidget(cell, 1);
        }
        auto *masterCell = new QWidget(dialRow);
        auto *masterCellLayout = new QVBoxLayout(masterCell);
        masterCellLayout->setContentsMargins(0, 0, 0, 0);
        masterControlDial_ = new AkaiMixerKnob(masterCell);
        masterControlDial_->setRange(0, 127); masterControlDial_->setValue(64); masterControlDial_->setFixedSize(48, 48);
        masterControlDial_->setToolTip(QStringLiteral("Master Volume — mengatur output aplikasi. Master Knob Assign menambahkan slider/knob lain sebagai target ikutan."));
        connect(masterControlDial_, &QDial::valueChanged, this, [this](int value) { handleMasterControlValue(value); });
        masterCellLayout->addWidget(masterControlDial_, 0, Qt::AlignHCenter | Qt::AlignVCenter);
        masterControlNameLabel_ = new QLabel(QStringLiteral("Master Vol"), masterCell);
        masterControlNameLabel_->setAlignment(Qt::AlignCenter);
        QFont masterNameFont = masterControlNameLabel_->font(); masterNameFont.setPointSize(7); masterControlNameLabel_->setFont(masterNameFont);
        masterControlNameLabel_->setToolTip(QStringLiteral("Master Volume — output aplikasi"));
        masterCellLayout->addWidget(masterControlNameLabel_, 0, Qt::AlignHCenter);
        dialLayout->addWidget(masterCell, 1);
        leftTopLayout->addWidget(dialRow);
        // Six physical function faders match the supplied reference image exactly.
        // They are intentionally not presented as a second 10-channel mixer.
        auto *slidersRow = new QWidget(leftTop);
        auto *slidersLayout = new QHBoxLayout(slidersRow);
        slidersLayout->setContentsMargins(1, 0, 1, 0);
        slidersLayout->setSpacing(7);
        static const std::array<const char *, 6> panelFaderLabels = {"STYLE", "SONG", "AUDIO", "PADS", "DRUM/PERC", "CHORD"};
        const std::array<int, 6> sliderInitial = {100, 100, 100, 100, 100, 100};
        for (int i = 0; i < 6; ++i) {
            auto *cell = new QWidget(slidersRow);
            cell->setObjectName(QStringLiteral("leftPanelFader_%1").arg(i));
            cell->setProperty("referenceMixerCell", true);
            cell->setAttribute(Qt::WA_StyledBackground, true);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(1);
            auto *slider = new ReferenceMixerSlider(cell);
            slider->setObjectName(QStringLiteral("leftPanelFaderSlider_%1").arg(i));
            slider->setProperty("referenceMixerFader", true);
            slider->setProperty("akaiStyleFader", true);
            slider->setFixedWidth(34);
            slider->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
            slider->setRange(0, 127);
            slider->setValue(sliderInitial[static_cast<std::size_t>(i)]);
            slider->setMinimumWidth(14);
            // Qt vertical slider: larger value is physically higher (louder), smaller is lower.
            slider->setInvertedAppearance(false);
            slider->setInvertedControls(false);
            slider->setEnabled(true);
            slider->setToolTip(QStringLiteral("%1 volume/level: 0 = minimum (bottom), 127 = maximum (top); startup 100").arg(QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)])));
            assignableSliders_[static_cast<std::size_t>(i)] = slider;
            connect(slider, &QSlider::valueChanged, this, [this, i](int value) { handleAssignableControlValue(i, value); });
            connect(slider, &QSlider::sliderReleased, this, [this, i] {
                handleAssignableControlPressed(i, QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)]));
            });
            cellLayout->addWidget(slider, 1, Qt::AlignHCenter);
            auto *nameLabel = new QLabel(QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)]), cell);
            nameLabel->setObjectName(QStringLiteral("leftPanelFaderLabel_%1").arg(i));
            nameLabel->setAlignment(Qt::AlignCenter);
            nameLabel->setMinimumWidth(0);
            nameLabel->setMaximumWidth(58);
            nameLabel->setFixedHeight(20);
            nameLabel->setWordWrap(true);
            nameLabel->setStyleSheet(QStringLiteral("color:#e1eae8;font-size:7pt;background:transparent;"));
            QFont nameFont = nameLabel->font(); nameFont.setPointSize(6); nameLabel->setFont(nameFont);
            assignableSliderNameLabels_[static_cast<std::size_t>(i)] = nameLabel;
            cellLayout->addWidget(nameLabel);

            auto *muteButton = new QPushButton(QStringLiteral("MUTE"), cell);
            muteButton->setProperty("akaiMuteButton", true);
            muteButton->setFixedWidth(34);
            muteButton->setCheckable(true);
            muteButton->setToolTip(QStringLiteral("Mute/unmute %1 tanpa menghapus level fader terakhir.").arg(QString::fromLatin1(panelFaderLabels[static_cast<std::size_t>(i)])));
            leftMixerMuteButtons_[static_cast<std::size_t>(i)] = muteButton;
            connect(muteButton, &QPushButton::toggled, this, [this, i, slider](bool muted) {
                const bool wasMuted = leftMixerMuted_[static_cast<std::size_t>(i)];
                leftMixerMuted_[static_cast<std::size_t>(i)] = muted;
                QSettings settings;
                settings.setValue(QStringLiteral("panel/leftMixerMuted/%1").arg(i), muted);
                if (muted) {
                    if (!wasMuted) leftMixerRestoreVolume_[static_cast<std::size_t>(i)] = slider->value();
                    if (slider->value() != 0) slider->setValue(0);
                } else {
                    const int restore = std::clamp(leftMixerRestoreVolume_[static_cast<std::size_t>(i)], 0, 127);
                    if (slider->value() != restore) slider->setValue(restore);
                }
                slider->setEnabled(!muted);
                settings.setValue(QStringLiteral("panel/leftMixerRestore/%1").arg(i), leftMixerRestoreVolume_[static_cast<std::size_t>(i)]);
                settings.sync();
            });
            cellLayout->addWidget(muteButton, 0, Qt::AlignHCenter);

            QSettings leftMixerSettings;
            leftMixerRestoreVolume_[static_cast<std::size_t>(i)] = std::clamp(leftMixerSettings.value(QStringLiteral("panel/leftMixerRestore/%1").arg(i), sliderInitial[static_cast<std::size_t>(i)]).toInt(), 0, 127);
            const bool initiallyMuted = leftMixerSettings.value(QStringLiteral("panel/leftMixerMuted/%1").arg(i), false).toBool();
            leftMixerMuted_[static_cast<std::size_t>(i)] = initiallyMuted;
            if (initiallyMuted) muteButton->setChecked(true);
            slidersLayout->addWidget(cell, 1);
        }
        leftTopLayout->addWidget(slidersRow, 4);
        // Captions are initialized from default mappings above; normal startup refreshes them
        // after loadControllerMaps(), including any saved custom assignments.
        topLayout->addWidget(leftTop, 305);

        auto *centerTop = makePanel(topRow);
        auto *centerLayout = new QVBoxLayout(centerTop);
        centerLayout->setContentsMargins(0, 0, 0, 0);
        centerLayout->setSpacing(0);
        lcdContentStack_ = new QStackedWidget(centerTop);
        lcdContentStack_->setObjectName(QStringLiteral("lcdContentStack"));
        centerLayout->addWidget(lcdContentStack_, 1);
        lcdHomePage_ = new QWidget(lcdContentStack_);
        lcdHomePage_->setObjectName(QStringLiteral("lcdHomePage"));
        lcdHomePage_->setStyleSheet(QStringLiteral("background:#101213;"));
        auto *lcdHomeLayout = new QVBoxLayout(lcdHomePage_);
        // Keep the LCD home page proportionate to the 16:9 reference.  Stretch
        // weights let every row use the available display height without
        // changing the surrounding hardware-panel geometry.
        lcdHomeLayout->setContentsMargins(2, 2, 2, 2);
        lcdHomeLayout->setSpacing(2);
        lcdContentStack_->addWidget(lcdHomePage_);
        const QString appDir = QCoreApplication::applicationDirPath();
        auto resolveLcdImage = [appDir](const QString &name) {
            const QStringList candidates = {
                QDir(appDir).filePath(QStringLiteral("data/Images/") + name),
                QDir(appDir).filePath(QStringLiteral("../data/Images/") + name),
                QDir(appDir).filePath(QStringLiteral("legacy-reference/data/Images/") + name),
                QDir::current().filePath(QStringLiteral("data/Images/") + name)
            };
            for (const auto &candidate : candidates)
                if (QFileInfo::exists(candidate)) return candidate;
            return QString();
        };
        const QString synthImage = resolveLcdImage(QStringLiteral("catalin-sandru-7SxSkCvVM1U-unsplash.jpg"));
        const QString keyboardImage = resolveLcdImage(QStringLiteral("sami-takarautio-UZOpP-YHe9Q-unsplash.jpg"));

        auto *lcdStatus = new QWidget(lcdHomePage_);
        lcdStatus->setObjectName(QStringLiteral("lcdStatusRow"));
        lcdStatus->setMinimumHeight(18);
        lcdStatus->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        lcdStatus->setStyleSheet(QStringLiteral("background:#090b0b;color:#f2f2f2;border:0;"));
        auto *lcdStatusLayout = new QHBoxLayout(lcdStatus);
        lcdStatusLayout->setContentsMargins(7, 0, 7, 0);
        lcdStatusLayout->setSpacing(5);
        auto *tempoIcon = new QLabel(QStringLiteral("♩"), lcdStatus);
        tempoIcon->setStyleSheet(QStringLiteral("color:#f4f4f4;font-size:8pt;"));
        lcdStatusLayout->addWidget(tempoIcon);
        tempoValue_ = new QLabel(QString::number(tempo_), lcdStatus);
        tempoValue_->setObjectName(QStringLiteral("tempoMetricValue"));
        tempoValue_->setStyleSheet(QStringLiteral("color:#f4f4f4;font-size:8pt;"));
        lcdStatusLayout->addWidget(tempoValue_);
        lcdPositionLabel_ = new QLabel(QStringLiteral("▤ 001.1"), lcdStatus);
        lcdPositionLabel_->setStyleSheet(QStringLiteral("color:#e2e2e2;font-size:8pt;"));
        lcdStatusLayout->addWidget(lcdPositionLabel_);
        lcdStatusLayout->addStretch(1);
        for (int i = 0; i < 4; ++i) {
            auto *indicator = new QLabel(lcdStatus);
            indicator->setFixedSize(24, 6);
            indicator->setStyleSheet(QStringLiteral("background:%1;border-radius:2px;").arg(i == 0 ? QStringLiteral("#f5d400") : QStringLiteral("#757575")));
            lcdStatusLayout->addWidget(indicator, 0, Qt::AlignVCenter);
        }
        lcdStatusLayout->addStretch(1);
        auto *midiActivity = new QLabel(QStringLiteral("▥ 0   ♪ 0"), lcdStatus);
        midiActivity->setStyleSheet(QStringLiteral("color:#ededed;font-size:8pt;"));
        lcdStatusLayout->addWidget(midiActivity);
        lcdHomeLayout->addWidget(lcdStatus, 6);

        auto *lcdPanels = new QWidget(lcdHomePage_);
        lcdPanels->setObjectName(QStringLiteral("lcdRegisterHarmonyRow"));
        lcdPanels->setMinimumHeight(32);
        lcdPanels->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        auto *lcdPanelsLayout = new QHBoxLayout(lcdPanels);
        lcdPanelsLayout->setContentsMargins(2, 2, 2, 2);
        lcdPanelsLayout->setSpacing(5);
        auto makeInfoPanel = [](const QString &title, const QString &value, QWidget *parent, int stretch) {
            auto *panel = new QFrame(parent);
            panel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            panel->setStyleSheet(QStringLiteral("QFrame{background:#253234;border:0;border-radius:6px;}"));
            auto *layout = new QVBoxLayout(panel);
            layout->setContentsMargins(9, 2, 7, 2);
            layout->setSpacing(1);
            auto *caption = new QLabel(title, panel);
            caption->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            caption->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
            caption->setStyleSheet(QStringLiteral("color:#c8c8c8;font-size:7pt;background:transparent;border:0;"));
            auto *valueLabel = new QLabel(value, panel);
            valueLabel->setMinimumWidth(0);
            valueLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            valueLabel->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
            valueLabel->setStyleSheet(QStringLiteral("color:#ffffff;font-size:9.5pt;font-weight:600;background:transparent;border:0;"));
            // Center the two-line Register/Harmony text block vertically so
            // neither line is pressed against or clipped by the card edges.
            layout->addStretch(1);
            layout->addWidget(caption);
            layout->addWidget(valueLabel);
            layout->addStretch(1);
            panel->setProperty("stretch", stretch);
            return panel;
        };
        lcdPanelsLayout->addWidget(makeInfoPanel(QStringLiteral("Register"), QStringLiteral("New Bank"), lcdPanels, 5), 5);
        lcdPanelsLayout->addWidget(makeInfoPanel(QStringLiteral("Vocal Harmony"), QStringLiteral("StandardHarmony"), lcdPanels, 3), 3);
        lcdHomeLayout->addWidget(lcdPanels, 12);

        auto *voiceCards = new QWidget(lcdHomePage_);
        voiceCards->setObjectName(QStringLiteral("lcdVoiceCardsRow"));
        voiceCards->setMinimumHeight(92);
        voiceCards->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        auto *voiceCardsLayout = new QHBoxLayout(voiceCards);
        voiceCardsLayout->setContentsMargins(2, 0, 2, 0);
        voiceCardsLayout->setSpacing(2);
        auto makeVoiceCard = [this, voiceCards](const QString &category, const QString &badge, const QString &imagePath,
                                                QLabel **nameOut, int channel, bool selected) {
            auto *card = new QPushButton(voiceCards);
            card->setObjectName(QStringLiteral("lcdVoiceCard"));
            card->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            card->setStyleSheet(QStringLiteral("QPushButton#lcdVoiceCard{background:%1;border:0;border-radius:6px;text-align:left;padding:3px 4px;color:#f5ffff;} QPushButton#lcdVoiceCard:hover{background:#08766d;}")
                .arg(selected ? QStringLiteral("#075f59") : QStringLiteral("#00645e"))
                .arg(selected ? QStringLiteral("#d7b85c") : QStringLiteral("#176a63")));
            auto *layout = new QVBoxLayout(card);
            layout->setContentsMargins(3, 2, 3, 2);
            layout->setSpacing(1);
            auto *categoryLabel = new QLabel(category, card);
            categoryLabel->setStyleSheet(QStringLiteral("color:#c9f5ee;font-size:7pt;background:transparent;"));
            auto *nameLabel = new QLabel(card);
            nameLabel->setStyleSheet(QStringLiteral("color:#ffffff;font-size:8.2pt;font-weight:600;background:transparent;"));
            nameLabel->setMinimumWidth(0);
            nameLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
            nameLabel->setToolTip(QStringLiteral("Select %1 voice").arg(badge));
            if (nameOut) *nameOut = nameLabel;
            auto *imageLabel = new CoverPhotoWidget(imagePath, card);
            imageLabel->setObjectName(QStringLiteral("lcdVoicePhoto"));
            imageLabel->setMinimumHeight(48);
            imageLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            auto *badgeRow = new QHBoxLayout;
            badgeRow->setContentsMargins(0, 1, 0, 0);
            auto *partBadge = new QLabel(badge, card);
            partBadge->setStyleSheet(selected
                ? QStringLiteral("color:#202f2e;background:#f5f5f5;border:1px solid #d7b85c;border-radius:3px;padding:1px 5px;font-size:6.5pt;font-weight:700;")
                : QStringLiteral("color:#e1f0ed;background:#185954;border:1px solid #2b7770;border-radius:3px;padding:1px 5px;font-size:6.5pt;font-weight:600;"));
            badgeRow->addWidget(partBadge, 0, Qt::AlignLeft);
            badgeRow->addStretch(1);
            layout->addWidget(categoryLabel);
            layout->addWidget(nameLabel);
            layout->addWidget(imageLabel, 1);
            layout->addLayout(badgeRow);
            connect(card, &QPushButton::clicked, this, [this, channel] { openVoiceSelectPage(channel); });
            return card;
        };
        voiceCardsLayout->addWidget(makeVoiceCard(QStringLiteral("VP Soft"), QStringLiteral("Left"), synthImage, &voiceLLabel_, 1, false), 1);
        voiceCardsLayout->addWidget(makeVoiceCard(QStringLiteral("S.Art"), QStringLiteral("Right1"), keyboardImage, &voiceR1Label_, 0, true), 1);
        voiceCardsLayout->addWidget(makeVoiceCard(QStringLiteral("S.Art"), QStringLiteral("Right2"), synthImage, &voiceR2Label_, 2, false), 1);
        voiceCardsLayout->addWidget(makeVoiceCard(QStringLiteral("S.Art"), QStringLiteral("Right3"), keyboardImage, &voiceR3Label_, 2, false), 1);
        lcdHomeLayout->addWidget(voiceCards, 38);

        auto *mediaRow = new QWidget(lcdHomePage_);
        mediaRow->setObjectName(QStringLiteral("lcdMidiAudioRow"));
        mediaRow->setMinimumHeight(34);
        mediaRow->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        mediaRow->setStyleSheet(QStringLiteral("background:transparent;border:0;"));
        auto *mediaRowLayout = new QHBoxLayout(mediaRow);
        mediaRowLayout->setContentsMargins(2, 2, 2, 2);
        mediaRowLayout->setSpacing(0);
        auto *mediaCard = new QWidget(mediaRow);
        mediaCard->setObjectName(QStringLiteral("lcdMidiAudioCard"));
        mediaCard->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        mediaCard->setStyleSheet(QStringLiteral("background:#1a2525;border:0;border-radius:6px;"));
        mediaRowLayout->addWidget(mediaCard);
        auto *mediaLayout = new QHBoxLayout(mediaCard);
        mediaLayout->setContentsMargins(6, 2, 6, 2);
        mediaLayout->setSpacing(4);
        auto addMediaPanel = [mediaCard, mediaLayout](const QString &captionText, const QString &valueText) {
            auto *panel = new QWidget(mediaCard);
            auto *layout = new QVBoxLayout(panel);
            layout->setContentsMargins(0, 0, 0, 0);
            layout->setSpacing(0);
            auto *caption = new QLabel(captionText, panel);
            caption->setStyleSheet(QStringLiteral("color:#f1a34f;font-size:7pt;background:transparent;border:0;"));
            auto *value = new QLabel(valueText, panel);
            value->setStyleSheet(QStringLiteral("color:#ffffff;font-size:9pt;font-weight:600;background:transparent;border:0;"));
            layout->addWidget(caption);
            layout->addWidget(value);
            mediaLayout->addWidget(panel, 1);
        };
        addMediaPanel(QStringLiteral("MIDI"), QStringLiteral("New Song"));
        lcdMidiMetaLabel_ = new QLabel(QStringLiteral("4/4     ♩=%1   001/001").arg(tempo_), mediaCard);
        lcdMidiMetaLabel_->setAlignment(Qt::AlignCenter);
        lcdMidiMetaLabel_->setStyleSheet(QStringLiteral("color:#ededed;font-size:7pt;background:transparent;border:0;"));
        mediaLayout->addWidget(lcdMidiMetaLabel_, 2);
        auto *mediaDivider = new QFrame(mediaCard);
        mediaDivider->setFixedWidth(1);
        mediaDivider->setStyleSheet(QStringLiteral("background:#37615c;border:0;"));
        mediaLayout->addWidget(mediaDivider);
        addMediaPanel(QStringLiteral("Audio"), QStringLiteral("New Audio"));
        lcdHomeLayout->addWidget(mediaRow, 13);

        auto *styleAndPad = new QWidget(lcdHomePage_);
        styleAndPad->setObjectName(QStringLiteral("lcdStylePadRow"));
        styleAndPad->setMinimumHeight(48);
        styleAndPad->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        auto *styleAndPadLayout = new QHBoxLayout(styleAndPad);
        styleAndPadLayout->setContentsMargins(2, 2, 2, 2);
        styleAndPadLayout->setSpacing(4);
        auto makeSelectionCard = [](const QString &captionText, const QString &valueText, QWidget *parent,
                                    const QString &color, const QString &iconText, QLabel **valueOut) {
            auto *card = new QPushButton(parent);
            card->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            card->setMinimumHeight(44);
            card->setStyleSheet(QStringLiteral("QPushButton{background:%1;border:0;border-radius:6px;text-align:left;padding:2px;color:#fff;} QPushButton:hover{background:rgba(255,255,255,10);}").arg(color));
            auto *layout = new QHBoxLayout(card);
            layout->setContentsMargins(6, 3, 7, 3);
            layout->setSpacing(7);
            auto *icon = new QLabel(iconText, card);
            icon->setFixedWidth(24);
            icon->setAlignment(Qt::AlignCenter);
            icon->setStyleSheet(QStringLiteral("color:#fff4e8;font-size:16pt;font-weight:600;background:rgba(0,0,0,35);border:1px solid rgba(255,255,255,45);border-radius:5px;"));
            auto *details = new QVBoxLayout;
            details->setContentsMargins(0, 0, 0, 0);
            details->setSpacing(1);
            auto *caption = new QLabel(captionText, card);
            caption->setObjectName(QStringLiteral("lcdSelectionCaption"));
            caption->setStyleSheet(QStringLiteral("color:#f2d9c3;font-size:7pt;background:transparent;"));
            caption->setMinimumWidth(0);
            caption->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
            auto *value = new QLabel(valueText, card);
            if (valueOut) *valueOut = value;
            value->setStyleSheet(QStringLiteral("color:#ffffff;font-size:9.5pt;font-weight:700;background:transparent;"));
            value->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
            value->setMinimumWidth(0);
            value->setWordWrap(true);
            details->addWidget(caption);
            details->addWidget(value);
            layout->addWidget(icon);
            layout->addLayout(details, 1);
            return card;
        };
        auto *styleCard = makeSelectionCard(QStringLiteral("Style    4/4     ♩ %1     1/8").arg(tempo_), QStringLiteral("No Style"), styleAndPad, QStringLiteral("#8c0014"), QStringLiteral("♫"), &styleNameLabel_);
        lcdStyleMetaLabel_ = styleCard->findChild<QLabel *>(QStringLiteral("lcdSelectionCaption"));
        if (lcdStyleMetaLabel_) lcdStyleMetaLabel_->setObjectName(QStringLiteral("lcdStyleMeta"));
        if (styleNameLabel_) styleNameLabel_->setObjectName(QStringLiteral("lcdStyleName"));
        connect(styleCard, &QPushButton::clicked, this, [this] {
            dataEntryStyleMode_ = true;
            if (lcdContentStack_ && lcdStylePickerPage_) lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
        });
        styleCard->setObjectName(QStringLiteral("lcdStyleCard"));
        styleAndPadLayout->addWidget(styleCard, 5);
        auto *padCard = makeSelectionCard(QStringLiteral("Multi Pad"), QStringLiteral("Shaker&Tambourine3"), styleAndPad, QStringLiteral("#4148c9"), QStringLiteral("▦"), nullptr);
        padCard->setObjectName(QStringLiteral("lcdMultiPadCard"));
        padCard->setToolTip(QStringLiteral("Multi Pad belum terhubung ke player.") );
        styleAndPadLayout->addWidget(padCard, 3);
        lcdHomeLayout->addWidget(styleAndPad, 19);

        auto *lcdNavigation = new QWidget(lcdHomePage_);
        lcdNavigation->setObjectName(QStringLiteral("lcdNavigationRow"));
        lcdNavigation->setMinimumHeight(24);
        lcdNavigation->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        // The navigation row is only a transparent holder; each of the six
        // buttons owns its own surface, with no shared background behind them.
        lcdNavigation->setStyleSheet(QStringLiteral("background:transparent;border:0;"));
        auto *lcdNavigationLayout = new QHBoxLayout(lcdNavigation);
        lcdNavigationLayout->setContentsMargins(2, 0, 2, 1);
        lcdNavigationLayout->setSpacing(3);
        const std::array<QString, 6> lcdNavigationNames = {
            QStringLiteral("VoicePart"), QStringLiteral("ChordLooper"), QStringLiteral("LiveControl"),
            QStringLiteral("Assignable"), QStringLiteral("Channel"), QStringLiteral("Demo")
        };
        for (std::size_t i = 0; i < lcdNavigationNames.size(); ++i) {
            auto *button = new QPushButton(lcdNavigationNames[i], lcdNavigation);
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            button->setMinimumHeight(22);
            button->setStyleSheet(QStringLiteral("QPushButton{background:#263537;border:0;border-radius:6px;padding:2px 3px;color:#f0f0f0;font-size:7pt;font-weight:600;} QPushButton:hover{background:#344648;}") );
            if (i == 0) connect(button, &QPushButton::clicked, this, [this] { openVoiceSelectPage(0); });
            else if (i == 3 || i == 4) connect(button, &QPushButton::clicked, this, [this] { if (settingsDialog_) settingsDialog_->show(); });
            lcdNavigationLayout->addWidget(button, 1);
        }
        lcdHomeLayout->addWidget(lcdNavigation, 10);

        measureMetricLabel_ = new QLabel(QStringLiteral("001/001"), lcdHomePage_);
        measureMetricLabel_->hide();
        beatMetricLabel_ = new QLabel(QStringLiteral("4/4"), lcdHomePage_);
        transposeMetricLabel_ = new QLabel(QStringLiteral("0"), lcdHomePage_);
        octaveMetricLabel_ = new QLabel(QStringLiteral("0"), lcdHomePage_);
        chordLabel_ = new QLabel(QStringLiteral("C min"), lcdHomePage_);
        beatMetricLabel_->hide();
        transposeMetricLabel_->hide();
        octaveMetricLabel_->hide();
        chordLabel_->hide();

        startupTrace("buildUi: before LCD Voice/Style picker pages");
        // The original application opens Voice and Style choosers inside the
        // central LCD itself, replacing the home/photo page rather than opening
        // a detached desktop dialog.  Keep each picker in this LCD stack so the
        // surrounding hardware controls never move when a list is opened.
        auto createLcdPickerPage = [this](const QString &title, const QString &subtitle,
                                          bool voiceMode, QListWidget **listOutput) {
            auto *page = new QWidget(lcdContentStack_);
            page->setObjectName(voiceMode ? QStringLiteral("lcdVoicePickerPage")
                                          : QStringLiteral("lcdStylePickerPage"));
            page->setStyleSheet(QStringLiteral("background:#273537;"));
            auto *pageLayout = new QVBoxLayout(page);
            pageLayout->setContentsMargins(0, 0, 0, 0);
            pageLayout->setSpacing(0);

            auto *header = new QWidget(page);
            header->setFixedHeight(47);
            header->setStyleSheet(QStringLiteral("background:#0a756e;"));
            auto *headerLayout = new QHBoxLayout(header);
            headerLayout->setContentsMargins(5, 2, 8, 2);
            headerLayout->setSpacing(4);
            auto *close = new QPushButton(QStringLiteral("×"), header);
            close->setObjectName(QStringLiteral("lcdPickerClose"));
            close->setFixedSize(23, 28);
            close->setStyleSheet(QStringLiteral("QPushButton{background:transparent;border:0;padding:0;font-size:17pt;font-weight:600;color:#f2ffff;} QPushButton:hover{color:#ffffff;background:#0d897e;}"));
            connect(close, &QPushButton::clicked, this, [this] {
                if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
            });

            auto *titleBox = new QWidget(header);
            auto *titleLayout = new QVBoxLayout(titleBox);
            titleLayout->setContentsMargins(0, 0, 0, 0);
            titleLayout->setSpacing(0);
            auto *titleLabel = new QLabel(title, titleBox);
            titleLabel->setObjectName(QStringLiteral("lcdPickerTitle"));
            titleLabel->setAlignment(Qt::AlignCenter);
            titleLabel->setStyleSheet(QStringLiteral("color:#ffffff;font-size:9pt;font-weight:700;background:transparent;"));
            auto *subtitleLabel = new QLabel(subtitle, titleBox);
            subtitleLabel->setObjectName(QStringLiteral("lcdPickerSubtitle"));
            subtitleLabel->setAlignment(Qt::AlignCenter);
            subtitleLabel->setStyleSheet(QStringLiteral("color:#d4efea;font-size:7pt;background:transparent;"));
            titleLayout->addWidget(titleLabel);
            titleLayout->addWidget(subtitleLabel);
            headerLayout->addWidget(close, 0, Qt::AlignVCenter);
            headerLayout->addWidget(titleBox, 1);
            auto *headerBalance = new QWidget(header);
            headerBalance->setFixedWidth(23);
            headerLayout->addWidget(headerBalance);
            pageLayout->addWidget(header);
            if (voiceMode) {
                auto *voiceFilterRow = new QWidget(page);
                voiceFilterRow->setStyleSheet(QStringLiteral("background:#202b2d;"));
                auto *filterLayout = new QHBoxLayout(voiceFilterRow);
                filterLayout->setContentsMargins(4, 3, 4, 3);
                filterLayout->setSpacing(4);
                lcdVoiceMapCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceMapCombo_->setObjectName(QStringLiteral("lcdVoiceMapCombo"));
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-8820"), 4);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-88Pro"), 3);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-88"), 2);
                lcdVoiceMapCombo_->addItem(QStringLiteral("SC-55"), 1);
                lcdVoiceCategoryCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceCategoryCombo_->setObjectName(QStringLiteral("lcdVoiceCategoryCombo"));
                for (const char *category : {"All Voice Types", "Piano", "Crm Perc", "Organ", "Guitar", "Bass", "Strings", "Brass", "Reed/Pipe", "Synth Lead", "Synth Pad", "Drum Kit", "Extra"})
                    lcdVoiceCategoryCombo_->addItem(QString::fromLatin1(category));
                lcdVoiceBankCombo_ = new QComboBox(voiceFilterRow);
                lcdVoiceBankCombo_->setObjectName(QStringLiteral("lcdVoiceBankCombo"));
                lcdVoiceBankCombo_->addItem(QStringLiteral("Standard · Bank 0"), 0);
                lcdVoiceBankCombo_->addItem(QStringLiteral("All variations"), -1);
                lcdVoiceMapCombo_->setStyleSheet(QStringLiteral("QComboBox{background:#304244;color:#fff;border:1px solid #435658;padding:3px;} QComboBox QAbstractItemView{background:#293638;color:#fff;selection-background-color:#0a756e;}"));
                lcdVoiceCategoryCombo_->setStyleSheet(lcdVoiceMapCombo_->styleSheet());
                lcdVoiceBankCombo_->setStyleSheet(lcdVoiceMapCombo_->styleSheet());
                filterLayout->addWidget(lcdVoiceMapCombo_, 1);
                filterLayout->addWidget(lcdVoiceCategoryCombo_, 2);
                filterLayout->addWidget(lcdVoiceBankCombo_, 2);
                pageLayout->addWidget(voiceFilterRow);
            }

            auto *list = new QListWidget(page);
            list->setObjectName(voiceMode ? QStringLiteral("lcdVoiceList") : QStringLiteral("lcdStyleList"));
            list->setFrameShape(QFrame::NoFrame);
            list->setSelectionMode(QAbstractItemView::SingleSelection);
            list->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
            list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            list->setUniformItemSizes(true);
            list->setIconSize(voiceMode ? QSize(54, 36) : QSize(50, 32));
            if (voiceMode) {
                // The legacy VoiceMenu is a vertical, wheel-scrollable catalog.
                // Do not tile/paginate voices: one full-width row per preset, with thumbnail and category.
                list->setViewMode(QListView::ListMode);
                list->setFlow(QListView::TopToBottom);
                list->setWrapping(false);
                list->setResizeMode(QListView::Adjust);
                list->setMovement(QListView::Static);
                list->setGridSize(QSize());
                list->setSpacing(0);
                list->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
                list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            }
            list->setItemDelegate(new LcdPickerItemDelegate(voiceMode, list));
            list->setStyleSheet(QStringLiteral(
                "QListWidget{background:#273537;border:0;outline:0;padding:0;color:#bdbdbd;}"
                "QListWidget::item{border:0;padding:0;}"
                "QScrollBar:vertical{background:#202b2d;width:8px;margin:0;}"
                "QScrollBar::handle:vertical{background:#536665;min-height:24px;border:1px solid #182224;}"
                "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"));
            pageLayout->addWidget(list, 1);
            if (voiceMode) {
                auto *countRow = new QWidget(page);
                countRow->setStyleSheet(QStringLiteral("background:#202b2d;"));
                auto *countLayout = new QHBoxLayout(countRow);
                countLayout->setContentsMargins(6, 2, 6, 2);
                lcdVoicePageLabel_ = new QLabel(QStringLiteral("Voice catalog"), countRow);
                lcdVoicePageLabel_->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
                lcdVoicePageLabel_->setStyleSheet(QStringLiteral("color:#aaaaaa;font-size:7pt;"));
                countLayout->addWidget(lcdVoicePageLabel_);
                countLayout->addStretch(1);
                pageLayout->addWidget(countRow);
                connect(lcdVoiceMapCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
                connect(lcdVoiceCategoryCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
                connect(lcdVoiceBankCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { refreshVoicePickerPage(); });
            }
            if (listOutput) *listOutput = list;
            return page;
        };

        // The Voice Select reference layout is hosted directly in the LCD stack.
        // It is not a QDialog and therefore never overlays the surrounding control panes.
        lcdVoicePickerPage_ = new QWidget(lcdContentStack_);
        lcdVoicePickerPage_->setObjectName(QStringLiteral("lcdVoicePickerPage"));
        lcdVoicePickerPage_->setStyleSheet(QStringLiteral("QWidget#lcdVoicePickerPage{background:#182224;color:#e1eae8;}"));
        lcdContentStack_->addWidget(lcdVoicePickerPage_);

        // Yamaha Style List: the proportions, two-column/five-row grid, category
        // tiles, teal command bar and page strip follow STYLE LIST.png (800x480).
        auto *stylePage = new LcdStyleResponsivePage(lcdContentStack_);
        lcdStylePickerPage_ = stylePage;
        lcdStylePickerPage_->setObjectName(QStringLiteral("lcdStylePickerPage"));
        lcdStylePickerPage_->setStyleSheet(QStringLiteral("QWidget#lcdStylePickerPage{background:#202b2d;color:#e1eae8;}"));
        auto *stylePageLayout = new QVBoxLayout(lcdStylePickerPage_);
        stylePageLayout->setContentsMargins(0, 0, 0, 0);
        stylePageLayout->setSpacing(0);

        auto *styleHeader = new QWidget(lcdStylePickerPage_);
        styleHeader->setObjectName(QStringLiteral("lcdStyleHeader"));
        styleHeader->setFixedHeight(56);
        styleHeader->setStyleSheet(QStringLiteral("background:#11675f;"));
        auto *styleHeaderLayout = new QHBoxLayout(styleHeader);
        styleHeaderLayout->setContentsMargins(15, 0, 0, 0);
        styleHeaderLayout->setSpacing(0);

        auto *styleLogo = new LcdStyleLogoWidget(styleHeader);
        styleLogo->setObjectName(QStringLiteral("lcdStyleLogo"));
        styleLogo->setFixedSize(29, 56);
        auto *styleTitle = new QLabel(QStringLiteral("Style"), styleHeader);
        styleTitle->setObjectName(QStringLiteral("lcdStyleTitle"));
        styleTitle->setAlignment(Qt::AlignVCenter | Qt::AlignLeft);
        styleTitle->setFixedHeight(56);
        styleTitle->setStyleSheet(QStringLiteral(
            "color:#ffffff;font-size:20pt;font-weight:500;padding-left:9px;background:transparent;"));
        styleHeaderLayout->addWidget(styleLogo, 0, Qt::AlignVCenter);
        styleHeaderLayout->addWidget(styleTitle, 0, Qt::AlignVCenter);
        styleHeaderLayout->addStretch(5);

        auto *styleModeGroup = new QWidget(styleHeader);
        styleModeGroup->setObjectName(QStringLiteral("lcdStyleModeGroup"));
        styleModeGroup->setStyleSheet(QStringLiteral("background:transparent;"));
        auto *styleModeLayout = new QHBoxLayout(styleModeGroup);
        styleModeLayout->setContentsMargins(0, 0, 0, 0);
        styleModeLayout->setSpacing(0);
        styleModeLayout->setAlignment(Qt::AlignVCenter);
        // This is a full-height alignment cell. The three mode buttons are
        // centered inside it, rather than centering a short group by font metrics.
        styleModeGroup->setFixedSize(192, 56);
        const QString modeButtonCss = QStringLiteral(
            "QPushButton{background:#354143;color:#ededed;border:1px solid #67797a;padding:2px 5px;font-size:10pt;}"
            "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}"
            "QPushButton:hover{border:1px solid #ffffff;}");
        lcdStylePresetButton_ = new QPushButton(QStringLiteral("Preset"), styleModeGroup);
        lcdStylePresetButton_->setObjectName(QStringLiteral("lcdStylePresetButton"));
        lcdStylePresetButton_->setCheckable(true);
        lcdStylePresetButton_->setChecked(true);
        lcdStylePresetButton_->setFixedSize(64, 38);
        lcdStylePresetButton_->setStyleSheet(modeButtonCss + QStringLiteral(
            "QPushButton{border-top-left-radius:7px;border-bottom-left-radius:7px;}"));
        lcdStyleUserButton_ = new QPushButton(styleModeGroup);
        lcdStyleUserButton_->setObjectName(QStringLiteral("lcdStyleUserButton"));
        lcdStyleUserButton_->setCheckable(true);
        lcdStyleUserButton_->setFixedSize(64, 38);
        lcdStyleUserButton_->setStyleSheet(modeButtonCss);
        auto *styleUserContent = new QWidget(lcdStyleUserButton_);
        styleUserContent->setAttribute(Qt::WA_TransparentForMouseEvents);
        styleUserContent->setStyleSheet(QStringLiteral("background:transparent;"));
        auto *styleUserContentLayout = new QHBoxLayout(styleUserContent);
        styleUserContentLayout->setContentsMargins(0, 0, 0, 0);
        styleUserContentLayout->setSpacing(1);
        styleUserContentLayout->setAlignment(Qt::AlignCenter);
        auto *styleUserLabel = new QLabel(QStringLiteral("User"), styleUserContent);
        styleUserLabel->setObjectName(QStringLiteral("lcdStyleUserLabel"));
        styleUserLabel->setStyleSheet(QStringLiteral("color:#ededed;background:transparent;font-size:10pt;"));
        auto *styleUserDiskIcon = new LcdStyleHeaderIconWidget(
            LcdStyleHeaderIconWidget::Kind::HardDrive, styleUserContent);
        styleUserDiskIcon->setObjectName(QStringLiteral("lcdStyleUserDiskIcon"));
        styleUserDiskIcon->setFixedSize(22, 22);
        styleUserContentLayout->addWidget(styleUserLabel);
        styleUserContentLayout->addWidget(styleUserDiskIcon);
        auto *styleUserButtonLayout = new QHBoxLayout(lcdStyleUserButton_);
        styleUserButtonLayout->setContentsMargins(0, 0, 0, 0);
        styleUserButtonLayout->setAlignment(Qt::AlignCenter);
        styleUserButtonLayout->addWidget(styleUserContent);
        lcdStyleFavoritesButton_ = new QPushButton(styleModeGroup);
        lcdStyleFavoritesButton_->setObjectName(QStringLiteral("lcdStyleFavoritesButton"));
        lcdStyleFavoritesButton_->setCheckable(true);
        lcdStyleFavoritesButton_->setFixedSize(64, 38);
        lcdStyleFavoritesButton_->setStyleSheet(modeButtonCss + QStringLiteral(
            "QPushButton{border-top-right-radius:7px;border-bottom-right-radius:7px;}"));
        auto *styleFavoritesLayout = new QHBoxLayout(lcdStyleFavoritesButton_);
        styleFavoritesLayout->setContentsMargins(0, 0, 0, 0);
        styleFavoritesLayout->setAlignment(Qt::AlignCenter);
        auto *styleFavoritesIcon = new LcdStyleHeaderIconWidget(
            LcdStyleHeaderIconWidget::Kind::Star, lcdStyleFavoritesButton_);
        styleFavoritesIcon->setObjectName(QStringLiteral("lcdStyleFavoritesIcon"));
        styleFavoritesIcon->setFixedSize(24, 24);
        styleFavoritesLayout->addWidget(styleFavoritesIcon);
        styleModeLayout->addWidget(lcdStylePresetButton_);
        styleModeLayout->addWidget(lcdStyleUserButton_);
        styleModeLayout->addWidget(lcdStyleFavoritesButton_);
        styleHeaderLayout->addWidget(styleModeGroup, 0, Qt::AlignVCenter);
        styleHeaderLayout->addStretch(4);

        const auto makeStyleHeaderAction = [styleHeader](const QString &caption,
                                                          LcdStyleHeaderIconWidget::Kind iconKind,
                                                          const QString &objectName) {
            auto *button = new QPushButton(styleHeader);
            button->setObjectName(objectName);
            button->setFixedSize(64, 56);
            button->setFlat(true);
            auto *content = new QVBoxLayout(button);
            content->setContentsMargins(0, 0, 0, 0);
            content->setSpacing(0);
            content->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
            auto *icon = new LcdStyleHeaderIconWidget(iconKind, button);
            icon->setObjectName(objectName + QStringLiteral("Icon"));
            icon->setFixedSize(iconKind == LcdStyleHeaderIconWidget::Kind::Folder ? 34 : 30,
                               iconKind == LcdStyleHeaderIconWidget::Kind::Folder ? 34 : 30);
            auto *text = new QLabel(caption, button);
            text->setObjectName(objectName + QStringLiteral("Caption"));
            text->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
            text->setFixedHeight(14);
            text->setStyleSheet(QStringLiteral(
                "color:#ffffff;background:transparent;font-size:9pt;font-weight:400;"));
            content->addWidget(icon, 0, Qt::AlignHCenter);
            content->addWidget(text, 0, Qt::AlignHCenter);
            button->setStyleSheet(QStringLiteral(
                "QPushButton{background:transparent;border:0;padding:0;}"
                "QPushButton:hover{background:rgba(255,255,255,35);}"));
            return button;
        };
        auto *styleSearchButton = makeStyleHeaderAction(QStringLiteral("Search"),
            LcdStyleHeaderIconWidget::Kind::Search, QStringLiteral("lcdStyleSearchButton"));
        auto *styleFileButton = makeStyleHeaderAction(QStringLiteral("File"),
            LcdStyleHeaderIconWidget::Kind::Folder, QStringLiteral("lcdStyleFileButton"));
        auto *styleMenuButton = makeStyleHeaderAction(QStringLiteral("Menu"),
            LcdStyleHeaderIconWidget::Kind::Menu, QStringLiteral("lcdStyleMenuButton"));
        auto *styleActionDivider = new QFrame(styleHeader);
        styleActionDivider->setObjectName(QStringLiteral("lcdStyleActionDivider"));
        styleActionDivider->setFrameShape(QFrame::NoFrame);
        styleActionDivider->setFixedSize(1, 44);
        styleActionDivider->setStyleSheet(QStringLiteral("background:rgba(255,255,255,150);"));
        auto *styleCloseButton = new QPushButton(styleHeader);
        styleCloseButton->setObjectName(QStringLiteral("lcdStyleCloseButton"));
        styleCloseButton->setFixedSize(64, 56);
        auto *styleCloseLayout = new QHBoxLayout(styleCloseButton);
        styleCloseLayout->setContentsMargins(0, 0, 0, 0);
        styleCloseLayout->setAlignment(Qt::AlignCenter);
        auto *styleCloseIcon = new LcdStyleHeaderIconWidget(
            LcdStyleHeaderIconWidget::Kind::Close, styleCloseButton);
        styleCloseIcon->setObjectName(QStringLiteral("lcdStyleCloseIcon"));
        styleCloseIcon->setFixedSize(34, 34);
        styleCloseLayout->addWidget(styleCloseIcon);
        styleCloseButton->setStyleSheet(QStringLiteral(
            "QPushButton{background:transparent;border:0;padding:0;}"
            "QPushButton:hover{background:rgba(255,255,255,35);}"));
        styleHeaderLayout->addWidget(styleSearchButton, 0, Qt::AlignVCenter);
        styleHeaderLayout->addWidget(styleFileButton, 0, Qt::AlignVCenter);
        styleHeaderLayout->addWidget(styleMenuButton, 0, Qt::AlignVCenter);
        styleHeaderLayout->addWidget(styleActionDivider, 0, Qt::AlignVCenter);
        styleHeaderLayout->addWidget(styleCloseButton, 0, Qt::AlignVCenter);
        stylePageLayout->addWidget(styleHeader);

        auto *styleMainRow = new QWidget(lcdStylePickerPage_);
        auto *styleMainLayout = new QHBoxLayout(styleMainRow);
        styleMainLayout->setContentsMargins(0, 0, 0, 0);
        styleMainLayout->setSpacing(0);

        auto *styleCategoryPane = new QWidget(styleMainRow);
        styleCategoryPane->setObjectName(QStringLiteral("lcdStyleCategoryPane"));
        styleCategoryPane->setStyleSheet(QStringLiteral("background:#202b2d;"));
        auto *styleCategoryLayout = new QGridLayout(styleCategoryPane);
        // Equal 6 px outer insets keep the category tiles centered in the left pane.
        styleCategoryLayout->setContentsMargins(6, 6, 0, 5);
        styleCategoryLayout->setHorizontalSpacing(5);
        styleCategoryLayout->setVerticalSpacing(5);
        const std::array<QString, 9> styleCategoryNames = {
            QStringLiteral("Pop&Rock"), QStringLiteral("Dance"), QStringLiteral("R&B"),
            QStringLiteral("Jazz"), QStringLiteral("Latin"), QStringLiteral("Ballroom"),
            QStringLiteral("Movie&Show"), QStringLiteral("Entertainer"), QStringLiteral("World")
        };
        lcdStyleCategoryButtons_.clear();
        for (std::size_t categoryIndex = 0; categoryIndex < styleCategoryNames.size(); ++categoryIndex) {
            const QString categoryName = styleCategoryNames[categoryIndex];
            QString categoryCaption = categoryName;
            categoryCaption.replace(QStringLiteral("&"), QStringLiteral("&&"));
            auto *categoryButton = new QPushButton(categoryCaption, styleCategoryPane);
            categoryButton->setObjectName(QStringLiteral("lcdStyleCategory_%1").arg(static_cast<int>(categoryIndex)));
            categoryButton->setProperty("styleCategory", categoryName);
            categoryButton->setCheckable(true);
            categoryButton->setMinimumHeight(0);
            categoryButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            categoryButton->setStyleSheet(QStringLiteral(
                "QPushButton{background:#2d3a3c;color:#c8cbd4;border:1px solid #5a6b6d;border-radius:3px;"
                "padding:4px 2px;font-size:10pt;}"
                "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}"
                "QPushButton:hover{border:1px solid #e1eae8;}") );
            const int gridRow = static_cast<int>(categoryIndex / 2);
            const int gridColumn = static_cast<int>(categoryIndex % 2);
            styleCategoryLayout->addWidget(categoryButton, gridRow, gridColumn);
            lcdStyleCategoryButtons_.push_back(categoryButton);
        }
        styleCategoryLayout->setColumnStretch(0, 1);
        styleCategoryLayout->setColumnStretch(1, 1);
        styleCategoryLayout->setRowStretch(5, 1);
        styleMainLayout->addWidget(styleCategoryPane);

        auto *styleListPane = new QWidget(styleMainRow);
        styleListPane->setObjectName(QStringLiteral("lcdStyleListPane"));
        styleListPane->setStyleSheet(QStringLiteral("background:#1f2b2d;"));
        auto *styleListPaneLayout = new QVBoxLayout(styleListPane);
        // Match the left and right edge inset exactly, then split the inner width
        // into two equal Style columns.
        styleListPaneLayout->setContentsMargins(6, 7, 6, 0);
        styleListPaneLayout->setSpacing(0);
        auto *styleGrid = new LcdStyleGridListWidget(styleListPane);
        lcdStyleList_ = styleGrid;
        styleGrid->setObjectName(QStringLiteral("lcdStyleList"));
        styleGrid->setFrameShape(QFrame::NoFrame);
        styleGrid->setViewMode(QListView::IconMode);
        styleGrid->setFlow(QListView::TopToBottom);
        styleGrid->setWrapping(true);
        styleGrid->setMovement(QListView::Static);
        styleGrid->setResizeMode(QListView::Adjust);
        styleGrid->setLayoutMode(QListView::SinglePass);
        styleGrid->setGridSize(QSize(286, 62));
        styleGrid->setSpacing(0);
        styleGrid->setUniformItemSizes(true);
        styleGrid->setSelectionMode(QAbstractItemView::SingleSelection);
        styleGrid->setSelectionBehavior(QAbstractItemView::SelectItems);
        styleGrid->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        styleGrid->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        styleGrid->setIconSize(QSize(0, 0));
        styleGrid->setItemDelegate(new LcdStyleGridItemDelegate(styleGrid));
        styleGrid->setStyleSheet(QStringLiteral(
            "QListWidget{background:#1f2b2d;border:0;outline:0;padding:0;color:#e1eae8;}"
            "QListWidget::item{border:0;padding:0;margin:0;}"));
        styleListPaneLayout->addWidget(styleGrid, 1);

        auto *stylePageFooter = new QWidget(styleListPane);
        stylePageFooter->setObjectName(QStringLiteral("lcdStylePageFooter"));
        stylePageFooter->setFixedHeight(44);
        stylePageFooter->setStyleSheet(QStringLiteral("background:#202b2d;"));
        auto *stylePageFooterLayout = new QHBoxLayout(stylePageFooter);
        // Page tabs and navigation share the same left/right rails as the Style rows.
        stylePageFooterLayout->setContentsMargins(6, 0, 6, 0);
        stylePageFooterLayout->setSpacing(3);
        for (int pageIndex = 0; pageIndex < static_cast<int>(lcdStylePageButtons_.size()); ++pageIndex) {
            auto *pageButton = new QPushButton(QStringLiteral("P%1").arg(pageIndex + 1), stylePageFooter);
            pageButton->setObjectName(QStringLiteral("lcdStylePage_%1").arg(pageIndex + 1));
            pageButton->setCheckable(true);
            pageButton->setFixedSize(70, 40);
            pageButton->setStyleSheet(QStringLiteral(
                "QPushButton{background:#111819;color:#879493;border:1px solid #435658;border-radius:13px 13px 5px 5px;font-size:11pt;}"
                "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}") );
            lcdStylePageButtons_[static_cast<std::size_t>(pageIndex)] = pageButton;
            stylePageFooterLayout->addWidget(pageButton);
        }
        stylePageFooterLayout->addStretch(1);
        lcdStylePreviousPageButton_ = new QPushButton(QStringLiteral("◀"), stylePageFooter);
        lcdStylePreviousPageButton_->setObjectName(QStringLiteral("lcdStylePreviousPage"));
        lcdStyleNextPageButton_ = new QPushButton(QStringLiteral("▶"), stylePageFooter);
        lcdStyleNextPageButton_->setObjectName(QStringLiteral("lcdStyleNextPage"));
        lcdStyleTopButton_ = new QPushButton(QStringLiteral("↥"), stylePageFooter);
        lcdStyleTopButton_->setObjectName(QStringLiteral("lcdStyleTopButton"));
        for (auto *button : {lcdStylePreviousPageButton_, lcdStyleNextPageButton_, lcdStyleTopButton_}) {
            button->setFixedSize(42, 38);
            button->setStyleSheet(QStringLiteral(
                "QPushButton{background:transparent;color:#e1eae8;border:0;font-size:18pt;padding:0;}"
                "QPushButton:disabled{color:#435658;} QPushButton:hover{color:#ffffff;background:#2d3d3e;}") );
            stylePageFooterLayout->addWidget(button);
        }
        styleListPaneLayout->addWidget(stylePageFooter);
        styleMainLayout->addWidget(styleListPane, 1);
        stylePageLayout->addWidget(styleMainRow, 1);

        auto *stylePathBar = new QWidget(lcdStylePickerPage_);
        stylePathBar->setObjectName(QStringLiteral("lcdStylePathBar"));
        stylePathBar->setFixedHeight(25);
        stylePathBar->setStyleSheet(QStringLiteral("background:#1b2527;"));
        auto *stylePathLayout = new QHBoxLayout(stylePathBar);
        stylePathLayout->setContentsMargins(8, 0, 5, 0);
        lcdStylePathLabel_ = new QLabel(QStringLiteral("Preset:/Pop&Rock/"), stylePathBar);
        lcdStylePathLabel_->setObjectName(QStringLiteral("lcdStylePathLabel"));
        lcdStylePathLabel_->setTextFormat(Qt::PlainText);
        lcdStylePathLabel_->setStyleSheet(QStringLiteral("color:#a5a5a5;font-size:8pt;background:transparent;"));
        stylePathLayout->addWidget(lcdStylePathLabel_);
        stylePathLayout->addStretch(1);
        stylePageLayout->addWidget(stylePathBar);

        // Match the supplied reference composition inside the LCD's existing
        // viewport. Scaling affects only Style page controls; the LCD stack,
        // surrounding panels, app window size and display resolution are untouched.
        stylePage->setResizeHandler([styleHeader, styleHeaderLayout, styleLogo, styleTitle, styleModeGroup,
                                     styleModeLayout, styleUserLabel, styleUserDiskIcon, styleFavoritesIcon,
                                     stylePresetButton = lcdStylePresetButton_,
                                     styleUserButton = lcdStyleUserButton_,
                                     styleFavoritesButton = lcdStyleFavoritesButton_,
                                     styleSearchButton, styleFileButton, styleMenuButton,
                                     styleActionDivider, styleCloseButton, styleCloseIcon,
                                     styleCategoryPane, stylePageFooter, stylePathBar,
                                     lcdStyleCategoryButtons = lcdStyleCategoryButtons_,
                                     pageButtons = lcdStylePageButtons_,
                                     previousButton = lcdStylePreviousPageButton_,
                                     nextButton = lcdStyleNextPageButton_, topButton = lcdStyleTopButton_](const QSize &viewportSize) {
            const qreal sx = std::clamp(static_cast<qreal>(viewportSize.width()) / 800.0, 0.55, 1.0);
            const qreal sy = std::clamp(static_cast<qreal>(viewportSize.height()) / 480.0, 0.55, 1.0);
            const int headerHeight = std::clamp(qRound(56 * sy), 32, 56);
            const int footerHeight = std::clamp(qRound(44 * sy), 26, 44);
            const int pathHeight = std::clamp(qRound(25 * sy), 16, 25);
            const int bodyHeight = std::max(0, viewportSize.height() - headerHeight - footerHeight - pathHeight);
            const int categoryHeight = std::clamp(qRound((bodyHeight - 31) / 5.0), 20, 50);
            const qreal textScale = std::min(sx, sy);
            styleHeader->setFixedHeight(headerHeight);
            styleHeaderLayout->setContentsMargins(std::max(8, qRound(15 * sx)), 0, 0, 0);
            // Every top-level header item receives the exact same full-height
            // cell. This gives one unambiguous vertical center line regardless
            // of the different visual sizes of icons, labels and button groups.
            styleLogo->setFixedSize(std::max(18, qRound(29 * sx)), headerHeight);
            styleTitle->setFixedHeight(headerHeight);
            styleTitle->setStyleSheet(QStringLiteral(
                "color:#ffffff;font-size:%1pt;font-weight:500;padding-left:%2px;background:transparent;")
                .arg(std::max(9, qRound(20 * textScale))).arg(std::max(4, qRound(9 * sx))));
            const int presetWidth = std::max(36, qRound(64 * sx));
            const int userWidth = std::max(40, qRound(70 * sx));
            const int favoritesWidth = std::max(36, qRound(64 * sx));
            const int modeHeight = std::max(24, qRound(38 * sy));
            styleModeGroup->setFixedSize(presetWidth + userWidth + favoritesWidth, headerHeight);
            stylePresetButton->setFixedSize(presetWidth, modeHeight);
            styleUserButton->setFixedSize(userWidth, modeHeight);
            styleFavoritesButton->setFixedSize(favoritesWidth, modeHeight);
            styleModeLayout->setAlignment(Qt::AlignVCenter);
            const int modeFont = std::max(7, qRound(11 * textScale));
            for (auto *button : styleModeGroup->findChildren<QPushButton *>()) {
                // Individual widths were assigned above so Preset, User and
                // Favorites retain their reference proportions.
                QString cornerStyle;
                if (button == stylePresetButton)
                    cornerStyle = QStringLiteral("border-top-left-radius:7px;border-bottom-left-radius:7px;");
                else if (button == styleFavoritesButton)
                    cornerStyle = QStringLiteral("border-top-right-radius:7px;border-bottom-right-radius:7px;");
                const int buttonFont = (button == styleFavoritesButton)
                    ? std::max(10, qRound(16 * textScale)) : modeFont;
                button->setStyleSheet(QStringLiteral(
                    "QPushButton{background:#354143;color:#ededed;border:1px solid #67797a;padding:1px 3px;font-size:%1pt;}"
                    "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}"
                    "QPushButton:hover{border:1px solid #ffffff;}").arg(buttonFont) + cornerStyle);
            }
            styleUserLabel->setStyleSheet(QStringLiteral(
                "color:#ededed;background:transparent;font-size:%1pt;").arg(modeFont));
            styleUserLabel->setAlignment(Qt::AlignCenter);
            styleUserLabel->ensurePolished();
            // Use the live Windows/Qt font metrics; fixed guessed heights can
            // clip glyph ascenders/descenders at non-100% display scaling.
            styleUserLabel->setFixedHeight(std::max(1, styleUserLabel->fontMetrics().height()));
            styleUserDiskIcon->setFixedSize(std::max(12, qRound(20 * sx)), std::max(12, qRound(20 * sy)));
            styleFavoritesIcon->setFixedSize(std::max(16, qRound(26 * sx)), std::max(16, qRound(26 * sy)));
            styleUserLabel->setFixedWidth(std::max(1, styleUserLabel->fontMetrics().horizontalAdvance(QStringLiteral("User"))));
            const int actionHeight = headerHeight;
            const int actionWidth = std::max(40, qRound(64 * sx));
            styleSearchButton->setFixedSize(actionWidth, actionHeight);
            styleFileButton->setFixedSize(actionWidth, actionHeight);
            styleMenuButton->setFixedSize(actionWidth, actionHeight);
            styleActionDivider->setFixedSize(1, std::max(20, qRound(44 * sy)));
            styleCloseButton->setFixedSize(actionWidth, actionHeight);
            styleCloseIcon->setFixedSize(std::max(20, qRound(34 * sx)),
                                         std::max(20, qRound(34 * sy)));
            for (auto *button : {styleSearchButton, styleFileButton, styleMenuButton}) {
                // LcdStyleHeaderIconWidget intentionally has no Q_OBJECT macro.
                // Search among QWidget children, whose Qt meta-object is available,
                // then use RTTI for the concrete custom icon type. Passing the custom
                // type directly to QObject::findChild<T>() triggers Qt 6's
                // "No Q_OBJECT in the class passed to QObject::findChild" assertion.
                for (QWidget *child : button->findChildren<QWidget *>()) {
                    if (auto *icon = dynamic_cast<LcdStyleHeaderIconWidget *>(child)) {
                        const bool isFileAction = button == styleFileButton;
                        const int iconExtent = std::max(16, qRound((isFileAction ? 34 : 30) * textScale));
                        icon->setFixedSize(iconExtent, iconExtent);
                        break;
                    }
                }
                if (auto *caption = button->findChild<QLabel *>(
                        button->objectName() + QStringLiteral("Caption"))) {
                    caption->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
                    caption->setStyleSheet(QStringLiteral(
                        "color:#ffffff;background:transparent;font-size:%1pt;font-weight:400;")
                        .arg(std::max(7, qRound(9 * textScale))));
                    caption->ensurePolished();
                    caption->setFixedHeight(std::max(1, caption->fontMetrics().height()));
                }
            }
            // The reference allocates 25.5% of the existing LCD viewport to the
            // category rail (204 px at 800 px wide); the list owns the remainder.
            // This fixes the rail edge deterministically without resizing the LCD.
            styleCategoryPane->setFixedWidth(std::clamp(
                qRound(static_cast<qreal>(viewportSize.width()) * 0.255),
                1, std::max(1, viewportSize.width())));
            for (auto *button : lcdStyleCategoryButtons) {
                if (!button) continue;
                button->setFixedHeight(categoryHeight);
                button->setStyleSheet(QStringLiteral(
                    "QPushButton{background:#2d3a3c;color:#c8cbd4;border:1px solid #5a6b6d;border-radius:3px;"
                    "padding:1px;font-size:%1pt;}"
                    "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}"
                    "QPushButton:hover{border:1px solid #e1eae8;}").arg(std::max(6, qRound(10 * sx))));
            }
            stylePageFooter->setFixedHeight(footerHeight);
            const int pageButtonWidth = std::max(30, qRound(70 * sx));
            const int pageButtonHeight = std::max(22, qRound(40 * sy));
            for (auto *button : pageButtons) {
                if (!button) continue;
                button->setFixedSize(pageButtonWidth, pageButtonHeight);
                button->setStyleSheet(QStringLiteral(
                    "QPushButton{background:#111819;color:#879493;border:1px solid #435658;border-radius:9px 9px 4px 4px;font-size:%1pt;}"
                    "QPushButton:checked{background:#0a756e;color:#ffffff;border:1px solid #69bdb3;}")
                    .arg(std::max(7, qRound(11 * textScale))));
            }
            const int navWidth = std::max(22, qRound(42 * sx));
            const int navHeight = std::max(22, qRound(38 * sy));
            for (auto *button : {previousButton, nextButton, topButton}) {
                if (!button) continue;
                button->setFixedSize(navWidth, navHeight);
                button->setStyleSheet(QStringLiteral(
                    "QPushButton{background:transparent;color:#e1eae8;border:0;font-size:%1pt;padding:0;}"
                    "QPushButton:disabled{color:#435658;}QPushButton:hover{color:#ffffff;background:#2d3d3e;}")
                    .arg(std::max(9, qRound(18 * textScale))));
            }
            stylePathBar->setFixedHeight(pathHeight);
            if (auto *label = stylePathBar->findChild<QLabel *>(QStringLiteral("lcdStylePathLabel")))
                label->setStyleSheet(QStringLiteral("color:#a5a5a5;font-size:%1pt;background:transparent;")
                    .arg(std::max(6, qRound(8 * textScale))));
        });
        lcdContentStack_->addWidget(lcdStylePickerPage_);

        // The visible page is only a ten-item window into the full preset/user
        // catalogue. Combo-box indices remain the single source of truth for
        // style loading and are stored on each visible grid item.
        auto refreshLcdStyleGrid = [this]() { rebuildLcdStyleGrid(); };

        for (auto *categoryButton : lcdStyleCategoryButtons_) {
            connect(categoryButton, &QPushButton::clicked, this, [this, categoryButton, refreshLcdStyleGrid] {
                lcdStyleCategory_ = categoryButton->property("styleCategory").toString();
                lcdStyleCategoryGroup_.clear();
                lcdStyleBadgeFilter_.clear();
                lcdStyleShortcutLabel_.clear();
                lcdStylePage_ = 0;
                lcdStyleFavoritesOnly_ = false;
                refreshLcdStyleGrid();
            });
        }
        for (int pageIndex = 0; pageIndex < static_cast<int>(lcdStylePageButtons_.size()); ++pageIndex) {
            auto *pageButton = lcdStylePageButtons_[static_cast<std::size_t>(pageIndex)];
            if (pageButton) connect(pageButton, &QPushButton::clicked, this, [this, pageIndex, refreshLcdStyleGrid] {
                lcdStylePage_ = (lcdStylePage_ / 5) * 5 + pageIndex;
                refreshLcdStyleGrid();
            });
        }
        connect(lcdStylePreviousPageButton_, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            lcdStylePage_ = std::max(0, lcdStylePage_ - 1); refreshLcdStyleGrid();
        });
        connect(lcdStyleNextPageButton_, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            lcdStylePage_ = std::min(lcdStylePageCount_ - 1, lcdStylePage_ + 1); refreshLcdStyleGrid();
        });
        connect(lcdStyleTopButton_, &QPushButton::clicked, this, [this] {
            if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
        });
        connect(lcdStylePresetButton_, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            lcdStyleUserMode_ = false;
            lcdStyleCategoryGroup_.clear(); lcdStyleBadgeFilter_.clear(); lcdStyleShortcutLabel_.clear();
            lcdStylePage_ = 0; refreshLcdStyleGrid();
        });
        connect(lcdStyleUserButton_, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            lcdStyleUserMode_ = true;
            lcdStyleCategoryGroup_.clear(); lcdStyleBadgeFilter_.clear(); lcdStyleShortcutLabel_.clear();
            lcdStylePage_ = 0; refreshLcdStyleGrid();
        });
        connect(lcdStyleFavoritesButton_, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            lcdStyleFavoritesOnly_ = !lcdStyleFavoritesOnly_; lcdStylePage_ = 0; refreshLcdStyleGrid();
        });
        connect(styleSearchButton, &QPushButton::clicked, this, [this, refreshLcdStyleGrid] {
            bool accepted = false;
            const QString query = QInputDialog::getText(this, QStringLiteral("Search Styles"),
                QStringLiteral("Style name:"), QLineEdit::Normal, lcdStyleSearchText_, &accepted);
            if (accepted) { lcdStyleSearchText_ = query.trimmed(); lcdStylePage_ = 0; refreshLcdStyleGrid(); }
        });
        connect(styleFileButton, &QPushButton::clicked, this, [this] { openStyleFileFromPc(); });
        connect(styleCloseButton, &QPushButton::clicked, this, [this] {
            if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
        });
        connect(styleMenuButton, &QPushButton::clicked, this, [this, styleMenuButton] {
            QMenu menu(styleMenuButton);
            QAction *openPresetFolder = menu.addAction(QStringLiteral("Open Yamaha PSR-S Folder"));
            QAction *openUserFolder = menu.addAction(QStringLiteral("Open User Style Folder"));
            QAction *chosen = menu.exec(styleMenuButton->mapToGlobal(QPoint(0, styleMenuButton->height())));
            QString directory;
            if (chosen == openPresetFolder)
                directory = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("data/StyleFiles/Yamaha PSR-S"));
            else if (chosen == openUserFolder) {
                const QString documents = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
                directory = QDir(documents).filePath(QStringLiteral("ensembles/styles"));
                QDir().mkpath(directory);
            }
            if (!directory.isEmpty()) QDesktopServices::openUrl(QUrl::fromLocalFile(directory));
        });
        connect(lcdStyleList_, &QListWidget::currentRowChanged, this, [this](int row) {
            if (row < 0 || !lcdStyleList_->item(row) || !styleCombo_) return;
            const int comboIndex = lcdStyleList_->item(row)->data(Qt::UserRole + 3).toInt();
            if (comboIndex >= 0 && comboIndex < styleCombo_->count() && styleCombo_->currentIndex() != comboIndex)
                styleCombo_->setCurrentIndex(comboIndex);
        });
        connect(lcdStyleList_, &QListWidget::customContextMenuRequested, this,
            [this, refreshLcdStyleGrid](const QPoint &position) {
                auto *item = lcdStyleList_ ? lcdStyleList_->itemAt(position) : nullptr;
                if (!item) return;
                const QString path = item->data(Qt::UserRole).toString();
                const bool isFavorite = lcdStyleFavoritePaths_.contains(path);
                QMenu menu(lcdStyleList_);
                QAction *toggleFavorite = menu.addAction(isFavorite ? QStringLiteral("Remove Favorite")
                                                                    : QStringLiteral("Add to Favorites"));
                if (menu.exec(lcdStyleList_->mapToGlobal(position)) != toggleFavorite) return;
                if (isFavorite) lcdStyleFavoritePaths_.removeAll(path);
                else lcdStyleFavoritePaths_.push_back(path);
                QSettings settings;
                settings.setValue(QStringLiteral("stylePicker/favorites"), lcdStyleFavoritePaths_);
                refreshLcdStyleGrid();
            });
        lcdStyleList_->setContextMenuPolicy(Qt::CustomContextMenu);
        QSettings stylePickerSettings;
        lcdStyleFavoritePaths_ = stylePickerSettings.value(QStringLiteral("stylePicker/favorites")).toStringList();
        refreshLcdStyleGrid();

        startupTrace("buildUi: picker widgets created; loading SCVSC voice catalog");
        // Build the voice browser from the shipped Roland SCVSC tone-file catalog.
        // The TNF contains real map/program/CC0 variation names for all four maps.
        loadVoiceCatalog();
        if (voiceCatalog_.empty()) {
            for (int program = 0; program < static_cast<int>(kPatchNames.size()); ++program) {
                VoiceCatalogEntry entry; entry.program = program; entry.bank = 0; entry.map = 4;
                entry.name = QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
                entry.category = voiceCategoryForProgram(program); voiceCatalog_.push_back(entry);
            }
        }
        startupTrace("buildUi: voice catalog populated; embedded LCD Voice Select page will build on demand");

        // Reference screenshot at 1344x704: side banks occupy about 31% each and
        // the LCD deck about 37.5%. Stretch weights are calibrated to the 407/500/421 px
        // panel widths after margins and the two 4 px gutters are deducted.
        startupTrace("mainPanel: before adding center widget to top layout");
        topLayout->addWidget(centerTop, 375);
        startupTrace("mainPanel: center widget added to top layout");

        startupTrace("rightPanel: before makePanel");
        auto *rightTop = makePanel(topRow);
        startupTrace("rightPanel: makePanel complete");
        auto *rightTopLayout = new QVBoxLayout(rightTop);
        startupTrace("rightPanel: layout constructed");
        rightTopLayout->setContentsMargins(4, 0, 4, 3);
        rightTopLayout->setSpacing(0);
        auto *controlsTop = new QWidget(rightTop);
        startupTrace("rightPanel: controlsTop constructed");
        // The reference's upper right deck has three distinct vertical zones:
        // (1) encoder/toggles/effects on the left, (2) four tall part faders on the right,
        // (3) a short transpose/octave/tempo/arpeggiator row along the bottom.
        controlsTop->setFixedHeight(229);
        auto *controlsTopLayout = new QHBoxLayout(controlsTop);
        controlsTopLayout->setContentsMargins(0, 0, 0, 0);
        controlsTopLayout->setSpacing(0);

        auto *leftControlBlock = new QWidget(controlsTop);
        leftControlBlock->setFixedWidth(198);
        auto *leftControlBlockLayout = new QVBoxLayout(leftControlBlock);
        leftControlBlockLayout->setContentsMargins(0, 0, 0, 0);
        // Reference coordinates: encoder/mode deck ends at y=258 and effects begin at y=258.
        leftControlBlockLayout->setSpacing(0);
        auto *upperControlRow = new QWidget(leftControlBlock);
        upperControlRow->setFixedHeight(196);
        auto *upperControlRowLayout = new QHBoxLayout(upperControlRow);
        // Target screenshot, relative to the right-panel content origin: the encoder
        // center is x=996 and the Chords column starts at x=1062 (1344x704 canvas).
        upperControlRowLayout->setContentsMargins(11, 0, 0, 0);
        upperControlRowLayout->setSpacing(1);
        leftControlBlockLayout->addWidget(upperControlRow);

        // Large encoder = Data Entry / scroll through the active Voice or Style picker.
        // Size and spacing follow the supplied reference image rather than shrinking it to
        // the same size as the four small left-panel knobs.
        auto *dialArea = new QWidget(upperControlRow);
        dialArea->setFixedWidth(130);
        auto *dialAreaLayout = new QVBoxLayout(dialArea);
        dialAreaLayout->setContentsMargins(0, 0, 0, 0);
        dialAreaLayout->setSpacing(0);
        // Reference canvas: the encoder face begins at y=80 (inner panel origin y=62).
        dialAreaLayout->addSpacing(18);
        dataEntryDial_ = new PanelDial(dialArea);
        dataEntryDial_->setObjectName(QStringLiteral("dataEntryDial"));
        dataEntryDial_->setRange(0, 127);
        dataEntryDial_->setWrapping(true);
        dataEntryDial_->setValue(dataEntryDialLastValue_);
        dataEntryDial_->setFixedSize(110, 110);
        dataEntryDial_->setToolTip(QStringLiteral("Data Entry / Scroll: putar untuk memilih Voice atau Style pada LCD. Gunakan tombol panah untuk membuka/menutup picker."));
        connect(dataEntryDial_, &QDial::valueChanged, this, [this](int value) { rotateDataEntryDial(value); });
        dialAreaLayout->addWidget(dataEntryDial_, 0, Qt::AlignHCenter);
        dialAreaLayout->addSpacing(13);
        auto *dataEntryButtons = new QHBoxLayout;
        dataEntryButtons->setContentsMargins(0, 0, 0, 0);
        dataEntryButtons->setSpacing(5);
        auto *minusDialButton = new QPushButton(QStringLiteral("−"), dialArea);
        auto *activateDialButton = new QPushButton(QStringLiteral("→"), dialArea);
        auto *plusDialButton = new QPushButton(QStringLiteral("+"), dialArea);
        for (auto *b : {minusDialButton, activateDialButton, plusDialButton}) {
            b->setObjectName(QStringLiteral("dataEntryStepButton"));
            b->setFixedSize(28, 28);
            b->setStyleSheet(QStringLiteral("QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #494949,stop:1 #1b2527);border:1px solid #151515;border-top:1px solid #5a6b6d;border-radius:0;padding:0;font-size:10pt;color:#f0f0f0;} QPushButton:pressed{background:#222;border-top:2px solid #48b1a5;}"));
        }
        minusDialButton->setToolTip(QStringLiteral("Item sebelumnya"));
        plusDialButton->setToolTip(QStringLiteral("Item berikutnya"));
        activateDialButton->setToolTip(QStringLiteral("Buka picker / kembali ke LCD utama"));
        connect(minusDialButton, &QPushButton::clicked, this, [this] { if (dataEntryDial_) dataEntryDial_->setValue(dataEntryDial_->value() - 1); });
        connect(plusDialButton, &QPushButton::clicked, this, [this] { if (dataEntryDial_) dataEntryDial_->setValue(dataEntryDial_->value() + 1); });
        connect(activateDialButton, &QPushButton::clicked, this, [this] { activateDataEntryContext(); });
        dataEntryButtons->addWidget(minusDialButton);
        dataEntryButtons->addWidget(activateDialButton);
        dataEntryButtons->addWidget(plusDialButton);
        dialAreaLayout->addLayout(dataEntryButtons);
        dialAreaLayout->setAlignment(dataEntryButtons, Qt::AlignHCenter);
        upperControlRowLayout->addWidget(dialArea, 0);

        auto *toggleColumn = new QVBoxLayout;
        toggleColumn->setSpacing(5);
        // Reserve the same compact column for Style, Chords, Layer and Split.
        // Style is an action (open picker), not an ON/OFF toggle.
        toggleColumn->addSpacing(66);
        auto *styleButton = new QPushButton(QStringLiteral("Style"), upperControlRow);
        styleButton->setObjectName(QStringLiteral("rightPanelStyleButton"));
        styleButton->setFixedSize(52, 22);
        styleButton->setCheckable(false);
        styleButton->setStyleSheet(QStringLiteral("QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #455759,stop:1 #1b2527);border:1px solid #151515;border-top:2px solid #687a7b;border-radius:0;padding:0;font-size:8pt;color:#ededed;} QPushButton:pressed{border-top:3px solid #48b1a5;background:#2d3d3e;}"));
        styleButton->setToolTip(QStringLiteral("Pilih Style arranger"));
        connect(styleButton, &QPushButton::clicked, this, [this] {
            dataEntryStyleMode_ = true;
            if (lcdContentStack_ && lcdStylePickerPage_)
                lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
            if (lcdStyleList_ && lcdStyleList_->currentItem())
                lcdStyleList_->scrollToItem(lcdStyleList_->currentItem(), QAbstractItemView::PositionAtCenter);
        });
        toggleColumn->addWidget(styleButton);
        accompButton_ = new QPushButton(QStringLiteral("Chords"), upperControlRow);
        layerButton_ = new QPushButton(QStringLiteral("Layer"), upperControlRow);
        splitButton_ = new QPushButton(QStringLiteral("Split"), upperControlRow);
        for (auto *b : {accompButton_, layerButton_, splitButton_}) {
            b->setObjectName(QStringLiteral("rightPanelModeButton"));
            b->setFixedSize(52, 22);
            b->setCheckable(true);
            b->setStyleSheet(QStringLiteral("QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #455759,stop:1 #1b2527);border:1px solid #151515;border-top:2px solid #687a7b;border-radius:0;padding:0;font-size:8pt;color:#ededed;} QPushButton:checked{border-top:3px solid #48b1a5;background:#2d3d3e;}"));
            toggleColumn->addWidget(b);
        }
        connect(accompButton_, &QPushButton::toggled, this, [this](bool on) {
            accompanimentEnabled_ = on;
            styleEngine_.setChordControlEnabled(on);
            if (styleChordControlButton_ && styleChordControlButton_->isChecked() != on)
                styleChordControlButton_->setChecked(on);
            if (!on) allSoundsOff();
            savePanelSettings();
            setStatus(on ? QStringLiteral("Chords aktif: style accompaniment mengikuti chord keyboard.")
                         : QStringLiteral("Chords nonaktif: keyboard memainkan Voice langsung."));
        });
        connect(layerButton_, &QPushButton::toggled, this, [this](bool on) {
            layerEnabled_ = on; savePanelSettings();
            // Layer is a quick toggle for R2; the independent R2 ON/OFF button can still be used afterwards.
            if (rightVoiceOnButtons_[2] && rightVoiceOnButtons_[2]->isChecked() != on)
                rightVoiceOnButtons_[2]->setChecked(on);
            setStatus(on ? QStringLiteral("Layer aktif: Voice R2 ditambahkan ke melodi kanan.") : QStringLiteral("Layer nonaktif: Voice R2 dimatikan oleh tombol Layer."));
        });
        connect(splitButton_, &QPushButton::toggled, this, [this](bool on) {
            splitEnabled_ = on; savePanelSettings();
            setStatus(on ? QStringLiteral("Split aktif pada key %1.").arg(splitKey_) : QStringLiteral("Split nonaktif: seluruh keyboard memakai Voice kanan."));
        });
        upperControlRowLayout->addLayout(toggleColumn, 0);
        upperControlRowLayout->addStretch(1);

        auto *rightFadersRow = new QWidget(controlsTop);
        rightFadersRow->setFixedWidth(180);
        auto *rightFadersLayout = new QHBoxLayout(rightFadersRow);
        rightFadersLayout->setContentsMargins(0, 0, 0, 0);
        rightFadersLayout->setSpacing(3);
        static const std::array<const char *, 4> rightFaderLabels = {"L", "R1", "R2", "R3"};
        static const std::array<int, 4> rightExternalChannels = {1, 0, 2, 3};
        static const std::array<int, 4> rightInternalChannels = {19, 17, 18, 3};
        QSettings rightFaderSettings;
        for (int i = 0; i < 4; ++i) {
            auto *cell = new QWidget(rightFadersRow);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(0);
            // Reference fader track: y=93..241 on the 1344x704 target canvas.
            cellLayout->addSpacing(31);
            auto *slider = new QSlider(Qt::Vertical, cell);
            slider->setObjectName(QStringLiteral("rightPartFader_%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            slider->setRange(0, 127);
            // Arranger reference startup: all four keyboard-part faders begin at exactly 100.
            // Ignore stale per-part values from older versions so the caps always align on launch.
            slider->setValue(100);
            rightFaderSettings.setValue(
                QStringLiteral("panel/rightFader%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])), 100);
            slider->setMinimumWidth(12);
            slider->setFixedHeight(148);
            // Match the reference gold fader cap (the app stylesheet uses this property).
            slider->setProperty("masterTarget", true);
            slider->setInvertedAppearance(false);
            slider->setToolTip(QStringLiteral("Volume Voice %1 — MIDI CC7; atas = lebih keras, bawah = lebih pelan.")
                .arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            rightVoiceFaders_[static_cast<std::size_t>(i)] = slider;
            connect(slider, &QSlider::valueChanged, this, [this, i](int value) {
                const int extChannel = rightExternalChannels[static_cast<std::size_t>(i)];
                const int intChannel = rightInternalChannels[static_cast<std::size_t>(i)];
                const bool enabled = rightVoiceEnabled_[static_cast<std::size_t>(i)];
                sendMidi(static_cast<quint8>(0xB0 | extChannel), 7,
                         static_cast<quint8>(enabled ? std::clamp(value, 0, 127) : 0), intChannel);
                QSettings settings;
                settings.setValue(QStringLiteral("panel/rightFader%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])), value);
                settings.sync();
            });
            auto *partIndicator = new QLabel(cell);
            partIndicator->setObjectName(QStringLiteral("rightPartIndicator_%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            partIndicator->setFixedSize(12, 3);
            partIndicator->setStyleSheet(rightVoiceEnabled_[static_cast<std::size_t>(i)]
                ? QStringLiteral("background:#e53935;border:0px;border-radius:1px;")
                : QStringLiteral("background:#39a99e;border:0px;border-radius:1px;"));
            auto *partOnButton = new QPushButton(QString(), cell);
            partOnButton->setObjectName(QStringLiteral("rightPartToggle_%1").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            partOnButton->setCheckable(true);
            partOnButton->setChecked(rightVoiceEnabled_[static_cast<std::size_t>(i)]);
            partOnButton->setAccessibleName(QStringLiteral("Voice %1 ON/OFF").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            partOnButton->setFixedSize(36, 18);
            partOnButton->setStyleSheet(QStringLiteral("QPushButton{background:#353535;border:1px solid #111;border-top:1px solid #3b4c4e;border-radius:0;padding:0;color:#eee;} QPushButton:checked{background:#293638;border-top:1px solid #3b4c4e;}"));
            partOnButton->setToolTip(QStringLiteral("Aktif/nonaktif Voice %1.").arg(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)])));
            rightVoiceOnButtons_[static_cast<std::size_t>(i)] = partOnButton;
            connect(partOnButton, &QPushButton::toggled, this, [this, i, partOnButton, partIndicator](bool enabled) {
                partOnButton->setText(QString());
                // The indicator is always visible: teal = inactive, red = active.
                partIndicator->setStyleSheet(enabled
                    ? QStringLiteral("background:#e53935;border:0px;border-radius:1px;")
                    : QStringLiteral("background:#39a99e;border:0px;border-radius:1px;"));
                applyRightVoicePartState(i, enabled);
            });
            // Reference order: long fader, short L/R label, then the independent ON/OFF switch.
            cellLayout->addWidget(slider, 0, Qt::AlignHCenter);
            auto *label = new QLabel(QString::fromLatin1(rightFaderLabels[static_cast<std::size_t>(i)]), cell);
            label->setAlignment(Qt::AlignCenter);
            label->setFixedHeight(17);
            label->setStyleSheet(QStringLiteral("font-weight:600;color:#0a756e;font-size:8pt;"));
            cellLayout->addWidget(label);
            // The target puts the small blue/red part status strip UNDER its name,
            // immediately above a compact blank switch—not at the top of the fader.
            cellLayout->addWidget(partIndicator, 0, Qt::AlignHCenter);
            cellLayout->addSpacing(1);
            cellLayout->addWidget(partOnButton, 0, Qt::AlignHCenter);
            cellLayout->addStretch(1);
            rightFadersLayout->addWidget(cell, 1);
        }
        rightFaderSettings.sync();
        controlsTopLayout->addWidget(leftControlBlock, 0);
        controlsTopLayout->addSpacing(12);
        controlsTopLayout->addWidget(rightFadersRow, 0);
        controlsTopLayout->addStretch(1);
        rightTopLayout->addWidget(controlsTop);
        startupTrace("rightPanel: top controls complete");

        auto *parameterPanel = new QWidget(rightTop);
        auto *parameterPanelLayout = new QVBoxLayout(parameterPanel);
        parameterPanelLayout->setContentsMargins(0, 0, 0, 0);
        parameterPanelLayout->setSpacing(0);

        // Reverb / EFX Setup / Chorus live directly beneath the encoder/toggle bank,
        // while the part faders keep their own full-height columns to the right.
        auto *effectsRowWidget = new QWidget(leftControlBlock);
        effectsRowWidget->setFixedHeight(36);
        auto *effectsRow = new QHBoxLayout(effectsRowWidget);
        effectsRow->setContentsMargins(4, 0, 1, 0);
        effectsRow->setSpacing(0);
        reverbButton_ = new QToolButton(effectsRowWidget);
        reverbButton_->setObjectName(QStringLiteral("rightPanelEffectButton"));
        reverbButton_->setText(QStringLiteral("Reverb"));
        reverbButton_->setCheckable(true);
        reverbLevelSpin_ = new QSpinBox(parameterPanel);
        reverbLevelSpin_->setRange(0, 10); reverbLevelSpin_->setValue(7); reverbLevelSpin_->hide();
        auto *efxCell = new QWidget(effectsRowWidget);
        auto *efxCellLayout = new QVBoxLayout(efxCell);
        efxCellLayout->setContentsMargins(0, 0, 0, 0); efxCellLayout->setSpacing(0);
        nativeEfxPanelButton_ = new QToolButton(efxCell);
        nativeEfxPanelButton_->setObjectName(QStringLiteral("rightPanelEffectButton"));
        nativeEfxPanelButton_->setText(QStringLiteral("EFX Setup"));
        nativeEfxPanelButton_->setCheckable(true);
        nativeEfxPanelButton_->setToolButtonStyle(Qt::ToolButtonTextOnly);
        nativeEfxPanelButton_->setFixedHeight(22);
        nativeEfxNameLabel_ = new QLabel(nativeEfxTypeCombo_ ? nativeEfxTypeCombo_->currentText() : QStringLiteral("Overdrive"), efxCell);
        nativeEfxNameLabel_->setAlignment(Qt::AlignCenter);
        nativeEfxNameLabel_->setStyleSheet(QStringLiteral("color:#d7e9e7;font-size:7pt;"));
        nativeEfxNameLabel_->setFixedHeight(14);
        nativeEfxNameLabel_->setToolTip(QStringLiteral("Native SCVA insertion effect; EFX Setup opens effect type and parameters."));
        efxCellLayout->addWidget(nativeEfxPanelButton_); efxCellLayout->addWidget(nativeEfxNameLabel_);
        chorusButton_ = new QToolButton(effectsRowWidget);
        chorusButton_->setObjectName(QStringLiteral("rightPanelEffectButton"));
        chorusButton_->setText(QStringLiteral("Chorus"));
        chorusButton_->setCheckable(true);
        chorusLevelSpin_ = new QSpinBox(parameterPanel);
        chorusLevelSpin_->setRange(0, 10); chorusLevelSpin_->setValue(2); chorusLevelSpin_->hide();
        reverbButton_->setFixedSize(54, 22);
        efxCell->setFixedWidth(59);
        chorusButton_->setFixedSize(58, 22);
        effectsRow->addWidget(reverbButton_, 0, Qt::AlignTop);
        effectsRow->addSpacing(11);
        effectsRow->addWidget(efxCell, 0, Qt::AlignTop);
        effectsRow->addSpacing(10);
        effectsRow->addWidget(chorusButton_, 0, Qt::AlignTop);
        effectsRow->addStretch(1);
        leftControlBlockLayout->addWidget(effectsRowWidget);

        auto makeAdjustGroup = [parameterPanel](const QString &title, QToolButton **toggleOut, QSpinBox **spinOut, int minimum, int maximum, int initial) {
            auto *group = new QWidget(parameterPanel);
            auto *layout = new QVBoxLayout(group);
            layout->setContentsMargins(0, 0, 0, 0); layout->setSpacing(1);
            auto *toggle = new QToolButton(group);
            toggle->setText(title); toggle->setCheckable(true); toggle->setFixedHeight(16);
            QFont smallHeadingFont = toggle->font(); smallHeadingFont.setPointSize(6); toggle->setFont(smallHeadingFont);
            auto *buttons = new QWidget(group);
            auto *buttonLayout = new QHBoxLayout(buttons);
            buttonLayout->setContentsMargins(0, 0, 0, 0); buttonLayout->setSpacing(2);
            auto *minus = new QPushButton(QStringLiteral("−"), buttons);
            auto *plus = new QPushButton(QStringLiteral("+"), buttons);
            minus->setFixedHeight(20); plus->setFixedHeight(20);
            buttonLayout->addWidget(minus); buttonLayout->addWidget(plus);
            auto *spin = new QSpinBox(group);
            spin->setRange(minimum, maximum); spin->setValue(initial); spin->hide();
            connect(minus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() - 1); });
            connect(plus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() + 1); });
            layout->addWidget(toggle); layout->addWidget(buttons);
            if (toggleOut) *toggleOut = toggle;
            if (spinOut) *spinOut = spin;
            return group;
        };
        // TRANSPOSE and OCTAVE are continuous arranger parameters: heading + minus/plus only.
        // They are deliberately not checkable buttons and have no ON/OFF state.
        auto makeStepAdjustGroup = [parameterPanel](const QString &title, QSpinBox **spinOut,
                                                    int minimum, int maximum, int initial) {
            auto *group = new QWidget(parameterPanel);
            auto *layout = new QVBoxLayout(group);
            layout->setContentsMargins(0, 0, 0, 0);
            layout->setSpacing(1);
            auto *heading = new QLabel(title, group);
            heading->setAlignment(Qt::AlignCenter);
            heading->setFixedHeight(16);
            QFont headingFont = heading->font();
            headingFont.setPointSize(6);
            heading->setFont(headingFont);
            auto *buttons = new QWidget(group);
            auto *buttonLayout = new QHBoxLayout(buttons);
            buttonLayout->setContentsMargins(0, 0, 0, 0);
            buttonLayout->setSpacing(2);
            auto *minus = new QPushButton(QStringLiteral("−"), buttons);
            auto *plus = new QPushButton(QStringLiteral("+"), buttons);
            minus->setFixedHeight(20);
            plus->setFixedHeight(20);
            buttonLayout->addWidget(minus);
            buttonLayout->addWidget(plus);
            auto *spin = new QSpinBox(group);
            spin->setRange(minimum, maximum);
            spin->setValue(initial);
            spin->hide();
            connect(minus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() - 1); });
            connect(plus, &QPushButton::clicked, spin, [spin] { spin->setValue(spin->value() + 1); });
            layout->addWidget(heading);
            layout->addWidget(buttons);
            if (spinOut) *spinOut = spin;
            return group;
        };
        auto *adjustRow = new QHBoxLayout;
        adjustRow->setContentsMargins(4, 0, 0, 0); adjustRow->setSpacing(0);
        auto *transposeGroup = makeStepAdjustGroup(QStringLiteral("TRANSPOSE"), &transposeSpin_, -12, 12, 0);
        transposeGroup->setFixedWidth(58);
        auto *octaveGroup = makeStepAdjustGroup(QStringLiteral("OCTAVE"), &octaveSpin_, -2, 2, 0);
        octaveGroup->setFixedWidth(59);
        adjustRow->addWidget(transposeGroup, 0, Qt::AlignLeft);
        adjustRow->addSpacing(48);
        adjustRow->addWidget(octaveGroup, 0, Qt::AlignLeft);
        adjustRow->addSpacing(47);

        // Tempo uses the existing Settings slider as the single source of truth.
        auto *panelTempoGroup = new QWidget(parameterPanel);
        auto *tempoLayout = new QVBoxLayout(panelTempoGroup);
        tempoLayout->setContentsMargins(0, 0, 0, 0); tempoLayout->setSpacing(1);
        auto *tempoLabelButton = new QToolButton(panelTempoGroup);
        tempoLabelButton->setObjectName(QStringLiteral("rightPanelTempoHeading"));
        tempoLabelButton->setText(QStringLiteral("TEMPO")); tempoLabelButton->setFixedHeight(16);
        QFont tempoHeadingFont = tempoLabelButton->font(); tempoHeadingFont.setPointSize(6); tempoLabelButton->setFont(tempoHeadingFont);
        auto *tempoStepRow = new QWidget(panelTempoGroup);
        auto *tempoStepLayout = new QHBoxLayout(tempoStepRow);
        tempoStepLayout->setContentsMargins(0, 0, 0, 0); tempoStepLayout->setSpacing(2);
        auto *tempoMinus = new QPushButton(QStringLiteral("−"), tempoStepRow);
        auto *tempoPlus = new QPushButton(QStringLiteral("+"), tempoStepRow);
        tempoMinus->setFixedHeight(20); tempoPlus->setFixedHeight(20);
        connect(tempoMinus, &QPushButton::clicked, this, [this] { if (tempoSlider_) tempoSlider_->setValue(std::max(40, tempoSlider_->value() - 1)); });
        connect(tempoPlus, &QPushButton::clicked, this, [this] { if (tempoSlider_) tempoSlider_->setValue(std::min(240, tempoSlider_->value() + 1)); });
        tempoStepLayout->addWidget(tempoMinus); tempoStepLayout->addWidget(tempoPlus);
        tempoLayout->addWidget(tempoLabelButton); tempoLayout->addWidget(tempoStepRow);
        panelTempoGroup->setFixedWidth(64);
        adjustRow->addWidget(panelTempoGroup, 0, Qt::AlignLeft);
        adjustRow->addSpacing(25);
        auto *arpGroup = makeAdjustGroup(QStringLiteral("ARPEGGIATOR"), &arpButton_, &arpSpin_, 1, 12, 1);
        arpGroup->setFixedWidth(86);
        adjustRow->addWidget(arpGroup, 0, Qt::AlignLeft);
        adjustRow->addStretch(1);
        parameterPanelLayout->addLayout(adjustRow);
        parameterPanelLayout->addStretch(1);

        nativeEfxPanelButton_->setChecked(nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        connect(nativeEfxPanelButton_, &QToolButton::toggled, this, [this](bool on) {
            if (nativeEfxCheck_ && nativeEfxCheck_->isChecked() != on) nativeEfxCheck_->setChecked(on);
        });
        connect(nativeEfxPanelButton_, &QToolButton::clicked, this, [this] { if (settingsDialog_) settingsDialog_->show(); });
        if (nativeEfxTypeCombo_) connect(nativeEfxTypeCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] {
            if (nativeEfxNameLabel_ && nativeEfxTypeCombo_) nativeEfxNameLabel_->setText(nativeEfxTypeCombo_->currentText());
        });
        if (nativeEfxCheck_) connect(nativeEfxCheck_, &QCheckBox::toggled, this, [this](bool on) {
            if (nativeEfxPanelButton_ && nativeEfxPanelButton_->isChecked() != on) nativeEfxPanelButton_->setChecked(on);
        });
        rightTopLayout->addWidget(parameterPanel, 1);
        startupTrace("rightPanel: parameter grid added");
        auto *transStatus = new QLabel(QStringLiteral(""), rightTop);
        transStatus->setVisible(false);
        reverbButton_->setCheckable(true);
        chorusButton_->setCheckable(true);
        arpButton_->setCheckable(true);
        // The Harmonizer card is not present in the current right-panel grid, so its
        // optional pointer remains null. Never dereference it until a real widget is added.
        if (harmonizerButton_) harmonizerButton_->setCheckable(true);
        // Arpeggiator is implemented below as a keyboard-held-note MIDI sequencer. The
        // Harmonizer remains unavailable because the original multi-note algorithm is not ported.
        arpButton_->setEnabled(true);
        arpSpin_->setEnabled(true);
        arpButton_->setToolTip(QStringLiteral("Arpeggiator aktif: tahan beberapa nada pada keyboard. Pola 1-4 naik, 5-8 turun, 9-12 naik-turun."));
        arpSpin_->setToolTip(QStringLiteral("Pola arpeggio: arah ditentukan kelompok 1-4 / 5-8 / 9-12; angka terakhir menentukan pembagian tempo."));
        if (harmonizerButton_) {
            harmonizerButton_->setEnabled(false);
            harmonizerButton_->setToolTip(QStringLiteral("Harmonizer belum tersedia: algoritma harmoni asli belum dipindahkan."));
        }
        if (harmonizerSpin_) {
            harmonizerSpin_->setEnabled(false);
            harmonizerSpin_->setToolTip(QStringLiteral("Harmonizer belum tersedia: algoritma harmoni asli belum dipindahkan."));
        }
        arpeggiatorTimer_.setSingleShot(false);
        connect(&arpeggiatorTimer_, &QTimer::timeout, this, [this] { advanceArpeggiator(); });
        connect(arpButton_, &QToolButton::toggled, this, [this](bool on) {
            if (!on) stopArpeggiator(true);
            else updateArpeggiatorTimer();
            savePanelSettings();
            setStatus(on ? QStringLiteral("Arpeggiator aktif — tahan nada untuk mulai.") : QStringLiteral("Arpeggiator nonaktif."));
        });
        connect(transposeSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            transposeAmount_ = value;
            if (transposeMetricLabel_) transposeMetricLabel_->setText(QString::number(value));
            savePanelSettings();
        });
        connect(octaveSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            octaveShiftAmount_ = value;
            if (octaveMetricLabel_) octaveMetricLabel_->setText(QString::number(value));
            savePanelSettings();
        });
        connect(arpSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int) { updateArpeggiatorTimer(); savePanelSettings(); });
        if (harmonizerSpin_) connect(harmonizerSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int) { savePanelSettings(); });
        connect(reverbButton_, &QToolButton::toggled, this, [this](bool on) {
            if (reverbCheck_ && reverbCheck_->isChecked() != on) reverbCheck_->setChecked(on);
            savePanelSettings();
        });
        connect(chorusButton_, &QToolButton::toggled, this, [this](bool on) {
            if (chorusCheck_ && chorusCheck_->isChecked() != on) chorusCheck_->setChecked(on);
            savePanelSettings();
        });
        connect(reverbLevelSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            Q_UNUSED(value);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        connect(chorusLevelSpin_, qOverload<int>(&QSpinBox::valueChanged), this, [this](int value) {
            Q_UNUSED(value);
            applyPanelMidiSettings();
            savePanelSettings();
        });
        // Finish the right-deck buttons as tactile hardware caps. This is deliberately
        // done after construction so it covers the Style/Chords/Layer/Split controls,
        // effects, transpose/octave/tempo step keys, arpeggiator and the four part switches.
        // Remove older per-widget mini styles so one consistent Genos2-inspired face is used.
        const auto rightDeckButtons = rightTop->findChildren<QAbstractButton *>();
        for (QAbstractButton *button : rightDeckButtons) {
            if (!button || button->objectName() == QStringLiteral("rightPanelTempoHeading")) continue;
            button->setStyleSheet(QString());
            button->setProperty("genosPhysicalButton", true);
            button->style()->unpolish(button);
            button->style()->polish(button);
            button->update();
        }

        startupTrace("rightPanel: before adding right panel to top layout");
        topLayout->addWidget(rightTop, 315);
        startupTrace("rightPanel: added right panel to top layout");
        topRow->setFixedHeight(282); // Match the reference deck height and keep its six faders fully visible.
        startupTrace("mainPanel: top row fixed height set");
        root->addWidget(topRow);
        startupTrace("mainPanel: top row added to root");

        // Secondary row contains Yamaha-style category keys, the single-row 8-part style mixer, and sampling pads.
        startupTrace("middleRow: before row construction");
        auto *middleRow = new QWidget(central);
        auto *middleLayout = new QHBoxLayout(middleRow);
        startupTrace("middleRow: row and layout constructed");
        middleLayout->setContentsMargins(0, 0, 0, 0);
        middleLayout->setSpacing(4);
        // Lower-left STYLE category shortcut panel. Its 5x2 key layout follows
        // the supplied reference panel; each caption sits above a compact hardware
        // key, and selecting a key opens the existing LCD Style browser.
        startupTrace("middleRow: before STYLE category shortcut panel");
        auto *styleShortcutPanel = new QFrame(middleRow);
        styleShortcutPanel->setObjectName(QStringLiteral("styleCategoryShortcutPanel"));
        styleShortcutPanel->setFrameShape(QFrame::NoFrame);
        styleShortcutPanel->setStyleSheet(QStringLiteral(
            "QFrame#styleCategoryShortcutPanel{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #30383a,stop:1 #171d1f);border:1px solid #080b0c;}"));
        auto *styleShortcutLayout = new QVBoxLayout(styleShortcutPanel);
        styleShortcutLayout->setContentsMargins(7, 5, 7, 5);
        styleShortcutLayout->setSpacing(2);

        auto *styleShortcutHeading = new QWidget(styleShortcutPanel);
        styleShortcutHeading->setStyleSheet(QStringLiteral("background:transparent;"));
        auto *styleShortcutHeadingLayout = new QHBoxLayout(styleShortcutHeading);
        styleShortcutHeadingLayout->setContentsMargins(0, 0, 0, 0);
        styleShortcutHeadingLayout->setSpacing(6);
        auto *styleShortcutTitle = new QLabel(QStringLiteral("STYLE"), styleShortcutHeading);
        styleShortcutTitle->setStyleSheet(QStringLiteral(
            "color:#e4eae9;background:transparent;font-size:9pt;font-weight:700;letter-spacing:1px;"));
        styleShortcutTitle->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        auto *styleShortcutRule = new QFrame(styleShortcutHeading);
        styleShortcutRule->setFrameShape(QFrame::HLine);
        styleShortcutRule->setStyleSheet(QStringLiteral("color:#657173;background:#657173;max-height:1px;"));
        styleShortcutHeadingLayout->addWidget(styleShortcutTitle);
        styleShortcutHeadingLayout->addWidget(styleShortcutRule, 1);
        styleShortcutLayout->addWidget(styleShortcutHeading);

        auto *styleShortcutGrid = new QGridLayout;
        styleShortcutGrid->setContentsMargins(0, 0, 0, 0);
        styleShortcutGrid->setHorizontalSpacing(5);
        styleShortcutGrid->setVerticalSpacing(3);
        auto *styleShortcutButtonGroup = new QButtonGroup(styleShortcutPanel);
        styleShortcutButtonGroup->setExclusive(true);
        static const std::array<const char *, 10> styleShortcutCaptions = {
            "POP", "ROCK&\nRETRO POP", "DANCE", "R&B\nOLDIES", "JAZZ&EASY\nLISTENING",
            "COUNTRY&\nBALLROOM", "MOVIE&SHOW", "ENTERTAINER", "LATIN&\nWORLD", "EXPANSION/\nUSER"
        };
        static const std::array<QStringList, 10> styleShortcutCategoryGroups = {{
            QStringList{QStringLiteral("Pop&Rock")},
            QStringList{QStringLiteral("Pop&Rock")},
            QStringList{QStringLiteral("Dance")},
            QStringList{QStringLiteral("R&B")},
            QStringList{QStringLiteral("Jazz")},
            QStringList{QStringLiteral("World"), QStringLiteral("Ballroom")},
            QStringList{QStringLiteral("Movie&Show")},
            QStringList{QStringLiteral("Entertainer")},
            QStringList{QStringLiteral("Latin"), QStringLiteral("World")},
            QStringList{}
        }};
        for (int keyIndex = 0; keyIndex < 10; ++keyIndex) {
            auto *keyCell = new QWidget(styleShortcutPanel);
            keyCell->setStyleSheet(QStringLiteral("background:transparent;"));
            auto *keyCellLayout = new QVBoxLayout(keyCell);
            keyCellLayout->setContentsMargins(0, 0, 0, 0);
            keyCellLayout->setSpacing(1);

            auto *caption = new QLabel(QString::fromUtf8(styleShortcutCaptions[static_cast<std::size_t>(keyIndex)]), keyCell);
            caption->setAlignment(Qt::AlignCenter);
            caption->setWordWrap(true);
            caption->setMinimumHeight(20);
            caption->setMaximumHeight(25);
            caption->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
            caption->setStyleSheet(QStringLiteral(
                "QLabel{color:#d2dbda;background:transparent;font-size:6.5pt;font-weight:600;letter-spacing:0.2px;padding:0;}"));

            auto *keyButton = new StyleCategoryKeyButton(keyCell);
            keyButton->setObjectName(QStringLiteral("styleShortcutButton_%1").arg(keyIndex));
            keyButton->setAccessibleName(caption->text().simplified());
            keyButton->setToolTip(QStringLiteral("Buka Style browser: %1").arg(caption->text().simplified()));
            keyButton->setFixedSize(58, 22);
            styleShortcutButtonGroup->addButton(keyButton, keyIndex);
            keyCellLayout->addWidget(caption);
            keyCellLayout->addWidget(keyButton, 0, Qt::AlignHCenter);
            styleShortcutGrid->addWidget(keyCell, keyIndex / 5, keyIndex % 5);

            connect(keyButton, &QPushButton::clicked, this, [this, keyIndex] {
                if (!lcdContentStack_ || !lcdStylePickerPage_) return;
                const auto &categoryGroup = styleShortcutCategoryGroups[static_cast<std::size_t>(keyIndex)];
                lcdStyleShortcutLabel_ = QString::fromUtf8(styleShortcutCaptions[static_cast<std::size_t>(keyIndex)])
                    .simplified().replace(QStringLiteral(" & "), QStringLiteral(" / "));
                lcdStyleUserMode_ = (keyIndex == 9);
                lcdStyleCategoryGroup_ = categoryGroup;
                lcdStyleCategory_ = categoryGroup.isEmpty() ? QStringLiteral("Pop&Rock") : categoryGroup.front();
                lcdStyleBadgeFilter_.clear();
                if (keyIndex == 0) lcdStyleBadgeFilter_ = QStringLiteral("Pop");
                else if (keyIndex == 1) lcdStyleBadgeFilter_ = QStringLiteral("Rock/Retro");
                lcdStyleFavoritesOnly_ = false;
                lcdStylePage_ = 0;
                dataEntryStyleMode_ = true;
                rebuildLcdStyleGrid();
                lcdContentStack_->setCurrentWidget(lcdStylePickerPage_);
                if (lcdStyleList_ && lcdStyleList_->currentItem())
                    lcdStyleList_->scrollToItem(lcdStyleList_->currentItem(), QAbstractItemView::PositionAtCenter);
            });
        }
        for (int column = 0; column < 5; ++column) styleShortcutGrid->setColumnStretch(column, 1);
        styleShortcutGrid->setRowStretch(0, 1);
        styleShortcutGrid->setRowStretch(1, 1);
        styleShortcutLayout->addLayout(styleShortcutGrid, 1);
        middleLayout->addWidget(styleShortcutPanel, 31);
        startupTrace("middleRow: STYLE category shortcut panel added to layout");

        // Dedicated 8-channel STYLE mixer for MIDI channels 9..16.
        // Match the supplied reference: CH label, PAN knob, vertical hardware fader,
        // and only MUTE / SOLO buttons. This panel stays inside the center middle-row cell.
        startupTrace("middleRow: before 8-channel STYLE mixer CH09-CH16");
        auto *mixerPanel = makePanel(middleRow);
        mixerPanel->setObjectName(QStringLiteral("akaiMidiMixPanel"));
        // Reserve enough width for eight non-overlapping hardware strips at the minimum window size.
        mixerPanel->setMinimumWidth(460);
        mixerPanel->setToolTip(QStringLiteral("STYLE mixer channels 9-16: RHY1, RHY2, BASS, CH1, CH2, PAD, PHR1, PHR2; volume, PAN, MUTE and SOLO."));
        // A horizontal box layout deliberately locks all eight channel strips to ONE row.
        // Do not convert this to a 4x2 grid or allow a second strip row at narrow widths.
        auto *mixerRow = new QHBoxLayout(mixerPanel);
        mixerRow->setContentsMargins(3, 3, 3, 3);
        mixerRow->setSpacing(2);

        static constexpr std::array<const char *, 8> styleTrackNames = {
            "RHY1", "RHY2", "BASS", "CH1", "CH2", "PAD", "PHR1", "PHR2"
        };
        QSettings stylePartSettings;
        styleMixerSelectedChannel_ = std::clamp(
            stylePartSettings.value(QStringLiteral("panel/styleMixerSelectedChannel"), 8).toInt(), 8, 15);

        for (int strip = 0; strip < 8; ++strip) {
            const int channel = strip + 8; // MIDI channel 9..16 (zero-based index 8..15).
            startupTrace((std::string("middleRow: before STYLE mixer strip ") + std::to_string(channel + 1)).c_str());
            auto *laneCell = new QWidget(mixerPanel);
            laneCell->setObjectName(QStringLiteral("styleMixerStrip_%1").arg(channel + 1));
            laneCell->setProperty("akaiStripCell", true);
            laneCell->setAttribute(Qt::WA_StyledBackground, true);
            auto *laneLayout = new QVBoxLayout(laneCell);
            laneLayout->setContentsMargins(1, 1, 1, 1);
            laneLayout->setSpacing(1);

            auto *channelLabel = new QLabel(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(strip)]), laneCell);
            channelLabel->setAlignment(Qt::AlignCenter);
            channelLabel->setProperty("akaiPrintedLabel", true);
            channelLabel->setFixedHeight(12);
            laneLayout->addWidget(channelLabel);

            auto *panLabel = new QLabel(QStringLiteral("PAN"), laneCell);
            panLabel->setAlignment(Qt::AlignCenter);
            panLabel->setProperty("akaiPrintedLabel", true);
            panLabel->setFixedHeight(9);
            laneLayout->addWidget(panLabel);

            auto *panKnob = new AkaiMixerKnob(laneCell);
            panKnob->setFixedSize(24, 24);
            panKnob->setRange(0, 127);
            panKnob->setValue(std::clamp(stylePartSettings.value(
                QStringLiteral("panel/stylePartCc/%1/10").arg(channel + 1), 64).toInt(), 0, 127));
            panKnob->setToolTip(QStringLiteral("%1 PAN — MIDI channel %2, CC10")
                                .arg(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(strip)]))
                                .arg(channel + 1));
            channelMixerPanKnobs_[static_cast<std::size_t>(channel)] = panKnob;
            laneLayout->addWidget(panKnob, 0, Qt::AlignHCenter);
            connect(panKnob, &QDial::valueChanged, this, [this, channel](int value) {
                QSettings settings;
                settings.setValue(QStringLiteral("panel/stylePartCc/%1/10").arg(channel + 1), value);
                settings.sync();
                sendStyleMixerController(channel - 8, 10, value);
            });

            channelMixerLevels_[static_cast<std::size_t>(channel)] = std::clamp(stylePartSettings.value(
                QStringLiteral("panel/stylePartVolume/%1").arg(channel + 1), 100).toInt(), 0, 127);
            auto *volumeFader = new ReferenceMixerSlider(laneCell);
            volumeFader->setObjectName(QStringLiteral("styleMixerVolumeFader_%1").arg(channel + 1));
            volumeFader->setProperty("akaiStyleFader", true);
            volumeFader->setRange(0, 127);
            volumeFader->setValue(channelMixerLevels_[static_cast<std::size_t>(channel)]);
            volumeFader->setMinimumHeight(58);
            volumeFader->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
            volumeFader->setFixedWidth(30);
            volumeFader->setInvertedAppearance(false);
            volumeFader->setInvertedControls(false);
            volumeFader->setToolTip(QStringLiteral("%1 volume — MIDI channel %2, CC7")
                                    .arg(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(strip)]))
                                    .arg(channel + 1));
            channelMixerFaders_[static_cast<std::size_t>(channel)] = volumeFader;
            laneLayout->addWidget(volumeFader, 1, Qt::AlignHCenter);
            connect(volumeFader, &QSlider::valueChanged, this, [this, channel](int value) {
                const int bounded = std::clamp(value, 0, 127);
                channelMixerLevels_[static_cast<std::size_t>(channel)] = bounded;
                const int outputValue = styleMixerPartMuted(channel) ? 0 : bounded;
                sendStyleMixerController(channel - 8, 7, outputValue);
            });
            connect(volumeFader, &QSlider::sliderReleased, this, [this, channel, volumeFader] {
                QSettings settings;
                settings.setValue(QStringLiteral("panel/stylePartVolume/%1").arg(channel + 1), volumeFader->value());
                settings.sync();
            });

            auto *buttonRow = new QWidget(laneCell);
            auto *buttonLayout = new QHBoxLayout(buttonRow);
            buttonLayout->setContentsMargins(0, 1, 0, 0);
            buttonLayout->setSpacing(1);

            auto *muteButton = new QPushButton(QStringLiteral("MUTE"), buttonRow);
            muteButton->setProperty("akaiMuteButton", true);
            muteButton->setFixedSize(25, 14);
            muteButton->setCheckable(true);
            muteButton->setToolTip(QStringLiteral("Mute %1").arg(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(strip)])));
            channelMixerMuted_[static_cast<std::size_t>(channel)] = stylePartSettings.value(
                QStringLiteral("panel/stylePartMuted/%1").arg(channel + 1), false).toBool();
            muteButton->setChecked(channelMixerMuted_[static_cast<std::size_t>(channel)]);
            buttonLayout->addWidget(muteButton);
            connect(muteButton, &QPushButton::toggled, this, [this, channel](bool muted) {
                channelMixerMuted_[static_cast<std::size_t>(channel)] = muted;
                QSettings settings;
                settings.setValue(QStringLiteral("panel/stylePartMuted/%1").arg(channel + 1), muted);
                settings.sync();
                const int outputValue = styleMixerPartMuted(channel)
                    ? 0 : channelMixerLevels_[static_cast<std::size_t>(channel)];
                sendStyleMixerController(channel - 8, 7, outputValue);
            });

            auto *soloButton = new QPushButton(QStringLiteral("SOLO"), buttonRow);
            soloButton->setProperty("akaiSoloButton", true);
            soloButton->setFixedSize(25, 14);
            soloButton->setCheckable(true);
            soloButton->setToolTip(QStringLiteral("Solo %1").arg(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(strip)])));
            channelMixerSoloButtons_[static_cast<std::size_t>(channel)] = soloButton;
            buttonLayout->addWidget(soloButton);
            laneLayout->addWidget(buttonRow, 0, Qt::AlignHCenter);

            connect(soloButton, &QPushButton::toggled, this, [this, channel, soloButton](bool solo) {
                styleMixerSelectedChannel_ = channel;
                styleMixerSoloActive_ = solo;
                QSettings settings;
                settings.setValue(QStringLiteral("panel/styleMixerSelectedChannel"), channel);
                settings.sync();
                for (int part = 8; part < 16; ++part) {
                    auto *otherSolo = channelMixerSoloButtons_[static_cast<std::size_t>(part)];
                    if (otherSolo && otherSolo != soloButton && otherSolo->isChecked()) {
                        const QSignalBlocker blocker(otherSolo);
                        otherSolo->setChecked(false);
                    }
                }
                for (int part = 8; part < 16; ++part) {
                    const int output = styleMixerPartMuted(part)
                        ? 0 : channelMixerLevels_[static_cast<std::size_t>(part)];
                    sendStyleMixerController(part - 8, 7, output);
                }
                setStatus(solo
                    ? QStringLiteral("SOLO STYLE %1").arg(QString::fromLatin1(styleTrackNames[static_cast<std::size_t>(channel - 8)]))
                    : QStringLiteral("SOLO STYLE nonaktif — MUTE tiap track tetap berlaku."));
            });

            // Never ignore the strip size hint: fixed-width PAN/fader/MUTE/SOLO controls
            // must stay inside their own cell instead of intruding into the adjacent channel.
            laneCell->setMinimumWidth(54);
            laneCell->setSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Expanding);
            mixerRow->addWidget(laneCell, 1);
            startupTrace((std::string("middleRow: STYLE mixer strip complete ") + std::to_string(channel + 1)).c_str());
        }
        startupTrace("middleRow: 8-channel STYLE mixer CH09-CH16 complete (single horizontal row)");
        middleLayout->addWidget(mixerPanel, 37);

        startupTrace("middleRow: before pads panel");
        auto *padsPanel = makePanel(middleRow);
        startupTrace("middleRow: pads panel constructed");
        auto *padsLayout = new QVBoxLayout(padsPanel);
        padsLayout->setContentsMargins(4, 3, 4, 3);
        padsLayout->setSpacing(2);
        auto *padTitle = makeCaption(QStringLiteral("PERCUSSION TRIGGERS · GM notes"), padsPanel);
        padsLayout->addWidget(padTitle);
        auto *padGrid = new QGridLayout;
        padGrid->setContentsMargins(0, 0, 0, 0);
        padGrid->setHorizontalSpacing(3);
        padGrid->setVerticalSpacing(3);
        const std::array<std::pair<const char *, int>, 12> padNotes = {{{"Kick",36},{"Snare",38},{"Closed Hat",42},{"Open Hat",46},{"Low Tom",45},{"Mid Tom",47},{"High Tom",50},{"Crash",49},{"Ride",51},{"Clap",39},{"Side Stick",37},{"Cowbell",56}}};
        for (int i = 0; i < static_cast<int>(padNotes.size()); ++i) {
            startupTrace((std::string("middleRow: before pad ") + std::to_string(i)).c_str());
            auto *pad = new QPushButton(QString::fromUtf8(padNotes[static_cast<std::size_t>(i)].first), padsPanel);
            pad->setToolTip(QStringLiteral("Kirim nada drum GM %1 (note %2). Ini pemicu MIDI, bukan playback file sampel.")
                .arg(QString::fromUtf8(padNotes[static_cast<std::size_t>(i)].first)).arg(padNotes[static_cast<std::size_t>(i)].second));
            pad->setMinimumHeight(25);
            pad->setStyleSheet(QStringLiteral("QPushButton{font-size:7pt;font-weight:600;padding:0;background:#435658;border:1px solid #262626;color:#eee;} QPushButton:pressed{background:#176c63;border:1px solid #71c1b4;}"));
            const int note = padNotes[static_cast<std::size_t>(i)].second;
            connect(pad, &QPushButton::clicked, this, [this, note] { triggerDrum(note); });
            padGrid->addWidget(pad, i / 6, i % 6);
            startupTrace((std::string("middleRow: pad complete ") + std::to_string(i)).c_str());
        }
        startupTrace("middleRow: all pads built");
        auto *padRecord = new QPushButton(QStringLiteral("MIDI Rec"), padsPanel);
        padRecord->setObjectName(QStringLiteral("redAction"));
        padRecord->setToolTip(QStringLiteral("Buka perekam event MIDI; perekam sampel audio belum tersedia."));
        connect(padRecord, &QPushButton::clicked, recorderDialog_, &QDialog::show);
        padGrid->addWidget(padRecord, 0, 6);
        auto *padFolder = new QPushButton(QStringLiteral("Open MIDI"), padsPanel);
        padFolder->setObjectName(QStringLiteral("blueAction"));
        padFolder->setToolTip(QStringLiteral("Pilih berkas MIDI untuk diputar; bukan muat sampel pad."));
        connect(padFolder, &QPushButton::clicked, this, [this] { loadMidi(); });
        padGrid->addWidget(padFolder, 1, 6);
        auto *padStop = new QPushButton(QStringLiteral("Stop"), padsPanel);
        padStop->setToolTip(QStringLiteral("All Sounds Off"));
        connect(padStop, &QPushButton::clicked, this, [this] { allSoundsOff(); });
        padGrid->addWidget(padStop, 0, 7, 2, 1);
        padsLayout->addLayout(padGrid, 1);
        middleLayout->addWidget(padsPanel, 32);
        // Keep all eight STYLE strips strictly BELOW the LCD row; no overlay or overlap.
        middleRow->setFixedHeight(150); // Match the target middle deck and return vertical room to the piano.
        startupTrace("middleRow: before adding middle row to root");
        root->addWidget(middleRow);
        startupTrace("middleRow: added middle row to root");

        // Original-style section/transport strip. Section buttons are independent from Start/Stop.
        startupTrace("transport: before panel construction");
        auto *transport = makePanel(central);
        startupTrace("transport: panel constructed");
        transport->setFixedHeight(64);
        auto *transportLayout = new QHBoxLayout(transport);
        transportLayout->setContentsMargins(3, 3, 3, 2);
        // Keep the hardware controls clustered like a physical arranger panel.
        // The flexible space belongs before BANK, not between each section group.
        transportLayout->setSpacing(2);
        auto makeArrangerCaption = [&](const QString &caption, QWidget *parent, bool flankedByRules) {
            auto *header = new QWidget(parent);
            auto *headerLayout = new QHBoxLayout(header);
            headerLayout->setContentsMargins(0, 0, 0, 0);
            headerLayout->setSpacing(4);
            auto *title = new QLabel(caption, header);
            title->setObjectName(QStringLiteral("arrangerSectionCaption"));
            title->setAlignment(Qt::AlignCenter);
            title->setFixedHeight(10);
            if (flankedByRules) {
                auto *leftRule = new QFrame(header);
                leftRule->setFrameShape(QFrame::HLine);
                leftRule->setFixedHeight(1);
                leftRule->setStyleSheet(QStringLiteral("background:#82918f;border:0;"));
                auto *rightRule = new QFrame(header);
                rightRule->setFrameShape(QFrame::HLine);
                rightRule->setFixedHeight(1);
                rightRule->setStyleSheet(QStringLiteral("background:#82918f;border:0;"));
                headerLayout->addWidget(leftRule, 1);
                headerLayout->addWidget(title, 0);
                headerLayout->addWidget(rightRule, 1);
            } else {
                headerLayout->addStretch(1);
                headerLayout->addWidget(title, 0);
                headerLayout->addStretch(1);
            }
            return header;
        };
        auto addSection = [&](const QString &caption, const std::vector<QString> &labels, QWidget *parent,
                                      const std::function<void(int)> &clicked, bool flankedByRules = true,
                                      bool momentary = false, bool showLed = true) {
            auto *section = new QWidget(parent);
            auto *vertical = new QVBoxLayout(section);
            vertical->setContentsMargins(5, 0, 5, 0);
            vertical->setSpacing(2);
            vertical->addWidget(makeArrangerCaption(caption, section, flankedByRules));
            auto *buttons = new QHBoxLayout;
            buttons->setContentsMargins(0, 0, 0, 0);
            buttons->setSpacing(4);
            buttons->addStretch(1);
            for (int i = 0; i < static_cast<int>(labels.size()); ++i) {
                auto *b = new HardwareCapButton(labels[static_cast<std::size_t>(i)], section);
                b->setObjectName(QStringLiteral("arrangerSectionButton"));
                b->setProperty("indicatorOnly", true);
                b->setFixedSize(38, 42);
                b->setCheckable(!momentary);
                b->setAutoExclusive(!momentary);
                if (showLed) {
                    auto *led = new QLabel(b);
                    led->setObjectName(QStringLiteral("arrangerButtonLed"));
                    led->setAttribute(Qt::WA_TransparentForMouseEvents);
                    led->setGeometry(5, 5, 7, 4);
                    led->show();
                }
                connect(b, &QPushButton::clicked, section, [clicked, i] { clicked(i); });
                buttons->addWidget(b, 0, Qt::AlignVCenter);
            }
            buttons->addStretch(1);
            vertical->addLayout(buttons);
            // Size the group to the button row plus a narrow caption/rule inset.
            // This prevents the four-button groups from expanding and creating large
            // empty gaps between INTRO, VARIATION, BREAK, and ENDING.
            const int buttonCount = static_cast<int>(labels.size());
            const int buttonGaps = buttonCount > 1 ? (buttonCount - 1) * 4 : 0;
            section->setFixedWidth(buttonCount * 38 + buttonGaps + 10);
            section->setFixedHeight(54); // 10 px caption + 2 px gap + 42 px hardware cap.
            section->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
            return section;
        };
        // Roland-style arranger strip: captions above each hardware-style cap.
        // Chord and Auto Fill are persistent toggles; sections are queued independently.
        auto *transportToggles = new QWidget(transport);
        transportToggles->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        auto *toggleLayout = new QHBoxLayout(transportToggles);
        toggleLayout->setContentsMargins(0, 0, 0, 0);
        toggleLayout->setSpacing(4);
        auto makeToggleCell = [&](const QString &caption, QPushButton *button) {
            auto *cell = new QWidget(transportToggles);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(2);
            auto *title = new QLabel(caption, cell);
            title->setObjectName(QStringLiteral("arrangerSectionCaption"));
            title->setAlignment(Qt::AlignCenter);
            title->setFixedHeight(10);
            button->setObjectName(QStringLiteral("arrangerToggleButton"));
            button->setProperty("indicatorOnly", true);
            // The reference has compact square Chord/Auto Fill caps (about
            // 34 x 31 px); they are deliberately shorter than section keys.
            button->setFixedSize(34, 32);
            auto *led = new QLabel(button);
            led->setObjectName(QStringLiteral("arrangerButtonLed"));
            led->setAttribute(Qt::WA_TransparentForMouseEvents);
            led->setGeometry(5, 5, 7, 4);
            led->show();
            cellLayout->addWidget(title);
            cellLayout->addWidget(button, 0, Qt::AlignHCenter);
            return std::make_pair(cell, title);
        };
        styleChordControlButton_ = new HardwareCapButton(QString(), transportToggles);
        auto *chordControl = styleChordControlButton_;
        chordControl->setText(QString());
        chordControl->setCheckable(true);
        chordControl->setChecked(accompButton_ ? accompButton_->isChecked() : true);
        chordControl->setToolTip(QStringLiteral("Enable live Roland chord recognition/voicing changes"));
        const auto chordToggleCell = makeToggleCell(QStringLiteral("Chord"), chordControl);
        arrangerChordLed_ = chordControl->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        connect(chordControl, &QPushButton::toggled, this, [this](bool on) {
            if (accompButton_ && accompButton_->isChecked() != on) accompButton_->setChecked(on);
            styleEngine_.setChordControlEnabled(on);
            refreshArrangerIndicators();
            setStatus(on ? QStringLiteral("Chord aktif: style accompaniment mengikuti chord keyboard.")
                         : QStringLiteral("Chord nonaktif: style chord tidak ditransposisikan.") );
        });
        styleEngine_.setChordControlEnabled(chordControl->isChecked());
        styleAutoFillButton_ = new HardwareCapButton(QString(), transportToggles);
        auto *autoFillControl = styleAutoFillButton_;
        autoFillControl->setText(QString());
        QSettings styleTransportSettings;
        const bool autoFillEnabled = styleTransportSettings.value(QStringLiteral("panel/yamahaGenosAutoFillV2"), true).toBool();
        styleEngine_.setAutoFillEnabled(autoFillEnabled);
        autoFillControl->setCheckable(true);
        autoFillControl->setChecked(autoFillEnabled);
        autoFillControl->setToolTip(QStringLiteral("Genos 2: ON plays the destination Main's own Fill before switching; OFF changes Main directly. Re-press the active Main for Self Fill."));
        const auto autoFillToggleCell = makeToggleCell(QStringLiteral("Auto Fill"), autoFillControl);
        arrangerAutoFillLed_ = autoFillControl->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        connect(autoFillControl, &QPushButton::toggled, this, [this](bool on) {
            styleEngine_.setAutoFillEnabled(on);
            QSettings settings;
            settings.setValue(QStringLiteral("panel/yamahaGenosAutoFillV2"), on);
            settings.sync();
            refreshArrangerIndicators();
            setStatus(on ? QStringLiteral("Genos Auto Fill aktif: Main tujuan memainkan Fill-nya sendiri sebelum berpindah; clock Style tetap berjalan.")
                         : QStringLiteral("Genos Auto Fill nonaktif: perpindahan Main langsung tanpa Fill; tekan Main aktif lagi untuk Self Fill.") );
        });
        // Do not stretch the toggle cells apart; keep Chord and Auto Fill together.
        toggleLayout->addWidget(chordToggleCell.first);
        toggleLayout->addWidget(autoFillToggleCell.first);
        transportLayout->addWidget(transportToggles);
        transportLayout->setAlignment(transportToggles, Qt::AlignTop);
        refreshArrangerIndicators();

        startupTrace("transport: before INTRO section");
        auto *introSection = addSection(QStringLiteral("INTRO"),
            {QStringLiteral("I"), QStringLiteral("II"), QStringLiteral("III")}, transport,
            [this](int i) {
                if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih Style terlebih dahulu.")); return; }
                // Yamaha has three distinct intro sections. Legacy Roland STL
                // exposes two; its third panel key intentionally aliases Intro 1.
                const int startsYamaha[] = {1, 2, 15};
                const int startsRoland[] = {1, 2, 1};
                const int start = styleEngine_.isYamahaStyle() ? startsYamaha[i] : startsRoland[i];
                queueArrangerIndicator(0, i, start);
                styleEngine_.queueIntro(start, start + 1);
            });
        const auto introButtons = introSection->findChildren<QPushButton *>(QString(), Qt::FindDirectChildrenOnly);
        for (int i = 0; i < 3 && i < introButtons.size(); ++i) {
            rolandIntroButtons_[static_cast<std::size_t>(i)] = introButtons[i];
            arrangerIntroLeds_[static_cast<std::size_t>(i)] = introButtons[i]->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        }
        transportLayout->addWidget(introSection);
        transportLayout->setAlignment(introSection, Qt::AlignTop);
        startupTrace("transport: INTRO section complete");
        auto *variationSection = addSection(QStringLiteral("VARIATION"),
            {QStringLiteral("A"), QStringLiteral("B"), QStringLiteral("C"), QStringLiteral("D")}, transport,
            [this](int i) {
                if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih Style terlebih dahulu.")); return; }
                const int starts[] = {3, 5, 7, 9};
                const int ends[] = {4, 6, 8, 10};
                queueArrangerIndicator(1, i, starts[i]);
                styleEngine_.playLoop(starts[i], ends[i]);
            });
        const auto variationButtons = variationSection->findChildren<QPushButton *>(QString(), Qt::FindDirectChildrenOnly);
        for (int i = 0; i < 4 && i < variationButtons.size(); ++i) {
            rolandVariationButtons_[static_cast<std::size_t>(i)] = variationButtons[i];
            arrangerVariationLeds_[static_cast<std::size_t>(i)] = variationButtons[i]->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        }
        transportLayout->addWidget(variationSection);
        transportLayout->setAlignment(variationSection, Qt::AlignTop);
        auto *breakSection = addSection(QStringLiteral("BREAK"), {QStringLiteral("-#-")}, transport,
            [this](int) {
                if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih Style terlebih dahulu.")); return; }
                if (!styleEngine_.isPlaying()) {
                    setStatus(QStringLiteral("BREAK Genos2 hanya dapat dijalankan saat Style sedang dimainkan."));
                    return;
                }
                if (!styleEngine_.hasBreakSection()) {
                    setStatus(QStringLiteral("Style ini tidak memiliki pola BREAK."));
                    return;
                }
                arrangerBreakPending_ = true;
                refreshArrangerIndicators();
                styleEngine_.breakPlay();
            }, false, true, true);
        const auto breakButtons = breakSection->findChildren<QPushButton *>(QString(), Qt::FindDirectChildrenOnly);
        if (!breakButtons.isEmpty()) {
            rolandBreakButton_ = breakButtons.front();
            arrangerBreakLed_ = rolandBreakButton_->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
            rolandBreakButton_->setToolTip(QStringLiteral("BREAK Genos2: masuk mengikuti timing Fill In, lalu kembali ke Main pada akhir frase"));
        }
        transportLayout->addWidget(breakSection);
        transportLayout->setAlignment(breakSection, Qt::AlignTop);
        startupTrace("transport: variation and break sections complete");
        auto *endingSection = addSection(QStringLiteral("ENDING"),
            {QStringLiteral("I"), QStringLiteral("II"), QStringLiteral("III")}, transport,
            [this](int i) {
                if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih Style terlebih dahulu.")); return; }
                // Yamaha exposes three real endings. Roland STL has two, so its
                // third control aliases Ending 1 instead of inventing Ending 4.
                const int startsYamaha[] = {11, 13, 16};
                const int startsRoland[] = {11, 13, 11};
                const int start = styleEngine_.isYamahaStyle() ? startsYamaha[i] : startsRoland[i];
                queueArrangerIndicator(2, i, start);
                styleEngine_.queueEnding(start, start + 1);
            });
        const auto endingButtons = endingSection->findChildren<QPushButton *>(QString(), Qt::FindDirectChildrenOnly);
        for (int i = 0; i < 3 && i < endingButtons.size(); ++i) {
            rolandEndingButtons_[static_cast<std::size_t>(i)] = endingButtons[i];
            arrangerEndingLeds_[static_cast<std::size_t>(i)] = endingButtons[i]->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        }
        transportLayout->addWidget(endingSection);
        transportLayout->setAlignment(endingSection, Qt::AlignTop);
        startupTrace("transport: ending section complete");
        auto *syncSection = new QWidget(transport);
        syncSection->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        auto *syncLayout = new QHBoxLayout(syncSection);
        syncLayout->setContentsMargins(5, 0, 5, 0);
        syncLayout->setSpacing(4);
        auto makeSyncCell = [&](const QString &caption, const QString &glyph) {
            auto *cell = new QWidget(syncSection);
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(2);
            auto *title = new QLabel(caption, cell);
            title->setObjectName(QStringLiteral("arrangerSectionCaption"));
            title->setAlignment(Qt::AlignCenter);
            title->setFixedHeight(10);
            auto *button = new HardwareCapButton(QString(), cell);
            button->setObjectName(QStringLiteral("arrangerTransportButton"));
            button->setProperty("indicatorOnly", true);
            button->setProperty("hardwareGlyph", glyph);
            button->setFixedSize(45, 42);
            auto *led = new QLabel(button);
            led->setObjectName(QStringLiteral("arrangerButtonLed"));
            led->setAttribute(Qt::WA_TransparentForMouseEvents);
            led->setGeometry(5, 5, 7, 4);
            led->show();
            cellLayout->addWidget(title);
            cellLayout->addWidget(button, 0, Qt::AlignHCenter);
            return std::make_pair(cell, button);
        };
        const auto syncStopCell = makeSyncCell(QStringLiteral("Sync Stop"), QStringLiteral("sync-stop"));
        const auto syncStartCell = makeSyncCell(QStringLiteral("Sync Start"), QStringLiteral("sync-start"));
        // Keep the Sync row on the exact same 54 px top-aligned rail as Ending.
        // Without a fixed height, the parent HBox can vertically center/stretch it.
        syncSection->setFixedHeight(54);
        syncSection->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        auto *syncStop = syncStopCell.second;
        auto *syncStart = syncStartCell.second;
        arrangerSyncStopLed_ = syncStop->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        arrangerSyncStartLed_ = syncStart->findChild<QLabel *>(QStringLiteral("arrangerButtonLed"));
        syncStop->setToolTip(QStringLiteral("Stop the arranger at the next section boundary"));
        syncStart->setToolTip(QStringLiteral("Start the arranger when a chord is detected"));
        connect(syncStart, &QPushButton::clicked, this, [this] {
            if (styleEngine_.hasStyle()) {
                styleEngine_.syncStart();
                refreshArrangerIndicators();
                setStatus(styleEngine_.syncStartPending()
                    ? QStringLiteral("Sync Start standby: tekan chord di wilayah kiri keyboard.")
                    : QStringLiteral("Sync Start standby dibatalkan."));
            } else setStatus(QStringLiteral("Pilih Style terlebih dahulu."));
        });
        connect(syncStop, &QPushButton::clicked, this, [this] {
            if (!styleEngine_.isPlaying()) {
                setStatus(QStringLiteral("Arranger sudah berhenti; Sync Stop tidak perlu dijadwalkan."));
                return;
            }
            styleEngine_.syncStop();
            refreshArrangerIndicators();
            setStatus(QStringLiteral("Sync Stop dijadwalkan pada batas section."));
        });
        syncLayout->addWidget(syncStopCell.first);
        syncLayout->addWidget(syncStartCell.first);
        transportLayout->addWidget(syncSection);
        transportLayout->setAlignment(syncSection, Qt::AlignTop);
        auto *startStopSection = new QWidget(transport);
        auto *startStopLayout = new QVBoxLayout(startStopSection);
        startStopLayout->setContentsMargins(3, 0, 3, 0);
        startStopLayout->setSpacing(2);
        startStopLayout->addWidget(makeArrangerCaption(QStringLiteral("Start/Stop"), startStopSection, false));
        styleStartStopButton_ = new HardwareCapButton(QString(), startStopSection);
        auto *startStop = styleStartStopButton_;
        startStop->setObjectName(QStringLiteral("arrangerTransportButton"));
        startStop->setProperty("indicatorOnly", true);
        startStop->setProperty("hardwareGlyph", QStringLiteral("start-stop"));
        startStop->setCheckable(true);
        startStop->setFixedSize(60, 42);
        auto *startStopLed = new QLabel(startStop);
        startStopLed->setObjectName(QStringLiteral("arrangerButtonLed"));
        startStopLed->setAttribute(Qt::WA_TransparentForMouseEvents);
        startStopLed->setGeometry(5, 5, 7, 4);
        startStopLed->show();
        arrangerStartStopLed_ = startStopLed;
        startStop->setToolTip(QStringLiteral("Start/Stop arranger — status ditunjukkan oleh LED"));
        connect(startStop, &QPushButton::clicked, this, [this] {
            if (!styleEngine_.hasStyle()) { setStatus(QStringLiteral("Pilih Style terlebih dahulu.")); return; }
            styleEngine_.togglePlay();
        });
        startStopLayout->addWidget(startStop, 0, Qt::AlignHCenter);
        // Caption + 2 px gap + 42 px cap: identical height and top edge to Ending.
        startStopSection->setFixedHeight(54);
        startStopSection->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        transportLayout->addWidget(startStopSection);
        transportLayout->setAlignment(startStopSection, Qt::AlignTop);
        // Absorb surplus width here so the arranger buttons remain tightly grouped;
        // BANK and REGISTRY stay aligned on the right side of the panel.
        transportLayout->addStretch(12);
        // The BANK selector is a compact, fixed-width group, as in the reference:
        // 16 px previous + 14 px bank number + 16 px next + two 1 px gaps = 48 px.
        // Its 54 px frame leaves 3 px of frame-side inset on both sides and must not
        // expand into the flexible gap before it (otherwise MEMORY shifts left).
        // The 41 px panel is vertically centered; accounting for the 1 px QFrame edge
        // and 2 px top inset, this puts the 20 px bank controls on the exact same row
        // as the Variation/Registry caps. BANK's caption then sits 5 px above the
        // REGISTRY MEMORY caption, matching the supplied reference layout.
        auto *bankPanel = makePanel(transport);
        bankPanel->setObjectName(QStringLiteral("registryBankPanel"));
        bankPanel->setFixedSize(54, 41);
        bankPanel->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        auto *bankLayout = new QVBoxLayout(bankPanel);
        bankLayout->setContentsMargins(0, 2, 0, 0);
        bankLayout->setSpacing(7);
        auto *bankButtons = new QHBoxLayout;
        bankButtons->setContentsMargins(2, 0, 2, 0);
        bankButtons->setSpacing(1);
        auto *bankPrev = new QPushButton(QStringLiteral("−"), bankPanel);
        bankPrev->setObjectName(QStringLiteral("registryBankStepButton"));
        bankPrev->setFixedSize(16, 20);
        registryBankLabel_ = new QLabel(QStringLiteral("1"), bankPanel);
        registryBankLabel_->setObjectName(QStringLiteral("registryBankNumber"));
        registryBankLabel_->setAlignment(Qt::AlignCenter);
        registryBankLabel_->setFixedSize(14, 20);
        registryBankLabel_->setStyleSheet(QStringLiteral("color:#e1eae8;font-weight:700;background:#202b2d;border:1px solid #141414;"));
        auto *bankNext = new QPushButton(QStringLiteral("+"), bankPanel);
        bankNext->setObjectName(QStringLiteral("registryBankStepButton"));
        bankNext->setFixedSize(16, 20);
        bankPrev->setToolTip(QStringLiteral("Registration bank sebelumnya"));
        bankNext->setToolTip(QStringLiteral("Registration bank berikutnya"));
        connect(bankPrev, &QPushButton::clicked, this, [this] { setRegistryBank(currentRegistryBank_ - 1); });
        connect(bankNext, &QPushButton::clicked, this, [this] { setRegistryBank(currentRegistryBank_ + 1); });
        bankButtons->addWidget(bankPrev);
        bankButtons->addWidget(registryBankLabel_);
        bankButtons->addWidget(bankNext);
        bankLayout->addLayout(bankButtons);
        auto *bankCaption = makeCaption(QStringLiteral("BANK"), bankPanel);
        bankCaption->setAlignment(Qt::AlignCenter);
        bankCaption->setFixedHeight(10);
        bankLayout->addWidget(bankCaption);
        transportLayout->addWidget(bankPanel);
        transportLayout->setAlignment(bankPanel, Qt::AlignVCenter);
        // Registration Memory follows the same hardware-cap geometry as VARIATION.
        // Each cap widget is 38x42; the antialiased painted face is 36x40, and
        // 4 px layout spacing yields the same 6 px visible gap as the reference.
        auto *registry = new QWidget(transport);
        constexpr int registryCapWidth = 38;
        constexpr int registryCapHeight = 42;
        constexpr int registryGap = 4;
        constexpr int registrySlotCount = 10;
        constexpr int registrySlotsWidth = registrySlotCount * registryCapWidth +
                                           (registrySlotCount - 1) * registryGap;
        registry->setFixedWidth(registryCapWidth + registryGap + registrySlotsWidth);
        registry->setFixedHeight(54);
        registry->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

        auto *registryLayout = new QHBoxLayout(registry);
        registryLayout->setContentsMargins(0, 0, 0, 0);
        registryLayout->setSpacing(registryGap);

        // MEMORY mode button has a caption above it and shares the exact same
        // vertical button baseline as the arranger section caps.
        auto *memoryCell = new QWidget(registry);
        memoryCell->setFixedSize(registryCapWidth, 54);
        auto *memoryCellLayout = new QVBoxLayout(memoryCell);
        memoryCellLayout->setContentsMargins(0, 0, 0, 0);
        memoryCellLayout->setSpacing(2);
        auto *memoryCaption = new QLabel(QStringLiteral("MEMORY"), memoryCell);
        memoryCaption->setObjectName(QStringLiteral("arrangerSectionCaption"));
        memoryCaption->setAlignment(Qt::AlignCenter);
        memoryCaption->setFixedHeight(10);
        memoryCellLayout->addWidget(memoryCaption);

        registryMemorizeButton_ = new HardwareCapButton(QString(), memoryCell);
        registryMemorizeButton_->setObjectName(QStringLiteral("arrangerToggleButton"));
        registryMemorizeButton_->setProperty("indicatorOnly", true);
        registryMemorizeButton_->setCheckable(true);
        registryMemorizeButton_->setFixedSize(registryCapWidth, registryCapHeight);
        registryMemorizeButton_->setToolTip(QStringLiteral("Aktifkan mode MEMORY lalu pilih slot 1–10 untuk menyimpan keadaan panel sekarang."));
        auto *memoryLed = new QLabel(registryMemorizeButton_);
        memoryLed->setObjectName(QStringLiteral("arrangerButtonLed"));
        memoryLed->setAttribute(Qt::WA_TransparentForMouseEvents);
        memoryLed->setGeometry(5, 5, 7, 4);
        memoryLed->show();
        connect(registryMemorizeButton_, &QPushButton::toggled, this, [this](bool on) {
            registryMemorizeMode_ = on;
            setStatus(on ? QStringLiteral("Mode Memorize aktif — pilih slot registrasi untuk menyimpan keadaan saat ini.")
                         : QStringLiteral("Mode Memorize nonaktif — slot yang ada akan dipanggil."));
        });
        memoryCellLayout->addWidget(registryMemorizeButton_, 0, Qt::AlignHCenter);
        registryLayout->addWidget(memoryCell, 0, Qt::AlignTop);

        // The ten registration slots use the very same HardwareCapButton, size,
        // LED placement and spacing as the four VARIATION buttons.
        auto *registrySlots = new QWidget(registry);
        registrySlots->setFixedSize(registrySlotsWidth, 54);
        auto *registrySlotsLayout = new QVBoxLayout(registrySlots);
        registrySlotsLayout->setContentsMargins(0, 0, 0, 0);
        registrySlotsLayout->setSpacing(0);
        registrySlotsLayout->addSpacing(12); // Caption-height + gap: baseline matches VARIATION.
        auto *registryButtons = new QHBoxLayout;
        registryButtons->setContentsMargins(0, 0, 0, 0);
        registryButtons->setSpacing(registryGap);
        for (int i = 0; i < static_cast<int>(registryButtons_.size()); ++i) {
            auto *b = new HardwareCapButton(QString::number(i + 1), registrySlots);
            b->setObjectName(QStringLiteral("arrangerSectionButton"));
            b->setFixedSize(registryCapWidth, registryCapHeight);
            registryButtons_[static_cast<std::size_t>(i)] = b;
            auto *led = new QLabel(b);
            led->setObjectName(QStringLiteral("arrangerButtonLed"));
            led->setAttribute(Qt::WA_TransparentForMouseEvents);
            led->setGeometry(5, 5, 7, 4);
            led->show();
            connect(b, &QPushButton::clicked, this, [this, i] { activateRegistrySlot(i); });
            registryButtons->addWidget(b);
        }
        registrySlotsLayout->addLayout(registryButtons);
        auto *registryLabel = makeCaption(QStringLiteral("REGISTRY MEMORY"), registrySlots);
        registryLabel->setAlignment(Qt::AlignCenter);
        registryLabel->setFixedHeight(10);
        registrySlotsLayout->addWidget(registryLabel);
        registryLayout->addWidget(registrySlots, 0, Qt::AlignTop);
        transportLayout->addWidget(registry);
        transportLayout->setAlignment(registry, Qt::AlignTop);
        startupTrace("transport: registry section complete");
        root->addWidget(transport);
        startupTrace("transport: added to root");

        startupTrace("buildUi: LCD and side panels complete; building keyboard deck");
        // Keyboard deck: left joystick assignment well, toolbar, and a live five-octave piano.
        auto *keyboardDeck = new QWidget(central);
        auto *keyboardDeckLayout = new QHBoxLayout(keyboardDeck);
        keyboardDeckLayout->setContentsMargins(0, 0, 0, 0);
        keyboardDeckLayout->setSpacing(3);
        auto *joystickWell = makePanel(keyboardDeck);
        joystickWell->setFixedWidth(145);
        auto *joystickLayout = new QVBoxLayout(joystickWell);
        joystickLayout->setContentsMargins(3, 3, 3, 3);
        joystickLayout->setSpacing(3);
        auto *xyRow = new QHBoxLayout;
        joystickXAssignButton_ = new QPushButton(QStringLiteral("X-Assign"), joystickWell);
        joystickYAssignButton_ = new QPushButton(QStringLiteral("Y-Assign"), joystickWell);
        joystickXAssignButton_->setFixedHeight(23); joystickYAssignButton_->setFixedHeight(23);
        connect(joystickXAssignButton_, &QPushButton::clicked, this, [this] { configureControlMapping(14, QStringLiteral("Joystick X")); });
        connect(joystickYAssignButton_, &QPushButton::clicked, this, [this] { configureControlMapping(15, QStringLiteral("Joystick Y")); });
        xyRow->addWidget(joystickXAssignButton_); xyRow->addWidget(joystickYAssignButton_);
        joystickLayout->addLayout(xyRow);
        joystickPad_ = new JoystickPadWidget(joystickWell);
        joystickPad_->setChangedCallback([this](int x, int y) {
            handleAssignableControlValue(14, x);
            handleAssignableControlValue(15, y);
        });
        joystickLayout->addWidget(joystickPad_, 1);
        keyboardDeckLayout->addWidget(joystickWell);

        auto *keyboardRight = new QWidget(keyboardDeck);
        auto *keyboardRightLayout = new QVBoxLayout(keyboardRight);
        keyboardRightLayout->setContentsMargins(0, 0, 0, 0);
        keyboardRightLayout->setSpacing(0);
        auto *keyboardToolbar = new QWidget(keyboardRight);
        keyboardToolbar->setFixedHeight(28);
        keyboardToolbar->setStyleSheet(QStringLiteral("background:#293638;border:1px solid #0a0a0a;"));
        auto *toolbarLayout = new QHBoxLayout(keyboardToolbar);
        toolbarLayout->setContentsMargins(6, 1, 4, 1);
        toolbarLayout->setSpacing(5);
        statusLabel_ = new QLabel(QString(), keyboardToolbar);
        statusLabel_->setObjectName(QStringLiteral("sectionLabel"));
        statusLabel_->setMinimumWidth(0);
        statusLabel_->setMaximumWidth(330);
        statusLabel_->setToolTip(QStringLiteral("Status and migration limitations are shown here."));
        statusLabel_->hide();
        toolbarLayout->addWidget(statusLabel_);
        toolbarLayout->addStretch(1);
        auto *holdLabel = makeCaption(QStringLiteral("H O L D"), keyboardToolbar);
        toolbarLayout->addWidget(holdLabel);
        auto *holdSwitch = new QCheckBox(keyboardToolbar);
        holdSwitch->setToolTip(QStringLiteral("Hold/sustain: mengirim MIDI CC64 ke voice aktif dan perangkat MIDI."));
        connect(holdSwitch, &QCheckBox::toggled, this, [this](bool on) {
            for (int slot : {0, 1, 2})
                sendMidi(static_cast<quint8>(0xB0 | slot), 64, on ? 127 : 0, internalVoiceChannel(slot));
            setStatus(on ? QStringLiteral("Hold aktif (MIDI sustain CC64=127).")
                         : QStringLiteral("Hold nonaktif (MIDI sustain CC64=0)."));
        });
        toolbarLayout->addWidget(holdSwitch);
        auto *zoomLabel = makeCaption(QStringLiteral("Z O O M"), keyboardToolbar);
        toolbarLayout->addWidget(zoomLabel);
        auto *zoomSwitch = new QCheckBox(keyboardToolbar);
        zoomSwitch->setToolTip(QStringLiteral("Zooms the five-octave keyboard and enables horizontal scrolling."));
        toolbarLayout->addWidget(zoomSwitch);
        auto *sustainButton = new QPushButton(QStringLiteral("SUST"), keyboardToolbar);
        // This control is a momentary pedal: preserve its physical press/release lifetime.
        sustainButton->setProperty("deferMouseClickUntilRelease", true);
        auto *keyStopButton = new QPushButton(QStringLiteral("STOP"), keyboardToolbar);
        sustainButton->setFixedHeight(23); keyStopButton->setFixedHeight(23);
        sustainButton->setToolTip(QStringLiteral("FluidSynth sustain pedal CC64; also forwarded when hardware MIDI is enabled"));
        connect(sustainButton, &QPushButton::pressed, this, [this] {
            for (int slot : {0, 1, 2}) sendMidi(static_cast<quint8>(0xB0 | slot), 64, 127, internalVoiceChannel(slot));
        });
        connect(sustainButton, &QPushButton::released, this, [this] {
            for (int slot : {0, 1, 2}) sendMidi(static_cast<quint8>(0xB0 | slot), 64, 0, internalVoiceChannel(slot));
        });
        connect(keyStopButton, &QPushButton::clicked, this, [this] { allSoundsOff(); });
        toolbarLayout->addWidget(sustainButton); toolbarLayout->addWidget(keyStopButton);
        keyboardRightLayout->addWidget(keyboardToolbar);
        auto *keyboardScroller = new QScrollArea(keyboardRight);
        keyboardScroller->setFrameShape(QFrame::NoFrame);
        keyboardScroller->setWidgetResizable(true);
        keyboardScroller->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        keyboardScroller->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        keyboardScroller->setMinimumHeight(108); // Keep a usable keybed visible below the transport row.
        pianoKeyboard_ = new PianoKeyboardWidget;
        pianoKeyboard_->setBaseNote(baseNote_);
        pianoKeyboard_->setNoteCallback([this](int note, bool pressed) { onKeyboardNote(note, pressed); });
        pianoKeyboard_->setSplitKey(splitKey_);
        pianoKeyboard_->setSplitKeyCallback([this](int note) {
            splitKey_ = std::clamp(note, 36, 95);
            if (pianoKeyboard_) pianoKeyboard_->setSplitKey(splitKey_);
            QSettings settings; settings.setValue(QStringLiteral("panel/splitKey"), splitKey_); settings.sync();
            setStatus(QStringLiteral("Split key dipindahkan ke %1 (%2). Pengaturan disimpan.")
                .arg(splitKey_).arg(QString::fromUtf8(kNoteNames[static_cast<std::size_t>(splitKey_ % 12)])));
        });
        keyboardScroller->setWidget(pianoKeyboard_);
        connect(zoomSwitch, &QCheckBox::toggled, this, [this, keyboardScroller](bool zoomed) {
            if (zoomed) {
                keyboardScroller->setWidgetResizable(false);
                pianoKeyboard_->setMinimumWidth(3200); // Same virtual width as original KeyBed::toggle_zoom.
                pianoKeyboard_->resize(3200, std::max(125, keyboardScroller->viewport()->height()));
            } else {
                pianoKeyboard_->setMinimumWidth(0);
                keyboardScroller->setWidgetResizable(true);
                pianoKeyboard_->resize(keyboardScroller->viewport()->size());
            }
        });
        keyboardRightLayout->addWidget(keyboardScroller, 1);
        keyboardDeckLayout->addWidget(keyboardRight, 1);
        root->addWidget(keyboardDeck, 1);

        // The original app uses a custom chrome without a conventional status bar.
        startupTrace("buildUi: before setCentralWidget / event filters");
        statusBar()->hide();
        setCentralWidget(central);
        central->installEventFilter(this);
        for (QWidget *child : central->findChildren<QWidget *>()) child->installEventFilter(this);
        startupTrace("buildUi: complete");
    }

    static bool isValidSoundFontFile(const QString &path) {
        if (path.isEmpty()) return false;
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly)) return false;
        const QByteArray header = file.read(12);
        return header.size() == 12 && header.left(4) == QByteArrayLiteral("RIFF")
            && header.mid(8, 4) == QByteArrayLiteral("sfbk");
    }

    bool hasActiveSf2PresetBrowser() const {
        return audioEngine_ && audioEngine_->isReady() && audioEngine_->isSoundFontPresetBrowserActive();
    }

    QString selectedExternalSoundFont() const {
        QSettings settings;
        const QString selected = settings.value(QStringLiteral("audio/externalSoundFontPath")).toString();
        return isValidSoundFontFile(selected) ? QFileInfo(selected).absoluteFilePath() : QString();
    }

    QString discoverStyleSoundFont() const {
        // A user-selected external bank takes priority for Yamaha Styles.
        // Do not use discoverSoundFont() here: its FluidSynth fallback may be
        // TimGM and must not silently replace the dedicated LS-GM default.
        const QString external = selectedExternalSoundFont();
        if (!external.isEmpty()) return external;
        return discoverLsGmSoundFont();
    }

    QString discoverLsGmSoundFont() const {
        const QString appDir = QCoreApplication::applicationDirPath();
        const QStringList candidates = {
            QDir(appDir).filePath(QStringLiteral("data/SoundFont/LS-GM.sf2")),
            QDir(appDir).filePath(QStringLiteral("SF2/LS-GM.sf2")),
            QDir::current().filePath(QStringLiteral("data/SoundFont/LS-GM.sf2")),
            QDir::current().filePath(QStringLiteral("SF2/LS-GM.sf2"))
        };
        for (const QString &candidate : candidates)
            if (isValidSoundFontFile(candidate)) return QFileInfo(candidate).absoluteFilePath();
        return QString();
    }

    QString discoverSoundFont() const {
        if (isValidSoundFontFile(soundFontPath_)) return soundFontPath_;
        const QString appDir = QCoreApplication::applicationDirPath();
        // Prefer the original bank if a real file is installed; this checkout's
        // EnsemblesGM file is a Git-LFS pointer, so fall through to the bundled GPL fallback.
        const QStringList candidates = {
            QDir(appDir).filePath(QStringLiteral("data/SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("data/SoundFonts/TimGM6mb.sf2")),
            QDir(appDir).filePath(QStringLiteral("SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("SoundFonts/TimGM6mb.sf2")),
            QDir(appDir).filePath(QStringLiteral("../data/SoundFonts/EnsemblesGM.sf2")),
            QDir(appDir).filePath(QStringLiteral("../data/SoundFonts/TimGM6mb.sf2")),
            QDir(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation))
                .filePath(QStringLiteral("ensembles/SoundFonts/EnsemblesGM.sf2")),
            QDir(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation))
                .filePath(QStringLiteral("ensembles/SoundFonts/TimGM6mb.sf2"))
        };
        for (const QString &candidate : candidates)
            if (isValidSoundFontFile(candidate)) return candidate;
        return QString();
    }

    bool wantsInternalAudioOutput() const {
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        // An explicit Windows MIDI-only route is authoritative. Keep an already-open
        // internal engine dormant rather than silently mirroring notes into it.
        if (route == QStringLiteral("winmm")) return false;
        if (audioEngine_ && audioEngine_->isReady() &&
            (audioEngine_->isVst2PluginLoaded() || audioEngine_->isNativeScvaActive() ||
             audioEngine_->isSyxg2006LeNativeActive() || audioEngine_->isNativeSoundFontActive() ||
             audioEngine_->isFluidSynthSoundFontActive())) return true;
        if (route == QStringLiteral("fluid") || route == QStringLiteral("lsgm") || route == QStringLiteral("both")) return true;
        return route == QStringLiteral("auto") && audioEngine_ && audioEngine_->isReady();
    }

    bool wantsWindowsMidiOutput() const {
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        // Explicit WinMM and Both are always honored, including while an internal
        // SF2/SCVA renderer is loaded. A selected physical MIDI device also receives
        // MIDI in Auto mode; choosing a port must not silently leave it disconnected.
        if (route == QStringLiteral("winmm") || route == QStringLiteral("both")) return true;
        const bool physicalDeviceSelected = midiOutputDeviceCombo_ &&
            midiOutputDeviceCombo_->currentData().toInt() >= 0;
        if (route == QStringLiteral("auto") && physicalDeviceSelected && midiOutputReady_) return true;
        return route == QStringLiteral("auto") && !(audioEngine_ && audioEngine_->isReady());
    }

    RtAudio::Api selectedRtAudioApi() const {
        if (!audioApiCombo_) return RtAudio::UNSPECIFIED;
        return static_cast<RtAudio::Api>(audioApiCombo_->currentData().toInt());
    }

    std::optional<unsigned int> selectedRtAudioDeviceId() const {
        if (!audioDeviceCombo_) return std::nullopt;
        bool ok = false;
        const qlonglong value = audioDeviceCombo_->currentData().toLongLong(&ok);
        if (!ok || value < 0 || static_cast<qulonglong>(value) > std::numeric_limits<unsigned int>::max())
            return std::nullopt;
        return static_cast<unsigned int>(value);
    }

    unsigned int selectedRtAudioSampleRate() const {
        return audioSampleRateCombo_ ? std::max(8000u, audioSampleRateCombo_->currentData().toUInt()) : 44100u;
    }

    unsigned int selectedRtAudioBufferFrames() const {
        return audioBufferCombo_ ? static_cast<unsigned int>(std::max(64, audioBufferCombo_->currentData().toInt())) : 256u;
    }

    void refreshAudioOutputDevices(qint64 preferredId) {
        if (!audioDeviceCombo_) return;
        const QSignalBlocker blocker(audioDeviceCombo_);
        audioDeviceCombo_->clear();
        audioDeviceCombo_->addItem(QStringLiteral("System default output device"), QVariant::fromValue<qlonglong>(-1));
        audioOutputDevices_ = ensembles::AudioEngine::availableOutputDevices(selectedRtAudioApi());
        for (const auto &device : audioOutputDevices_) {
            QString label = QString::fromUtf8(device.name.c_str());
            if (device.isDefaultOutput) label += QStringLiteral("  (system default)");
            label += QStringLiteral("  ·  %1 channels").arg(device.outputChannels);
            audioDeviceCombo_->addItem(label, QVariant::fromValue<qulonglong>(device.id));
        }
        int selectedIndex = 0;
        if (preferredId >= 0) {
            const int match = audioDeviceCombo_->findData(QVariant::fromValue<qulonglong>(static_cast<qulonglong>(preferredId)));
            if (match >= 0) selectedIndex = match;
        }
        audioDeviceCombo_->setCurrentIndex(selectedIndex);
        if (audioOutputDevices_.empty()) {
            audioDeviceCombo_->setItemText(0, QStringLiteral("No stereo output device found for this API"));
            audioDeviceCombo_->setEnabled(false);
        } else {
            audioDeviceCombo_->setEnabled(true);
        }
    }

    void refreshAudioSampleRates(unsigned int preferredRate) {
        if (!audioSampleRateCombo_) return;
        std::vector<unsigned int> rates;
        std::optional<unsigned int> wantedId = selectedRtAudioDeviceId();
        const ensembles::AudioEngine::OutputDevice *selected = nullptr;
        if (wantedId) {
            for (const auto &d : audioOutputDevices_) if (d.id == *wantedId) { selected = &d; break; }
        } else {
            for (const auto &d : audioOutputDevices_) if (d.isDefaultOutput) { selected = &d; break; }
            if (!selected && !audioOutputDevices_.empty()) selected = &audioOutputDevices_.front();
        }
        if (selected) {
            for (const unsigned int rate : selected->sampleRates) {
                if (rate >= 8000 && rate <= 192000 &&
                    std::find(rates.begin(), rates.end(), rate) == rates.end()) rates.push_back(rate);
            }
        }
        if (rates.empty()) rates = {22050, 32000, 44100, 48000, 88200, 96000};
        std::sort(rates.begin(), rates.end());
        const QSignalBlocker blocker(audioSampleRateCombo_);
        audioSampleRateCombo_->clear();
        for (const unsigned int rate : rates)
            audioSampleRateCombo_->addItem(QStringLiteral("%1 Hz").arg(rate), rate);
        int index = audioSampleRateCombo_->findData(preferredRate);
        if (index < 0) index = audioSampleRateCombo_->findData(44100u);
        if (index < 0) index = 0;
        audioSampleRateCombo_->setCurrentIndex(index);
    }

    void persistAudioOutputSettings() {
        QSettings settings;
        settings.setValue(QStringLiteral("audio/rtaudioApi"), static_cast<int>(selectedRtAudioApi()));
        const auto device = selectedRtAudioDeviceId();
        settings.setValue(QStringLiteral("audio/outputDeviceId"), device ? static_cast<qint64>(*device) : qint64(-1));
        settings.setValue(QStringLiteral("audio/sampleRate"), selectedRtAudioSampleRate());
        settings.setValue(QStringLiteral("audio/bufferFrames"), selectedRtAudioBufferFrames());
        settings.sync();
    }

    void applyAudioOutputSettings() {
        if (!audioSettingsReady_) return;
        if (soundFontPath_.isEmpty()) {
            persistAudioOutputSettings();
            if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Pilihan audio disimpan. Pilih SoundFont SF2 yang valid untuk membuka stream RtAudio."));
            return;
        }
        if (!audioEngine_ || !audioEngine_->isReady()) {
            QString error;
            if (loadSoundFont(soundFontPath_, false, &error)) {
                persistAudioOutputSettings();
            } else {
                persistAudioOutputSettings();
                if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Belum ada stream aktif. Gagal mengaktifkan pilihan RtAudio: %1").arg(error));
            }
            return;
        }

        const RtAudio::Api oldApi = audioEngine_->outputApi();
        const unsigned int oldDevice = audioEngine_->outputDeviceId();
        const unsigned int oldRate = audioEngine_->sampleRate();
        const unsigned int oldFrames = audioEngine_->bufferFrames();
        QString error;
        if (!loadSoundFont(soundFontPath_, false, &error)) {
            audioSettingsReady_ = false;
            const int apiIndex = audioApiCombo_->findData(static_cast<int>(oldApi));
            audioApiCombo_->setCurrentIndex(apiIndex >= 0 ? apiIndex : 0);
            refreshAudioOutputDevices(static_cast<qint64>(oldDevice));
            refreshAudioSampleRates(oldRate);
            int rateIndex = audioSampleRateCombo_->findData(oldRate);
            if (rateIndex >= 0) audioSampleRateCombo_->setCurrentIndex(rateIndex);
            int frameIndex = audioBufferCombo_->findData(static_cast<int>(oldFrames));
            if (frameIndex >= 0) audioBufferCombo_->setCurrentIndex(frameIndex);
            audioSettingsReady_ = true;
            if (audioOutputStatusLabel_) audioOutputStatusLabel_->setText(QStringLiteral("Perubahan gagal diterapkan; output lama tetap aktif. %1").arg(error));
            return;
        }
        persistAudioOutputSettings();
    }

    void updateAudioOutputStatus() {
        if (!audioOutputStatusLabel_) return;
        if (!audioEngine_ || !audioEngine_->isReady()) {
            audioOutputStatusLabel_->setText(QStringLiteral("RtAudio tidak aktif. Periksa SoundFont dan pilihan perangkat."));
            return;
        }
        const QString apiName = QString::fromUtf8(RtAudio::getApiDisplayName(audioEngine_->outputApi()).c_str());
        const QString renderer = audioEngine_->isFluidSynthSoundFontActive() ? QStringLiteral("FluidSynth SF2")
            : audioEngine_->isNativeSoundFontActive() ? QStringLiteral("Native LS-GM SF2")
            : audioEngine_->isSyxg2006LeNativeActive() ? QStringLiteral("S-YXG2006LE Native C++")
            : audioEngine_->isNativeScvaActive() ? QStringLiteral("Native SCVA C++")
            : audioEngine_->isVst2PluginLoaded() ? QStringLiteral("VST2")
            : QStringLiteral("FluidSynth");
        audioOutputStatusLabel_->setText(QStringLiteral("%1 · %2 · %3 · %4 Hz · buffer %5 frames (%6 ms per buffer, perkiraan)")
            .arg(renderer, QString::fromUtf8(audioEngine_->outputDeviceName().c_str()), apiName)
            .arg(audioEngine_->sampleRate()).arg(audioEngine_->bufferFrames())
            .arg(1000.0 * audioEngine_->bufferFrames() / std::max(1u, audioEngine_->sampleRate()), 0, 'f', 1));
    }

    QString discoverBundledVst2Plugin() const {
        const QString appDir = QCoreApplication::applicationDirPath();
        QStringList candidates;
        // A previously selected user-owned plugin takes priority if it still exists.
        if (!vst2PluginPath_.isEmpty() && QFileInfo(vst2PluginPath_).isFile())
            candidates << vst2PluginPath_;
        // Portable SCVA layout: keep its companion DLLs and data files beside its main DLL.
        candidates << QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("Plugins/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("Plugins/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("plugins/SCVA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SOUND Canvas VA.dll"))
                   << QDir(appDir).filePath(QStringLiteral("VST2/SCVA.dll"));
        for (const QString &candidate : candidates) {
            const QFileInfo info(candidate);
            if (info.isFile() && info.isReadable()) return info.absoluteFilePath();
        }
        return QString();
    }

    void initializeAudioEngine() {
        // --scva-native-required (or ENSEMBLES_SCVA_NATIVE_REQUIRED=1) is a strict
        // validation mode: native failure stays silent and visible; it must never
        // hide the failure behind a VST2 or FluidSynth fallback.
        std::vector<std::string> startupArguments;
        const QStringList qtArguments = QCoreApplication::arguments();
        startupArguments.reserve(static_cast<std::size_t>(qtArguments.size()));
        for (const QString &argument : qtArguments)
            startupArguments.push_back(argument.toStdString());
        const bool nativeRequired = ensembles::scvaNativeRequired(
            startupArguments, qgetenv("ENSEMBLES_SCVA_NATIVE_REQUIRED").toStdString());

        // Try the in-process C++ SCVA engine first. The embedded SCCore.dll is
        // read as a data image by NativeTS, never loaded as executable code.
        const QString scvaPath = discoverBundledVst2Plugin();
        const QString fallbackSoundFont = isValidSoundFontFile(soundFontPath_)
            ? soundFontPath_ : discoverSoundFont();
        const QString outputRoute = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        if (outputRoute == QStringLiteral("fluid")) {
            // An explicit FluidSynth route must win over automatic SCVA/VST2 startup.
            // In particular, the remembered external SF2 must not be silently left
            // as a fallback while another renderer takes the audio stream.
            const QString externalBank = selectedExternalSoundFont();
            const QString bank = !externalBank.isEmpty() ? externalBank : fallbackSoundFont;
            if (bank.isEmpty()) {
                const QString message = QStringLiteral("Rute FluidSynth dipilih, tetapi tidak ada SF2 valid. Pilih file SF2 eksternal terlebih dahulu.");
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth dipilih secara eksplisit; startup SCVA/VST2 tidak mengambil alih rute ini."));
                setStatus(message);
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            QString fluidError;
            if (!loadSoundFont(bank, false, &fluidError)) {
                const QString message = QStringLiteral("FluidSynth SF2 gagal dimuat: %1").arg(fluidError);
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("Rute FluidSynth dipertahankan; renderer lain tidak dijalankan sebagai pengganti."));
                setStatus(message);
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            soundFontPath_ = bank;
            QSettings settings;
            settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
            settings.setValue(QStringLiteral("audio/outputRouting"), QStringLiteral("fluid"));
            settings.sync();
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("FluidSynth SF2 aktif: %1").arg(QFileInfo(bank).fileName()));
            if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth merender SF2 pilihan; TinySoundFont tidak digunakan sebagai renderer eksternal."));
            setStatus(QStringLiteral("Rute FluidSynth aktif dengan %1.").arg(QFileInfo(bank).fileName()));
            updateAudioOutputStatus(); updateOutputStatus();
            return;
        }
        if (outputRoute == QStringLiteral("lsgm")) {
            const QString externalBank = selectedExternalSoundFont();
            if (!externalBank.isEmpty()) {
                // Migrate the previous external-SF2-to-TinySoundFont route to
                // FluidSynth without opening a second RtAudio stream.
                QString audioError;
                if (!ensureAudioEngineForVst2(QString(), &audioError)) {
                    if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("FluidSynth SF2 RtAudio gagal: %1").arg(audioError));
                    setStatus(QStringLiteral("FluidSynth SF2 tidak dapat membuka output audio: %1").arg(audioError));
                    updateAudioOutputStatus(); updateOutputStatus();
                    return;
                }
                std::string fluidError;
                const QByteArray bankPath = QDir::toNativeSeparators(externalBank).toUtf8();
                if (!audioEngine_->loadFluidSynthSoundFont(bankPath.constData(), &fluidError)) {
                    const QString message = QString::fromUtf8(fluidError.data(), static_cast<qsizetype>(fluidError.size()));
                    if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                    setStatus(QStringLiteral("FluidSynth SF2 gagal dimuat: %1").arg(message));
                    updateAudioOutputStatus(); updateOutputStatus();
                    return;
                }
                soundFontPath_ = externalBank;
                if (audioRoutingCombo_) {
                    const QSignalBlocker blocker(audioRoutingCombo_);
                    const int fluidIndex = audioRoutingCombo_->findData(QStringLiteral("fluid"));
                    if (fluidIndex >= 0) audioRoutingCombo_->setCurrentIndex(fluidIndex);
                }
                QSettings settings;
                settings.setValue(QStringLiteral("audio/outputRouting"), QStringLiteral("fluid"));
                settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                settings.sync();
                refreshSf2PresetBrowser();
                applyAllVoicePrograms();
                setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                applyPanelMidiSettings();
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("FluidSynth SF2 eksternal aktif: %1").arg(QFileInfo(externalBank).fileName()));
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth merender SF2 eksternal; TinySoundFont tidak digunakan sebagai renderer."));
                setStatus(QStringLiteral("SF2 eksternal dimuat melalui FluidSynth: %1").arg(QFileInfo(externalBank).fileName()));
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            const QString lsGmBank = discoverLsGmSoundFont();
            if (lsGmBank.isEmpty()) {
                const QString message = QStringLiteral("LS-GM.sf2 bawaan tidak ditemukan. Pilih SF2 eksternal untuk FluidSynth atau tempatkan LS-GM.sf2 di data/SoundFont/.");
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                setStatus(message);
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            QString audioError;
            if (!ensureAudioEngineForVst2(QString(), &audioError)) {
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("Native SF2 RtAudio gagal: %1").arg(audioError));
                setStatus(QStringLiteral("Native SF2 tidak dapat membuka output audio: %1").arg(audioError));
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            std::string lgError;
            const QByteArray bankPath = QDir::toNativeSeparators(lsGmBank).toUtf8();
            if (!audioEngine_->loadNativeSoundFont(bankPath.constData(), &lgError)) {
                const QString message = QString::fromUtf8(lgError.data(), static_cast<qsizetype>(lgError.size()));
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                setStatus(QStringLiteral("Native SF2 gagal dimuat: %1").arg(message));
                updateAudioOutputStatus(); updateOutputStatus();
                return;
            }
            soundFontPath_ = lsGmBank;
            setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
            applyPanelMidiSettings();
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("Native C++ LS-GM aktif: %1 (bundled LS-GM)")
                .arg(QFileInfo(lsGmBank).fileName()));
            if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("Native C++ SF2 sampler aktif; FluidSynth/VST2 tidak digunakan pada rute ini."));
            setStatus(QStringLiteral("Native C++ SF2 aktif dengan %1. Style arranger dan keyboard dirender melalui RtAudio.").arg(QFileInfo(lsGmBank).fileName()));
            updateAudioOutputStatus(); updateOutputStatus();
            return;
        }
        QString nativeScvaFailure;

        // Explicit Yamaha-native startup takes precedence over SCVA/VST2. The
        // environment variables point to the plain 2006LE bank index and a
        // PCM-zone manifest; all assets are loaded before the audio callback is resumed.
        const QString yamahaBankPath = qEnvironmentVariable("ENSEMBLES_SYXG2006LE_BANK");
        const QString yamahaPcmManifest = qEnvironmentVariable("ENSEMBLES_SYXG2006LE_PCM_MANIFEST");
        if (!yamahaBankPath.isEmpty() || !yamahaPcmManifest.isEmpty()) {
            if (yamahaBankPath.isEmpty() || yamahaPcmManifest.isEmpty()) {
                const QString message = QStringLiteral("Set both ENSEMBLES_SYXG2006LE_BANK and ENSEMBLES_SYXG2006LE_PCM_MANIFEST.");
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("Yamaha native startup requested; SCVA/VST2 startup is skipped."));
                setStatus(message);
                updateAudioOutputStatus();
                updateOutputStatus();
                return;
            }
            QString audioError;
            if (!ensureAudioEngineForVst2(fallbackSoundFont, &audioError)) {
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("Yamaha native audio device failed: %1").arg(audioError));
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("Yamaha native startup requested; no SCVA/VST2 fallback was started."));
                setStatus(QStringLiteral("Yamaha S-YXG2006LE native could not open RtAudio: %1").arg(audioError));
                updateAudioOutputStatus();
                updateOutputStatus();
                return;
            }
            std::string yamahaError;
            const QByteArray bankBytes = QDir::toNativeSeparators(yamahaBankPath).toUtf8();
            const QByteArray pcmBytes = QDir::toNativeSeparators(yamahaPcmManifest).toUtf8();
            if (!audioEngine_->loadSyxg2006LeNative(bankBytes.constData(), pcmBytes.constData(), &yamahaError)) {
                const QString detail = QString::fromUtf8(yamahaError.data(), static_cast<qsizetype>(yamahaError.size()));
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("Yamaha native renderer failed: %1").arg(detail));
                if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("Yamaha native startup requested; SCVA/VST2/FluidSynth fallback was not started."));
                setStatus(QStringLiteral("S-YXG2006LE native failed to initialize: %1").arg(detail));
                updateAudioOutputStatus();
                updateOutputStatus();
                return;
            }
            soundFontPath_.clear();
            vst2PluginPath_.clear();
            setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
            applyPanelMidiSettings();
            if (vst2PluginStatusLabel_) vst2PluginStatusLabel_->setText(QStringLiteral("S-YXG2006LE C++ PCM renderer aktif; SCVA/VST2 tidak dirender."));
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("Yamaha bank index + PCM zones dimuat; output stereo masuk langsung ke RtAudio mixer."));
            setStatus(QStringLiteral("S-YXG2006LE native C++ renderer aktif sebagai satu-satunya sumber audio internal."));
            updateAudioOutputStatus();
            updateOutputStatus();
            return;
        }

#if ENSEMBLES_HAS_NATIVE_SCVA
        QFile embeddedCore(QStringLiteral(":/SCVA/SCCore.dll"));
        if (!embeddedCore.open(QIODevice::ReadOnly)) {
            nativeScvaFailure = QStringLiteral("Embedded resource :/SCVA/SCCore.dll could not be opened.");
        } else {
            const QByteArray coreBlob = embeddedCore.readAll();
            QString audioError;
            if (ensureAudioEngineForVst2(fallbackSoundFont, &audioError)) {
                std::vector<std::uint8_t> coreBytes(
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData()),
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData() + coreBlob.size()));
                std::string nativeError;
                if (audioEngine_->loadNativeScvaFromMemory(std::move(coreBytes), &nativeError)) {
                    soundFontPath_ = fallbackSoundFont; // retained only as a user fallback path
                    vst2PluginPath_.clear();
                    QSettings settings;
                    settings.setValue(QStringLiteral("audio/vst2PluginPath"), QString());
                    settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                    settings.sync();
                    setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                    applyPanelMidiSettings();
                    applyNativeEfxSettings(true);
                    updateAudioOutputStatus();
                    updateOutputStatus();
                    if (vst2PluginStatusLabel_)
                        vst2PluginStatusLabel_->setText(QStringLiteral("SCVA aktif sebagai native C++ engine (NativeTS); VST tidak digunakan."));
                    if (soundFontStatusLabel_)
                        soundFontStatusLabel_->setText(QStringLiteral("SCCore.dll tertanam sebagai data di executable; suara dirender oleh native C++ engine."));
                    setStatus(QStringLiteral("Native SCVA aktif; Voice/Style mengirim MIDI langsung ke engine C++ tertanam."));
                    return;
                }
                nativeScvaFailure = QString::fromUtf8(nativeError.data(), static_cast<qsizetype>(nativeError.size()));
            } else {
                nativeScvaFailure = audioError;
            }
        }
#endif

        if (!ensembles::scvaVst2FallbackAllowed(nativeRequired)) {
            const QString detail = nativeScvaFailure.isEmpty()
                ? QStringLiteral("Native SCVA tidak aktif dan mode native wajib sedang aktif.")
                : nativeScvaFailure;
            if (vst2PluginStatusLabel_)
                vst2PluginStatusLabel_->setText(QStringLiteral("MODE NATIVE WAJIB: VST2 dinonaktifkan. %1").arg(detail));
            if (soundFontStatusLabel_)
                soundFontStatusLabel_->setText(QStringLiteral("Native SCVA gagal; fallback VST2 dan FluidSynth sengaja tidak dijalankan."));
            setStatus(QStringLiteral("SCVA native diwajibkan tetapi gagal diaktifkan: %1").arg(detail));
            updateAudioOutputStatus();
            updateOutputStatus();
            return;
        }

        // Automatic mode only: if native initialization fails, the exact SCVA
        // instrument may be loaded through VST2. Strict native-required mode has
        // already returned above, before any VST2/FluidSynth fallback call.
        QString scvaFailure = nativeScvaFailure;
        if (!scvaPath.isEmpty()) {
            QString audioError;
            if (ensureAudioEngineForVst2(fallbackSoundFont, &audioError)) {
                std::string pluginError;
                const QByteArray pluginBytes = QDir::toNativeSeparators(scvaPath).toUtf8();
                if (audioEngine_->loadVst2Plugin(pluginBytes.constData(), &pluginError)) {
                    vst2PluginPath_ = scvaPath;
                    soundFontPath_ = fallbackSoundFont; // retained as a fallback path; not loaded into this engine
                    QSettings settings;
                    settings.setValue(QStringLiteral("audio/vst2PluginPath"), vst2PluginPath_);
                    settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                    settings.sync();
                    setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
                    applyPanelMidiSettings();
                    updateAudioOutputStatus();
                    updateOutputStatus();
                    if (nativeScvaFailure.isEmpty()) {
                        if (vst2PluginStatusLabel_)
                            vst2PluginStatusLabel_->setText(QStringLiteral("SCVA dimuat otomatis: %1").arg(QFileInfo(scvaPath).fileName()));
                        if (soundFontStatusLabel_)
                            soundFontStatusLabel_->setText(QStringLiteral("SCVA aktif melalui host VST2 internal. SoundFont disimpan sebagai fallback dan tidak dirender."));
                        setStatus(QStringLiteral("SCVA dimuat otomatis ke host internal; Voice/Style diarahkan ke SCVA."));
                    } else {
                        if (vst2PluginStatusLabel_)
                            vst2PluginStatusLabel_->setText(QStringLiteral("Native SCVA belum aktif; SCVA asli berjalan melalui VST2. Native: %1").arg(nativeScvaFailure));
                        if (soundFontStatusLabel_)
                            soundFontStatusLabel_->setText(QStringLiteral("SCVA tetap aktif melalui VST2; native C++ menolak build SCCore.dll ini."));
                        setStatus(QStringLiteral("SCVA asli aktif via VST2; native C++ menunggu profil data yang cocok untuk SCCore.dll ini."));
                    }
                    return;
                }
                scvaFailure = QString::fromUtf8(pluginError.data(), static_cast<qsizetype>(pluginError.size()));
                if (!nativeScvaFailure.isEmpty())
                    scvaFailure += QStringLiteral("; native SCVA: ") + nativeScvaFailure;
                audioEngine_.reset();
            } else {
                scvaFailure = audioError;
                if (!nativeScvaFailure.isEmpty())
                    scvaFailure += QStringLiteral("; native SCVA: ") + nativeScvaFailure;
            }
        }

        // If a persisted SCVA path is now missing or failed at startup, avoid a
        // duplicate load attempt from loadSoundFont(); keep its path in QSettings
        // so the user can repair the portable plugin folder and retry next launch.
        const QString savedVstPath = vst2PluginPath_;
        if (!savedVstPath.isEmpty() && (scvaPath.isEmpty() || !scvaFailure.isEmpty()))
            vst2PluginPath_.clear();
        const QString candidatePath = fallbackSoundFont;
        if (candidatePath.isEmpty()) {
            if (soundFontStatusLabel_) {
                const QString detail = scvaFailure.isEmpty()
                    ? QStringLiteral("SCVA.dll tidak ditemukan di folder plugins/SCVA.")
                    : QStringLiteral("SCVA gagal dimuat: %1").arg(scvaFailure);
                soundFontStatusLabel_->setText(detail + QStringLiteral(" Tidak ada SoundFont fallback yang valid."));
            }
            if (vst2PluginStatusLabel_ && !scvaFailure.isEmpty())
                vst2PluginStatusLabel_->setText(QStringLiteral("SCVA terdeteksi tetapi gagal dimuat: %1").arg(scvaFailure));
            vst2PluginPath_ = savedVstPath;
            updateOutputStatus();
            return;
        }
        QString errorMessage;
        const bool fluidReady = loadSoundFont(candidatePath, false, &errorMessage);
        vst2PluginPath_ = savedVstPath;
        if (!fluidReady && soundFontStatusLabel_)
            soundFontStatusLabel_->setText(QStringLiteral("Gagal memuat SoundFont: %1").arg(errorMessage));
        if (!scvaFailure.isEmpty() && vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("SCVA ditemukan tetapi gagal dimuat; FluidSynth fallback. Detail: %1").arg(scvaFailure));
        else if (scvaPath.isEmpty() && !savedVstPath.isEmpty() && vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("Lokasi SCVA tersimpan tidak ditemukan; periksa plugins/SCVA/SOUND Canvas VA.dll."));
        updateOutputStatus();
    }

    bool loadSoundFont(const QString &path, bool persist, QString *errorOut = nullptr) {
        if (!isValidSoundFontFile(path)) {
            const QString message = QStringLiteral("File bukan SoundFont SF2 RIFF/SFBK yang valid. Pilih file SF2 lengkap, bukan pointer Git LFS.");
            if (errorOut) *errorOut = message;
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
            return false;
        }
        auto candidate = std::make_unique<ensembles::AudioEngine>();
        std::string error;
        const QByteArray encodedPath = QDir::toNativeSeparators(path).toUtf8();
        const QString externalBank = selectedExternalSoundFont();
        const bool isSelectedExternalBank = !externalBank.isEmpty() &&
            QFileInfo(path).absoluteFilePath().compare(externalBank, Qt::CaseInsensitive) == 0;
        const bool useLsGmRoute = audioRoutingCombo_ &&
            audioRoutingCombo_->currentData().toString() == QStringLiteral("lsgm") && !isSelectedExternalBank;
        if (!candidate->initialize(useLsGmRoute ? "" : encodedPath.constData(), &error, selectedRtAudioApi(),
                                   selectedRtAudioDeviceId(), selectedRtAudioSampleRate(),
                                   selectedRtAudioBufferFrames())) {
            const QString message = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
            if (errorOut) *errorOut = message;
            if (soundFontStatusLabel_) soundFontStatusLabel_->setText(QStringLiteral("SoundFont tidak bisa diaktifkan: %1").arg(message));
            return false;
        }
        if (useLsGmRoute) {
            if (!candidate->loadNativeSoundFont(encodedPath.constData(), &error)) {
                const QString message = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
                if (errorOut) *errorOut = message;
                if (soundFontStatusLabel_) soundFontStatusLabel_->setText(message);
                return false;
            }
        }
        QString vst2Failure;
        const bool explicitFluidRoute = audioRoutingCombo_ &&
            audioRoutingCombo_->currentData().toString() == QStringLiteral("fluid");
        if (!useLsGmRoute && !explicitFluidRoute && !vst2PluginPath_.isEmpty()) {
            const QByteArray vst2Path = QDir::toNativeSeparators(vst2PluginPath_).toUtf8();
            if (!candidate->loadVst2Plugin(vst2Path.constData(), &error))
                vst2Failure = QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size()));
        }

        // Initialize new instance completely before replacing any active engine.
        if (audioEngine_ && audioEngine_->isReady()) audioEngine_->allSoundsOff();
        audioEngine_.swap(candidate);
        soundFontPath_ = path;
        if (persist || isSelectedExternalBank) {
            QSettings settings;
            settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
            settings.setValue(QStringLiteral("audio/externalSoundFontPath"), QFileInfo(path).absoluteFilePath());
            if (isSelectedExternalBank) settings.setValue(QStringLiteral("audio/outputRouting"), QStringLiteral("fluid"));
            settings.sync();
        }
        if (isSelectedExternalBank && audioRoutingCombo_) {
            const QSignalBlocker blocker(audioRoutingCombo_);
            const int fluidIndex = audioRoutingCombo_->findData(QStringLiteral("fluid"));
            if (fluidIndex >= 0) audioRoutingCombo_->setCurrentIndex(fluidIndex);
        }
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        refreshSf2PresetBrowser();
        applyAllVoicePrograms();
        if (soundFontStatusLabel_) {
            soundFontStatusLabel_->setText(QStringLiteral("Aktif: %1\nRtAudio: %2")
                .arg(QFileInfo(path).fileName(), QString::fromUtf8(audioEngine_->outputDeviceName().c_str())));
        }
        if (vst2PluginStatusLabel_) {
            if (audioEngine_->isVst2PluginLoaded())
                vst2PluginStatusLabel_->setText(QStringLiteral("VST2 aktif: %1").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
            else if (!vst2PluginPath_.isEmpty() && !explicitFluidRoute)
                vst2PluginStatusLabel_->setText(QStringLiteral("VST2 gagal dimuat; FluidSynth tetap aktif. %1").arg(vst2Failure));
            else if (audioEngine_->isNativeSoundFontActive())
                vst2PluginStatusLabel_->setText(QStringLiteral("Native LS-GM sampler aktif; FluidSynth/VST2 tidak digunakan pada rute ini."));
            else if (audioEngine_->isFluidSynthSoundFontActive())
                vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth aktif sebagai renderer SF2; TinySoundFont tidak merender bank eksternal."));
            else
                vst2PluginStatusLabel_->setText(QStringLiteral("Instrumen eksternal: tidak aktif (FluidSynth)"));
        }
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(audioEngine_->isVst2PluginLoaded()
            ? QStringLiteral("Instrumen VST2 %1 aktif pada RtAudio; pemilihan Voice/Style mengirim MIDI ke instrumen tersebut.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()))
            : audioEngine_->isNativeSoundFontActive()
                ? QStringLiteral("Native LS-GM aktif dengan %1; arranger dan keyboard dirender melalui RtAudio.").arg(QFileInfo(path).fileName())
                : QStringLiteral("FluidSynth aktif dengan SoundFont %1; output audio lewat RtAudio.").arg(QFileInfo(path).fileName()));
        return true;
    }

    bool ensureAudioEngineForVst2(const QString &sfPath, QString *errorOut) {
        if (audioEngine_ && audioEngine_->isReady()) return true;
        (void)sfPath; // Keep the chosen SF2 as a manual fallback; do not start FluidSynth for VST selection.

        // VST-only operation requires an RtAudio stream, not a FluidSynth synth.
        // This intentionally avoids initializing FluidSynth merely to load SCVA.
        auto candidate = std::make_unique<ensembles::AudioEngine>();
        std::string audioOnlyError;
        if (!candidate->initialize("", &audioOnlyError, selectedRtAudioApi(),
                                   selectedRtAudioDeviceId(), selectedRtAudioSampleRate(),
                                   selectedRtAudioBufferFrames())) {
            if (errorOut) *errorOut = QString::fromUtf8(audioOnlyError.data(), static_cast<qsizetype>(audioOnlyError.size()));
            return false;
        }
        audioEngine_.swap(candidate);
        soundFontPath_.clear();
        return true;
    }

    void chooseVst2Plugin() {
        const QString start = vst2PluginPath_.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::MusicLocation)
            : QFileInfo(vst2PluginPath_).absolutePath();
        const QString path = QFileDialog::getOpenFileName(this,
            QStringLiteral("Pilih instrumen VST2 64-bit"), start,
            QStringLiteral("VST2 plugin 64-bit (*.dll);;Semua file (*.*)"));
        if (path.isEmpty()) return;

        QString sfPath = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
        // Reuse the active stream, or create a device-only stream if no SF2 exists.
        QString initError;
        if (!ensureAudioEngineForVst2(sfPath, &initError)) {
            QMessageBox::warning(this, QStringLiteral("Audio engine gagal"), initError);
            return;
        }
        if (!sfPath.isEmpty()) soundFontPath_ = sfPath; // Save fallback path only; FluidSynth is not initialized by VST selection.
        if (audioEngine_->isVst2PluginLoaded()) {
            std::string unloadError;
            if (!audioEngine_->unloadVst2Plugin(&unloadError)) {
                QMessageBox::warning(this, QStringLiteral("VST2 tidak bisa diganti"),
                    QString::fromUtf8(unloadError.data(), static_cast<qsizetype>(unloadError.size())));
                return;
            }
        }
        std::string error;
        const QByteArray pluginEncoded = QDir::toNativeSeparators(path).toUtf8();
        if (!audioEngine_->loadVst2Plugin(pluginEncoded.constData(), &error)) {
            const bool fluidAvailable = !audioEngine_->soundFontPath().empty();
            if (vst2PluginStatusLabel_)
                vst2PluginStatusLabel_->setText(fluidAvailable
                    ? QStringLiteral("VST2 gagal dimuat; FluidSynth aktif.")
                    : QStringLiteral("VST2 gagal dimuat; belum ada instrumen audio aktif."));
            QMessageBox::warning(this, QStringLiteral("VST2 gagal dimuat"),
                QString::fromUtf8(error.data(), static_cast<qsizetype>(error.size())));
            if (!fluidAvailable) {
                audioEngine_.reset();
                updateAudioOutputStatus();
                updateOutputStatus();
            }
            return;
        }

        vst2PluginPath_ = path;
        QSettings settings;
        // A VST instrument renders through the internal RtAudio engine. Replace
        // a stale WinMM-only route so the UI and actual MIDI route agree.
        if (audioRoutingCombo_ && audioRoutingCombo_->currentData().toString() == QStringLiteral("winmm")) {
            const int internalRoute = audioRoutingCombo_->findData(QStringLiteral("fluid"));
            if (internalRoute >= 0) {
                const QSignalBlocker blocker(audioRoutingCombo_);
                audioRoutingCombo_->setCurrentIndex(internalRoute);
            }
        }
        settings.setValue(QStringLiteral("audio/outputRouting"), audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto"));
        settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
        settings.setValue(QStringLiteral("audio/vst2PluginPath"), vst2PluginPath_);
        settings.sync();
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        for (int channel = 0; channel < 3; ++channel) {
            audioEngine_->sendMidi(static_cast<std::uint8_t>(0xC0 | channel),
                static_cast<std::uint8_t>(voicePrograms_[static_cast<std::size_t>(channel)]), 0,
                internalVoiceChannel(channel));
        }
        if (vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("VST2 aktif: %1").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
        if (soundFontStatusLabel_)
            soundFontStatusLabel_->setText(soundFontPath_.isEmpty()
                ? QStringLiteral("Mode VST2 eksklusif: FluidSynth/SoundFont tidak dimuat.")
                : QStringLiteral("FluidSynth standby, tidak ikut merender output VST2: %1").arg(QFileInfo(soundFontPath_).fileName()));
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(QStringLiteral("VST2 %1 aktif secara eksklusif melalui RtAudio; MIDI Voice/Style hanya dikirim ke VST2.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str())));
    }

    void disableVst2Plugin() {
        QString error;
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isVst2PluginLoaded()) {
            std::string unloadError;
            if (!audioEngine_->unloadVst2Plugin(&unloadError)) {
                QMessageBox::warning(this, QStringLiteral("VST2 tidak bisa dinonaktifkan"),
                    QString::fromUtf8(unloadError.data(), static_cast<qsizetype>(unloadError.size())));
                return;
            }
        }
        vst2PluginPath_.clear();
        QSettings settings;
        settings.setValue(QStringLiteral("audio/vst2PluginPath"), QString());
        settings.sync();
        if (!audioEngine_ || !audioEngine_->isReady()) {
            const QString path = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
            if (path.isEmpty() || !loadSoundFont(path, false, &error)) {
                if (vst2PluginStatusLabel_)
                    vst2PluginStatusLabel_->setText(QStringLiteral("VST2 dinonaktifkan, tetapi FluidSynth belum aktif: %1").arg(error));
                return;
            }
        }
        bool fluidAvailable = audioEngine_ && audioEngine_->isReady() && !audioEngine_->soundFontPath().empty();
        if (!fluidAvailable) {
            // The VST-only engine deliberately has no FluidSynth. Close its stream
            // before reopening the same exclusive RtAudio device for SoundFont mode.
            audioEngine_.reset();
            const QString fallback = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : discoverSoundFont();
            if (!fallback.isEmpty() && loadSoundFont(fallback, false, &error)) {
                soundFontPath_ = fallback;
                fluidAvailable = true;
            }
        }
        if (vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(fluidAvailable
                ? QStringLiteral("Instrumen eksternal: tidak aktif (FluidSynth)")
                : QStringLiteral("VST2 dinonaktifkan; pilih SoundFont untuk mengaktifkan FluidSynth."));
        updateAudioOutputStatus();
        updateOutputStatus();
        setStatus(fluidAvailable ? QStringLiteral("Kembali ke FluidSynth + RtAudio.")
                                 : QStringLiteral("VST2 dinonaktifkan; tidak ada engine instrumen aktif."));
    }

    void refreshSf2PresetBrowser() {
        sf2PresetCatalog_.clear();
        if (hasActiveSf2PresetBrowser())
            sf2PresetCatalog_ = audioEngine_->activeSoundFontPresets();
        std::sort(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(), [](const auto &a, const auto &b) {
            if (a.bank != b.bank) return a.bank < b.bank;
            if (a.program != b.program) return a.program < b.program;
            return a.name < b.name;
        });

        if (!sf2PresetCombo_) return;
        const QSignalBlocker blocker(sf2PresetCombo_);
        sf2PresetCombo_->clear();
        for (const auto &preset : sf2PresetCatalog_) {
            if (preset.program > 127 || preset.bank > 0x3fff) continue;
            const int msb = static_cast<int>((preset.bank >> 7) & 0x7f);
            const int lsb = static_cast<int>(preset.bank & 0x7f);
            const int pc = static_cast<int>(preset.program) + 1;
            const QString display = QStringLiteral("%1   ·   MSB %2 / LSB %3 / PC %4")
                .arg(QString::fromUtf8(preset.name.c_str()))
                .arg(msb).arg(lsb).arg(pc);
            const int row = sf2PresetCombo_->count();
            sf2PresetCombo_->addItem(display);
            sf2PresetCombo_->setItemData(row, msb, Qt::UserRole);
            sf2PresetCombo_->setItemData(row, lsb, Qt::UserRole + 1);
            sf2PresetCombo_->setItemData(row, static_cast<int>(preset.program), Qt::UserRole + 2);
        }
        const bool available = !sf2PresetCatalog_.empty() && hasActiveSf2PresetBrowser();
        if (sf2PartCombo_) sf2PartCombo_->setEnabled(available);
        sf2PresetCombo_->setEnabled(available);
        if (sf2BankMsbSpin_) sf2BankMsbSpin_->setEnabled(available);
        if (sf2BankLsbSpin_) sf2BankLsbSpin_->setEnabled(available);
        if (sf2ProgramSpin_) sf2ProgramSpin_->setEnabled(available);
        if (sf2ApplyPresetButton_) sf2ApplyPresetButton_->setEnabled(available);
        if (!available && sf2PresetStatusLabel_)
            sf2PresetStatusLabel_->setText(QStringLiteral("SF2 Native belum aktif. Pilih file .sf2 terlebih dahulu."));
        updateSf2PresetControlsForSlot(sf2PartCombo_ ? sf2PartCombo_->currentIndex() : 0);
    }

    void updateSf2PresetControlsForSlot(int requestedSlot) {
        const int slot = std::clamp(requestedSlot, 0, 2);
        if (sf2PartCombo_ && sf2PartCombo_->currentIndex() != slot) {
            const QSignalBlocker blocker(sf2PartCombo_);
            sf2PartCombo_->setCurrentIndex(slot);
        }
        if (sf2BankMsbSpin_) {
            const QSignalBlocker blocker(sf2BankMsbSpin_);
            sf2BankMsbSpin_->setValue(sf2BankMsb_[static_cast<std::size_t>(slot)]);
        }
        if (sf2BankLsbSpin_) {
            const QSignalBlocker blocker(sf2BankLsbSpin_);
            sf2BankLsbSpin_->setValue(sf2BankLsb_[static_cast<std::size_t>(slot)]);
        }
        if (sf2ProgramSpin_) {
            const QSignalBlocker blocker(sf2ProgramSpin_);
            sf2ProgramSpin_->setValue(sf2ProgramNumbers_[static_cast<std::size_t>(slot)] + 1);
        }
        syncSf2PresetComboToFields();
    }

    void syncSf2PresetComboToFields() {
        if (!sf2PresetCombo_ || !sf2BankMsbSpin_ || !sf2BankLsbSpin_ || !sf2ProgramSpin_) return;
        const int msb = sf2BankMsbSpin_->value();
        const int lsb = sf2BankLsbSpin_->value();
        const int program = sf2ProgramSpin_->value() - 1;
        int match = -1;
        QString presetName;
        for (int row = 0; row < sf2PresetCombo_->count(); ++row) {
            if (sf2PresetCombo_->itemData(row, Qt::UserRole).toInt() == msb &&
                sf2PresetCombo_->itemData(row, Qt::UserRole + 1).toInt() == lsb &&
                sf2PresetCombo_->itemData(row, Qt::UserRole + 2).toInt() == program) {
                match = row;
                presetName = sf2PresetCombo_->itemText(row).section(QStringLiteral("   ·   "), 0, 0);
                break;
            }
        }
        const QSignalBlocker blocker(sf2PresetCombo_);
        sf2PresetCombo_->setCurrentIndex(match);
        if (sf2ApplyPresetButton_)
            sf2ApplyPresetButton_->setEnabled(match >= 0 && hasActiveSf2PresetBrowser());
        if (!sf2PresetStatusLabel_) return;
        if (match >= 0) {
            sf2PresetStatusLabel_->setText(QStringLiteral("Preset tersedia: %1  |  Bank %2  |  PC %3 (MIDI byte %4).")
                .arg(presetName).arg((msb << 7) | lsb).arg(program + 1).arg(program));
        } else {
            sf2PresetStatusLabel_->setText(QStringLiteral("Preset tidak tersedia: MSB %1 / LSB %2 / PC %3. Pilih preset yang ada di daftar.")
                .arg(msb).arg(lsb).arg(program + 1));
        }
    }

    void selectSf2PresetEntry(int row) {
        if (row < 0 || !sf2PresetCombo_ || !sf2BankMsbSpin_ || !sf2BankLsbSpin_ || !sf2ProgramSpin_) return;
        const int msb = sf2PresetCombo_->itemData(row, Qt::UserRole).toInt();
        const int lsb = sf2PresetCombo_->itemData(row, Qt::UserRole + 1).toInt();
        const int program = sf2PresetCombo_->itemData(row, Qt::UserRole + 2).toInt();
        {
            const QSignalBlocker b1(sf2BankMsbSpin_);
            const QSignalBlocker b2(sf2BankLsbSpin_);
            const QSignalBlocker b3(sf2ProgramSpin_);
            sf2BankMsbSpin_->setValue(msb);
            sf2BankLsbSpin_->setValue(lsb);
            sf2ProgramSpin_->setValue(program + 1);
        }
        syncSf2PresetComboToFields();
    }

    void sendVoiceProgramForSlot(int slot) {
        if (!audioEngine_ || !audioEngine_->isReady() || slot < 0 || slot >= 3) return;
        const int extChannel = slot;
        const int internalChannel = internalVoiceChannel(slot);
        int msb = voiceBanks_[static_cast<std::size_t>(slot)];
        int lsb = voiceMaps_[static_cast<std::size_t>(slot)];
        int program = voicePrograms_[static_cast<std::size_t>(slot)];
        if (hasActiveSf2PresetBrowser()) {
            msb = sf2BankMsb_[static_cast<std::size_t>(slot)];
            lsb = sf2BankLsb_[static_cast<std::size_t>(slot)];
            program = sf2ProgramNumbers_[static_cast<std::size_t>(slot)];
        }
        // MIDI Bank Select order: CC0 (MSB), CC32 (LSB), then Program Change.
        sendMidi(static_cast<quint8>(0xB0 | extChannel), 0,
                 static_cast<quint8>(std::clamp(msb, 0, 127)), internalChannel);
        sendMidi(static_cast<quint8>(0xB0 | extChannel), 32,
                 static_cast<quint8>(std::clamp(lsb, 0, 127)), internalChannel);
        sendMidi(static_cast<quint8>(0xC0 | extChannel),
                 static_cast<quint8>(std::clamp(program, 0, 127)), 0, internalChannel);
        if (slot == 2) {
            // R3 remains mirrored from R2 until it receives its own voice slot.
            sendMidi(0xB3, 0, static_cast<quint8>(std::clamp(msb, 0, 127)), 3);
            sendMidi(0xB3, 32, static_cast<quint8>(std::clamp(lsb, 0, 127)), 3);
            sendMidi(0xC3, static_cast<quint8>(std::clamp(program, 0, 127)), 0, 3);
        }
    }

    void updateSf2VoiceLabels() {
        if (!hasActiveSf2PresetBrowser()) return;
        auto nameForSlot = [this](int slot) {
            const auto index = static_cast<std::size_t>(slot);
            const std::uint16_t requestedBank = static_cast<std::uint16_t>(
                (sf2BankMsb_[index] << 7) | sf2BankLsb_[index]);
            const std::uint16_t program = static_cast<std::uint16_t>(sf2ProgramNumbers_[index]);
            auto preset = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
                [requestedBank, program](const lsgm::PresetInfo &item) {
                    return item.bank == requestedBank && item.program == program;
                });
            if (preset == sf2PresetCatalog_.end()) {
                preset = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
                    [program](const lsgm::PresetInfo &item) {
                        return item.bank == 0 && item.program == program;
                    });
            }
            if (preset != sf2PresetCatalog_.end()) return QString::fromUtf8(preset->name.c_str());
            return QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]);
        };
        if (voiceR1Label_) voiceR1Label_->setText(nameForSlot(0));
        if (voiceLLabel_) voiceLLabel_->setText(nameForSlot(1));
        if (voiceR2Label_) voiceR2Label_->setText(nameForSlot(2));
        if (voiceR3Label_) voiceR3Label_->setText(nameForSlot(2)); // R3 mirrors R2.
        if (programCombo_) {
            const int slot = std::clamp(selectedProgramChannel_, 0, 2);
            const QSignalBlocker blocker(programCombo_);
            programCombo_->setCurrentIndex(sf2ProgramNumbers_[static_cast<std::size_t>(slot)]);
        }
    }

    void applyAllVoicePrograms() {
        for (int slot = 0; slot < 3; ++slot) sendVoiceProgramForSlot(slot);
        updateSf2VoiceLabels();
    }

    void applySf2PresetSelection(bool persist) {
        const int slot = sf2PartCombo_ ? std::clamp(sf2PartCombo_->currentIndex(), 0, 2) : 0;
        if (!audioEngine_ || !audioEngine_->isReady() || !hasActiveSf2PresetBrowser()) {
            if (sf2PresetStatusLabel_) sf2PresetStatusLabel_->setText(QStringLiteral("FluidSynth/Native SF2 belum aktif; preset tidak dikirim."));
            return;
        }
        const int msb = sf2BankMsbSpin_ ? sf2BankMsbSpin_->value() : 0;
        const int lsb = sf2BankLsbSpin_ ? sf2BankLsbSpin_->value() : 0;
        const int program = sf2ProgramSpin_ ? sf2ProgramSpin_->value() - 1 : 0;
        const std::uint16_t bank = static_cast<std::uint16_t>((msb << 7) | lsb);
        const auto preset = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
            [bank, program](const lsgm::PresetInfo &item) {
                return item.bank == bank && item.program == static_cast<std::uint16_t>(program);
            });
        if (preset == sf2PresetCatalog_.end()) {
            syncSf2PresetComboToFields();
            return;
        }
        sf2BankMsb_[static_cast<std::size_t>(slot)] = msb;
        sf2BankLsb_[static_cast<std::size_t>(slot)] = lsb;
        sf2ProgramNumbers_[static_cast<std::size_t>(slot)] = program;
        sendVoiceProgramForSlot(slot);
        if (programCombo_ && selectedProgramChannel_ == slot) {
            const QSignalBlocker blocker(programCombo_);
            programCombo_->setCurrentIndex(program);
        }
        const QString name = QString::fromUtf8(preset->name.c_str());
        if (slot == 0 && voiceR1Label_) voiceR1Label_->setText(name);
        if (slot == 1 && voiceLLabel_) voiceLLabel_->setText(name);
        if (slot == 2 && voiceR2Label_) voiceR2Label_->setText(name);
        if (slot == 2 && voiceR3Label_) voiceR3Label_->setText(name);
        if (persist) savePanelSettings();
        if (sf2PresetStatusLabel_)
            sf2PresetStatusLabel_->setText(QStringLiteral("Terkirim: %1  |  CC0/MSB %2 → CC32/LSB %3 → PC %4 (byte %5)  |  Bank %6.")
                .arg(name).arg(msb).arg(lsb).arg(program + 1).arg(program).arg(bank));
        setStatus(QStringLiteral("SF2 %1 · MSB %2 · LSB %3 · PC %4")
            .arg(name).arg(msb).arg(lsb).arg(program + 1));
    }

    void chooseSoundFont() {
        const QString remembered = selectedExternalSoundFont();
        const QString current = isValidSoundFontFile(soundFontPath_) ? soundFontPath_ : remembered;
        const QString start = current.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::MusicLocation) : QFileInfo(current).absolutePath();
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Pilih SoundFont SF2 eksternal"), start,
            QStringLiteral("SoundFont 2 (*.sf2);;All files (*.*)"));
        if (path.isEmpty()) return;

        const QString absolutePath = QFileInfo(path).absoluteFilePath();
        const QByteArray bankPath = QDir::toNativeSeparators(absolutePath).toUtf8();

        // Roland .STL owns the current audio route through SCVA. Remember the
        // selected external bank for the next non-STL session without replacing
        // the live SCVA engine underneath the active style.
        if (activeStyleExtension_ == QStringLiteral("stl")) {
            QSettings settings;
            soundFontPath_ = absolutePath;
            settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
            settings.setValue(QStringLiteral("audio/externalSoundFontPath"), soundFontPath_);
            settings.sync();
            if (soundFontStatusLabel_)
                soundFontStatusLabel_->setText(QStringLiteral("SF2 eksternal disimpan untuk sesi berikutnya: %1. Style .STL yang sedang aktif tetap dirender SCVA.")
                    .arg(QFileInfo(path).fileName()));
            savePanelSettings();
            setStatus(QStringLiteral("SF2 eksternal disimpan. Rute SCVA untuk Style .STL aktif tidak diubah."));
            return;
        }

        QString error;
        bool loaded = false;
        if (audioEngine_ && audioEngine_->isReady()) {
            // Reuse the existing RtAudio stream. FluidSynth is constructed and
            // populated off-callback, then atomically becomes the SF2 renderer.
            std::string rendererError;
            bool routeReleased = true;
            if (audioEngine_->isVst2PluginLoaded())
                routeReleased = audioEngine_->unloadVst2Plugin(&rendererError);
            if (routeReleased && audioEngine_->isNativeScvaActive())
                routeReleased = audioEngine_->unloadNativeScva(&rendererError);
            if (routeReleased && audioEngine_->isSyxg2006LeNativeActive())
                routeReleased = audioEngine_->unloadSyxg2006LeNative(&rendererError);
            if (!routeReleased) {
                error = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
            } else {
                loaded = audioEngine_->loadFluidSynthSoundFont(bankPath.constData(), &rendererError);
                if (!loaded)
                    error = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
            }
        } else {
            // No stream exists yet: initialize a single FluidSynth + RtAudio engine.
            if (audioRoutingCombo_) {
                const QSignalBlocker blocker(audioRoutingCombo_);
                const int fluidIndex = audioRoutingCombo_->findData(QStringLiteral("fluid"));
                if (fluidIndex >= 0) audioRoutingCombo_->setCurrentIndex(fluidIndex);
            }
            loaded = loadSoundFont(absolutePath, false, &error);
        }

        if (!loaded) {
            if (soundFontStatusLabel_)
                soundFontStatusLabel_->setText(QStringLiteral("SF2 eksternal gagal dimuat ke FluidSynth: %1").arg(error));
            QMessageBox::warning(this, QStringLiteral("SoundFont gagal dimuat"), error);
            return;
        }

        soundFontPath_ = absolutePath;
        if (audioRoutingCombo_) {
            const QSignalBlocker blocker(audioRoutingCombo_);
            const int fluidIndex = audioRoutingCombo_->findData(QStringLiteral("fluid"));
            if (fluidIndex >= 0) audioRoutingCombo_->setCurrentIndex(fluidIndex);
        }
        QSettings settings;
        settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
        settings.setValue(QStringLiteral("audio/externalSoundFontPath"), soundFontPath_);
        settings.setValue(QStringLiteral("audio/outputRouting"), QStringLiteral("fluid"));
        settings.sync();
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        refreshSf2PresetBrowser();
        applyAllVoicePrograms();
        if (soundFontStatusLabel_)
            soundFontStatusLabel_->setText(QStringLiteral("FluidSynth SF2 aktif: %1 · %2 preset")
                .arg(QFileInfo(path).fileName())
                .arg(audioEngine_ ? static_cast<qulonglong>(audioEngine_->activeSoundFontPresets().size()) : 0ULL));
        if (vst2PluginStatusLabel_)
            vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth merender SF2 eksternal; TinySoundFont bukan renderer untuk bank ini."));
        setStatus(QStringLiteral("SF2 eksternal berhasil dimuat ke FluidSynth tanpa membuka stream audio kedua: %1")
            .arg(QFileInfo(path).fileName()));
        updateAudioOutputStatus();
        updateOutputStatus();
        savePanelSettings();
    }

    void updateOutputStatus() {
        updateAudioOutputStatus();
        if (!outputLabel_) return;
        const QString deviceName = audioEngine_ && audioEngine_->isReady()
            ? QString::fromUtf8(audioEngine_->outputDeviceName().c_str()) : QString();
        const QString route = audioRoutingCombo_ ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        if (route == QStringLiteral("winmm")) {
            const QString midiDevice = midiOutputDeviceCombo_
                ? midiOutputDeviceCombo_->currentText() : QStringLiteral("Windows MIDI device");
            outputLabel_->setText(midiOutputReady_
                ? QStringLiteral("Rute aktif: %1. Keyboard dan style dikirim ke perangkat ini; audio internal dinonaktifkan.").arg(midiDevice)
                : QStringLiteral("%1 dipilih tetapi belum terbuka. Periksa perangkat MIDI OUT.").arg(midiDevice));
            return;
        }
        if (route == QStringLiteral("both")) {
            const QString internal = audioEngine_ && audioEngine_->isReady()
                ? QStringLiteral("audio internal aktif") : QStringLiteral("audio internal belum siap");
            outputLabel_->setText(QStringLiteral("Rute gabungan: %1 + %2")
                .arg(internal, midiOutputReady_ ? QStringLiteral("Windows MIDI OUT siap") : QStringLiteral("Windows MIDI OUT belum siap")));
            return;
        }
        if (route == QStringLiteral("auto") && midiOutputDeviceCombo_ &&
            midiOutputDeviceCombo_->currentData().toInt() >= 0) {
            const QString internal = audioEngine_ && audioEngine_->isReady()
                ? QStringLiteral("audio internal aktif") : QStringLiteral("audio internal tidak aktif");
            const QString external = midiOutputReady_ ? midiOutputDeviceCombo_->currentText()
                : QStringLiteral("MIDI OUT belum terbuka");
            outputLabel_->setText(QStringLiteral("Rute otomatis: %1 + %2").arg(internal, external));
            return;
        }
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isSyxg2006LeNativeActive()) {
            outputLabel_->setText(QStringLiteral("Rute aktif: S-YXG2006LE native C++ PCM renderer + RtAudio (%1). SCVA/VST2/FluidSynth tidak menerima MIDI.").arg(deviceName));
            return;
        }
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isFluidSynthSoundFontActive()) {
            outputLabel_->setText(QStringLiteral("Rute aktif: FluidSynth + SF2 + RtAudio (%1). Keyboard dan Yamaha Style dirender melalui FluidSynth; satu audio stream aktif.").arg(deviceName));
            return;
        }
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isNativeSoundFontActive()) {
            outputLabel_->setText(QStringLiteral("Rute aktif: Native LS-GM bundled + RtAudio (%1). Yamaha Style dan keyboard dirender native; FluidSynth/VST2/WinMM tidak menerima duplikasi MIDI.").arg(deviceName));
            return;
        }
        if (audioEngine_ && audioEngine_->isReady() && audioEngine_->isVst2PluginLoaded()) {
            outputLabel_->setText(QStringLiteral("Rute aktif: VST2 %1 eksklusif + RtAudio (%2). FluidSynth tidak menerima MIDI dan tidak merender output.")
                .arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName));
            return;
        }
        if (route == QStringLiteral("fluid") || route == QStringLiteral("lsgm")) {
            outputLabel_->setText(audioEngine_ && audioEngine_->isReady()
                ? (audioEngine_->isVst2PluginLoaded()
                    ? QStringLiteral("Rute aktif: VST2 %1 + RtAudio (%2).\nFallback SoundFont: %3").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName, QFileInfo(soundFontPath_).fileName())
                    : QStringLiteral("Rute aktif: FluidSynth + RtAudio (%1).\nSoundFont: %2").arg(deviceName, QFileInfo(soundFontPath_).fileName()))
                : (route == QStringLiteral("lsgm")
                    ? QStringLiteral("Native SF2 dipilih tetapi engine belum siap. Pilih bank eksternal atau pastikan data/SoundFont/LS-GM.sf2 tersedia.")
                    : QStringLiteral("Rute internal dipilih tetapi audio engine belum siap. Pilih SoundFont SF2 yang valid.")));
        } else if (route == QStringLiteral("winmm")) {
            outputLabel_->setText(midiOutputReady_ ? QStringLiteral("Rute aktif: Windows MIDI Mapper.") : QStringLiteral("Windows MIDI Mapper tidak tersedia."));
        } else if (route == QStringLiteral("both")) {
            outputLabel_->setText(QStringLiteral("Rute aktif: %1 + %2")
                .arg(audioEngine_ && audioEngine_->isReady() ? QStringLiteral("FluidSynth/RtAudio") : QStringLiteral("FluidSynth belum siap"),
                     midiOutputReady_ ? QStringLiteral("Windows MIDI Mapper") : QStringLiteral("WinMM tidak tersedia")));
        } else if (audioEngine_ && audioEngine_->isReady()) {
            outputLabel_->setText(audioEngine_->isVst2PluginLoaded()
                ? QStringLiteral("Rute otomatis: VST2 %1 + RtAudio (%2). SoundFont fallback %3.").arg(QString::fromUtf8(audioEngine_->vst2PluginName().c_str()), deviceName, QFileInfo(soundFontPath_).fileName())
                : QStringLiteral("Rute otomatis: FluidSynth + RtAudio (%1). SoundFont %2.").arg(deviceName, QFileInfo(soundFontPath_).fileName()));
        } else {
            outputLabel_->setText(midiOutputReady_
                ? QStringLiteral("Rute otomatis memakai Windows MIDI Mapper karena SoundFont/FluidSynth belum siap.")
                : QStringLiteral("Tidak ada output aktif: pilih SoundFont SF2 atau periksa perangkat MIDI Windows."));
        }
    }

    void synchronizeOutputRoutes() {
        // Clear held notes on both backends before moving subsequent notes.
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady()) audioEngine_->allSoundsOff();
#ifdef _WIN32
        if (wantsWindowsMidiOutput() && midiOut_) {
            for (int channel = 0; channel < 16; ++channel) {
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 120, 0);
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 123, 0);
            }
        }
#endif
        for (int channel = 0; channel < 3; ++channel) {
            if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady()) {
                audioEngine_->sendMidi(static_cast<std::uint8_t>(0xC0 | channel),
                    static_cast<std::uint8_t>(voicePrograms_[static_cast<std::size_t>(channel)]), 0, internalVoiceChannel(channel));
            }
            if (wantsWindowsMidiOutput()) sendWindowsMidi(static_cast<quint8>(0xC0 | channel),
                static_cast<quint8>(voicePrograms_[static_cast<std::size_t>(channel)]), 0);
        }
    }

    void testMidiOutput() {
#ifdef _WIN32
        if (!midiOutputReady_ || !midiOut_) {
            setStatus(QStringLiteral("Test MIDI OUT gagal: perangkat belum terbuka. Pilih perangkat MIDI OUT yang tersedia."));
            return;
        }
        // Initialize a predictable GM patch/level before the test note. This
        // bypasses arranger routing and clears any stale channel-volume state.
        sendWindowsMidi(0xC0, 0, 0);       // Acoustic Grand Piano, channel 1.
        sendWindowsMidi(0xB0, 7, 127);      // Channel Volume full.
        sendWindowsMidi(0xB0, 11, 127);     // Expression full.
        sendWindowsMidi(0x90, 60, 112);     // C4, audible test velocity.
        QTimer::singleShot(500, this, [this] {
            sendWindowsMidi(0x80, 60, 0);
            sendWindowsMidi(0xB0, 123, 0);
        });
        setStatus(QStringLiteral("Test MIDI OUT dikirim: GM Piano C4, channel 1, velocity 112."));
#else
        setStatus(QStringLiteral("Test MIDI OUT hanya tersedia pada Windows."));
#endif
    }

    void openMidiOutput() {
#ifdef _WIN32
        const UINT count = midiOutGetNumDevs();
        if (count == 0) {
            midiOutputReady_ = false;
            if (midiOutTestButton_) midiOutTestButton_->setEnabled(false);
            outputLabel_->setText(QStringLiteral("Tidak ada perangkat output MIDI Windows yang terdeteksi."));
            setStatus(QStringLiteral("Perangkat output MIDI Windows tidak ditemukan; audio internal tetap bisa digunakan."));
            return;
        }
        const int selectedMidiDevice = midiOutputDeviceCombo_ ? midiOutputDeviceCombo_->currentData().toInt() : -1;
        const UINT midiDeviceId = selectedMidiDevice < 0 ? MIDI_MAPPER : static_cast<UINT>(selectedMidiDevice);
        const MMRESULT result = midiOutOpen(&midiOut_, midiDeviceId, 0, 0, CALLBACK_NULL);
        if (result != MMSYSERR_NOERROR) {
            midiOut_ = nullptr;
            midiOutputReady_ = false;
            if (midiOutTestButton_) midiOutTestButton_->setEnabled(false);
            outputLabel_->setText(QStringLiteral("Output MIDI gagal dibuka (kode %1).").arg(result));
            setStatus(QStringLiteral("Gagal membuka output MIDI Windows; audio internal tetap bisa digunakan."));
            return;
        }
        midiOutputReady_ = true;
        if (midiOutTestButton_) midiOutTestButton_->setEnabled(true);
        startScheduledWindowsMidiWorker();
        MIDIOUTCAPSW caps{};
        QString deviceName = selectedMidiDevice < 0 ? QStringLiteral("Windows MIDI Mapper") : QStringLiteral("MIDI OUT device %1").arg(selectedMidiDevice);
        UINT midiOutId = 0;
        if (midiOutGetID(midiOut_, &midiOutId) == MMSYSERR_NOERROR &&
            midiOutGetDevCapsW(static_cast<UINT_PTR>(midiOutId), &caps, sizeof(caps)) == MMSYSERR_NOERROR) {
            const QString candidate = QString::fromWCharArray(caps.szPname);
            if (!candidate.isEmpty()) deviceName = candidate;
        }
        outputLabel_->setText(QStringLiteral("Perangkat eksternal terdeteksi: %1").arg(deviceName));
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        updateOutputStatus();
#else
        midiOutputReady_ = false;
        if (midiOutTestButton_) midiOutTestButton_->setEnabled(false);
        outputLabel_->setText(QStringLiteral("Windows MIDI API hanya tersedia pada Windows."));
#endif
    }

#ifdef _WIN32
    static void CALLBACK midiInputCallback(HMIDIIN, UINT message, DWORD_PTR instance,
                                           DWORD_PTR param1, DWORD_PTR) {
        if (message != MIM_DATA) return;
        auto *self = reinterpret_cast<EnsemblesWindow *>(instance);
        if (!self) return;
        const quint32 packed = static_cast<quint32>(param1);
        // WinMM calls back from a driver thread. Never touch Qt widgets or the
        // synthesizer here; queue the compact short-message to the GUI thread.
        QMetaObject::invokeMethod(self, [self, packed] {
            self->handleMidiInputMessage(packed);
        }, Qt::QueuedConnection);
    }
#endif

    void refreshMidiInputDevices() {
        if (!midiInputDeviceList_) return;
#ifndef _WIN32
        midiInputDeviceList_->clear();
        midiInputDeviceList_->setEnabled(false);
        if (midiInputStatusLabel_) midiInputStatusLabel_->setText(QStringLiteral("WinMM MIDI Input hanya tersedia pada Windows."));
        if (refreshMidiInputDevicesButton_) refreshMidiInputDevicesButton_->setEnabled(false);
#else
        const QSignalBlocker blocker(midiInputDeviceList_);
        midiInputDeviceList_->clear();
        const UINT count = midiInGetNumDevs();
        for (UINT id = 0; id < count; ++id) {
            MIDIINCAPSW caps{};
            const MMRESULT result = midiInGetDevCapsW(static_cast<UINT_PTR>(id), &caps, sizeof(caps));
            if (result != MMSYSERR_NOERROR) continue;
            auto *item = new QListWidgetItem(QString::fromWCharArray(caps.szPname), midiInputDeviceList_);
            item->setData(Qt::UserRole, id);
            item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
            item->setCheckState(midiInputHandles_.find(id) != midiInputHandles_.end()
                ? Qt::Checked : Qt::Unchecked);
            item->setToolTip(QStringLiteral("WinMM input device ID %1").arg(id));
        }
        midiInputDeviceList_->setEnabled(count > 0);
        if (refreshMidiInputDevicesButton_) refreshMidiInputDevicesButton_->setEnabled(true);
        updateMidiInputStatus();
#endif
    }

#ifdef _WIN32
    bool connectMidiInputDevice(UINT id) {
        if (midiInputHandles_.find(id) != midiInputHandles_.end()) return true;
        HMIDIIN handle = nullptr;
        const MMRESULT openResult = midiInOpen(
            &handle, id,
            reinterpret_cast<DWORD_PTR>(&EnsemblesWindow::midiInputCallback),
            reinterpret_cast<DWORD_PTR>(this), CALLBACK_FUNCTION);
        if (openResult != MMSYSERR_NOERROR || !handle) {
            setStatus(QStringLiteral("Gagal membuka MIDI input device %1 (WinMM %2).")
                .arg(id).arg(openResult));
            return false;
        }
        const MMRESULT startResult = midiInStart(handle);
        if (startResult != MMSYSERR_NOERROR) {
            midiInReset(handle);
            midiInClose(handle);
            setStatus(QStringLiteral("Gagal memulai MIDI input device %1 (WinMM %2).")
                .arg(id).arg(startResult));
            return false;
        }
        midiInputHandles_.emplace(id, handle);
        updateMidiInputStatus();
        setStatus(QStringLiteral("MIDI input terhubung: %1.").arg(id));
        return true;
    }

    void disconnectMidiInputDevice(UINT id) {
        const auto it = midiInputHandles_.find(id);
        if (it == midiInputHandles_.end()) return;
        HMIDIIN handle = it->second;
        midiInputHandles_.erase(it);
        if (handle) {
            midiInStop(handle);
            midiInReset(handle);
            midiInClose(handle);
        }
        updateMidiInputStatus();
    }

    void closeAllMidiInputDevices() {
        std::vector<HMIDIIN> handles;
        handles.reserve(midiInputHandles_.size());
        for (const auto &entry : midiInputHandles_) handles.push_back(entry.second);
        midiInputHandles_.clear();
        for (HMIDIIN handle : handles) {
            if (!handle) continue;
            midiInStop(handle);
            midiInReset(handle);
            midiInClose(handle);
        }
    }
#endif

    void updateMidiInputStatus() {
        if (!midiInputStatusLabel_) return;
#ifdef _WIN32
        const std::size_t active = midiInputHandles_.size();
        midiInputStatusLabel_->setText(active == 0
            ? QStringLiteral("Tidak ada perangkat MIDI input terhubung. Centang perangkat untuk mulai menerima note.")
            : QStringLiteral("%1 perangkat MIDI input terhubung. Note-on/note-off aktif; pemetaan CC ke kontrol UI masih dalam tahap porting.")
                .arg(static_cast<qulonglong>(active)));
#else
        midiInputStatusLabel_->setText(QStringLiteral("WinMM MIDI Input hanya tersedia pada Windows."));
#endif
    }

    void handleMidiInputMessage(quint32 packed) {
        const auto input = ensembles::decodeMidiShortMessage(packed);
        if (!input.isNoteEvent()) return; // CC mappings are ported separately from note routing.
        const quint8 data1 = input.data1;
        const quint8 data2 = input.data2;
        const int sourceChannel = static_cast<int>(input.channel);
        const bool noteOn = input.isPressed();

        const bool splitByChannel = midiSplitByChannelCheck_ && midiSplitByChannelCheck_->isChecked()
#ifdef _WIN32
            && !midiInputHandles_.empty()
#endif
            ;
        const int velocity = noteOn ? static_cast<int>(data2) : 0;
        const bool pressed = noteOn;
        if (!splitByChannel) {
            // Original synthesizer_send_notes() without midi-split routes notes
            // through the normal keyboard split/accompaniment logic.
            onKeyboardNote(static_cast<int>(data1), pressed, velocity, true);
            return;
        }

        // Port of MidiInputHost.process_note_signal(): MIDI channels 1, 2 and 3
        // select layers 0, 1 and 2; every channel above 3 maps to layer 2.
        // The legacy synthesizer uses internal channels 17 (R1), 18 (R2), 19 (L).
        // Preserve the legacy R1/R2/L channel mapping and reserve MIDI channel 4 for the new R3 part.
        const int layer = sourceChannel == 3 ? 3 : ensembles::originalMidiInputLayerForChannel(sourceChannel);
        int note = static_cast<int>(data1);
        note += transposeAmount_;
        note += octaveShiftAmount_ * 12;
        note = std::clamp(note, 0, 127);
        const quint8 noteType = pressed ? 0x90u : 0x80u;
        if (pianoKeyboard_) pianoKeyboard_->setActiveNote(static_cast<int>(data1), pressed, layer == 2 ? 1 : 0);

        // With channel splitting enabled, original MidiInputHost passes layer+17
        // to the synthesizer; L/channel 3 controls chords while accompaniment is on.
        if (layer == 2 && accompanimentEnabled_) {
            int detectedType = 0;
            int detectedGenosId = 34;
            int detectedBassPc = -1;
            const int detectedRoot = chord_finder_infer_genos(note, noteType, &detectedType, &detectedGenosId, &detectedBassPc);
            if (detectedRoot > -6) {
                styleEngine_.changeChord(detectedRoot, detectedType, detectedGenosId, detectedBassPc);
                updateChordLabel(detectedRoot, detectedType);
            }

            // Chord recognition remains active, while Split+L can also sound the left Voice.
            sendFallbackChordVoicing(note, pressed, velocity, detectedRoot);
            captureEvent(static_cast<quint8>(noteType | layer), note, velocity);
            if (splitEnabled_ && rightVoiceEnabled_[0]) {
                const auto leftStatus = static_cast<quint8>(noteType | 1u);
                sendInternalMidiOnly(leftStatus, note, velocity, 19);
                captureEvent(leftStatus, note, velocity);
            }
            return;
        }

        // External channel-split input preserves the legacy L/R1/R2 mapping, but obeys the
        // same part switches as the on-screen keyboard and never sends into a muted part.
        const int partIndex = layer == 0 ? 1 : layer == 1 ? 2 : layer == 2 ? 0 : 3; // R1, R2, L, R3
        if (!rightVoiceEnabled_[static_cast<std::size_t>(partIndex)]) return;
        const int internalChannel = layer == 3 ? 3 : 17 + layer;
        const quint8 midiStatus = static_cast<quint8>(noteType | layer);
        sendInternalMidiOnly(midiStatus, note, velocity, internalChannel);
        captureEvent(midiStatus, note, velocity);

        // Layer is a shortcut for the R2 part. R2's own ON/OFF switch remains authoritative.
        if (layer == 0 && rightVoiceEnabled_[2]) {
            const quint8 layerStatus = static_cast<quint8>(noteType | 2u);
            sendInternalMidiOnly(layerStatus, note, velocity, 18);
            captureEvent(layerStatus, note, velocity);
        }
    }

    void sendWindowsMidi(quint8 status, quint8 data1, quint8 data2) {
#ifdef _WIN32
        DWORD packed = static_cast<DWORD>(status) |
            (static_cast<DWORD>(data1 & 0x7f) << 8) |
            (static_cast<DWORD>(data2 & 0x7f) << 16);
        MMRESULT result = MMSYSERR_INVALHANDLE;
        {
            std::lock_guard<std::mutex> outputLock(midiOutMutex_);
            if (!midiOut_) return;
            result = midiOutShortMsg(midiOut_, packed);
        }
        if (result != MMSYSERR_NOERROR && midiOutputReady_) {
            midiOutputReady_ = false;
            setStatus(QStringLiteral("Perintah Windows MIDI gagal dikirim (kode %1). Periksa perangkat output.").arg(result));
            updateOutputStatus();
        }
#else
        Q_UNUSED(status); Q_UNUSED(data1); Q_UNUSED(data2);
#endif
    }

    // STYLE messages carry absolute steady-clock deadlines from StyleEngine.
    // Do not flatten them into the 3 ms Qt GUI timer: use a dedicated worker so
    // WinMM-only and dual-output routes preserve the same event phase as RtAudio.
    void sendWindowsMidiAt(quint8 status, quint8 data1, quint8 data2,
                           std::uint64_t targetTimeUs, bool styleMessage = false) {
#ifdef _WIN32
        if (targetTimeUs == 0) {
            sendWindowsMidi(status, data1, data2);
            return;
        }
        if (!midiOutputReady_ || !midiOut_) {
            ensembles::acmp_trace::Trace::instance().recordGui(
                ensembles::acmp_trace::Stage::QueueDrop,
                ensembles::acmp_trace::monotonicNowUs(), targetTimeUs, -1,
                status, data1, data2, 0, 2, "WinMM output not ready; scheduled event dropped");
            return;
        }
        bool immediateFallback = false;
        {
            std::lock_guard<std::mutex> queueLock(scheduledMidiMutex_);
            if (scheduledMidiStopping_ || !scheduledMidiThread_.joinable() ||
                scheduledMidiQueue_.size() >= 32768) {
                // Preserve delivery at startup/shutdown or under queue saturation.
                // Do the fallback after releasing the scheduler lock.
                immediateFallback = true;
            } else {
                scheduledMidiQueue_.push(ScheduledWinMidiMessage{
                    targetTimeUs, scheduledMidiSequence_++, status, data1, data2,
                    styleMessage, styleMessage ? scheduledStyleMidiGeneration_.load(std::memory_order_acquire) : 0});
            }
        }
        if (immediateFallback) {
            ensembles::acmp_trace::Trace::instance().recordGui(
                ensembles::acmp_trace::Stage::WinMmFallback,
                ensembles::acmp_trace::monotonicNowUs(), targetTimeUs, -1,
                status, data1, data2, 0, 2, "scheduler unavailable or queue saturated; sent immediately");
            sendWindowsMidi(status, data1, data2);
        } else scheduledMidiCv_.notify_one();
#else
        Q_UNUSED(status); Q_UNUSED(data1); Q_UNUSED(data2); Q_UNUSED(targetTimeUs); Q_UNUSED(styleMessage);
#endif
    }

#ifdef _WIN32
    void cancelScheduledWindowsStyleMidi() {
        // Invalidate even an event already popped by the worker but not yet
        // sent. The worker checks this generation under midiOutMutex_.
        const auto newGeneration = scheduledStyleMidiGeneration_.fetch_add(
            1, std::memory_order_acq_rel) + 1;
        {
            std::lock_guard<std::mutex> queueLock(scheduledMidiMutex_);
            std::vector<ScheduledWinMidiMessage> keep;
            keep.reserve(scheduledMidiQueue_.size());
            while (!scheduledMidiQueue_.empty()) {
                const auto event = scheduledMidiQueue_.top();
                scheduledMidiQueue_.pop();
                if (!event.styleMessage || event.styleGeneration == newGeneration)
                    keep.push_back(event);
            }
            for (const auto& event : keep) scheduledMidiQueue_.push(event);
        }
        scheduledMidiCv_.notify_one();
    }

    void startScheduledWindowsMidiWorker() {
        if (scheduledMidiThread_.joinable()) return;
        {
            std::lock_guard<std::mutex> queueLock(scheduledMidiMutex_);
            scheduledMidiStopping_ = false;
        }
        midiTimerPeriodActive_ = (timeBeginPeriod(1) == TIMERR_NOERROR);
        scheduledMidiThread_ = std::thread([this] { scheduledWindowsMidiLoop(); });
    }

    void stopScheduledWindowsMidiWorker() {
        {
            std::lock_guard<std::mutex> queueLock(scheduledMidiMutex_);
            scheduledMidiStopping_ = true;
            while (!scheduledMidiQueue_.empty()) scheduledMidiQueue_.pop();
        }
        scheduledMidiCv_.notify_all();
        if (scheduledMidiThread_.joinable()) scheduledMidiThread_.join();
        if (midiTimerPeriodActive_) {
            timeEndPeriod(1);
            midiTimerPeriodActive_ = false;
        }
    }

    void scheduledWindowsMidiLoop() {
        std::unique_lock<std::mutex> queueLock(scheduledMidiMutex_);
        for (;;) {
            if (scheduledMidiStopping_) return;
            if (scheduledMidiQueue_.empty()) {
                scheduledMidiCv_.wait(queueLock, [this] {
                    return scheduledMidiStopping_ || !scheduledMidiQueue_.empty();
                });
                continue;
            }

            const auto next = scheduledMidiQueue_.top();
            const auto deadline = std::chrono::steady_clock::time_point(
                std::chrono::microseconds(next.targetTimeUs));
            if (std::chrono::steady_clock::now() < deadline) {
                scheduledMidiCv_.wait_until(queueLock, deadline, [this, &next] {
                    return scheduledMidiStopping_ || scheduledMidiQueue_.empty() ||
                           scheduledMidiQueue_.top().sequence != next.sequence;
                });
                continue;
            }

            const auto due = scheduledMidiQueue_.top();
            scheduledMidiQueue_.pop();
            queueLock.unlock();

            const DWORD packed = static_cast<DWORD>(due.status) |
                (static_cast<DWORD>(due.data1 & 0x7f) << 8) |
                (static_cast<DWORD>(due.data2 & 0x7f) << 16);
            MMRESULT result = MMSYSERR_INVALHANDLE;
            bool hadOutput = false;
            {
                std::lock_guard<std::mutex> outputLock(midiOutMutex_);
                const bool staleStyleEvent = due.styleMessage && due.styleGeneration !=
                    scheduledStyleMidiGeneration_.load(std::memory_order_acquire);
                if (!staleStyleEvent && midiOut_) {
                    hadOutput = true;
                    result = midiOutShortMsg(midiOut_, packed);
                }
            }
            if (hadOutput) {
                const auto observedUs = ensembles::acmp_trace::monotonicNowUs();
                const std::string resultText = "MMRESULT=" + std::to_string(static_cast<unsigned long>(result));
                ensembles::acmp_trace::Trace::instance().recordWinMm(
                    ensembles::acmp_trace::Stage::WinMmSend, observedUs, due.targetTimeUs, -1,
                    due.status, due.data1, due.data2,
                    static_cast<std::uint32_t>(result), 2, resultText);
            }
            if (hadOutput && result != MMSYSERR_NOERROR) {
                QMetaObject::invokeMethod(this, [this, result] {
                    if (!midiOutputReady_) return;
                    midiOutputReady_ = false;
                    setStatus(QStringLiteral("Penjadwal Windows MIDI gagal mengirim (kode %1). Periksa perangkat output.").arg(result));
                    updateOutputStatus();
                }, Qt::QueuedConnection);
            }
            queueLock.lock();
        }
    }
#endif

    void sendInternalMidiOnly(quint8 status, int data1, int data2, int synthChannelOverride) {
        if (!audioEngine_ || !audioEngine_->isReady()) return;
        audioEngine_->sendMidi(status, static_cast<quint8>(std::clamp(data1, 0, 127)),
                               static_cast<quint8>(std::clamp(data2, 0, 127)), synthChannelOverride);
    }

    void markMidiActivity(quint8 status, quint8 data1, quint8 data2, int synthChannelOverride) {
        const int eventType = status & 0xF0;
        const int midiChannel = status & 0x0F;
        int lane = midiChannel;
        if (synthChannelOverride == 19) lane = 16; // left voice
        else if (synthChannelOverride == 17) lane = 17; // right 1
        else if (synthChannelOverride == 18) lane = 18; // right 2
        if (lane < 0 || lane >= static_cast<int>(channelActivityLevels_.size())) return;
        int level = 25;
        if (eventType == 0x90 && data2 > 0) level = 25 + (std::clamp(static_cast<int>(data2), 0, 127) * 75 / 127);
        else if (eventType == 0xB0) level = data1 == 120 || data1 == 123 ? 15 : 48;
        else if (eventType == 0x80 || (eventType == 0x90 && data2 == 0)) level = 18;
        channelActivityLevels_[static_cast<std::size_t>(lane)] = std::max(channelActivityLevels_[static_cast<std::size_t>(lane)], level);
    }

    void sendMidi(quint8 status, quint8 data1, quint8 data2, int synthChannelOverride = -1) {
        markMidiActivity(status, data1, data2, synthChannelOverride);
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady()) {
            if (!audioEngine_->sendMidi(status, data1, data2, synthChannelOverride)) {
                // Queue overflow is unlikely for ordinary UI/MIDI traffic; status is
                // not repeatedly changed here because this path may be realtime.
            }
        }
        if (wantsWindowsMidiOutput()) sendWindowsMidi(status, data1, data2);
    }

    int styleMixerPartIndexForEvent(arranger::YamahaStylePartRole role,
                                    std::uint16_t sourceTrack,
                                    int destinationMidiChannel) const noexcept {
        int partIndex = arranger::yamahaStyleMixerPartIndex(role);
        if (partIndex < 0) {
            const int trackIndex = sourceTrack > 0 ? static_cast<int>(sourceTrack) - 1 : -1;
            partIndex = arranger::yamahaStyleMixerPartIndexFallback(trackIndex, destinationMidiChannel);
        }
        return partIndex;
    }

    int styleMixerSynthChannelOverride(int partIndex, int midiChannel) const noexcept {
        if (!styleEngine_.isYamahaStyle() || !audioEngine_ ||
            !audioEngine_->isReady() ||
            !(audioEngine_->isNativeSoundFontActive() || audioEngine_->isFluidSynthSoundFontActive()))
            return -1;
        if (partIndex < 0 || partIndex >= arranger::kYamahaStyleMixerPartCount)
            partIndex = (midiChannel >= 8 && midiChannel <= 15) ? midiChannel - 8 : -1;
        return arranger::yamahaStylePrivateChannelForPart(partIndex);
    }

    void sendStyleMixerController(int partIndex, int controller, int value) {
        if (partIndex < 0 || partIndex >= arranger::kYamahaStyleMixerPartCount) return;
        const int midiChannel = std::clamp(stylePartOutputChannels_[static_cast<std::size_t>(partIndex)], 0, 15);
        sendMidi(static_cast<quint8>(0xB0 | midiChannel),
                 static_cast<quint8>(std::clamp(controller, 0, 127)),
                 static_cast<quint8>(std::clamp(value, 0, 127)),
                 styleMixerSynthChannelOverride(partIndex, midiChannel));
    }

    void setMidiOutputVolume(int value) {
        const int volume = std::clamp(value, 0, 100);
        if (audioEngine_ && audioEngine_->isReady())
            audioEngine_->setMasterGain(0.9f * static_cast<float>(volume) / 100.0f * static_cast<float>(std::clamp(audioFaderVolume_, 0, 127)) / 127.0f);
#ifdef _WIN32
        {
            std::lock_guard<std::mutex> outputLock(midiOutMutex_);
            if (midiOut_) {
                const WORD level = static_cast<WORD>((65535 * volume) / 100);
                const DWORD packed = static_cast<DWORD>(level) | (static_cast<DWORD>(level) << 16);
                midiOutSetVolume(midiOut_, packed);
            }
        }
#endif
    }

    void allSoundsOff() {
        stopArpeggiator(true);
        if (wantsInternalAudioOutput() && audioEngine_ && audioEngine_->isReady())
            audioEngine_->allSoundsOff();
        if (wantsWindowsMidiOutput()) {
            for (int channel = 0; channel < 16; ++channel) {
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 120, 0);
                sendWindowsMidi(static_cast<quint8>(0xB0 | channel), 123, 0);
            }
        }
    }

    void captureEvent(quint8 status, int note, int velocity) {
        if (!recording_) return;
        const auto elapsedUs = static_cast<std::uint64_t>(std::max<qint64>(0, recordClock_.nsecsElapsed() / 1000));
        recordedEvents_.push_back({elapsedUs, status, static_cast<std::uint8_t>(note), static_cast<std::uint8_t>(velocity)});
        recordLabel_->setText(QStringLiteral("Merekam… %1 event").arg(static_cast<qulonglong>(recordedEvents_.size())));
    }

    void loadMidi() {
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Buka berkas MIDI"), QStandardPaths::writableLocation(QStandardPaths::MusicLocation), QStringLiteral("MIDI files (*.mid *.midi *.MID *.MIDI)"));
        if (path.isEmpty()) return;
        ensembles::MidiFile parsed;
        std::string error;
        const std::filesystem::path native = std::filesystem::path(path.toStdWString());
        if (!ensembles::load_midi_file(native, parsed, error)) {
            QMessageBox::warning(this, QStringLiteral("Gagal membuka MIDI"), QString::fromLocal8Bit(error.c_str()));
            setStatus(QStringLiteral("Gagal membuka MIDI.")); return;
        }
        stopPlayback(false);
        midiFile_ = std::move(parsed); midiPath_ = path; playbackIndex_ = 0;
        midiFileLabel_->setText(QFileInfo(path).fileName());
        setStatus(QStringLiteral("MIDI dimuat: %1 — %2 event, %3 track.").arg(nativePathMessage(path)).arg(static_cast<qulonglong>(midiFile_.events.size())).arg(midiFile_.tracks));
    }

    void togglePlayback() {
        if (playbackActive_) { stopPlayback(); return; }
        if (midiFile_.events.empty()) { setStatus(QStringLiteral("Muat berkas MIDI terlebih dahulu.")); return; }
        if (!midiOutputReady_) { setStatus(QStringLiteral("Output MIDI belum siap. Periksa perangkat MIDI Windows.")); return; }
        playbackIndex_ = 0;
        playbackClock_.start();
        playbackActive_ = true;
        playbackTimer_.start();
        playButton_->setText(QStringLiteral("Ⅱ Jeda/Stop MIDI"));
        setStatus(QStringLiteral("Memutar MIDI: %1").arg(QFileInfo(midiPath_).fileName()));
    }

    void stopPlayback(bool report = true) {
        playbackTimer_.stop(); playbackActive_ = false; playbackIndex_ = 0;
        if (playButton_) playButton_->setText(QStringLiteral("▶ Putar MIDI"));
        allSoundsOff();
        if (report) setStatus(QStringLiteral("Playback MIDI dihentikan."));
    }

    void onPlaybackTick() {
        if (!playbackActive_) { playbackTimer_.stop(); return; }
        const qint64 elapsedUs = playbackClock_.nsecsElapsed() / 1000;
        const qint64 positionUs = elapsedUs * tempo_ / 120;
        while (playbackIndex_ < midiFile_.events.size() && static_cast<qint64>(midiFile_.events[playbackIndex_].time_us) <= positionUs) {
            const auto &event = midiFile_.events[playbackIndex_++];
            int data2 = event.data2;
            const int eventType = event.status & 0xF0;
            if ((eventType == 0x90 && data2 > 0) || (eventType == 0xB0 && event.data1 == 7))
                data2 = (data2 * songVolume_ + 63) / 127;
            sendMidi(event.status, event.data1, static_cast<quint8>(std::clamp(data2, 0, 127)));
        }
        if (playbackIndex_ >= midiFile_.events.size()) {
            playbackTimer_.stop(); playbackActive_ = false;
            playButton_->setText(QStringLiteral("▶ Putar MIDI"));
            allSoundsOff(); setStatus(QStringLiteral("Playback MIDI selesai."));
        }
    }

    void toggleRecording() {
        if (!recording_) {
            recordedEvents_.clear(); recordClock_.start(); recording_ = true;
            recordButton_->setText(QStringLiteral("■ Selesaikan & Simpan"));
            recordLabel_->setText(QStringLiteral("Merekam… 0 event"));
            setStatus(QStringLiteral("Rekaman MIDI dimulai. Rekaman menangkap keyboard virtual dan pad drum."));
            return;
        }
        recording_ = false; recordButton_->setText(QStringLiteral("● Rekam MIDI"));
        if (recordedEvents_.empty()) { recordLabel_->setText(QStringLiteral("Tidak ada event direkam")); setStatus(QStringLiteral("Rekaman kosong.")); return; }
        QString path = QFileDialog::getSaveFileName(this, QStringLiteral("Simpan rekaman MIDI"), QDir::current().filePath(QStringLiteral("ensembles-recording.mid")), QStringLiteral("MIDI files (*.mid)"));
        if (path.isEmpty()) { setStatus(QStringLiteral("Penyimpanan rekaman dibatalkan.")); return; }
        if (QFileInfo(path).suffix().isEmpty()) path += QStringLiteral(".mid");
        std::string error;
        const std::filesystem::path native(path.toStdWString());
        if (!ensembles::save_midi_file(native, recordedEvents_, tempo_, error)) {
            QMessageBox::warning(this, QStringLiteral("Gagal menyimpan MIDI"), QString::fromLocal8Bit(error.c_str()));
            setStatus(QStringLiteral("Gagal menyimpan rekaman MIDI.")); return;
        }
        recordLabel_->setText(QStringLiteral("%1 event tersimpan").arg(static_cast<qulonglong>(recordedEvents_.size())));
        setStatus(QStringLiteral("Rekaman MIDI disimpan: %1").arg(nativePathMessage(path)));
    }

    void triggerDrum(int note) {
        const int velocity = std::clamp((110 * padsVolume_ + 63) / 127, 1, 127);
        sendMidi(0x99, static_cast<quint8>(note), static_cast<quint8>(velocity));
        captureEvent(0x99, note, velocity);
        QTimer::singleShot(120, this, [this, note] { sendMidi(0x89, static_cast<quint8>(note), 0); captureEvent(0x89, note, 0); });
        setStatus(QStringLiteral("GM drum pad: note %1.").arg(note));
    }

    void playShortNote(int channel, int note, int velocity, int durationMs) {
        const int internalChannel = channel == 9 ? 16 : -1; // Original metronome voice.
        sendMidi(static_cast<quint8>(0x90 | channel), static_cast<quint8>(note), static_cast<quint8>(velocity), internalChannel);
        QTimer::singleShot(durationMs, this, [this, channel, note, internalChannel] {
            sendMidi(static_cast<quint8>(0x80 | channel), static_cast<quint8>(note), 0, internalChannel);
        });
    }

    void sendStyleMidi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2,
                       std::uint64_t targetTimeUs = 0, int stylePartIndex = -1) {
        const int type = status & 0xF0;
        if (type == 0xB0 && data1 == 120 && !styleMidiStopPurgeIssued_) {
            styleMidiStopPurgeIssued_ = true;
            if (audioEngine_) audioEngine_->cancelPendingStyleMidi();
#ifdef _WIN32
            cancelScheduledWindowsStyleMidi();
#endif
        }
        const bool windowsRoute = wantsWindowsMidiOutput();
        const bool internalEngineReady = audioEngine_ && audioEngine_->isReady();
        const bool yamahaInternalReady = internalEngineReady &&
            (audioEngine_->isNativeSoundFontActive() || audioEngine_->isFluidSynthSoundFontActive());
        const bool rolandInternalReady = internalEngineReady && audioEngine_->isNativeScvaActive();
        const bool styleInternalCompatible = isYamahaStyleExtension(activeStyleExtension_)
            ? yamahaInternalReady
            : (activeStyleExtension_ == QStringLiteral("stl") ? rolandInternalReady : internalEngineReady);
        // External MIDI playback is a valid renderer by itself. Only reject a style
        // when neither a compatible internal engine nor a ready WinMM output exists.
        if (!styleInternalCompatible && !windowsRoute &&
            (isYamahaStyleExtension(activeStyleExtension_) || activeStyleExtension_ == QStringLiteral("stl"))) {
            ensembles::acmp_trace::Trace::instance().recordGui(
                ensembles::acmp_trace::Stage::QueueDrop,
                ensembles::acmp_trace::monotonicNowUs(), targetTimeUs, -1,
                status, data1, data2, 0, 0,
                "STYLE MIDI blocked: no compatible internal renderer or Windows MIDI OUT route");
            return;
        }
        const int channel = status & 0x0F;
        int styleVelocity = data2;
        // Chord fader applies only to melodic accompaniment. Yamaha Style has
        // two rhythm parts (RHY1/RHY2 on zero-based channels 8 and 9).
        const bool yamahaRhythmChannel = styleEngine_.isYamahaStyle() &&
            (stylePartIndex == 0 || stylePartIndex == 1 ||
             (stylePartIndex < 0 && (channel == 8 || channel == 9)));
        if (type == 0x90 && data2 > 0 && !yamahaRhythmChannel &&
            !(stylePartIndex < 0 && channel == 9) && chordVolume_ < 127)
            styleVelocity = (styleVelocity * chordVolume_ + 63) / 127;

        const bool internalRoute = wantsInternalAudioOutput() && styleInternalCompatible;
        const int synthChannelOverride = internalRoute
            ? styleMixerSynthChannelOverride(stylePartIndex, channel) : -1;
        markMidiActivity(status, data1, data2, synthChannelOverride);
        const std::uint8_t routeMask = static_cast<std::uint8_t>((internalRoute ? 1 : 0) | (windowsRoute ? 2 : 0));
        ensembles::acmp_trace::Trace::instance().recordGui(
            ensembles::acmp_trace::Stage::OutputQueue,
            ensembles::acmp_trace::monotonicNowUs(), targetTimeUs, -1,
            status, data1, static_cast<std::uint8_t>(styleVelocity), routeMask, routeMask,
            "STYLE event handed to output route(s)");

        if (internalRoute) {
            // Yamaha Style parts are routed by their CASM/track role into stable
            // private SF2 channels 40..47. CASM may change destination MIDI channels
            // between sections; using the destination channel as mixer identity
            // caused CC7/CC10 faders to control the wrong part or no audible part.
            // Queue rejection was previously silent. Record it so a full command ring
            // cannot masquerade as a parser/timing error during the forensic run.
            const bool accepted = targetTimeUs != 0
                ? audioEngine_->sendStyleMidiAt(status, data1, static_cast<std::uint8_t>(styleVelocity), targetTimeUs, synthChannelOverride)
                : audioEngine_->sendStyleMidi(status, data1, static_cast<std::uint8_t>(styleVelocity), synthChannelOverride);
            if (!accepted) {
                ensembles::acmp_trace::Trace::instance().recordGui(
                    ensembles::acmp_trace::Stage::QueueDrop,
                    ensembles::acmp_trace::monotonicNowUs(), targetTimeUs, -1,
                    status, data1, static_cast<std::uint8_t>(styleVelocity), 1, 1,
                    "AudioEngine command queue rejected STYLE MIDI event");
            }
        }
        if (windowsRoute) {
            int externalData2 = styleVelocity;
            if (type == 0xB0 && (data1 == 7 || data1 == 11 || data1 == 10)) {
                // Keep accompaniment loudness and pan behavior consistent with the
                // internal SF2 path. Live keyboard MIDI remains byte-for-byte unchanged.
                externalData2 = ensembles::audio::compensateStyleSf2Controller(data1, data2);
            } else if (type == 0x90 && data2 > 0 && styleVolume_ < 127) {
                externalData2 = (externalData2 * styleVolume_ + 63) / 127;
            }
            sendWindowsMidiAt(status, data1,
                static_cast<std::uint8_t>(std::clamp(externalData2, 0, 127)), targetTimeUs, true);
        }
    }

    void setupStyleEngine() {
        styleEngine_.setXgEffectSink([this](const std::array<std::uint8_t, 3>& address,
                                            const std::array<std::uint8_t, 16>& data,
                                            std::uint8_t dataLength,
                                            std::uint64_t targetTimeUs) {
            if (audioEngine_ && audioEngine_->isReady())
                (void)audioEngine_->sendStyleXgEffectParameterAt(address, data, dataLength, targetTimeUs);
        });
        const auto dispatchStylePartMidi = [this](std::uint8_t status, std::uint8_t data1,
            std::uint8_t data2, std::uint64_t targetTimeUs,
            arranger::YamahaStylePartRole partRole, std::uint16_t sourceTrack) {
            const int type = status & 0xF0;
            const int channel = status & 0x0F;
            const int mixerPart = styleEngine_.isYamahaStyle()
                ? styleMixerPartIndexForEvent(partRole, sourceTrack, channel) : -1;
            const int mixerChannel = mixerPart >= 0 ? 8 + mixerPart : channel;
            if (mixerPart >= 0 && channel >= 0 && channel < 16)
                stylePartOutputChannels_[static_cast<std::size_t>(mixerPart)] = channel;

            if (type == 0xB0 && data1 == 10 && mixerChannel >= 0 && mixerChannel < 16) {
                if (auto *panKnob = channelMixerPanKnobs_[static_cast<std::size_t>(mixerChannel)]) {
                    const QSignalBlocker blocker(panKnob);
                    panKnob->setValue(std::clamp(static_cast<int>(data2), 0, 127));
                }
            }
            // Keep each visible STYLE part fader synchronized by its Yamaha role,
            // not by the CASM destination channel (which is allowed to rotate).
            if (type == 0xB0 && data1 == 7 && mixerChannel >= 0 && mixerChannel < 16) {
                const int partLevel = std::clamp(static_cast<int>(data2), 0, 127);
                channelMixerLevels_[static_cast<std::size_t>(mixerChannel)] = partLevel;
                if (auto *volumeFader = channelMixerFaders_[static_cast<std::size_t>(mixerChannel)]) {
                    const QSignalBlocker blocker(volumeFader);
                    volumeFader->setValue(partLevel);
                }
                if (styleMixerPartMuted(mixerChannel)) data2 = 0;
            }
            // Rhythm-role metadata is authoritative even when CASM routes RHY1/RHY2
            // to non-standard destination channels.
            const bool rhythmPart = partRole == arranger::YamahaStylePartRole::Rhythm1 ||
                partRole == arranger::YamahaStylePartRole::Rhythm2 ||
                (partRole == arranger::YamahaStylePartRole::Unknown &&
                 styleEngine_.isYamahaStyle() && (channel == 8 || channel == 9));
            if (!accompanimentEnabled_ && type == 0x90 && data2 > 0 && !rhythmPart &&
                !(partRole == arranger::YamahaStylePartRole::Unknown && channel == 9)) return;
            sendStyleMidi(status, data1, data2, targetTimeUs, mixerPart);
        };
        styleEngine_.setTimedMidiSink([dispatchStylePartMidi](std::uint8_t status, std::uint8_t data1,
            std::uint8_t data2, std::uint64_t targetTimeUs) {
            dispatchStylePartMidi(status, data1, data2, targetTimeUs,
                arranger::YamahaStylePartRole::Unknown, 0);
        });
        styleEngine_.setTimedYamahaPartMidiSink([dispatchStylePartMidi](std::uint8_t status,
            std::uint8_t data1, std::uint8_t data2, std::uint64_t targetTimeUs,
            arranger::YamahaStylePartRole partRole, std::uint16_t sourceTrack) {
            dispatchStylePartMidi(status, data1, data2, targetTimeUs, partRole, sourceTrack);
        });
        styleEngine_.setStateSink([this](bool playing) {
            if (playing) styleMidiStopPurgeIssued_ = false;
            if (styleStartStopButton_ && styleStartStopButton_->isChecked() != playing)
                styleStartStopButton_->setChecked(playing);
            if (playing) {
                styleClock_.start();
                lastStyleElapsedUs_ = 0;
                styleMidiTimelinePrimed_ = false;
                styleTimer_.start();
                if (styleInfo_ && styleEngine_.hasStyle())
                    styleInfo_->setText(QStringLiteral("Playing · %1 BPM · %2/%3")
                        .arg(styleEngine_.tempo())
                        .arg(styleEngine_.analysis().timeSignatureNumerator)
                        .arg(styleEngine_.analysis().timeSignatureDenominator));
            } else {
                arrangerPendingGroup_ = -1;
                arrangerPendingButton_ = -1;
                arrangerPendingMarker_ = -1;
                arrangerBreakPending_ = false;
                // The original CentralBus keeps its clock latch alive for 300 ms
                // after a section edge, even if a sync-ending stops the player.
                if (!styleEngine_.needsClockMaintenance()) styleTimer_.stop();
                if (styleInfo_ && styleEngine_.hasStyle())
                    styleInfo_->setText(QStringLiteral("Stopped · %1 BPM · %2/%3")
                        .arg(styleEngine_.tempo())
                        .arg(styleEngine_.analysis().timeSignatureNumerator)
                        .arg(styleEngine_.analysis().timeSignatureDenominator));
                if (!pendingStylePath_.isEmpty()) {
                    const QString requestedPath = pendingStylePath_;
                    QTimer::singleShot(0, this, [this, requestedPath] {
                        // If the user picked a different style while this
                        // queued callback was waiting, do not apply a stale path.
                        if (pendingStylePath_ != requestedPath) return;
                        pendingStylePath_.clear();
                        if (applyStyleFile(requestedPath, 0)) {
                            // Every newly loaded style starts at its embedded BPM,
                            // including a style change deferred until the bar edge.
                            styleEngine_.play();
                        }
                    });
                }
            }
            refreshArrangerIndicators();
        });
        styleEngine_.setPartSink([this](int markerIndex) {
            const auto setExclusive = [](const auto& buttons, int selected) {
                for (int i = 0; i < static_cast<int>(buttons.size()); ++i)
                    if (buttons[static_cast<std::size_t>(i)])
                        buttons[static_cast<std::size_t>(i)]->setChecked(i == selected);
            };
            if (markerIndex > 0) {
                int displayedMarker = markerIndex;
                // Roland STL reports its fill marker. Its destination is the next
                // odd Main marker; Yamaha runtime reports the destination directly.
                if (styleEngine_.fillPlaybackActive() && displayedMarker >= 4 &&
                    displayedMarker <= 10 && (displayedMarker % 2) == 0)
                    ++displayedMarker;

                if (displayedMarker == 1 || displayedMarker == 2 || displayedMarker == 15) {
                    arrangerActiveGroup_ = 0;
                    arrangerActiveButton_ = displayedMarker == 15 ? 2 : displayedMarker - 1;
                    setExclusive(rolandIntroButtons_, arrangerActiveButton_);
                    setExclusive(rolandVariationButtons_, -1);
                    setExclusive(rolandEndingButtons_, -1);
                } else if (displayedMarker == 3 || displayedMarker == 5 ||
                           displayedMarker == 7 || displayedMarker == 9) {
                    arrangerActiveGroup_ = 1;
                    arrangerActiveButton_ = (displayedMarker - 3) / 2;
                    setExclusive(rolandIntroButtons_, -1);
                    setExclusive(rolandVariationButtons_, arrangerActiveButton_);
                    setExclusive(rolandEndingButtons_, -1);
                    if (rolandBreakButton_) rolandBreakButton_->setChecked(false);
                } else if (displayedMarker == 11 || displayedMarker == 13 || displayedMarker == 16) {
                    arrangerActiveGroup_ = 2;
                    arrangerActiveButton_ = displayedMarker == 16 ? 2 : (displayedMarker - 11) / 2;
                    setExclusive(rolandIntroButtons_, -1);
                    setExclusive(rolandVariationButtons_, -1);
                    setExclusive(rolandEndingButtons_, arrangerActiveButton_);
                }

                // Preserve the exact panel key that was pressed when two aliases
                // map to the same source Intro/Ending pattern (legacy STL layout).
                if (arrangerPendingGroup_ >= 0 && arrangerPendingMarker_ == displayedMarker) {
                    arrangerActiveGroup_ = arrangerPendingGroup_;
                    arrangerActiveButton_ = arrangerPendingButton_;
                    arrangerPendingGroup_ = -1;
                    arrangerPendingButton_ = -1;
                    arrangerPendingMarker_ = -1;
                }
                if (styleEngine_.breakPlaybackActive()) arrangerBreakPending_ = false;
            } else if (!styleEngine_.isPlaying()) {
                // Stop clears queued transitions, but the last selected section
                // remains the red current-section lamp just like the PSR-S panel.
                if (rolandBreakButton_) rolandBreakButton_->setChecked(false);
            }
            refreshArrangerIndicators();
            static const std::array<const char*, 17> names = {
                "Config", "Intro A", "Intro B", "Variation A", "Fill A", "Variation B", "Fill B",
                "Variation C", "Fill C", "Variation D", "Fill D", "Ending A", "End of Style A",
                "Ending B", "End of Style B", "Intro C", "Ending C"};
            if (styleInfo_ && markerIndex >= 0 && markerIndex < static_cast<int>(names.size())) {
                const QString sectionName = markerIndex == 4 && styleEngine_.breakPlaybackActive()
                    ? QStringLiteral("Break")
                    : QString::fromUtf8(names[static_cast<std::size_t>(markerIndex)]);
                styleInfo_->setText(QStringLiteral("Section: %1 · %2 BPM · %3/%4")
                    .arg(sectionName)
                    .arg(styleEngine_.tempo())
                    .arg(styleEngine_.analysis().timeSignatureNumerator)
                    .arg(styleEngine_.analysis().timeSignatureDenominator));
            }
        });

        struct DiscoveredStyle {
            QString genre;
            QString name;
            QString path;
            QString category;
            QString badge;
            int tempoBpm = 0;
            bool userStyle = false;
        };

        QString builtInDirectory = QDir(QCoreApplication::applicationDirPath())
            .filePath(QStringLiteral("data/StyleFiles/Yamaha PSR-S"));
        if (!QDir(builtInDirectory).exists()) {
            const QString standardRoot = QDir(QCoreApplication::applicationDirPath())
                .filePath(QStringLiteral("data/StyleFiles"));
            const QString legacy = QDir(QCoreApplication::applicationDirPath())
                .filePath(QStringLiteral("legacy-reference/data/Styles/StyleFiles/Yamaha PSR-S"));
            if (QDir(legacy).exists()) builtInDirectory = legacy;
            else builtInDirectory = standardRoot;
        }

        // Match Application.user_data_dir + "/styles" in the original Vala
        // application: Documents/ensembles/styles on Windows.
        QString documentsDirectory = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
        if (documentsDirectory.isEmpty()) documentsDirectory = QDir::home().filePath(QStringLiteral("Documents"));
        const QString userDataDirectory = QDir(documentsDirectory).filePath(QStringLiteral("ensembles"));
        const QString userStyleDirectory = QDir(userDataDirectory).filePath(QStringLiteral("styles"));
        if (!QDir().mkpath(userStyleDirectory)) {
            styleInfo_->setText(QStringLiteral("Folder style pengguna tidak dapat dibuat: %1")
                .arg(QDir::toNativeSeparators(userStyleDirectory)));
        }

        const auto isBallroomName = [](const QString &name) {
            const QString lower = name.toLower();
            static const QStringList tokens = {
                QStringLiteral("foxtrot"), QStringLiteral("quickstep"), QStringLiteral("slowfox"),
                QStringLiteral("waltz"), QStringLiteral("polka"), QStringLiteral("mazurka"),
                QStringLiteral("tarantella"), QStringLiteral("viennese"), QStringLiteral("pasodoble"),
                QStringLiteral("swingfox"), QStringLiteral("jive"), QStringLiteral("ballroom")
            };
            for (const QString &token : tokens) if (lower.contains(token)) return true;
            return false;
        };
        const auto categoryForFolder = [&isBallroomName](const QString &folder, const QString &name, bool userStyle) {
            if (userStyle) return QStringLiteral("User");
            if (folder == QStringLiteral("Pop&Rock") || folder == QStringLiteral("Ballad"))
                return QStringLiteral("Pop&Rock");
            if (folder == QStringLiteral("Dance")) return QStringLiteral("Dance");
            if (folder == QStringLiteral("R&B")) return QStringLiteral("R&B");
            if (folder == QStringLiteral("Swing&Jazz")) return QStringLiteral("Jazz");
            if (folder == QStringLiteral("Latin&Ballroom"))
                return isBallroomName(name) ? QStringLiteral("Ballroom") : QStringLiteral("Latin");
            if (folder == QStringLiteral("Movie&Show")) return QStringLiteral("Movie&Show");
            if (folder == QStringLiteral("Entertainer")) return QStringLiteral("Entertainer");
            if (folder == QStringLiteral("World") || folder == QStringLiteral("Country"))
                return QStringLiteral("World");
            return QStringLiteral("Pop&Rock");
        };
        const auto badgeForStyle = [](const QString &category, const QString &name) {
            if (category == QStringLiteral("Pop&Rock")) {
                const QString lower = name.toLower();
                return (lower.contains(QStringLiteral("rock")) || lower.contains(QStringLiteral("grunge")) ||
                        lower.contains(QStringLiteral("stadium"))) ? QStringLiteral("Rock") : QStringLiteral("Pop");
            }
            if (category == QStringLiteral("Movie&Show")) return QStringLiteral("Movie");
            if (category == QStringLiteral("Entertainer")) return QStringLiteral("Show");
            return category;
        };

        std::vector<DiscoveredStyle> discovered;
        const auto scanStyleDirectory = [&discovered, &categoryForFolder, &badgeForStyle](const QString &path, bool userStyle) {
            QDir directory(path);
            if (!directory.exists()) return;
            QDirIterator iterator(path, QDir::Files, QDirIterator::Subdirectories);
            static const QRegularExpression tempoPattern(QStringLiteral(R"(\.T(\d{2,3})$)"),
                                                         QRegularExpression::CaseInsensitiveOption);
            while (iterator.hasNext()) {
                const QString filePath = iterator.next();
                const QFileInfo fileInfo(filePath);
                QString stem = fileInfo.completeBaseName();
                const QString extension = fileInfo.suffix().toLower();
                const bool yamahaStyle = isYamahaStyleExtension(extension);
                if (extension != QStringLiteral("enstl") && extension != QStringLiteral("stl") &&
                    !yamahaStyle) continue;

                DiscoveredStyle item;
                item.userStyle = userStyle;
                item.path = fileInfo.absoluteFilePath();
                if (extension == QStringLiteral("stl")) {
                    // Legacy Roland STL has no genre@name filename contract.
                    item.genre = QStringLiteral("Roland");
                    item.name = stem;
                } else if (yamahaStyle) {
                    if (stem.startsWith(QStringLiteral("LS-GM - "), Qt::CaseInsensitive) && extension == QStringLiteral("sty")) {
                        item.genre = QStringLiteral("LS-GM");
                        item.name = stem.mid(8);
                    } else {
                        item.genre = QStringLiteral("Yamaha ") + yamahaStyleKindLabel(extension);
                        item.name = stem;
                    }
                } else {
                    const qsizetype separator = stem.indexOf(QLatin1Char('@'));
                    // Native Ensembles filenames follow "genre@name.enstl".
                    if (separator <= 0 || separator >= stem.size() - 1) continue;
                    item.genre = stem.left(separator);
                    item.name = stem.mid(separator + 1);
                }

                const QRegularExpressionMatch tempoMatch = tempoPattern.match(item.name);
                if (tempoMatch.hasMatch()) {
                    item.tempoBpm = tempoMatch.captured(1).toInt();
                    item.name = item.name.left(tempoMatch.capturedStart());
                }
                QString folder = fileInfo.dir().dirName();
                const QString relativeFolder = QDir(path).relativeFilePath(fileInfo.absolutePath());
                const QStringList folderParts = QDir::fromNativeSeparators(relativeFolder).split(QLatin1Char('/'), Qt::SkipEmptyParts);
                if (!folderParts.isEmpty()) {
                    if (folderParts.size() >= 2 && folderParts.first().compare(QStringLiteral("Yamaha PSR-S"), Qt::CaseInsensitive) == 0)
                        folder = folderParts.at(1);
                    else
                        folder = folderParts.last();
                }
                item.category = categoryForFolder(folder, item.name, userStyle);
                item.badge = badgeForStyle(item.category, item.name);
                if (item.name.isEmpty()) item.name = QFileInfo(filePath).completeBaseName();
                discovered.push_back(std::move(item));
            }
        };
        scanStyleDirectory(builtInDirectory, false);
        scanStyleDirectory(userStyleDirectory, true);

        // Keep the existing combo as the authoritative all-style index. The
        // LCD grid filters it by the physical Yamaha category buttons and pages.
        std::stable_sort(discovered.begin(), discovered.end(), [](const auto &a, const auto &b) {
            const int categoryOrder = QString::compare(a.category, b.category, Qt::CaseInsensitive);
            if (categoryOrder != 0) return categoryOrder < 0;
            const int badgeOrder = QString::compare(a.badge, b.badge, Qt::CaseInsensitive);
            if (badgeOrder != 0) return badgeOrder < 0;
            return QString::compare(a.name, b.name, Qt::CaseInsensitive) < 0;
        });

        for (const auto &style : discovered) {
            QString display = style.genre + QStringLiteral(" — ") + style.name;
            display.replace(QLatin1Char('_'), QLatin1Char(' '));
            styleCombo_->addItem(display, style.path);
            const int comboIndex = styleCombo_->count() - 1;
            styleCombo_->setItemData(comboIndex, style.path, Qt::ToolTipRole);
            styleCombo_->setItemData(comboIndex, style.category, Qt::UserRole + 1);
            styleCombo_->setItemData(comboIndex, style.badge, Qt::UserRole + 2);
            styleCombo_->setItemData(comboIndex, style.tempoBpm > 0
                ? QStringLiteral("♩=%1").arg(style.tempoBpm) : QString(), Qt::UserRole + 3);
            styleCombo_->setItemData(comboIndex, style.userStyle, Qt::UserRole + 4);
            QString visibleName = style.name;
            visibleName.replace(QLatin1Char('_'), QLatin1Char(' '));
            styleCombo_->setItemData(comboIndex, visibleName, Qt::UserRole + 5);

            // MIDI style categories share the Yamaha SMF/CASM parser. Audio
            // style summaries are not estimated from MIDI because the song lane
            // is stored in AASM/AFil chunks.
            QString secondary;
            const QString styleExtension = QFileInfo(style.path).suffix().toLower();
            if (isYamahaStyleExtension(style.path) && styleExtension != QStringLiteral("aus") &&
                style.tempoBpm <= 0) {
                arranger::YamahaStyleRuntime runtime;
                std::string runtimeError;
                if (runtime.load(std::filesystem::path(style.path.toStdWString()), runtimeError)) {
                    const int parsedTempo = static_cast<int>(std::lround(runtime.summary().tempo_bpm));
                    secondary = QStringLiteral("%1 sections · %2 BPM")
                        .arg(static_cast<qulonglong>(runtime.summary().section_count))
                        .arg(parsedTempo);
                    if (styleCombo_->itemData(comboIndex, Qt::UserRole + 3).toString().isEmpty() && parsedTempo > 0)
                        styleCombo_->setItemData(comboIndex, QStringLiteral("♩=%1").arg(parsedTempo), Qt::UserRole + 3);
                }
            }
            ensembles::MidiFile styleMidi;
            std::string midiError;
            if (!isYamahaStyleExtension(style.path) &&
                ensembles::load_style_source_file(std::filesystem::path(style.path.toStdWString()), styleMidi, midiError)) {
                secondary = QStringLiteral("%1/%2")
                    .arg(styleMidi.time_signature_numerator)
                    .arg(styleMidi.time_signature_denominator);
                int bpm = 0;
                for (const auto &meta : styleMidi.meta_events) {
                    if (meta.type != 0x06) continue;
                    const QString marker = QString::fromStdString(meta.text);
                    if (!marker.startsWith(QStringLiteral("Config:"))) continue;
                    const int separator = marker.indexOf(QLatin1Char(';'));
                    if (separator < 0) continue;
                    const int comma = marker.indexOf(QLatin1Char(','), separator + 1);
                    bool ok = false;
                    const QString bpmText = comma < 0 ? marker.mid(separator + 1)
                                                      : marker.mid(separator + 1, comma - separator - 1);
                    const int parsedBpm = bpmText.toInt(&ok);
                    if (ok && parsedBpm > 0) { bpm = parsedBpm; break; }
                }
                if (bpm > 0) {
                    secondary += QStringLiteral("  ♩ = %1").arg(bpm);
                    styleCombo_->setItemData(comboIndex, QStringLiteral("♩=%1").arg(bpm), Qt::UserRole + 3);
                }
            }
            styleCombo_->setItemData(comboIndex, secondary, Qt::UserRole + 6);
        }
        if (discovered.empty()) {
            styleCombo_->addItem(QStringLiteral("Style Ensembles / Roland / Yamaha tidak ditemukan"));
            styleCombo_->setEnabled(false);
            styleInfo_->setText(QStringLiteral("Style tidak ditemukan. Folder pencarian mendukung .enstl, .STL, serta keluarga Yamaha .STY/.PRS/.SST/.BCS/.FPS/.PST/.PCS/.SCP/.AUS."));
            rebuildLcdStyleGrid();
        } else {
            // Start on the category shown as selected in the reference screen,
            // so the first Pop&Rock entry is highlighted when the page opens.
            int initialStyleIndex = -1;
            for (int index = 0; index < styleCombo_->count(); ++index) {
                if (!styleCombo_->itemData(index, Qt::UserRole + 4).toBool() &&
                    styleCombo_->itemData(index, Qt::UserRole + 1).toString() == lcdStyleCategory_) {
                    initialStyleIndex = index;
                    break;
                }
            }
            if (initialStyleIndex >= 0) styleCombo_->setCurrentIndex(initialStyleIndex);
            connect(styleCombo_, qOverload<int>(&QComboBox::currentIndexChanged), this,
                [this](int index) {
                rebuildLcdStyleGrid();
                if (index >= 0) loadSelectedStyle();
            });
            rebuildLcdStyleGrid();
            loadSelectedStyle();
        }
    }

    bool activateNativeRendererForStyle(const QString &path, QString *errorOut = nullptr) {
        const QString extension = QFileInfo(path).suffix().toLower();
        const bool yamahaSty = isYamahaStyleExtension(extension);
        const bool rolandStl = extension == QStringLiteral("stl");
        if (!yamahaSty && !rolandStl) {
            if (errorOut) errorOut->clear();
            return true;
        }
        const QString requestedRoute = audioRoutingCombo_
            ? audioRoutingCombo_->currentData().toString() : QStringLiteral("auto");
        const bool physicalMidiDeviceSelected = midiOutputDeviceCombo_ &&
            midiOutputDeviceCombo_->currentData().toInt() >= 0;
        const bool preserveBothRoute = requestedRoute == QStringLiteral("both");
        const bool externalMidiSelected = requestedRoute == QStringLiteral("winmm") ||
            (requestedRoute == QStringLiteral("auto") && physicalMidiDeviceSelected && midiOutputReady_);
        if (externalMidiSelected) {
            // WinMM-only, or Auto with a physical port selected, can render the
            // original style MIDI stream externally. Do not make style loading
            // depend on an internal SF2/SCVA engine being available; any compatible
            // engine already active may still mirror the style via sendStyleMidi().
            if (errorOut) errorOut->clear();
            updateOutputStatus();
            return true;
        }

        QString audioError;
        if (!audioEngine_ || !audioEngine_->isReady()) {
            if (!ensureAudioEngineForVst2(QString(), &audioError)) {
                if (errorOut) *errorOut = QStringLiteral("RtAudio tidak dapat diaktifkan: %1").arg(audioError);
                return false;
            }
        }

        std::string rendererError;
        // Every external style gets an exclusive, format-specific native renderer.
        // Tear down the previous renderer before initializing the next one so the
        // same RtAudio stream is never asked to render two sound engines.
        if (audioEngine_->isVst2PluginLoaded() && !audioEngine_->unloadVst2Plugin(&rendererError)) {
            if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
            return false;
        }
        if (audioEngine_->isSyxg2006LeNativeActive() && !audioEngine_->unloadSyxg2006LeNative(&rendererError)) {
            if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
            return false;
        }

        if (yamahaSty) {
            if (audioEngine_->isNativeScvaActive() && !audioEngine_->unloadNativeScva(&rendererError)) {
                if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
                return false;
            }
            const QString externalBank = selectedExternalSoundFont();
            if (!externalBank.isEmpty()) {
                // On Windows the chooser/settings path may use forward slashes,
                // while FluidSynth stores the native backslash form. Compare the
                // resolved file paths, not their raw text, or every Yamaha style
                // switch can reload the same large SF2 and restart RtAudio.
                const auto normalizedFilePath = [](const QString &value) {
                    QFileInfo info(QDir::fromNativeSeparators(value));
                    QString resolved = info.canonicalFilePath();
                    if (resolved.isEmpty()) resolved = info.absoluteFilePath();
                    return QDir::cleanPath(QDir::fromNativeSeparators(resolved));
                };
                const QString activeFluidBank = QString::fromUtf8(audioEngine_->soundFontPath().c_str());
                const QString requestedFluidBank = normalizedFilePath(externalBank);
                const QString activeFluidBankNormalized = normalizedFilePath(activeFluidBank);
#ifdef Q_OS_WIN
                constexpr Qt::CaseSensitivity pathCaseSensitivity = Qt::CaseInsensitive;
#else
                constexpr Qt::CaseSensitivity pathCaseSensitivity = Qt::CaseSensitive;
#endif
                const bool sameFluidBank = audioEngine_->isFluidSynthSoundFontActive() &&
                    !requestedFluidBank.isEmpty() &&
                    requestedFluidBank.compare(activeFluidBankNormalized, pathCaseSensitivity) == 0;
                if (!sameFluidBank) {
                    const QByteArray bankPath = QDir::toNativeSeparators(externalBank).toUtf8();
                    if (!audioEngine_->loadFluidSynthSoundFont(bankPath.constData(), &rendererError)) {
                        if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
                        return false;
                    }
                }
                soundFontPath_ = externalBank;
                if (audioRoutingCombo_ && !preserveBothRoute) {
                    const QSignalBlocker blocker(audioRoutingCombo_);
                    const int index = audioRoutingCombo_->findData(QStringLiteral("fluid"));
                    if (index >= 0) audioRoutingCombo_->setCurrentIndex(index);
                }
                // Avoid a synchronous settings-disk flush on every style change;
                // write only when the selected renderer/bank really changed.
                const QString rendererRoute = preserveBothRoute ? QStringLiteral("both") : QStringLiteral("fluid");
                QSettings settings;
                const QString savedBank = settings.value(QStringLiteral("audio/soundFontPath")).toString();
                const bool settingsChanged =
                    settings.value(QStringLiteral("audio/outputRouting")).toString() != rendererRoute ||
                    normalizedFilePath(savedBank).compare(requestedFluidBank, pathCaseSensitivity) != 0;
                if (settingsChanged) {
                    settings.setValue(QStringLiteral("audio/outputRouting"), rendererRoute);
                    settings.setValue(QStringLiteral("audio/soundFontPath"), soundFontPath_);
                    settings.sync();
                }
                if (soundFontStatusLabel_)
                    soundFontStatusLabel_->setText(QStringLiteral("Yamaha %1 → FluidSynth SF2 · %2")
                        .arg(yamahaStyleKindLabel(extension), QFileInfo(externalBank).fileName()));
                if (vst2PluginStatusLabel_)
                    vst2PluginStatusLabel_->setText(QStringLiteral("FluidSynth merender SF2 eksternal untuk Yamaha Style; TinySoundFont tidak digunakan."));
            } else {
                const QString bank = discoverLsGmSoundFont();
                if (bank.isEmpty()) {
                    if (errorOut) *errorOut = QStringLiteral("LS-GM.sf2 bawaan tidak ditemukan. Pilih SF2 eksternal untuk FluidSynth atau pasang LS-GM.sf2 di data/SoundFont/.");
                    return false;
                }
                const QByteArray bankPath = QDir::toNativeSeparators(bank).toUtf8();
                if (!audioEngine_->isNativeSoundFontActive() &&
                    !audioEngine_->loadNativeSoundFont(bankPath.constData(), &rendererError)) {
                    if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
                    return false;
                }
                soundFontPath_ = bank;
                if (audioRoutingCombo_ && !preserveBothRoute) {
                    const QSignalBlocker blocker(audioRoutingCombo_);
                    const int index = audioRoutingCombo_->findData(QStringLiteral("lsgm"));
                    if (index >= 0) audioRoutingCombo_->setCurrentIndex(index);
                }
                QSettings settings;
                settings.setValue(QStringLiteral("audio/outputRouting"),
                                   preserveBothRoute ? QStringLiteral("both") : QStringLiteral("lsgm"));
                settings.sync();
                if (soundFontStatusLabel_)
                    soundFontStatusLabel_->setText(QStringLiteral("Yamaha %1 → Native LS-GM · %2")
                        .arg(yamahaStyleKindLabel(extension), QFileInfo(bank).fileName()));
                if (vst2PluginStatusLabel_)
                    vst2PluginStatusLabel_->setText(QStringLiteral("Native LS-GM aktif untuk Yamaha Style; FluidSynth/VST2 tidak menerima MIDI style."));
            }
        } else {
            if (audioEngine_->isNativeSoundFontActive() && !audioEngine_->unloadNativeSoundFont(&rendererError)) {
                if (errorOut) *errorOut = QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size()));
                return false;
            }
            if (!audioEngine_->isNativeScvaActive()) {
#if ENSEMBLES_HAS_NATIVE_SCVA
                QFile embeddedCore(QStringLiteral(":/SCVA/SCCore.dll"));
                if (!embeddedCore.open(QIODevice::ReadOnly)) {
                    if (errorOut) *errorOut = QStringLiteral("SCVA Native tidak dapat diaktifkan: resource :/SCVA/SCCore.dll tidak tersedia.");
                    return false;
                }
                const QByteArray coreBlob = embeddedCore.readAll();
                std::vector<std::uint8_t> coreBytes(
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData()),
                    reinterpret_cast<const std::uint8_t *>(coreBlob.constData() + coreBlob.size()));
                if (!audioEngine_->loadNativeScvaFromMemory(std::move(coreBytes), &rendererError)) {
                    if (errorOut) *errorOut = QStringLiteral("SCVA Native gagal aktif: %1").arg(
                        QString::fromUtf8(rendererError.data(), static_cast<qsizetype>(rendererError.size())));
                    return false;
                }
#else
                if (errorOut) *errorOut = QStringLiteral("Build ini tidak menyertakan backend SCVA Native. .STL tidak akan dialihkan ke Native SF2 atau FluidSynth.");
                return false;
#endif
            }
            if (audioRoutingCombo_ && !preserveBothRoute) {
                const QSignalBlocker blocker(audioRoutingCombo_);
                const int index = audioRoutingCombo_->findData(QStringLiteral("auto"));
                if (index >= 0) audioRoutingCombo_->setCurrentIndex(index);
            }
            QSettings settings;
            settings.setValue(QStringLiteral("audio/outputRouting"),
                               preserveBothRoute ? QStringLiteral("both") : QStringLiteral("auto"));
            settings.sync();
            applyNativeEfxSettings(true);
            if (soundFontStatusLabel_)
                soundFontStatusLabel_->setText(QStringLiteral("Roland .STL → Native SCVA C++; LS-GM tidak menerima MIDI style."));
            if (vst2PluginStatusLabel_)
                vst2PluginStatusLabel_->setText(QStringLiteral("Native SCVA aktif khusus untuk Roland .STL; VST2/FluidSynth tidak digunakan."));
        }

        audioEngine_->allSoundsOff();
        setMidiOutputVolume(gainSlider_ ? gainSlider_->value() : 75);
        applyPanelMidiSettings();
        updateAudioOutputStatus();
        updateOutputStatus();
        if (errorOut) errorOut->clear();
        return true;
    }

    bool applyStyleFile(const QString &path, int customTempoBpm) {
        std::string error;
        if (!styleEngine_.loadStyle(std::filesystem::path(path.toStdWString()), customTempoBpm, error)) {
            styleInfo_->setText(QStringLiteral("Gagal memuat style: %1").arg(QString::fromLocal8Bit(error.c_str())));
            setStatus(QStringLiteral("Style Ensembles gagal dimuat."));
            return false;
        }

        QString rendererError;
        if (!activateNativeRendererForStyle(path, &rendererError)) {
            styleInfo_->setText(QStringLiteral("Style terbaca, tetapi sound engine wajib gagal diaktifkan: %1").arg(rendererError));
            setStatus(QStringLiteral("Playback diblokir: %1").arg(rendererError));
            return false;
        }
        activeStyleExtension_ = QFileInfo(path).suffix().toLower();
        for (int part = 0; part < 8; ++part)
            stylePartOutputChannels_[static_cast<std::size_t>(part)] = 8 + part;
        applyInitialYamahaStyleMixerLevels();
        arrangerActiveGroup_ = -1;
        arrangerActiveButton_ = -1;
        arrangerPendingGroup_ = -1;
        arrangerPendingButton_ = -1;
        arrangerPendingMarker_ = -1;
        arrangerBreakPending_ = false;

        // Loading a style with customTempo=0 uses the Config marker tempo in
        // the original application. A live style change passes the current BPM.
        tempo_ = styleEngine_.tempo();
        if (audioEngine_ && audioEngine_->isReady()) {
            if (const auto* effectProfile = styleEngine_.yamahaStyleEffectProfile();
                styleEngine_.isYamahaStyle() && effectProfile) {
                (void)audioEngine_->setYamahaStyleEffects(*effectProfile, tempo_);
            } else {
                (void)audioEngine_->clearYamahaStyleEffects();
            }
        }
        if (tempoSlider_) {
            const QSignalBlocker blocker(tempoSlider_);
            tempoSlider_->setValue(tempo_);
        }
        if (tempoValue_) tempoValue_->setText(QString::number(tempo_));
        if (tempoDialogValue_) tempoDialogValue_->setText(QString::number(tempo_));
        if (styleNameLabel_) {
            QString displayName = QFileInfo(path).completeBaseName();
            const qsizetype at = displayName.indexOf(QLatin1Char('@'));
            if (at >= 0) displayName = displayName.mid(at + 1);
            displayName.replace(QLatin1Char('_'), QLatin1Char(' '));
            styleNameLabel_->setText(displayName);
        }
        if (beatMetricLabel_) beatMetricLabel_->setText(QStringLiteral("%1/%2")
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator));
        if (lcdMidiMetaLabel_) lcdMidiMetaLabel_->setText(QStringLiteral("%1/%2     ♩=%3   001/001")
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator)
            .arg(tempo_));
        if (lcdStyleMetaLabel_) lcdStyleMetaLabel_->setText(QStringLiteral("Style    %1/%2     ♩ %3     1/8")
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator)
            .arg(tempo_));
        const QString audioPartNote = styleEngine_.hasYamahaAudioPart()
            ? QStringLiteral(" · Audio Part terdeteksi, belum dirender") : QString();
        QString xgEffectNote;
        if (const auto* profile = styleEngine_.yamahaStyleEffectProfile();
            profile && profile->hasAnyEffectType())
            xgEffectNote = QStringLiteral(" · Yamaha XG FX");
        styleInfo_->setText(QStringLiteral("Ready · %1 BPM · %2/%3 · %4 section slots%5%6")
            .arg(styleEngine_.tempo())
            .arg(styleEngine_.analysis().timeSignatureNumerator)
            .arg(styleEngine_.analysis().timeSignatureDenominator)
            .arg(static_cast<qulonglong>(styleEngine_.isYamahaStyle() ? 17 : 15))
            .arg(audioPartNote)
            .arg(xgEffectNote));
        chordLabel_->setText(QStringLiteral("C min"));
        const QString extension = QFileInfo(path).suffix().toLower();
        const QString sourceLabel = extension == QStringLiteral("stl")
            ? QStringLiteral("Roland STL (konversi kompatibilitas)")
            : (isYamahaStyleExtension(extension)
                ? QStringLiteral("Yamaha %1 Style · SFF/CASM") .arg(yamahaStyleKindLabel(extension))
                : QStringLiteral("Style Ensembles asli"));
        refreshArrangerIndicators();
        setStatus(styleEngine_.hasYamahaAudioPart()
            ? QStringLiteral("%1 dimuat: %2 · Audio Part terdeteksi tetapi belum dimainkan oleh decoder Audio Style.")
                .arg(sourceLabel, QFileInfo(path).completeBaseName())
            : QStringLiteral("%1 dimuat: %2").arg(sourceLabel, QFileInfo(path).completeBaseName()));
        return true;
    }

    void rebuildLcdStyleGrid() {
        if (!styleCombo_ || !lcdStyleList_) return;
        std::vector<int> matching;
        matching.reserve(static_cast<std::size_t>(styleCombo_->count()));
        for (int index = 0; index < styleCombo_->count(); ++index) {
            const bool userStyle = styleCombo_->itemData(index, Qt::UserRole + 4).toBool();
            if (userStyle != lcdStyleUserMode_) continue;
            if (!lcdStyleUserMode_) {
                const QString itemCategory = styleCombo_->itemData(index, Qt::UserRole + 1).toString();
                if (!lcdStyleCategoryGroup_.isEmpty()) {
                    if (!lcdStyleCategoryGroup_.contains(itemCategory)) continue;
                } else if (itemCategory != lcdStyleCategory_) {
                    continue;
                }
                if (!lcdStyleBadgeFilter_.isEmpty()) {
                    const QString itemBadge = styleCombo_->itemData(index, Qt::UserRole + 2).toString();
                    if (lcdStyleBadgeFilter_ == QStringLiteral("Rock/Retro")) {
                        const QString visibleName = styleCombo_->itemData(index, Qt::UserRole + 5).toString();
                        if (itemBadge != QStringLiteral("Rock") &&
                            !visibleName.contains(QStringLiteral("retro"), Qt::CaseInsensitive)) continue;
                    } else if (itemBadge != lcdStyleBadgeFilter_) {
                        continue;
                    }
                }
            }
            const QString path = styleCombo_->itemData(index).toString();
            if (lcdStyleFavoritesOnly_ && !lcdStyleFavoritePaths_.contains(path)) continue;
            if (!lcdStyleSearchText_.isEmpty()) {
                const QString haystack = styleCombo_->itemData(index, Qt::UserRole + 5).toString() + QLatin1Char(' ') + path;
                if (!haystack.contains(lcdStyleSearchText_, Qt::CaseInsensitive)) continue;
            }
            matching.push_back(index);
        }
        std::stable_sort(matching.begin(), matching.end(), [this](int left, int right) {
            const QString leftBadge = styleCombo_->itemData(left, Qt::UserRole + 2).toString();
            const QString rightBadge = styleCombo_->itemData(right, Qt::UserRole + 2).toString();
            const int badgeOrder = QString::compare(leftBadge, rightBadge, Qt::CaseInsensitive);
            if (badgeOrder != 0) return badgeOrder < 0;
            return QString::compare(styleCombo_->itemData(left, Qt::UserRole + 5).toString(),
                                    styleCombo_->itemData(right, Qt::UserRole + 5).toString(),
                                    Qt::CaseInsensitive) < 0;
        });

        std::vector<int> pageEntries;
        if (!lcdStyleUserMode_ && lcdStyleCategory_ == QStringLiteral("Pop&Rock")) {
            // The target places Pop styles in the left column and Rock styles
            // in the right column. Build each page as five Pop + five Rock
            // entries so the view's TopToBottom flow keeps those columns aligned.
            std::vector<int> popEntries;
            std::vector<int> rockEntries;
            for (const int comboIndex : matching) {
                const QString badge = styleCombo_->itemData(comboIndex, Qt::UserRole + 2).toString();
                if (badge == QStringLiteral("Rock")) rockEntries.push_back(comboIndex);
                else popEntries.push_back(comboIndex);
            }
            const std::size_t largestColumn = std::max(popEntries.size(), rockEntries.size());
            lcdStylePageCount_ = std::max(1, static_cast<int>((largestColumn + 4U) / 5U));
            lcdStylePage_ = std::clamp(lcdStylePage_, 0, lcdStylePageCount_ - 1);
            const std::size_t first = static_cast<std::size_t>(lcdStylePage_) * 5U;
            for (std::size_t offset = first; offset < std::min(first + 5U, popEntries.size()); ++offset)
                pageEntries.push_back(popEntries[offset]);
            for (std::size_t offset = first; offset < std::min(first + 5U, rockEntries.size()); ++offset)
                pageEntries.push_back(rockEntries[offset]);
        } else {
            lcdStylePageCount_ = std::max(1, static_cast<int>((matching.size() + 9U) / 10U));
            lcdStylePage_ = std::clamp(lcdStylePage_, 0, lcdStylePageCount_ - 1);
            const int first = lcdStylePage_ * 10;
            const int last = std::min(first + 10, static_cast<int>(matching.size()));
            for (int index = first; index < last; ++index)
                pageEntries.push_back(matching[static_cast<std::size_t>(index)]);
        }
        int selectedVisibleRow = -1;
        {
            const QSignalBlocker blocker(lcdStyleList_);
            lcdStyleList_->clear();
            for (const int comboIndex : pageEntries) {
                auto *item = new QListWidgetItem(
                    styleCombo_->itemData(comboIndex, Qt::UserRole + 5).toString());
                item->setData(Qt::UserRole, styleCombo_->itemData(comboIndex).toString());
                item->setData(Qt::UserRole + 1, styleCombo_->itemData(comboIndex, Qt::UserRole + 3).toString());
                item->setData(Qt::UserRole + 2, styleCombo_->itemData(comboIndex, Qt::UserRole + 2).toString());
                item->setData(Qt::UserRole + 3, comboIndex);
                item->setToolTip(QDir::toNativeSeparators(styleCombo_->itemData(comboIndex).toString()));
                lcdStyleList_->addItem(item);
                if (comboIndex == styleCombo_->currentIndex()) selectedVisibleRow = lcdStyleList_->count() - 1;
            }
            if (lcdStyleList_->count() == 0) {
                auto *empty = new QListWidgetItem(QStringLiteral("No Styles Found"));
                empty->setFlags(Qt::NoItemFlags);
                lcdStyleList_->addItem(empty);
            }
            lcdStyleList_->setCurrentRow(selectedVisibleRow);
        }

        const int firstPageInWindow = (lcdStylePage_ / 5) * 5;
        for (int slot = 0; slot < static_cast<int>(lcdStylePageButtons_.size()); ++slot) {
            auto *button = lcdStylePageButtons_[static_cast<std::size_t>(slot)];
            if (!button) continue;
            const int pageNumber = firstPageInWindow + slot;
            button->setText(QStringLiteral("P%1").arg(pageNumber + 1));
            button->setVisible(true);
            button->setEnabled(pageNumber < lcdStylePageCount_);
            button->setChecked(pageNumber == lcdStylePage_);
        }
        if (lcdStylePreviousPageButton_) lcdStylePreviousPageButton_->setEnabled(lcdStylePage_ > 0);
        if (lcdStyleNextPageButton_) lcdStyleNextPageButton_->setEnabled(lcdStylePage_ + 1 < lcdStylePageCount_);
        if (lcdStylePathLabel_) {
            const QString mode = lcdStyleUserMode_ ? QStringLiteral("User:") : QStringLiteral("Preset:");
            const QString category = lcdStyleUserMode_ ? QStringLiteral("All Styles")
                : (!lcdStyleShortcutLabel_.isEmpty() ? lcdStyleShortcutLabel_ : lcdStyleCategory_);
            lcdStylePathLabel_->setText(QStringLiteral("%1/%2/").arg(mode, category));
        }
        if (lcdStyleFavoritesButton_) lcdStyleFavoritesButton_->setChecked(lcdStyleFavoritesOnly_);
        if (lcdStylePresetButton_) lcdStylePresetButton_->setChecked(!lcdStyleUserMode_);
        if (lcdStyleUserButton_) lcdStyleUserButton_->setChecked(lcdStyleUserMode_);
        for (auto *button : lcdStyleCategoryButtons_) {
            if (!button) continue;
            const QString buttonCategory = button->property("styleCategory").toString();
            const bool categorySelected = lcdStyleCategoryGroup_.isEmpty()
                ? buttonCategory == lcdStyleCategory_ : lcdStyleCategoryGroup_.contains(buttonCategory);
            button->setChecked(!lcdStyleUserMode_ && categorySelected);
        }
    }

    void addExternalStyleToPicker(const QString &path) {
        if (!styleCombo_ || !lcdStyleList_ || path.isEmpty()) return;

        int index = styleCombo_->findData(path);
        if (index < 0) {
            // Replace the empty-library placeholder when the user loads the
            // first style directly from disk.
            if (styleCombo_->count() == 1 && styleCombo_->itemData(0).toString().isEmpty()) {
                const QSignalBlocker comboBlocker(styleCombo_);
                const QSignalBlocker listBlocker(lcdStyleList_);
                styleCombo_->clear();
                lcdStyleList_->clear();
                styleCombo_->setEnabled(true);
            }

            const QFileInfo info(path);
            const QString extension = info.suffix().toLower();
            const QString genre = extension == QStringLiteral("stl")
                ? QStringLiteral("Roland")
                : (isYamahaStyleExtension(extension)
                    ? QStringLiteral("Yamaha ") + yamahaStyleKindLabel(extension) : QStringLiteral("Ensembles"));
            QString visibleName = info.completeBaseName();
            static const QRegularExpression externalTempoPattern(QStringLiteral(R"(\.T(\d{2,3})$)"),
                                                                 QRegularExpression::CaseInsensitiveOption);
            const QRegularExpressionMatch tempoMatch = externalTempoPattern.match(visibleName);
            const QString tempo = tempoMatch.hasMatch()
                ? QStringLiteral("♩=%1").arg(tempoMatch.captured(1)) : QString();
            if (tempoMatch.hasMatch()) visibleName = visibleName.left(tempoMatch.capturedStart());
            visibleName.replace(QLatin1Char('_'), QLatin1Char(' '));
            const QString display = genre + QStringLiteral(" — ") + visibleName;

            const QSignalBlocker comboBlocker(styleCombo_);
            styleCombo_->addItem(display, path);
            index = styleCombo_->count() - 1;
            styleCombo_->setItemData(index, path, Qt::ToolTipRole);
            styleCombo_->setItemData(index, QStringLiteral("User"), Qt::UserRole + 1);
            styleCombo_->setItemData(index, QStringLiteral("User"), Qt::UserRole + 2);
            styleCombo_->setItemData(index, tempo, Qt::UserRole + 3);
            styleCombo_->setItemData(index, true, Qt::UserRole + 4);
            styleCombo_->setItemData(index, visibleName, Qt::UserRole + 5);
            styleCombo_->setItemData(index, QStringLiteral("Loaded from PC · %1").arg(info.suffix().toUpper()), Qt::UserRole + 6);
        }

        // Keep the combo and LCD browser in lockstep, but block the combo's
        // change handler because the file was already loaded by the caller.
        const QSignalBlocker comboBlocker(styleCombo_);
        styleCombo_->setEnabled(true);
        styleCombo_->setCurrentIndex(index);
        lcdStyleUserMode_ = true;
        lcdStyleCategoryGroup_.clear();
        lcdStyleBadgeFilter_.clear();
        lcdStyleShortcutLabel_.clear();
        lcdStyleFavoritesOnly_ = false;
        lcdStyleSearchText_.clear();
        lcdStylePage_ = 0;
        rebuildLcdStyleGrid();
    }

    void openStyleFileFromPc() {
        QSettings settings;
        QString startDirectory = settings.value(
            QStringLiteral("stylePicker/lastDirectory"),
            QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)).toString();
        if (startDirectory.isEmpty() || !QDir(startDirectory).exists())
            startDirectory = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
        if (startDirectory.isEmpty()) startDirectory = QDir::homePath();

        const QString filters = QStringLiteral(
            "Yamaha PSR/SX/Genos styles (*.STY *.sty *.PRS *.prs *.SST *.sst *.BCS *.bcs *.FPS *.fps *.PST *.pst *.PCS *.pcs *.SCP *.scp *.AUS *.aus);;"
            "Roland styles (*.STL *.stl);;"
            "All supported style files (*.enstl *.STY *.sty *.PRS *.prs *.SST *.sst *.BCS *.bcs *.FPS *.fps *.PST *.pst *.PCS *.pcs *.SCP *.scp *.AUS *.aus *.STL *.stl)");
        const QString path = QFileDialog::getOpenFileName(
            this, QStringLiteral("Load Style from PC"), startDirectory, filters);
        if (path.isEmpty()) return;

        const QFileInfo selectedFile(path);
        const QString extension = selectedFile.suffix().toLower();
        if (!isYamahaStyleExtension(extension) && extension != QStringLiteral("stl") &&
            extension != QStringLiteral("enstl")) {
            QMessageBox::warning(this, QStringLiteral("Unsupported style file"),
                QStringLiteral("Pilih keluarga Yamaha (.STY/.PRS/.SST/.BCS/.FPS/.PST/.PCS/.SCP/.AUS), Roland .STL, atau Ensembles .enstl."));
            return;
        }
        settings.setValue(QStringLiteral("stylePicker/lastDirectory"), selectedFile.absolutePath());
        settings.sync();

        if (styleEngine_.isPlaying()) {
            // Change at the safe bar boundary, then adopt the newly loaded
            // style's authored BPM before playback resumes.
            addExternalStyleToPicker(path);
            pendingStylePath_ = path;
            styleEngine_.requestStyleChangeStop();
            setStatus(QStringLiteral("Pergantian style dijadwalkan pada birama berikutnya; tempo mengikuti BPM bawaan style."));
            return;
        }

        pendingStylePath_.clear();
        if (applyStyleFile(path, 0)) {
            addExternalStyleToPicker(path);
            setStatus(QStringLiteral("Style berhasil dimuat dari PC: %1")
                .arg(QDir::toNativeSeparators(path)));
        }
    }

    void loadSelectedStyle() {
        if (!styleCombo_ || styleCombo_->currentData().toString().isEmpty()) return;
        const QString path = styleCombo_->currentData().toString();
        if (styleEngine_.isPlaying()) {
            // End the current section via sync-stop, then load and resume
            // the selected style at its embedded BPM.
            pendingStylePath_ = path;
            styleEngine_.requestStyleChangeStop();
            setStatus(QStringLiteral("Pergantian style dijadwalkan pada birama berikutnya; tempo mengikuti BPM bawaan style."));
            return;
        }
        // A direct selection made after playback stopped supersedes a queued
        // switch that has not yet run its zero-delay callback.
        pendingStylePath_.clear();
        applyStyleFile(path, 0);
    }

    void onStyleTick() {
        if (!styleClock_.isValid()) return;
        const qint64 elapsed = styleClock_.nsecsElapsed() / 1000;
        const qint64 delta = std::max<qint64>(0, elapsed - lastStyleElapsedUs_);
        lastStyleElapsedUs_ = elapsed;
        const auto steadyNow = std::chrono::steady_clock::now().time_since_epoch();
        const auto nowUs = static_cast<std::uint64_t>(
            std::chrono::duration_cast<std::chrono::microseconds>(steadyNow).count());
        // Prime ahead for every active STYLE output route. Both RtAudio and the
        // WinMM worker receive the same absolute event deadlines, so dual-output
        // mode must not disable look-ahead for either route.
        constexpr std::uint64_t kMidiLookAheadUs = 15'000;
        const std::uint64_t leadUs = (wantsInternalAudioOutput() || wantsWindowsMidiOutput())
            ? kMidiLookAheadUs : 0;
        const std::uint64_t deltaUs = static_cast<std::uint64_t>(delta);
        const bool firstAdvance = !styleMidiTimelinePrimed_;
        const std::uint64_t intervalStartUs = nowUs >= deltaUs
            ? nowUs - deltaUs + (firstAdvance ? 0 : leadUs)
            : (firstAdvance ? 0 : leadUs);
        const std::uint64_t advanceUs = deltaUs + (firstAdvance ? leadUs : 0);
        styleMidiTimelinePrimed_ = true;
        styleEngine_.advanceMicroseconds(advanceUs, intervalStartUs);
        if (!styleEngine_.isPlaying() && !styleEngine_.needsClockMaintenance())
            styleTimer_.stop();
    }

    void updateChordLabel(int detectedRoot, int detectedType) {
        if (!chordLabel_ || detectedRoot <= -6 ||
            detectedType < 0 || detectedType >= static_cast<int>(kChordTypeNames.size())) return;
        const int pitchClass = ((detectedRoot % 12) + 12) % 12;
        QString type = QString::fromUtf8(kChordTypeNames[static_cast<std::size_t>(detectedType)]);
        type.replace(QStringLiteral("Major"), QStringLiteral(""));
        type.replace(QStringLiteral("Minor"), QStringLiteral("min"));
        type = type.trimmed();
        chordLabel_->setText(QStringLiteral("%1%2")
            .arg(QString::fromUtf8(kChordNames[static_cast<std::size_t>(pitchClass)]))
            .arg(type.isEmpty() ? QString() : QStringLiteral(" ") + type));
    }

    void sendFallbackChordVoicing(int alreadyTransposedNote, bool pressed, int velocity, int detectedRoot) {
        const int note = std::clamp(alreadyTransposedNote, 0, 127);
        if (pressed) {
            // This mirrors synthesizer.c: get_central_style_looping()==0 and
            // get_central_style_sync_start()==0 are both required for attacks.
            if (detectedRoot <= -6 || styleEngine_.isLooping() || styleEngine_.syncStartPending()) return;
            const int v = std::clamp(velocity, 1, 127);
            sendInternalMidiOnly(0xb0, 91, 0, 20);
            sendInternalMidiOnly(0xb0, 91, 0, 21);
            sendInternalMidiOnly(0xb0, 120, 0, 21);
            sendInternalMidiOnly(0x90, std::clamp(note + 12, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.6), 1, 127), 20);
            sendInternalMidiOnly(0x90, std::clamp(detectedRoot + 36, 0, 127), v, 21);
            sendInternalMidiOnly(0x90, std::clamp(note + 36, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.2), 1, 127), 22);
            sendInternalMidiOnly(0x90, std::clamp(note + 24, 0, 127),
                                 std::clamp(static_cast<int>(v * 0.4), 1, 127), 22);
            return;
        }
        sendInternalMidiOnly(0x80, std::clamp(note + 12, 0, 127), 0, 20);
        sendInternalMidiOnly(0xb0, 120, 0, 21);
        sendInternalMidiOnly(0x80, std::clamp(note + 36, 0, 127), 0, 22);
        sendInternalMidiOnly(0x80, std::clamp(note + 24, 0, 127), 0, 22);
    }

    void updateArpeggiatorTimer() {
        if (!arpButton_ || !arpButton_->isChecked() || arpeggiatorHeldNotes_.empty()) {
            if (!arpButton_ || !arpButton_->isChecked()) arpeggiatorTimer_.stop();
            return;
        }
        const int pattern = arpSpin_ ? std::clamp(arpSpin_->value(), 1, 12) : 1;
        const int bpm = std::clamp(tempo_, 40, 240);
        static constexpr std::array<int, 4> divisions = {60000, 30000, 15000, 45000}; // quarter, eighth, sixteenth, dotted eighth
        const int denominator = divisions[static_cast<std::size_t>((pattern - 1) % 4)];
        arpeggiatorTimer_.setInterval(std::max(40, denominator / bpm));
        if (!arpeggiatorTimer_.isActive()) arpeggiatorTimer_.start();
    }

    void releaseArpeggiatorCurrentNote() {
        if (arpeggiatorCurrentNote_ < 0) return;
        const int slot = std::clamp(arpeggiatorCurrentVoiceSlot_, 0, 3);
        const auto noteOffStatus = static_cast<quint8>(0x80 | slot);
        if (arpeggiatorCurrentInternalOnly_) sendInternalMidiOnly(noteOffStatus, arpeggiatorCurrentNote_, 0, internalVoiceChannel(slot));
        else sendMidi(noteOffStatus, static_cast<quint8>(arpeggiatorCurrentNote_), 0, internalVoiceChannel(slot));
        captureEvent(noteOffStatus, arpeggiatorCurrentNote_, 0);
        if (arpeggiatorCurrentLayered_) {
            if (arpeggiatorCurrentInternalOnly_) sendInternalMidiOnly(0x82, arpeggiatorCurrentNote_, 0, internalVoiceChannel(2));
            else sendMidi(0x82, static_cast<quint8>(arpeggiatorCurrentNote_), 0, internalVoiceChannel(2));
            captureEvent(0x82, arpeggiatorCurrentNote_, 0);
        }
        arpeggiatorCurrentNote_ = -1;
        arpeggiatorCurrentLayered_ = false;
        arpeggiatorCurrentInternalOnly_ = false;
    }

    void stopArpeggiator(bool clearHeld) {
        arpeggiatorTimer_.stop();
        releaseArpeggiatorCurrentNote();
        if (clearHeld) arpeggiatorHeldNotes_.clear();
        arpeggiatorStep_ = 0;
    }

    void advanceArpeggiator() {
        if (!arpButton_ || !arpButton_->isChecked() || arpeggiatorHeldNotes_.empty()) {
            stopArpeggiator(false);
            return;
        }
        releaseArpeggiatorCurrentNote();
        auto notes = arpeggiatorHeldNotes_;
        std::stable_sort(notes.begin(), notes.end(), [](const auto &a, const auto &b) {
            if (a.note != b.note) return a.note < b.note;
            return a.voiceSlot < b.voiceSlot;
        });
        const int count = static_cast<int>(notes.size());
        const int pattern = arpSpin_ ? std::clamp(arpSpin_->value(), 1, 12) : 1;
        const int direction = (pattern - 1) / 4;
        int index = 0;
        if (direction == 0) index = arpeggiatorStep_ % count;
        else if (direction == 1) index = count - 1 - (arpeggiatorStep_ % count);
        else if (count == 1) index = 0;
        else {
            const int period = count * 2 - 2;
            const int phase = arpeggiatorStep_ % period;
            index = phase < count ? phase : period - phase;
        }
        const auto note = notes[static_cast<std::size_t>(index)];
        arpeggiatorCurrentNote_ = note.note;
        arpeggiatorCurrentVoiceSlot_ = note.voiceSlot;
        arpeggiatorCurrentLayered_ = false; // R1/R2/R3 are already represented as separate held-note slots.
        arpeggiatorCurrentInternalOnly_ = note.internalOnly;
        const auto status = static_cast<quint8>(0x90 | note.voiceSlot);
        if (note.internalOnly) sendInternalMidiOnly(status, note.note, std::clamp(note.velocity, 1, 127), internalVoiceChannel(note.voiceSlot));
        else sendMidi(status, static_cast<quint8>(note.note), static_cast<quint8>(std::clamp(note.velocity, 1, 127)), internalVoiceChannel(note.voiceSlot));
        captureEvent(status, note.note, note.velocity);
        if (arpeggiatorCurrentLayered_) {
            if (note.internalOnly) sendInternalMidiOnly(0x92, note.note, std::clamp(note.velocity, 1, 127), internalVoiceChannel(2));
            else sendMidi(0x92, static_cast<quint8>(note.note), static_cast<quint8>(std::clamp(note.velocity, 1, 127)), internalVoiceChannel(2));
            captureEvent(0x92, note.note, note.velocity);
        }
        ++arpeggiatorStep_;
        updateArpeggiatorTimer();
    }

    void applyInitialYamahaStyleMixerLevels() {
        if (!styleEngine_.isYamahaStyle()) return;
        // The general mixer is initialized during application startup, before a
        // Style and its private SF2 part channels exist. Re-apply only the eight
        // Yamaha track strips after a Style is loaded so stored CC7/CC10 values
        // reach the stable internal channels 40..47 before playback begins.
        for (int part = 0; part < arranger::kYamahaStyleMixerPartCount; ++part) {
            const int mixerChannel = 8 + part;
            const int level = styleMixerPartMuted(mixerChannel)
                ? 0 : channelMixerLevels_[static_cast<std::size_t>(mixerChannel)];
            sendStyleMixerController(part, 7, level);
            if (const auto *panKnob = channelMixerPanKnobs_[static_cast<std::size_t>(mixerChannel)])
                sendStyleMixerController(part, 10, panKnob->value());
        }
    }

    void applyInitialMixerLevels() {
        for (int i = 0; i < 16; ++i) {
            const int level = styleMixerPartMuted(i)
                ? 0 : channelMixerLevels_[static_cast<std::size_t>(i)];
            if (i >= 8 && i <= 15) sendStyleMixerController(i - 8, 7, level);
            else sendMidi(static_cast<quint8>(0xB0 | i), 7,
                          static_cast<quint8>(std::clamp(level, 0, 127)), i);
            const auto *panKnob = channelMixerPanKnobs_[static_cast<std::size_t>(i)];
            if (panKnob) {
                if (i >= 8 && i <= 15) sendStyleMixerController(i - 8, 10, panKnob->value());
                else sendMidi(static_cast<quint8>(0xB0 | i), 10,
                              static_cast<quint8>(std::clamp(panKnob->value(), 0, 127)), i);
            }
        }
    }

    void onKeyboardNote(int note, bool pressed, int velocity = 100, bool internalInputOnly = false) {
        const int statusType = pressed ? 0x90 : 0x80;
        const auto emitNote = [this, internalInputOnly](quint8 status, quint8 noteValue, quint8 noteVelocity, int channel) {
            if (internalInputOnly) sendInternalMidiOnly(status, noteValue, noteVelocity, channel);
            else sendMidi(status, noteValue, noteVelocity, channel);
        };
        const bool chordRegion = accompanimentEnabled_ && note <= splitKey_;
        const int visualNoteType = chordRegion ? 1 : 0;
        if (pianoKeyboard_) pianoKeyboard_->setActiveNote(note, pressed, visualNoteType);

        int outputNote = note;
        outputNote += transposeAmount_;
        outputNote += octaveShiftAmount_ * 12;
        outputNote = std::clamp(outputNote, 0, 127);
        const int effectiveVelocity = pressed ? std::clamp(velocity, 1, 127) : 0;

        if (chordRegion) {
            // The original Synthesizer sends the transposed key to chord_finder,
            // even when no style file is loaded; a style is not a prerequisite
            // for chord detection or the fallback chord voice.
            int detectedType = 0;
            int detectedGenosId = 34;
            int detectedBassPc = -1;
            const int detectedRoot = chord_finder_infer_genos(outputNote, statusType, &detectedType, &detectedGenosId, &detectedBassPc);
            if (detectedRoot > -6) {
                styleEngine_.changeChord(detectedRoot, detectedType, detectedGenosId, detectedBassPc);
                updateChordLabel(detectedRoot, detectedType);
            }
            sendFallbackChordVoicing(outputNote, pressed, effectiveVelocity, detectedRoot);
            // Chord recognition and the left/split Voice are not mutually exclusive: if Split and L
            // are enabled, the left-hand Voice must still sound while the note updates the chord.
            if (splitEnabled_ && rightVoiceEnabled_[0]) {
                const auto leftStatus = static_cast<quint8>(statusType | 1);
                emitNote(leftStatus, static_cast<quint8>(outputNote), static_cast<quint8>(effectiveVelocity), internalVoiceChannel(1));
                captureEvent(leftStatus, outputNote, effectiveVelocity);
            }
            return;
        }

        // Build the actual set of parts that should receive this keyboard note.
        // With Split enabled, the lower side belongs to L; otherwise right-hand
        // notes are sent independently to each enabled R1/R2/R3 part.
        std::vector<int> activeSlots;
        const bool leftSide = splitEnabled_ && note <= splitKey_;
        if (leftSide) {
            if (rightVoiceEnabled_[0]) activeSlots.push_back(1); // L, internal channel 19
        } else {
            if (rightVoiceEnabled_[1]) activeSlots.push_back(0); // R1, internal channel 17
            if (rightVoiceEnabled_[2]) activeSlots.push_back(2); // R2, internal channel 18
            if (rightVoiceEnabled_[3]) activeSlots.push_back(3); // R3, internal channel 4
        }

        if (arpButton_ && arpButton_->isChecked()) {
            if (pressed) {
                for (const int slot : activeSlots) {
                    const auto found = std::find_if(arpeggiatorHeldNotes_.begin(), arpeggiatorHeldNotes_.end(),
                        [outputNote, slot](const ArpeggiatorHeldNote &held) { return held.note == outputNote && held.voiceSlot == slot; });
                    if (found == arpeggiatorHeldNotes_.end())
                        arpeggiatorHeldNotes_.push_back({outputNote, slot, effectiveVelocity, internalInputOnly});
                }
                if (!activeSlots.empty()) updateArpeggiatorTimer();
            } else {
                arpeggiatorHeldNotes_.erase(std::remove_if(arpeggiatorHeldNotes_.begin(), arpeggiatorHeldNotes_.end(),
                    [outputNote](const ArpeggiatorHeldNote &held) { return held.note == outputNote; }), arpeggiatorHeldNotes_.end());
                if (arpeggiatorHeldNotes_.empty()) stopArpeggiator(false);
                else updateArpeggiatorTimer();
            }
            return;
        }

        for (const int slot : activeSlots) {
            const auto status = static_cast<quint8>(statusType | slot);
            emitNote(status, static_cast<quint8>(outputNote), static_cast<quint8>(effectiveVelocity), internalVoiceChannel(slot));
            captureEvent(status, outputNote, effectiveVelocity);
        }
    }
    void loadVoiceCatalog() {
        voiceCatalog_.clear();
        const QString appDir = QCoreApplication::applicationDirPath();
        const QStringList candidates = {
            QDir(appDir).filePath(QStringLiteral("plugins/SCVA/SCVSC.tnf")),
            QDir(appDir).filePath(QStringLiteral("../plugins/SCVA/SCVSC.tnf")),
            QDir::current().filePath(QStringLiteral("plugins/SCVA/SCVSC.tnf")),
            QDir::current().filePath(QStringLiteral("../plugins/SCVA/SCVSC.tnf"))
        };
        QString tnfPath;
        for (const QString &candidate : candidates) if (QFileInfo::exists(candidate)) { tnfPath = candidate; break; }
        if (tnfPath.isEmpty()) return;
        QFile file(tnfPath);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
        const QString text = QString::fromLocal8Bit(file.readAll());
        int currentMap = 0;
        const auto lines = text.split(QLatin1Char('\n'));
        for (const QString &line : lines) {
            const QString trimmed = line.trimmed();
            if (trimmed.startsWith(QStringLiteral("PAGE="))) {
                const QString page = trimmed.mid(5).trimmed().section(QLatin1Char('\t'), 0, 0).section(QLatin1Char(' '), 0, 0).trimmed();
                bool ok = false; const int p = page.toInt(&ok);
                currentMap = ok ? p : 0;
                continue;
            }
            if (currentMap < 1 || currentMap > 4 || !trimmed.contains(QLatin1Char('\t'))) continue;
            const QStringList cells = line.split(QLatin1Char('\t'), Qt::KeepEmptyParts);
            if (cells.size() < 2) continue;
            bool programOk = false;
            const int oneBasedProgram = cells[0].trimmed().toInt(&programOk);
            if (!programOk || oneBasedProgram < 1 || oneBasedProgram > 128 || cells[1].trimmed().isEmpty()) continue;
            // TNF column 1 is bank 0; each following cell is CC0 variation bank 1..127.
            for (int column = 1; column < cells.size() && column <= 128; ++column) {
                const QString name = cells[column].trimmed();
                if (name.isEmpty()) continue;
                VoiceCatalogEntry entry;
                entry.program = oneBasedProgram - 1;
                entry.bank = column - 1;
                entry.map = currentMap;
                entry.name = name;
                entry.category = voiceCategoryForProgram(entry.program);
                voiceCatalog_.push_back(std::move(entry));
            }
        }
    }

    bool voiceMatchesPickerFamily(const VoiceCatalogEntry &entry, const QString &family) const {
        const int p = entry.program;
        if (family == QStringLiteral("All Voice Types")) return true;
        if (family == QStringLiteral("Piano")) return p >= 0 && p <= 7;
        if (family == QStringLiteral("Crm Perc")) return p >= 8 && p <= 15;
        if (family == QStringLiteral("Organ")) return p >= 16 && p <= 23;
        if (family == QStringLiteral("Guitar")) return p >= 24 && p <= 31;
        if (family == QStringLiteral("Bass")) return p >= 32 && p <= 39;
        if (family == QStringLiteral("Strings")) return p >= 40 && p <= 55; // Strings + Ensemble, matching the legacy 12-button surface.
        if (family == QStringLiteral("Brass")) return p >= 56 && p <= 63;
        if (family == QStringLiteral("Reed/Pipe")) return p >= 64 && p <= 79;
        if (family == QStringLiteral("Synth Lead")) return p >= 80 && p <= 87;
        if (family == QStringLiteral("Synth Pad")) return p >= 88 && p <= 95;
        if (family == QStringLiteral("Extra")) return p >= 96 && p <= 127;
        return false; // A drum kit is a percussion bank/channel, not a melodic program family.
    }

    QString voiceThumbnailPath(const VoiceCatalogEntry &entry) const {
        const QString appDir = QCoreApplication::applicationDirPath();
        QStringList roots = {
            QDir(appDir).filePath(QStringLiteral("data/Images/Instruments")),
            QDir(appDir).filePath(QStringLiteral("../data/Images/Instruments")),
            QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("legacy-reference/data/Images/Instruments")),
            QDir::current().filePath(QStringLiteral("data/Images/Instruments")),
            QDir::current().filePath(QStringLiteral("legacy-reference/data/Images/Instruments"))
        };
        QString familyAsset = entry.category;
        if (familyAsset == QStringLiteral("Chromatic Percussion")) familyAsset = QStringLiteral("Chromatic Perc");
        else if (familyAsset == QStringLiteral("Reed") || familyAsset == QStringLiteral("Pipe")) familyAsset = QStringLiteral("Reed_Pipe");
        else if (familyAsset == QStringLiteral("Ensemble")) familyAsset = QStringLiteral("Strings");
        else if (familyAsset == QStringLiteral("Synth Effects") || familyAsset == QStringLiteral("Sound Effects")) familyAsset = QStringLiteral("GM Extra");
        else familyAsset.replace(QLatin1Char('/'), QLatin1Char('_'));
        for (const QString &root : roots) {
            const QString exact = QDir(root).filePath(entry.name + QStringLiteral(".jpg"));
            if (QFileInfo::exists(exact)) return exact;
        }
        for (const QString &root : roots) {
            const QString family = QDir(root).filePath(familyAsset + QStringLiteral(".jpg"));
            if (QFileInfo::exists(family)) return family;
        }
        return {};
    }

    static QString voiceSelectCategoryForProgram(int program) {
        // Canonical GM program-family fallback (program is zero-based).
        // The Voice Select UI deliberately keeps the reference's category names.
        const int p = std::clamp(program, 0, 127);
        if (p <= 3) return QStringLiteral("Piano");
        if (p <= 7) return QStringLiteral("E.Piano");
        if (p <= 15) return QStringLiteral("Chromatic Perc");
        if (p <= 23) return QStringLiteral("Organ");
        if (p <= 31) return QStringLiteral("Guitar");
        if (p <= 39) return QStringLiteral("Bass");
        if (p <= 55) return QStringLiteral("Strings");
        if (p <= 63) return QStringLiteral("Brass");
        if (p <= 79) return QStringLiteral("Reed/Pipe");
        if (p <= 95) return QStringLiteral("Synth");
        return QStringLiteral("Extra");
    }

    static QString voiceSelectCategoryForEntry(const VoiceCatalogEntry &entry) {
        // SCVA variation-bank names are not guaranteed to match the GM family
        // of their program number. Classify recognizable instrument names first;
        // use the canonical GM family only when the name is ambiguous.
        const QString n = entry.name.trimmed().toLower();
        auto has = [&n](std::initializer_list<const char *> words) {
            for (const char *word : words) if (n.contains(QString::fromLatin1(word))) return true;
            return false;
        };
        if (has({"bass", "finger", "slap", "fretless", "upright bass"})) return QStringLiteral("Bass");
        if (has({"piano", "grand piano", "bright piano", "honky-tonk", "honky tonk"})) {
            if (has({"electric", "e.piano", "epiano", "rhodes", "wurli", "wurlitzer", "fm piano", "dx piano"})) return QStringLiteral("E.Piano");
            return QStringLiteral("Piano");
        }
        if (has({"e.piano", "epiano", "electric piano", "rhodes", "wurli", "wurlitzer", "dx piano", "fm piano", "clavinet", "clavi", "harpsichord"})) return QStringLiteral("E.Piano");
        if (has({"organ", "orgen", "church organ", "drawbar", "percussive organ", "rotary", "accordion", "harmonica"})) return QStringLiteral("Organ");
        if (has({"guitar", "nylon", "steel guitar", "strat", "telecaster", "overdrive guitar", "distortion guitar"})) return QStringLiteral("Guitar");
        if (has({"violin", "viola", "cello", "string", "strings", "ensemble", "orchestra", "harp", "tremolo", "pizzicato", "choir", "aahs"})) return QStringLiteral("Strings");
        if (has({"trumpet", "trombone", "tuba", "brass", "horn", "cornet", "flugel"})) return QStringLiteral("Brass");
        if (has({"sax", "oboe", "english horn", "bassoon", "clarinet", "piccolo", "flute", "recorder", "pan flute", "whistle", "pipe", "shakuhachi", "ocarina", "bag pipe", "shanai"})) return QStringLiteral("Reed/Pipe");
        if (has({"synth", "synth.", "syn.", "lead", "pad", "impulse", "saw", "square", "polysynth", "fx ", "soundtrack", "rain", "halo", "sweep", "funny vox", "voice", "vox"})) return QStringLiteral("Synth");
        if (has({"celesta", "glockenspiel", "music box", "vibraphone", "marimba", "xylophone", "tubular bell", "dulcimer", "bell", "chime", "kalimba", "steel drum", "agogo", "woodblock", "taiko", "tom", "cymbal", "percussion"})) return QStringLiteral("Chromatic Perc");
        if (has({"sitar", "banjo", "shamisen", "koto", "fiddle", "ethnic", "bagpipe"})) return QStringLiteral("Extra");
        return voiceSelectCategoryForProgram(entry.program);
    }

    void ensureVoiceSelectPage() {
        if (voiceSelectPageWidget_) return;
        if (!lcdVoicePickerPage_) return;

        // Everything is attached to lcdVoicePickerPage_ inside lcdContentStack_.
        // No QDialog/QWindow is created here: the selector takes over the central
        // LCD surface while all mixer, transport, keyboard, and side panels stay put.
        auto *page = lcdVoicePickerPage_;
        voiceSelectPageWidget_ = page;
        auto *root = new QVBoxLayout(page);
        root->setContentsMargins(5, 5, 5, 5);
        root->setSpacing(5);
        page->setStyleSheet(QStringLiteral(
            "QWidget#lcdVoicePickerPage{background:#182224;color:#e1eae8;}"
            "QFrame#voiceSelectHeader{background:#244b47;border:0;border-radius:7px;}"
            "QLabel#voiceSelectTitle{color:#f5f7fb;font-size:10pt;font-weight:700;background:transparent;border:0;}"
            "QLabel#voiceSelectSectionTitle{color:#e4e6ea;font-size:8pt;font-weight:700;background:transparent;border:0;}"
            "QLabel#voiceSelectFooter{color:#b9bec6;font-size:7pt;background:transparent;border:0;}"
            "QPushButton#voiceSelectClose{color:#e8eef7;background:transparent;border:0;font-size:12pt;font-weight:600;padding:0;}"
            "QPushButton#voiceSelectClose:hover{color:#ffffff;background:#355452;border-radius:4px;}"
            "QPushButton#voiceSelectModelButton{background:#334b49;color:#f3f5fa;border:0;border-radius:4px;padding:3px 3px;min-height:25px;font-size:8pt;}"
            "QPushButton#voiceSelectModelButton[active=\"true\"]{background:#08766d;color:white;}"
            "QPushButton#voiceSelectModelButton:hover{background:#46635f;}"
            "QPushButton#voiceSelectModelButton[active=\"true\"]:hover{background:#0a8c82;}"
            "QListWidget#voiceSelectCategoryList{background:transparent;color:#e1eae8;border:0;outline:0;padding:0;font-size:8pt;}"
            "QListWidget#voiceSelectCategoryList::item{background:transparent;color:#e1eae8;border:0;border-radius:5px;padding:0 6px;margin:1px 0;min-height:25px;}"
            "QListWidget#voiceSelectCategoryList::item:hover{background:#283b3a;}"
            "QListWidget#voiceSelectCategoryList::item:selected{background:#0a756e;color:#ffffff;}"
            "QScrollBar:vertical{background:#182224;width:6px;margin:0;}"
            "QScrollBar::handle:vertical{background:#536665;min-height:20px;border-radius:3px;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
            "QPushButton#voiceSelectPatchButton{background:#1b2729;color:#e8e8e8;border:1px solid #617976;border-radius:5px;text-align:left;padding:0 6px;min-height:29px;font-size:8pt;}"
            "QPushButton#voiceSelectPatchButton:hover{background:#304143;border-color:#7ca7a0;}"
            "QPushButton#voiceSelectPatchButton[selected=\"true\"]{background:#0a756e;color:#102033;border:1px solid #69c1b4;font-weight:600;}"
            "QPushButton#voiceSelectPatchButton[selected=\"true\"]:hover{background:#f0f0f0;}"
            "QPushButton#voiceSelectPageButton{background:#293638;color:#d8dce2;border:0;border-radius:10px;min-width:23px;min-height:21px;padding:0 4px;font-size:7pt;font-weight:600;}"
            "QPushButton#voiceSelectPageButton[active=\"true\"]{background:#225953;color:#a2eae0;}"
            "QPushButton#voiceSelectPageButton:disabled{color:#82918f;background:transparent;}"
            "QPushButton#voiceSelectArrow{background:transparent;color:#dedede;border:0;min-width:16px;min-height:20px;font-size:12pt;}"
            "QPushButton#voiceSelectArrow:disabled{color:#657473;}"
            "QLabel#voiceSelectEmpty{color:#adb4be;background:transparent;font-size:8pt;}") );

        auto *header = new QFrame(page);
        header->setObjectName(QStringLiteral("voiceSelectHeader"));
        auto *headerLayout = new QVBoxLayout(header);
        headerLayout->setContentsMargins(8, 5, 8, 6);
        headerLayout->setSpacing(4);
        auto *titleRow = new QHBoxLayout;
        titleRow->setContentsMargins(0, 0, 0, 0);
        titleRow->setSpacing(4);
        voiceSelectTitleLabel_ = new QLabel(QStringLiteral("VOICE SELECT — SC-8820"), header);
        voiceSelectTitleLabel_->setObjectName(QStringLiteral("voiceSelectTitle"));
        titleRow->addWidget(voiceSelectTitleLabel_, 1);
        auto *closeButton = new QPushButton(QStringLiteral("×"), header);
        closeButton->setObjectName(QStringLiteral("voiceSelectClose"));
        closeButton->setFixedSize(20, 20);
        closeButton->setToolTip(QStringLiteral("Kembali ke LCD utama"));
        connect(closeButton, &QPushButton::clicked, this, [this] {
            if (lcdContentStack_ && lcdHomePage_) lcdContentStack_->setCurrentWidget(lcdHomePage_);
        });
        titleRow->addWidget(closeButton, 0, Qt::AlignRight | Qt::AlignVCenter);
        headerLayout->addLayout(titleRow);

        auto *modelRow = new QHBoxLayout;
        modelRow->setContentsMargins(0, 0, 0, 0);
        modelRow->setSpacing(4);
        voiceSelectModelButtons_.clear();
        const std::array<std::pair<const char *, int>, 4> maps = {{{"SC-8820", 4}, {"SC-88Pro", 3}, {"SC-88", 2}, {"SC-55", 1}}};
        for (const auto &mapInfo : maps) {
            auto *button = new QPushButton(QString::fromLatin1(mapInfo.first), header);
            button->setObjectName(QStringLiteral("voiceSelectModelButton"));
            button->setCheckable(true);
            button->setAutoExclusive(true);
            button->setProperty("map", mapInfo.second);
            const int mapValue = mapInfo.second;
            connect(button, &QPushButton::clicked, this, [this, mapValue] {
                voiceSelectMap_ = mapValue;
                voiceSelectPage_ = 0;
                refreshVoiceSelectPage();
            });
            voiceSelectModelButtons_.push_back(button);
            modelRow->addWidget(button, 1);
        }
        headerLayout->addLayout(modelRow);
        root->addWidget(header, 0);

        auto *body = new QWidget(page);
        auto *bodyLayout = new QHBoxLayout(body);
        bodyLayout->setContentsMargins(0, 0, 0, 0);
        bodyLayout->setSpacing(5);
        auto *categoryColumn = new QWidget(body);
        categoryColumn->setMinimumWidth(88);
        categoryColumn->setMaximumWidth(112);
        auto *categoryColumnLayout = new QVBoxLayout(categoryColumn);
        categoryColumnLayout->setContentsMargins(0, 0, 0, 0);
        categoryColumnLayout->setSpacing(2);
        auto *categoryHeading = new QLabel(QStringLiteral("CATEGORY"), categoryColumn);
        categoryHeading->setObjectName(QStringLiteral("voiceSelectSectionTitle"));
        categoryColumnLayout->addWidget(categoryHeading);
        voiceSelectCategoryList_ = new QListWidget(categoryColumn);
        voiceSelectCategoryList_->setObjectName(QStringLiteral("voiceSelectCategoryList"));
        voiceSelectCategoryList_->setSelectionMode(QAbstractItemView::SingleSelection);
        voiceSelectCategoryList_->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        voiceSelectCategoryList_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        voiceSelectCategoryList_->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        const std::array<const char *, 11> categoryNames = {
            "Piano", "E.Piano", "Organ", "Guitar", "Bass", "Strings", "Brass", "Synth",
            "Chromatic Perc", "Reed/Pipe", "Extra"
        };
        for (const char *category : categoryNames) {
            auto *item = new QListWidgetItem(QString::fromLatin1(category));
            item->setSizeHint(QSize(90, 26));
            voiceSelectCategoryList_->addItem(item);
        }
        categoryColumnLayout->addWidget(voiceSelectCategoryList_, 1);
        bodyLayout->addWidget(categoryColumn, 0);

        voiceSelectGridHost_ = new QWidget(body);
        voiceSelectGridHost_->setObjectName(QStringLiteral("voiceSelectGridHost"));
        auto *gridHostLayout = new QVBoxLayout(voiceSelectGridHost_);
        gridHostLayout->setContentsMargins(0, 0, 0, 0);
        gridHostLayout->setSpacing(0);
        voiceSelectGridLayout_ = new QGridLayout;
        voiceSelectGridLayout_->setContentsMargins(0, 0, 0, 0);
        voiceSelectGridLayout_->setHorizontalSpacing(2);
        voiceSelectGridLayout_->setVerticalSpacing(2);
        voiceSelectGridLayout_->setColumnStretch(0, 1);
        voiceSelectGridLayout_->setColumnStretch(1, 1);
        gridHostLayout->addLayout(voiceSelectGridLayout_, 1);
        bodyLayout->addWidget(voiceSelectGridHost_, 1);
        root->addWidget(body, 1);

        auto *footer = new QHBoxLayout;
        footer->setContentsMargins(1, 0, 1, 0);
        footer->setSpacing(3);
        voiceSelectPageSummaryLabel_ = new QLabel(QStringLiteral("12 Voice per halaman"), page);
        voiceSelectPageSummaryLabel_->setObjectName(QStringLiteral("voiceSelectFooter"));
        footer->addWidget(voiceSelectPageSummaryLabel_);
        footer->addStretch(1);
        voiceSelectPreviousPageButton_ = new QPushButton(QStringLiteral("‹"), page);
        voiceSelectPreviousPageButton_->setObjectName(QStringLiteral("voiceSelectArrow"));
        voiceSelectPreviousPageButton_->setToolTip(QStringLiteral("Halaman sebelumnya"));
        footer->addWidget(voiceSelectPreviousPageButton_);
        voiceSelectPageButtonsLayout_ = new QHBoxLayout;
        voiceSelectPageButtonsLayout_->setContentsMargins(0, 0, 0, 0);
        voiceSelectPageButtonsLayout_->setSpacing(3);
        footer->addLayout(voiceSelectPageButtonsLayout_);
        voiceSelectNextPageButton_ = new QPushButton(QStringLiteral("›"), page);
        voiceSelectNextPageButton_->setObjectName(QStringLiteral("voiceSelectArrow"));
        voiceSelectNextPageButton_->setToolTip(QStringLiteral("Halaman berikutnya"));
        footer->addWidget(voiceSelectNextPageButton_);
        root->addLayout(footer);

        connect(voiceSelectCategoryList_, &QListWidget::currentTextChanged, this, [this](const QString &category) {
            if (category.isEmpty()) return;
            voiceSelectCategory_ = category;
            voiceSelectPage_ = 0;
            refreshVoiceSelectPage();
        });
        connect(voiceSelectPreviousPageButton_, &QPushButton::clicked, this, [this] {
            if (voiceSelectPage_ > 0) { --voiceSelectPage_; refreshVoiceSelectPage(); }
        });
        connect(voiceSelectNextPageButton_, &QPushButton::clicked, this, [this] {
            const int pages = std::max(1, static_cast<int>((voiceSelectFilteredEntries_.size() + 11) / 12));
            if (voiceSelectPage_ + 1 < pages) { ++voiceSelectPage_; refreshVoiceSelectPage(); }
        });
        const QSignalBlocker blocker(voiceSelectCategoryList_);
        voiceSelectCategoryList_->setCurrentRow(0);
    }

    void openVoiceSelectPage(int channel, const QString &preferredCategory = QString()) {
        dataEntryStyleMode_ = false;
        selectedProgramChannel_ = std::clamp(channel, 0, 2);
        const auto slot = static_cast<std::size_t>(selectedProgramChannel_);
        voiceSelectMap_ = std::clamp(voiceMaps_[slot], 1, 4);
        voiceSelectCategory_ = preferredCategory.isEmpty()
            ? voiceSelectCategoryForProgram(voicePrograms_[slot]) : preferredCategory;
        if (voiceSelectCategory_ == QStringLiteral("Crm Perc")) voiceSelectCategory_ = QStringLiteral("Chromatic Perc");
        else if (voiceSelectCategory_ == QStringLiteral("Synth Lead") || voiceSelectCategory_ == QStringLiteral("Synth Pad")) voiceSelectCategory_ = QStringLiteral("Synth");
        else if (voiceSelectCategory_ == QStringLiteral("Drum Kit")) voiceSelectCategory_ = QStringLiteral("Extra");
        voiceSelectPage_ = 0;
        ensureVoiceSelectPage();
        if (!voiceSelectCategoryList_) return;
        {
            const QSignalBlocker blocker(voiceSelectCategoryList_);
            auto items = voiceSelectCategoryList_->findItems(voiceSelectCategory_, Qt::MatchExactly);
            const int row = items.isEmpty() ? 0 : voiceSelectCategoryList_->row(items.front());
            voiceSelectCategoryList_->setCurrentRow(row);
            voiceSelectCategory_ = voiceSelectCategoryList_->currentItem()
                ? voiceSelectCategoryList_->currentItem()->text() : QStringLiteral("Piano");
        }
        refreshVoiceSelectPage();

        int selectedIndex = -1;
        for (std::size_t i = 0; i < voiceSelectFilteredEntries_.size(); ++i) {
            const auto &entry = voiceSelectFilteredEntries_[i];
            if (entry.program == voicePrograms_[slot] && entry.bank == voiceBanks_[slot] && entry.map == voiceMaps_[slot]) {
                selectedIndex = static_cast<int>(i);
                break;
            }
        }
        if (selectedIndex >= 0) {
            voiceSelectPage_ = selectedIndex / 12;
            refreshVoiceSelectPage();
        }
        if (lcdContentStack_ && lcdVoicePickerPage_)
            lcdContentStack_->setCurrentWidget(lcdVoicePickerPage_);
    }

    void refreshVoiceSelectPage() {
        if (!voiceSelectPageWidget_ || !voiceSelectCategoryList_ || !voiceSelectGridLayout_) return;
        const std::array<const char *, 4> mapNames = {"", "SC-55", "SC-88", "SC-88Pro"};
        const QString mapName = voiceSelectMap_ == 4 ? QStringLiteral("SC-8820")
            : QString::fromLatin1(mapNames[static_cast<std::size_t>(std::clamp(voiceSelectMap_, 1, 3))]);
        if (voiceSelectTitleLabel_) voiceSelectTitleLabel_->setText(QStringLiteral("VOICE SELECT — %1").arg(mapName));
        for (auto *button : voiceSelectModelButtons_) {
            if (!button) continue;
            const bool active = button->property("map").toInt() == voiceSelectMap_;
            button->setProperty("active", active);
            button->setChecked(active);
            if (button->style()) { button->style()->unpolish(button); button->style()->polish(button); }
        }
        if (voiceSelectCategoryList_->currentItem()) voiceSelectCategory_ = voiceSelectCategoryList_->currentItem()->text();

        voiceSelectFilteredEntries_.clear();
        for (const auto &entry : voiceCatalog_) {
            if (entry.map != voiceSelectMap_) continue;
            if (voiceSelectCategoryForEntry(entry) != voiceSelectCategory_) continue;
            voiceSelectFilteredEntries_.push_back(entry);
        }
        std::stable_sort(voiceSelectFilteredEntries_.begin(), voiceSelectFilteredEntries_.end(), [](const auto &a, const auto &b) {
            if (a.program != b.program) return a.program < b.program;
            if (a.bank != b.bank) return a.bank < b.bank;
            return a.name.compare(b.name, Qt::CaseInsensitive) < 0;
        });
        const int pageCount = std::max(1, static_cast<int>((voiceSelectFilteredEntries_.size() + 11) / 12));
        voiceSelectPage_ = std::clamp(voiceSelectPage_, 0, pageCount - 1);

        while (auto *item = voiceSelectGridLayout_->takeAt(0)) {
            if (auto *widget = item->widget()) { widget->hide(); widget->deleteLater(); }
            delete item;
        }
        const auto selectedSlot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        const std::size_t start = static_cast<std::size_t>(voiceSelectPage_ * 12);
        const std::size_t end = std::min(start + 12, voiceSelectFilteredEntries_.size());
        int localIndex = 0;
        for (std::size_t i = start; i < end; ++i, ++localIndex) {
            const VoiceCatalogEntry entry = voiceSelectFilteredEntries_[i];
            auto *button = new QPushButton(entry.name, voiceSelectGridHost_);
            button->setObjectName(QStringLiteral("voiceSelectPatchButton"));
            const bool selected = entry.program == voicePrograms_[selectedSlot]
                && entry.bank == voiceBanks_[selectedSlot] && entry.map == voiceMaps_[selectedSlot];
            button->setProperty("selected", selected);
            if (button->style()) { button->style()->unpolish(button); button->style()->polish(button); }
            button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            button->setToolTip(QStringLiteral("%1\nProgram %2 · CC0 bank %3 · %4").arg(entry.name).arg(entry.program + 1).arg(entry.bank).arg(mapName));
            connect(button, &QPushButton::clicked, this, [this, entry] {
                applyVoiceCatalogEntry(entry);
                refreshVoiceSelectPage();
            });
            voiceSelectGridLayout_->addWidget(button, localIndex / 2, localIndex % 2);
        }
        if (localIndex == 0) {
            auto *empty = new QLabel(QStringLiteral("Tidak ada Voice pada kategori ini untuk map %1.").arg(mapName), voiceSelectGridHost_);
            empty->setObjectName(QStringLiteral("voiceSelectEmpty"));
            empty->setAlignment(Qt::AlignCenter);
            voiceSelectGridLayout_->addWidget(empty, 0, 0, 1, 2);
        }
        // Always occupy the same 6 x 2 matrix. Without these empty cells Qt
        // distributes the full LCD height among only the final 1-2 entries,
        // making the last page's buttons much larger than the rest.
        if (localIndex == 0) {
            // Empty-category message already spans the grid; keep its height stable.
            for (int row = 0; row < 6; ++row) voiceSelectGridLayout_->setRowStretch(row, 1);
        } else {
            while (localIndex < 12) {
                const int row = localIndex / 2;
                const int col = localIndex % 2;
                auto *spacerCell = new QWidget(voiceSelectGridHost_);
                spacerCell->setObjectName(QStringLiteral("voiceSelectEmptyCell"));
                spacerCell->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
                spacerCell->setAttribute(Qt::WA_TransparentForMouseEvents, true);
                voiceSelectGridLayout_->addWidget(spacerCell, row, col);
                ++localIndex;
            }
            for (int row = 0; row < 6; ++row) voiceSelectGridLayout_->setRowStretch(row, 1);
        }
        if (voiceSelectPageSummaryLabel_)
            voiceSelectPageSummaryLabel_->setText(QStringLiteral("12 Voice/page · %1 voices").arg(voiceSelectFilteredEntries_.size()));
        if (voiceSelectPreviousPageButton_) voiceSelectPreviousPageButton_->setEnabled(voiceSelectPage_ > 0);
        if (voiceSelectNextPageButton_) voiceSelectNextPageButton_->setEnabled(voiceSelectPage_ + 1 < pageCount);

        if (voiceSelectPageButtonsLayout_) {
            while (auto *item = voiceSelectPageButtonsLayout_->takeAt(0)) {
                if (auto *widget = item->widget()) { widget->hide(); widget->deleteLater(); }
                delete item;
            }
            int firstPage = 0;
            if (pageCount > 3) firstPage = std::clamp(voiceSelectPage_ - 1, 0, pageCount - 3);
            const int lastPage = std::min(pageCount, firstPage + 3);
            for (int pageNo = firstPage; pageNo < lastPage; ++pageNo) {
                auto *pageButton = new QPushButton(QStringLiteral("P%1").arg(pageNo + 1), voiceSelectPageWidget_);
                pageButton->setObjectName(QStringLiteral("voiceSelectPageButton"));
                pageButton->setProperty("active", pageNo == voiceSelectPage_);
                pageButton->setCheckable(true);
                pageButton->setChecked(pageNo == voiceSelectPage_);
                if (pageButton->style()) { pageButton->style()->unpolish(pageButton); pageButton->style()->polish(pageButton); }
                connect(pageButton, &QPushButton::clicked, this, [this, pageNo] {
                    voiceSelectPage_ = pageNo;
                    refreshVoiceSelectPage();
                });
                voiceSelectPageButtonsLayout_->addWidget(pageButton);
            }
        }
    }

    void refreshVoicePickerPage() {
        startupTrace("voicePicker: refresh entered");
        if (!lcdVoiceList_ || !lcdVoiceMapCombo_ || !lcdVoiceCategoryCombo_ || !lcdVoiceBankCombo_) {
            startupTrace("voicePicker: required widget pointer missing; return");
            return;
        }
        const int map = lcdVoiceMapCombo_->currentData().toInt();
        const QString family = lcdVoiceCategoryCombo_->currentText();
        const int bankFilter = lcdVoiceBankCombo_->currentData().toInt(); // 0 = standard bank; -1 = all SCVA variations.
        const int selectedSlot = std::clamp(selectedProgramChannel_, 0, 2);
        filteredVoiceCatalog_.clear();
        for (const auto &entry : voiceCatalog_) {
            if (entry.map != map) continue;
            if (bankFilter >= 0 && entry.bank != bankFilter) continue;
            if (!voiceMatchesPickerFamily(entry, family)) continue;
            filteredVoiceCatalog_.push_back(entry);
        }
        std::stable_sort(filteredVoiceCatalog_.begin(), filteredVoiceCatalog_.end(), [](const auto &a, const auto &b) {
            if (a.program != b.program) return a.program < b.program;
            return a.bank < b.bank;
        });
        startupTrace((std::string("voicePicker: filtered count=") + std::to_string(filteredVoiceCatalog_.size()) +
                      ", vertical list, bank filter=" + std::to_string(bankFilter)).c_str());
        const QSignalBlocker blocker(lcdVoiceList_);
        lcdVoiceList_->clear();
        int selectedRow = -1;
        for (std::size_t i = 0; i < filteredVoiceCatalog_.size(); ++i) {
            const auto &entry = filteredVoiceCatalog_[i];
            auto *item = new QListWidgetItem(entry.name);
            item->setData(Qt::UserRole, entry.program);
            item->setData(Qt::UserRole + 1, QStringLiteral("Program %1 · Bank %2").arg(entry.program + 1).arg(entry.bank));
            item->setData(Qt::UserRole + 2, entry.category);
            item->setData(Qt::UserRole + 3, entry.bank);
            item->setData(Qt::UserRole + 4, entry.map);
            const QString thumbPath = voiceThumbnailPath(entry);
            if (!thumbPath.isEmpty()) item->setIcon(QIcon(QPixmap(thumbPath).scaled(54, 36, Qt::KeepAspectRatio, Qt::FastTransformation)));
            item->setToolTip(QStringLiteral("%1 · %2 · CC0 bank %3 · Program %4 · %5 map")
                .arg(entry.category, entry.name).arg(entry.bank).arg(entry.program + 1).arg(entry.map));
            lcdVoiceList_->addItem(item);
            if (entry.program == voicePrograms_[static_cast<std::size_t>(selectedSlot)] &&
                entry.bank == voiceBanks_[static_cast<std::size_t>(selectedSlot)] &&
                entry.map == voiceMaps_[static_cast<std::size_t>(selectedSlot)])
                selectedRow = static_cast<int>(i);
        }
        if (selectedRow >= 0 && selectedRow < lcdVoiceList_->count())
            lcdVoiceList_->setCurrentRow(selectedRow);
        if (lcdVoicePageLabel_) {
            const QString bankLabel = bankFilter == 0 ? QStringLiteral("Standard bank · CC0=0") : QStringLiteral("All SCVA variations");
            lcdVoicePageLabel_->setText(QStringLiteral("%1 voices · %2 · map %3")
                .arg(filteredVoiceCatalog_.size()).arg(bankLabel).arg(map));
        }
        startupTrace("voicePicker: refresh completed");
    }

    void applyVoiceCatalogSelection(int row) {
        if (row < 0 || !lcdVoiceList_ || !audioEngine_) return;
        auto *item = lcdVoiceList_->item(row);
        if (!item) return;
        VoiceCatalogEntry entry;
        entry.program = item->data(Qt::UserRole).toInt();
        entry.name = item->text();
        entry.category = item->data(Qt::UserRole + 2).toString();
        entry.bank = item->data(Qt::UserRole + 3).toInt();
        entry.map = item->data(Qt::UserRole + 4).toInt();
        applyVoiceCatalogEntry(entry);
    }

    void applyVoiceCatalogEntry(const VoiceCatalogEntry &entry) {
        if (!audioEngine_) return;
        const int program = std::clamp(entry.program, 0, 127);
        const int bank = std::clamp(entry.bank, 0, 127);
        const int map = std::clamp(entry.map, 1, 4);
        const auto slot = static_cast<std::size_t>(std::clamp(selectedProgramChannel_, 0, 2));
        if (hasActiveSf2PresetBrowser()) {
            sf2ProgramNumbers_[slot] = program;
            voicePrograms_[slot] = program;
            sendVoiceProgramForSlot(selectedProgramChannel_);
            if (sf2PartCombo_ && sf2PartCombo_->currentIndex() == selectedProgramChannel_)
                updateSf2PresetControlsForSlot(selectedProgramChannel_);
            const std::uint16_t requestedBank = static_cast<std::uint16_t>(
                (sf2BankMsb_[slot] << 7) | sf2BankLsb_[slot]);
            auto selected = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
                [requestedBank, program](const lsgm::PresetInfo &item) {
                    return item.bank == requestedBank && item.program == static_cast<std::uint16_t>(program);
                });
            if (selected == sf2PresetCatalog_.end())
                selected = std::find_if(sf2PresetCatalog_.begin(), sf2PresetCatalog_.end(),
                    [program](const lsgm::PresetInfo &item) {
                        return item.bank == 0 && item.program == static_cast<std::uint16_t>(program);
                    });
            const QString actualName = selected == sf2PresetCatalog_.end()
                ? entry.name : QString::fromUtf8(selected->name.c_str());
            if (selectedProgramChannel_ == 0 && voiceR1Label_) voiceR1Label_->setText(actualName);
            if (selectedProgramChannel_ == 1 && voiceLLabel_) voiceLLabel_->setText(actualName);
            if (selectedProgramChannel_ == 2 && voiceR2Label_) voiceR2Label_->setText(actualName);
            if (selectedProgramChannel_ == 2 && voiceR3Label_) voiceR3Label_->setText(actualName);
            savePanelSettings();
            setStatus(QStringLiteral("SF2 PC %1 pada bank MSB %2 / LSB %3.")
                .arg(program + 1).arg(sf2BankMsb_[slot]).arg(sf2BankLsb_[slot]));
            return;
        }
        voicePrograms_[slot] = program;
        voiceBanks_[slot] = bank;
        voiceMaps_[slot] = map;
        const int channel = selectedProgramChannel_;
        const int nativeChannel = internalVoiceChannel(channel);
        sendMidi(static_cast<quint8>(0xB0 | channel), 0, static_cast<quint8>(bank), nativeChannel);
        sendMidi(static_cast<quint8>(0xB0 | channel), 32, static_cast<quint8>(map), nativeChannel);
        sendMidi(static_cast<quint8>(0xC0 | channel), static_cast<quint8>(program), 0, nativeChannel);
        if (channel == 2) {
            // The independent R3 part follows R2's selected Voice until it gets its own picker.
            sendMidi(0xB3, 0, static_cast<quint8>(bank), 3);
            sendMidi(0xB3, 32, static_cast<quint8>(map), 3);
            sendMidi(0xC3, static_cast<quint8>(program), 0, 3);
        }
        if (programCombo_) { const QSignalBlocker blocker(programCombo_); programCombo_->setCurrentIndex(program); }
        const QString name = entry.name.isEmpty() ? QString::fromUtf8(kPatchNames[static_cast<std::size_t>(program)]) : entry.name;
        if (channel == 0 && voiceR1Label_) voiceR1Label_->setText(name);
        if (channel == 1 && voiceLLabel_) voiceLLabel_->setText(name);
        if (channel == 2 && voiceR2Label_) voiceR2Label_->setText(name);
        if (channel == 2 && voiceR3Label_) voiceR3Label_->setText(name);
        QSettings settings;
        settings.setValue(QStringLiteral("voiceR1"), voicePrograms_[0]);
        settings.setValue(QStringLiteral("voiceL"), voicePrograms_[1]);
        settings.setValue(QStringLiteral("voiceR2"), voicePrograms_[2]);
        settings.setValue(QStringLiteral("voiceNameR1"), voiceR1Label_ ? voiceR1Label_->text() : QString());
        settings.setValue(QStringLiteral("voiceNameL"), voiceLLabel_ ? voiceLLabel_->text() : QString());
        settings.setValue(QStringLiteral("voiceNameR2"), voiceR2Label_ ? voiceR2Label_->text() : QString());
        settings.setValue(QStringLiteral("voiceMapR1"), voiceMaps_[0]);
        settings.setValue(QStringLiteral("voiceMapL"), voiceMaps_[1]);
        settings.setValue(QStringLiteral("voiceMapR2"), voiceMaps_[2]);
        settings.setValue(QStringLiteral("voiceBankR1"), voiceBanks_[0]);
        settings.setValue(QStringLiteral("voiceBankL"), voiceBanks_[1]);
        settings.setValue(QStringLiteral("voiceBankR2"), voiceBanks_[2]);
        settings.setValue(QStringLiteral("sf2BankMsbR1"), sf2BankMsb_[0]);
        settings.setValue(QStringLiteral("sf2BankMsbL"), sf2BankMsb_[1]);
        settings.setValue(QStringLiteral("sf2BankMsbR2"), sf2BankMsb_[2]);
        settings.setValue(QStringLiteral("sf2BankLsbR1"), sf2BankLsb_[0]);
        settings.setValue(QStringLiteral("sf2BankLsbL"), sf2BankLsb_[1]);
        settings.setValue(QStringLiteral("sf2BankLsbR2"), sf2BankLsb_[2]);
        settings.setValue(QStringLiteral("sf2ProgramR1"), sf2ProgramNumbers_[0]);
        settings.setValue(QStringLiteral("sf2ProgramL"), sf2ProgramNumbers_[1]);
        settings.setValue(QStringLiteral("sf2ProgramR2"), sf2ProgramNumbers_[2]);
        settings.sync();
        setStatus(QStringLiteral("Voice %1 · program %2 · bank %3 · %4").arg(name).arg(program + 1).arg(bank).arg(
            map == 4 ? QStringLiteral("SC-8820") : map == 3 ? QStringLiteral("SC-88Pro") : map == 2 ? QStringLiteral("SC-88") : QStringLiteral("SC-55")));
    }

    void sendGsDt1(std::uint8_t ah, std::uint8_t am, std::uint8_t al, std::uint8_t value) {
        if (!audioEngine_) return;
        const auto packet = makeGsDt1(ah, am, al, value);
        audioEngine_->sendSysEx(std::span<const std::uint8_t>(packet.data(), packet.size()));
    }

    void applyNativeEfxSettings(bool resetParameters = false) {
        if (!nativeEfxTypeCombo_) return;
        const int index = std::clamp(nativeEfxTypeCombo_->currentIndex(), 0, static_cast<int>(kNativeEfxChoices.size()) - 1);
        const int key = kNativeEfxChoices[static_cast<std::size_t>(index)].key;
        sendGsDt1(0x40, 0x03, 0x00, static_cast<std::uint8_t>((key >> 8) & 0x7f));
        sendGsDt1(0x40, 0x03, 0x01, static_cast<std::uint8_t>(key & 0x7f));
        if (resetParameters) {
            for (auto *parameter : nativeEfxParams_) {
                if (!parameter || parameter->value() == -1) continue;
                const QSignalBlocker blocker(parameter);
                parameter->setValue(-1); // Changing algorithms restores the effect's own ROM defaults.
            }
        }
        // GS part block 40 4x 22: 00=bypass, 01=EFX. Route all 16 parts.
        const std::uint8_t route = nativeEfxCheck_ && nativeEfxCheck_->isChecked() && key != 0 ? 1 : 0;
        for (int channel = 0; channel < 16; ++channel) {
            const int partNibble = channel == 9 ? 0 : (channel < 9 ? channel + 1 : channel); // GS block order: 1..9, 0, A..F.
            sendGsDt1(0x40, static_cast<std::uint8_t>(0x40 | partNibble), 0x22, route);
        }
        QSettings settings;
        settings.setValue(QStringLiteral("nativeEfxOn"), nativeEfxCheck_ && nativeEfxCheck_->isChecked());
        settings.setValue(QStringLiteral("nativeEfxType"), index);
        settings.sync();
    }

    void updateModulationTimer() {
        const bool needTimer = metronomeCheck_->isChecked() || lfoCheck_->isChecked();
        if (needTimer && !modulationTimer_.isActive()) {
            modulationClock_.start(); nextBeatUs_ = 0; lastLfoUs_ = 0; beatCount_ = 0; modulationTimer_.start();
        } else if (!needTimer) {
            modulationTimer_.stop();
        }
    }

    void onModulationTick() {
        if (!modulationClock_.isValid()) return;
        const qint64 nowUs = modulationClock_.nsecsElapsed() / 1000;
        const qint64 beatUs = 60000000LL / std::max(1, tempo_);
        if (metronomeCheck_->isChecked() && nowUs >= nextBeatUs_) {
            nextBeatUs_ = nowUs + beatUs;
            ++beatCount_;
            if (metronomeCheck_->isChecked()) {
                const int note = (beatCount_ % 4 == 1) ? 76 : 77;
                playShortNote(9, note, (beatCount_ % 4 == 1) ? 115 : 78, 55);
            }
        }
        if (lfoCheck_->isChecked() && nowUs - lastLfoUs_ >= 40000) {
            lastLfoUs_ = nowUs;
            const double phase = static_cast<double>(nowUs) / 1000000.0 * 0.7 * 2.0 * 3.14159265358979323846;
            const int value = static_cast<int>(64.0 + 63.0 * std::sin(phase));
            sendMidi(0xB0, 1, static_cast<quint8>(std::clamp(value, 0, 127)));
            captureEvent(0xB0, 1, value);
        }
    }
};
} // namespace

int main(int argc, char *argv[]) {
    startupTrace("main: entry; next QApplication construction");
    QApplication app(argc, argv);
    startupTrace("main: QApplication constructed");
    ImmediateMouseButtonPressFilter immediateButtonPressFilter;
    app.installEventFilter(&immediateButtonPressFilter);
    QCoreApplication::setOrganizationName(QStringLiteral("Ensembles"));
    QCoreApplication::setApplicationName(QStringLiteral("Ensembles C++"));
    startupTrace("main: before EnsemblesWindow construction");
    EnsemblesWindow window;
    startupTrace("main: EnsemblesWindow constructed");
    window.show();
    if (QCoreApplication::arguments().contains(QStringLiteral("--voice-select-preview"))) {
        QTimer::singleShot(0, &window, [&window] { window.showVoiceSelectPreview(); });
    }
    startupTrace("main: window.show returned; entering Qt event loop");
    return app.exec();
}
